import os
import shutil
import argparse
# import msvcrt

parser = argparse.ArgumentParser(description='find images based on json files')
parser.add_argument('--image_path', default='', type=str, help='images path')
parser.add_argument('--json_path', default='', type=str, help='json path')
parser.add_argument('--save_path', default='', type=str, help='save image to floder')
opt = parser.parse_args()

class FindImage(object):
    def __init__(self, image_path, json_path, save_path):
        self.image_path = image_path
        self.json_path = json_path
        self.save_path = save_path

    def find_image_based_on_json(self):
        json_list = os.listdir(self.json_path)
        i = 0
        for json_name in json_list:
            image_name = json_name.split(".json")[0] + ".png"
            if os.path.isfile(self.image_path + image_name):
                if os.path.exists(self.save_path + image_name):
                    print("=====================")
                    print(image_name + " exist, labels repeat")
                    print("=====================")
                else:
                    shutil.copy(self.image_path + image_name, self.save_path)
                    i += 1
                    print("find " + image_name + " success")
            else:
                print(image_name + " doesn't exist")


if __name__ == "__main__":
    find_image = FindImage(opt.image_path, opt.json_path, opt.save_path)

    if os.path.exists(opt.json_path):
        if os.path.exists(opt.save_path):
            print("=====================")
            print("png floder had exist, continue may cover the images")
            print("=====================")
            # print("Press 'D' to continue")
            # while True:
            #     if ord(msvcrt.getch()) in [68, 100]:
            #         break
            find_image.find_image_based_on_json()
        else:
            os.makedirs(opt.save_path)
            find_image.find_image_based_on_json()
    else:
        print("Error, labels don't exist!")