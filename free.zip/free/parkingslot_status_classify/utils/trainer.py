import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.distributed as dist
from torch.cuda import amp
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils import data
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
import torchvision
import time
import argparse
import numpy as np
import random
import os
import math


def make_optimizer(model, hyp, args):
    pg0, pg1, pg2 = [], [], []  # optimizer parameter groups
    for k, v in model.named_modules():
        if hasattr(v, 'bias') and isinstance(v.bias, nn.Parameter):
            pg2.append(v.bias)  # biases
        if isinstance(v, nn.BatchNorm2d):
            pg0.append(v.weight)  # no decay
        elif hasattr(v, 'weight') and isinstance(v.weight, nn.Parameter):
            pg1.append(v.weight)  # apply decay
    if args.adam:
        optimizer = optim.Adam(pg0, lr=hyp['lr0'], betas=(hyp['momentum'], 0.999))  # adjust beta1 to momentum
    else:
        optimizer = optim.SGD(pg0, lr=hyp['lr0'], momentum=hyp['momentum'], nesterov=True)

    optimizer.add_param_group({'params': pg1, 'weight_decay': hyp['weight_decay']})  # add pg1 with weight_decay
    optimizer.add_param_group({'params': pg2})  # add pg2 (biases)

    if hyp['scheduler'] == 'lamda':
        lf = one_cycle(1, hyp['lrf'], hyp['maxepoch'])  # cosine 1->hyp['lrf']
        scheduler = optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lf)
    else:
        scheduler = optim.lr_scheduler.MultiStepLR(optimizer, milestones=hyp['steps'], gamma=hyp['lrdecay'])
    return optimizer, scheduler


def one_cycle(y1=0.0, y2=1.0, steps=100):
    # lambda function for sinusoidal ramp from y1 to y2
    return lambda x: ((1 - math.cos(x * math.pi / steps)) / 2) * (y2 - y1) + y1


def warmup(n_iter, optimizer, hyp, max_iter):
    xi = [0, max_iter]  # x interp
    # model.gr = np.interp(ni, xi, [0.0, 1.0])  # iou loss ratio (obj_loss = 1.0 or iou)
    for j, x in enumerate(optimizer.param_groups):
        # bias lr falls from 0.1 to lr0, all other lrs rise from 0.0 to lr0
        x['lr'] = np.interp(n_iter, xi, [hyp['warmup_bias_lr'] if j == 2 else 0.0, x['initial_lr']])
        if 'momentum' in x:
            x['momentum'] = np.interp(n_iter, xi, [hyp['warmup_momentum'], hyp['momentum']])


class Trainer(object):
    def __init__(self, net, trainLoader, valLoader, criterion, args, hyp, rank, optimizer=None):
        self.net = net
        self.netname = net.name
        self.loader_train = trainLoader
        self.max_iter = len(self.loader_train)
        self.loader_val = valLoader
        self.criterion = criterion
        self.args = args
        self.hyp = hyp
        self.rank = rank
        self.n_iter = 0

        self.start_epoch = 0
        self.max_epoch = hyp['maxepoch']
        self.max_warmup_iter = min(round(hyp['warmup_epochs'] * len(trainLoader)), 3000)

        if self.rank == 0:
            save_dir = 'runs/' + self.netname
            i = 0
            while os.path.exists(save_dir):
                save_dir = 'runs/' + self.netname + '_%02d' % i
                i += 1
            self.writer = SummaryWriter(save_dir)

        self.optimizer, self.scheduler = make_optimizer(self.net, hyp, args)
        self.min_loss = 1e5

        if args.resume:
            self.resume_train(args)

        # self.net = torch.nn.SyncBatchNorm.convert_sync_batchnorm(self.net)
        # print('Using SyncBatchNorm default')
        self.net = DDP(self.net, device_ids=[rank])

    def run(self):
        for epoch in range(self.start_epoch, self.max_epoch):
            if self.rank == 0:
                print('\n  Start Training Epoch: %03d/%03d' % (epoch, self.max_epoch))
            t0 = time.time()
            # Train
            loss_train = self.train_epoch(epoch)
            # Validation
            loss_val = self.validate_epoch(epoch)
            # Check and save model
            self.save_checkpoint(epoch, loss_val)
            # Take a scheduler step
            self.scheduler.step()

            t1 = time.time()
            if self.rank == 0:
                self.writer.add_scalars('Loss/train-val', {'train_loss': loss_train, 'val_loss': loss_val}, epoch)
            print('one training epoch time ', t1 - t0)
        print('Training completed')

    def train_epoch(self, epoch):
        self.net.train()

        self.loader_train.sampler.set_epoch(epoch)
        loss_train = 0.0
        pbar = tqdm(enumerate(self.loader_train), total=len(self.loader_train))
        for i, batch in pbar:
            if self.n_iter < self.max_warmup_iter:
                warmup(self.n_iter, self.optimizer, self.hyp, self.max_warmup_iter)
            self.optimizer.zero_grad()
            img, truth = self.sample_to_cuda(batch)
            if self.args.half:
                with amp.autocast(enabled=True):
                    pred = self.net(img)
                    loss, loss_tags = self.criterion(pred, truth)
            else:
                pred = self.net(img)
                loss, loss_tags = self.criterion(pred, truth)
            loss *= self.args.worldsize
            loss.backward()
            self.optimizer.step()

            if self.rank == 0:
                for k in loss_tags.keys():
                    self.writer.add_scalar('Loss/%s' % k, loss_tags[k], self.n_iter)
            loss_train += loss_tags['loss']
            self.n_iter += 1
        return loss_train / (i + 1)

    def validate_epoch(self, epoch):
        self.net.eval()
        self.loader_val.sampler.set_epoch(epoch)
        loss_val = 0.0
        pbar = tqdm(enumerate(self.loader_val), total=len(self.loader_val))
        for i, batch in pbar:
            img, truth = self.sample_to_cuda(batch)
            pred = self.net(img)
            loss, loss_tags = self.criterion(pred, truth)
            loss_val += loss_tags['loss']
        return loss_val / (i + 1)

    def sample_to_cuda(self, data):
        if isinstance(data, str):
            return data
        elif isinstance(data, dict):
            return {key: self.sample_to_cuda(data[key]) for key in data.keys()}
        elif isinstance(data, list):
            return [self.sample_to_cuda(val) for val in data]
        else:
            return data.cuda(self.rank)

    def save_checkpoint(self, i, loss_val):
        if self.rank == 0:
            print('Saving weights...')
            net_dict = self.net.module.state_dict()
            state = {
                'net': net_dict,
                'loss': loss_val,
                'epoch': i,
                "optimizer": self.optimizer.state_dict(),
                'args': self.args
            }
            if not os.path.isdir('checkpoint'):
                os.mkdir('checkpoint')
            if (i + 1) % (self.max_epoch // 5) == 0:
                torch.save(state, './checkpoint/%s-%03d.pth' % (self.netname, i))
            if loss_val < self.min_loss:
                torch.save(state, './checkpoint/%s-best.pth' % (self.netname))
                self.min_loss = loss_val
            torch.save(state, './checkpoint/%s-backup.pth' % (self.netname))

    def resume_train(self, args):
        ckpt = torch.load(args.ckpt, map_location='cpu')
        self.net.load_state_dict(ckpt["net"])
        self.optimizer.load_state_dict(ckpt["optimizer"])
        self.start_epoch = ckpt['epoch'] + 1
