import os
import numpy as np
import time
import csv

from lib.utils.common import chinese_to_english
from .make_report import task_metric_map


table_notes = ["table_start", "table_end"]


def abstract(csv_lib_dir, scene_count_info, general_results, scene_results):
    scene_list = ["abstract", "scenes", "all_class"]
    if scene_results:
        scene_names = list(scene_count_info.keys())
        print(scene_names)
        for name in scene_names:
            scene_list.append(chinese_to_english.get(name, name))
    model_names = list(general_results.keys())
    new_model_task = general_results[model_names[0]]["model_path"]
    csvFile2 = open("{}/abstract.csv".format(csv_lib_dir), "w", newline="")
    writer = csv.writer(csvFile2)
    writer.writerow(["abstract", "model", "parking"])
    # writer.writerow(['abstract', 'output', ''])
    # writer.writerow(['abstract', 'baseline_task', ''])
    # writer.writerow(['abstract', 'new_model_task', new_model_task[0]])
    # writer.writerow(['abstract', 'base_line_model_management', ''])
    writer.writerow(scene_list)

    if scene_count_info:
        infos = [["class", "subclass", "num_imgs"]]
        for scene_name in scene_count_info:
            for scene_value in scene_count_info[scene_name]:
                infos.append(
                    [
                        chinese_to_english.get(scene_name, scene_name),
                        chinese_to_english.get(scene_value, scene_value),
                        scene_count_info[scene_name][scene_value],
                    ]
                )

        writer.writerow(["table_start", "fan_chart", "test_set_distribution"])
        for row in range(len(infos)):
            infos[row].insert(0, "test_set_distribution")
            writer.writerow(infos[row])
        writer.writerow(["table_end"])
    csvFile2.close()


def slot_info(general_results):
    model_names = list(general_results.keys())
    metric_names = ["Precision", "Recall", "F1-score"]
    cls_names = ["Only Slot", "With Status", "With Type", "With Status and Type"]

    infos_ = [
        [
            "model_version",
        ],
    ]
    for idx, model_name in enumerate(model_names):
        infos_.append(
            [
                model_name,
            ]
        )

    for i in range(len(cls_names)):
        for j in range(len(metric_names)):
            infos_[0].append(cls_names[i] + ";" + metric_names[j])
            for idx, model_name in enumerate(model_names):
                infos_[idx + 1].append(
                    round(general_results[model_name]["slot"][metric_names[j]][i], 4)
                )
    return infos_


def point_info(general_results, opt, mode="point"):
    if mode == "point":
        cls_names = opt.point_cls
    elif mode == "center":
        cls_names = opt.center_cls
    model_names = list(general_results.keys())
    metric_names = ["Precision", "Recall", "F1-score", "AP"]

    infos_ = [
        ["model_version", "mAP", "tp_offset"],
    ]
    for idx, model_name in enumerate(model_names):
        infos_.append(
            [
                model_name,
                "{:.4f}".format(general_results[model_name][mode]["mAP"]),
                "{:.4f}".format(-general_results[model_name][mode]["tp_offset"]),
            ]
        )

    for i in range(len(cls_names)):
        for j in range(len(metric_names)):
            infos_[0].append(cls_names[i] + ";" + metric_names[j])
            for idx, model_name in enumerate(model_names):
                infos_[idx + 1].append(
                    general_results[model_name][mode][metric_names[j]][i]
                )
    return infos_


def doc_seg_info(results, opt):
    model_names = list(results.keys())
    infos = [
        ["model_version", "mean-iou"],
    ]
    for idx, model_name in enumerate(model_names):
        infos.append([model_name, "{:.4f}".format(results[model_name]["seg"]["miou"])])

    for i in range(opt.n_cats):
        infos[0].append(opt.train_id_map[i])
        for idx, model_name in enumerate(model_names):
            infos[idx + 1].append(results[model_name]["seg"]["ious"][i])
    return infos


def edge_info(results, opt):
    model_names = list(results.keys())
    metric_names_all = [
        "Precision_all",
        "Recall_all",
        "F1_all",
        "Diff_avg_all",
        "Diff_std_all",
    ]
    metric_names = ["Precision", "Recall", "F1", "Diff_avg", "Diff_std"]
    infos = [
        ["model_version", "metric", "dist"],
    ]

    cls_ids = [1, 2, 3, 9]  # pillar, vehicle, curb, free space
    # for i in range(opt.n_cats):
    for i in cls_ids:
        infos[0].append(opt.train_id_map[i])

    for metric_name in metric_names_all:
        for idx, model_name in enumerate(model_names):
            item = []
            item.append(model_name)
            item.append(metric_name)
            item.append("all")
            # for i in range(opt.n_cats):
            for i in cls_ids:
                item.append(round(results[model_name]["edge"][metric_name][i][0], 4))
            infos.append(item)

    dist_heads = []
    for i in range(len(opt.grid_dists) + 1):
        if i == 0:
            dist_heads.append(f"<{opt.grid_dists[i]}")
            continue
        if i == len(opt.grid_dists):
            dist_heads.append(f">{opt.grid_dists[-1]}")
            continue
        dist_heads.append(f"{opt.grid_dists[i-1]}~{opt.grid_dists[i]}")

    for j, dist_head in enumerate(dist_heads):
        for metric_name in metric_names:
            for idx, model_name in enumerate(model_names):
                item = []
                item.append(model_name)
                item.append(metric_name)
                item.append(dist_head)
                # for i in range(opt.n_cats):
                for i in cls_ids:
                    item.append(
                        round(results[model_name]["edge"][metric_name][i][j], 4)
                    )
                infos.append(item)
    return infos


def all_class(csv_lib_dir, general_results, opt):
    csvFile2 = open("{}/all_class.csv".format(csv_lib_dir), "w", newline="")
    writer = csv.writer(csvFile2)
    model_names = list(general_results.keys())

    writer.writerow(["table_start", "table", "speed_info"])
    infos = [
        ["model_version", "batchsize=1 (s)"],
    ]
    for idx, model_name in enumerate(model_names):
        infos.append(
            [model_name, "{:.4f}".format(general_results[model_name]["inference_time"])]
        )
    for row in range(len(infos)):
        infos[row].insert(0, "speed_info")
        writer.writerow(infos[row])
    writer.writerow(["table_end"])

    # slot
    if task_metric_map[opt.task].get("slot", False):
        writer.writerow(
            ["table_start", "table", "slot_result_eval_results_for_all_scenes"]
        )
        slot_infos = slot_info(general_results)
        for row in range(len(slot_infos)):
            slot_infos[row].insert(0, "slot_result_eval_results_for_all_scenes")
            writer.writerow(slot_infos[row])
        writer.writerow(["table_end"])

    # point
    if task_metric_map[opt.task].get("point", False):
        writer.writerow(
            ["table_start", "table", "point_result_eval_results_for_all_scenes"]
        )
        point_infos = point_info(general_results, opt, mode="point")
        for row in range(len(point_infos)):
            point_infos[row].insert(0, "point_result_eval_results_for_all_scenes")
            writer.writerow(point_infos[row])
        writer.writerow(["table_end"])

    # center
    if task_metric_map[opt.task].get("center", False):
        writer.writerow(
            ["table_start", "table", "center_result_eval_results_for_all_scenes"]
        )
        center_infos = point_info(general_results, opt, mode="center")
        for row in range(len(center_infos)):
            center_infos[row].insert(0, "center_result_eval_results_for_all_scenes")
            writer.writerow(center_infos[row])
        writer.writerow(["table_end"])

    # seg
    if task_metric_map[opt.task].get("seg", False):
        writer.writerow(
            ["table_start", "table", "seg_result_eval_results_for_all_scenes"]
        )
        seg_infos = doc_seg_info(general_results, opt)
        for row in range(len(seg_infos)):
            seg_infos[row].insert(0, "seg_result_eval_results_for_all_scenes")
            writer.writerow(seg_infos[row])
        writer.writerow(["table_end"])

    # edge
    if task_metric_map[opt.task].get("edge", False):
        writer.writerow(
            ["table_start", "table", "edge_result_eval_results_for_all_scenes"]
        )
        edge_infos = edge_info(general_results, opt)
        for row in range(len(edge_infos)):
            edge_infos[row].insert(0, "edge_result_eval_results_for_all_scenes")
            writer.writerow(edge_infos[row])
        writer.writerow(["table_end"])


def scene_slot_info(results, name="all"):
    model_names = list(results.keys())

    infos = [["subclass", "model_version", "F1"]]

    scene_values = list(results[model_names[0]][name].keys())
    for scene_value in scene_values:
        for model_name in model_names:
            infos.append(
                [
                    chinese_to_english.get(scene_value, scene_value),
                    model_name,
                    "{:.4f}".format(
                        round(
                            results[model_name][name][scene_value]["slot"]["F1-score"][
                                0
                            ],
                            4,
                        )
                    ),
                ]
            )
    return infos


def scene_point_info(results, mode="point", name="all"):
    model_names = list(results.keys())

    infos = [["subclass", "model_version", "mAP"]]

    scene_values = list(results[model_names[0]][name].keys())
    for scene_value in scene_values:
        for model_name in model_names:
            if type(results[model_name][name][scene_value][mode]["mAP"]) in [
                float,
                np.float32,
                np.float64,
                np.ndarray,
            ]:
                infos.append(
                    [
                        chinese_to_english.get(scene_value, scene_value),
                        model_name,
                        "{:.4f}".format(
                            results[model_name][name][scene_value][mode]["mAP"]
                        ),
                    ]
                )
    return infos


def scene_seg_info(results, opt, name="all"):
    model_names = list(results.keys())
    infos = [["subclass", "model_version", "mean-ious"]]

    scene_values = list(results[model_names[0]][name].keys())
    for scene_value in scene_values:
        for model_name in model_names:
            infos.append(
                [
                    chinese_to_english.get(scene_value, scene_value),
                    model_name,
                    "{:.4f}".format(
                        results[model_name][name][scene_value]["seg"]["miou"]
                    ),
                ]
            )
    return infos


def scene_edge_info(results, opt, name="all"):
    model_names = list(results.keys())
    infos = [["subclass", "model_version", "diff-mean"]]

    scene_values = list(results[model_names[0]][name].keys())
    for scene_value in scene_values:
        for model_name in model_names:
            diff_sum = 0
            count = 0
            for value in results[model_name][name][scene_value]["edge"]["Diff_avg_all"][
                :, 0
            ]:
                if value >= 0:
                    diff_sum += value
                    count += 1
            diff_mean = diff_sum / (count + 0.001)
            infos.append(
                [
                    chinese_to_english.get(scene_value, scene_value),
                    model_name,
                    "{:.4f}".format(round(diff_mean, 4)),
                ]
            )
    return infos


def scene(results, csv_dir, opt, scene_name):
    csvFile2 = open(csv_dir, "w", newline="")
    writer = csv.writer(csvFile2)

    # slot
    if task_metric_map[opt.task].get("slot", False):
        slot_info = scene_slot_info(results, name=scene_name)
        writer.writerow(
            [
                "table_start",
                "chart",
                "slot_result",
                "subclass",
                "F1",
                "(0,1)",
                "model_version",
            ]
        )
        for row in range(len(slot_info)):
            slot_info[row].insert(0, "slot_result")
            writer.writerow(slot_info[row])
        writer.writerow(["table_end"])

    # point
    if task_metric_map[opt.task].get("point", False):
        point_info = scene_point_info(results, mode="point", name=scene_name)
        writer.writerow(
            [
                "table_start",
                "chart",
                "point_result",
                "subclass",
                "mAP",
                "(0,1)",
                "model_version",
            ]
        )
        for row in range(len(point_info)):
            point_info[row].insert(0, "point_result")
            writer.writerow(point_info[row])
        writer.writerow(["table_end"])

    # center
    if task_metric_map[opt.task].get("center", False):
        writer.writerow(
            [
                "table_start",
                "chart",
                "center_result",
                "subclass",
                "mAP",
                "(0,1)",
                "model_version",
            ]
        )
        center_info = scene_point_info(results, mode="center", name=scene_name)
        for row in range(len(center_info)):
            center_info[row].insert(0, "center_result")
            writer.writerow(center_info[row])
        writer.writerow(["table_end"])

    # seg
    if task_metric_map[opt.task].get("seg", False):
        writer.writerow(
            [
                "table_start",
                "chart",
                "seg_result ",
                "subclass",
                "mean-ious",
                "(0,1)",
                "model_version",
            ]
        )
        seg = scene_seg_info(results, opt, name=scene_name)
        for row in range(len(seg)):
            seg[row].insert(0, "seg_result ")
            writer.writerow(seg[row])
        writer.writerow(["table_end"])

    # edge
    if task_metric_map[opt.task].get("edge", False):
        writer.writerow(
            [
                "table_start",
                "chart",
                "edge_result ",
                "subclass",
                "diff-mean",
                "(0,1)",
                "model_version",
            ]
        )
        edge = scene_edge_info(results, opt, name=scene_name)
        for row in range(len(edge)):
            edge[row].insert(0, "edge_result ")
            writer.writerow(edge[row])
        writer.writerow(["table_end"])

    csvFile2.close()


def generate_csv(report_path, general_results, scene_results, scene_count_info, opt):

    csv_lib_dir = os.path.join(report_path, "csv")
    if not os.path.exists(csv_lib_dir):
        os.makedirs(csv_lib_dir)
    # create abstract.csv
    abstract(csv_lib_dir, scene_count_info, general_results, scene_results)

    # create all_class.csv
    all_class(csv_lib_dir, general_results, opt)

    if scene_results:
        scene_names = list(scene_count_info.keys())
        for scene_name in scene_names:
            csv_dir = os.path.join(
                csv_lib_dir,
                "{}.csv".format(chinese_to_english.get(scene_name, scene_name)),
            )
            # create each scene csv
            scene(scene_results, csv_dir, opt, scene_name)


if __name__ == "__main__":
    pass
