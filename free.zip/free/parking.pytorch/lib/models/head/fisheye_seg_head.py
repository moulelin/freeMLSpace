import torch
from torch import nn

from lib.models.head.base_head import SegmentHead, chan_infos


class FishEyeSegHead(nn.Module):
    def __init__(self, opt, backbone, decoder, mode="train"):
        super(FishEyeSegHead, self).__init__()
        self.mode = mode
        self.opt = opt
        self.backbone = backbone
        self.name = "fisheye_seg"
        n_classes = self.opt.n_cats

        base_chan = chan_infos[self.opt.backbone]

        self.seghead = SegmentHead(
            base_chan * 8, 256, n_classes, up_factor=8, aux=False
        )
        # self.freespacehead = SegmentHead(
        #     base_chan * 8, 256, 2, up_factor=8, aux=False
        # )
        if self.mode in ["train", "val"]:
            if "lite" in self.opt.backbone:
                self.aux2 = SegmentHead(base_chan, 128, n_classes, up_factor=0.5)
                self.aux3 = SegmentHead(base_chan, 128, n_classes, up_factor=1)
                self.aux4 = SegmentHead(base_chan * 2, 128, n_classes, up_factor=2)
                self.aux5 = SegmentHead(base_chan * 4, 128, n_classes, up_factor=4)
            else:
                self.aux2 = SegmentHead(base_chan, 128, n_classes, up_factor=0.5)
                self.aux3 = SegmentHead(base_chan * 2, 128, n_classes, up_factor=1)
                self.aux4 = SegmentHead(base_chan * 4, 128, n_classes, up_factor=2)
                self.aux5 = SegmentHead(base_chan * 8, 128, n_classes, up_factor=4)
        else:
            self.decoder = decoder
        self.init_weights()

    def forward(self, x):
        feat_dict = self.backbone(x)

        logits = self.seghead(feat_dict["feat"])
        # freespace_logits = self.freespacehead(feat_dict["feat"])
        if self.mode in ["train", "val"]:
            logits_aux2 = self.aux2(feat_dict["feat2"])
            logits_aux3 = self.aux3(feat_dict["feat3"])
            logits_aux4 = self.aux4(feat_dict["feat4"])
            logits_aux5 = self.aux5(feat_dict["feat5"])
            return {
                "logits": logits,
                "logits_aux2": logits_aux2,
                "logits_aux3": logits_aux3,
                "logits_aux4": logits_aux4,
                "logits_aux5": logits_aux5,
                # "freespace_logits": freespace_logits,
            }
        else:
            # return self.decoder.run(logits, freespace_logits)
            return self.decoder.run(logits)

    def init_weights(self):
        for name, module in self.named_modules():
            if isinstance(module, (nn.Conv2d, nn.Linear)):
                # nn.init.kaiming_normal_(module.weight, mode='fan_out')
                continue
            elif isinstance(module, nn.modules.batchnorm._BatchNorm):
                if hasattr(module, "last_bn") and module.last_bn:
                    nn.init.zeros_(module.weight)
                else:
                    nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)
        self.load_pretrain()

    def load_pretrain(self):
        if self.opt.head_pretrain_path:
            print("load head pretrain model: ", self.opt.head_pretrain_path)
            state_dict = torch.load(self.opt.head_pretrain_path, map_location="cpu")
            if "net" in state_dict:
                state_dict = state_dict["net"]

            # filter_keys = []
            # for key in state_dict:
            #     if "seghead" in key:
            #         filter_keys.append(key)
            #     if "aux" in key:
            #         filter_keys.append(key)

            # for key in filter_keys:
            #     print(key)
            #     state_dict.pop(key)

            self.load_state_dict(state_dict, strict=False)
            print("finished load")
        else:
            print("no head pretrain model!!!")

    def get_params(self):
        def add_param_to_list(mod, wd_params, nowd_params):
            for param in mod.parameters():
                if param.dim() == 1:
                    nowd_params.append(param)
                elif param.dim() == 4:
                    wd_params.append(param)
                else:
                    print(name)

        (
            wd_params,
            nowd_params,
            lr_mul10_wd_params,
            lr_mul10_nowd_params,
            lr_mul2_wd_params,
            lr_mul2_nowd_params,
        ) = ([], [], [], [], [], [])
        for name, child in self.named_children():
            if "head" in name or "aux" in name:
                if "center" in name or "point" in name:
                    add_param_to_list(child, lr_mul2_wd_params, lr_mul2_nowd_params)
                else:
                    add_param_to_list(child, lr_mul10_wd_params, lr_mul10_nowd_params)
            else:
                add_param_to_list(child, wd_params, nowd_params)
        return (
            wd_params,
            nowd_params,
            lr_mul10_wd_params,
            lr_mul10_nowd_params,
            lr_mul2_wd_params,
            lr_mul2_nowd_params,
        )
