import argparse
from tabulate import tabulate

import torch
from torch.utils import data

from lib.datasets.dataset_factory import get_dataset
from lib.models.model_factory import create_model, creat_decoder
from lib.evaluate.evaluator_factory import create_evaluator
from lib.utils.common import (
    init_opt,
    get_scene_count_info,
    get_scene_infos_list_from_test_dict,
    train_id_to_name_map,
)
from tools.pth_infer import PTHModule


@torch.no_grad()
def eval_model(opt, net, decoder, valset):
    loader_val = data.DataLoader(
        valset,
        batch_size=opt.val_batch,
        shuffle=False,
        num_workers=opt.workers,
        pin_memory=True,
        drop_last=True,
    )

    eval_func = create_evaluator(opt, decoder)
    eval_results, scene_results = eval_func(net, loader_val)

    # point metric
    if "point" in eval_results:
        table_point_header = ["Class", "Precision", "Recall", "F1-score", "AP"]
        point_results = eval_results["point"]
        table_point_data = [
            (
                "Entry",
                point_results["Precision"][0],
                point_results["Recall"][0],
                point_results["F1-score"][0],
                point_results["AP"][0],
            ),
            (
                "End",
                point_results["Precision"][1],
                point_results["Recall"][1],
                point_results["F1-score"][1],
                point_results["AP"][1],
            ),
            ("mAP: ", point_results["mAP"]),
            ("tp_offset: ", point_results["tp_offset"]),
        ]
        print(tabulate(table_point_data, headers=table_point_header, tablefmt="grid"))
        print("\n")

    # center metric
    if "center" in eval_results:
        table_center_header = ["Class", "Precision", "Recall", "F1-score", "AP"]
        center_results = eval_results["center"]
        table_center_data = [
            (
                "Empty",
                center_results["Precision"][0],
                center_results["Recall"][0],
                center_results["F1-score"][0],
                center_results["AP"][0],
            ),
            (
                "Occupied",
                center_results["Precision"][1],
                center_results["Recall"][1],
                center_results["F1-score"][1],
                center_results["AP"][1],
            ),
            ("mAP: ", center_results["mAP"]),
            ("tp_offset: ", center_results["tp_offset"]),
        ]
        if "angle_diff" in center_results:
            table_center_data.append(("angle_diff: ", center_results["angle_diff"]))
        if "angle_acc" in center_results:
            table_center_data.append(("angle_acc: ", center_results["angle_acc"]))
        print(tabulate(table_center_data, headers=table_center_header, tablefmt="grid"))
        print("\n")

    # seg metric
    if "seg" in eval_results:
        table_iou_data = []
        table_iou_header = ["Class", "Iou"]
        seg_results = eval_results["seg"]

        train_id_map = train_id_to_name_map(valset.labels_info)
        for i in range(opt.n_cats):
            table_iou_data.append([train_id_map[i], seg_results["ious"][i]])
        table_iou_data.append(["mIOU: ", seg_results["miou"]])
        print(tabulate(table_iou_data, headers=table_iou_header, tablefmt="grid"))

    # cls metric
    if "cls" in eval_results:
        table_cls_data = []
        table_cls_header = ["Class", "num", "Precision", "Recall", "F1"]
        cls_results = eval_results["cls"]
        for i, cls_name in enumerate(opt.slot_type):
            table_cls_data.append(
                [
                    cls_name,
                    cls_results["cls_num"][i],
                    cls_results["precision"][i],
                    cls_results["recall"][i],
                    cls_results["f1"][i],
                ]
            )
        print(tabulate(table_cls_data, headers=table_cls_header, tablefmt="grid"))

    return eval_results, scene_results


def evaluate(opt):

    test_datasets = (
        eval(opt.test_datasets)
        if type(opt.train_datasets) == str
        else opt.test_datasets
    )

    if opt.scene:
        scene_infos_list = get_scene_infos_list_from_test_dict(
            opt.dataset_root, test_datasets
        )
        scene_count_info = get_scene_count_info(
            scene_infos_list, filter_keys=opt.filter_keys
        )
    else:
        scene_infos_list = []
        scene_count_info = {}
    print(scene_count_info)
    opt.scene_infos_list = scene_infos_list

    torch.cuda.init()

    # creat model
    net = PTHModule(opt.pth, opt)

    # creat decoder
    decoder = creat_decoder(opt)

    # creat dataset
    Dataset = get_dataset(opt.task)
    valset = Dataset(opt, "val")

    cur_results, scene_results = eval_model(opt, net, decoder, valset)


def get_parse():
    parser = argparse.ArgumentParser(description="Parking PyTorch Test On Imgs For Vis")
    parser.add_argument("--config", default="", type=str, help="path to config")
    parser.add_argument(
        "--test_datasets", default="", type=str, help="str of dict: path to test txt"
    )
    parser.add_argument(
        "--dataset_root",
        default="/data/perception/datasets",
        type=str,
        help="path to origin data",
    )
    parser.add_argument(
        "--preprocess_root",
        default="/proc_data/perception/datasets",
        type=str,
        help="path to preprocess data",
    )
    parser.add_argument("--pth", default="", type=str, help="path to model")
    parser.add_argument("--onnx", action="store_true", help="decode for onnx, trt")
    parser.add_argument("--scene", action="store_true", help="decode for onnx, trt")
    return parser


if __name__ == "__main__":

    opt = get_parse().parse_args()
    init_opt(opt)
    opt.val_batch = 1
    opt.filter_keys = ["unknown", "NULL", "特殊车位线", "严重磨损"]
    print(opt)

    evaluate(opt)
