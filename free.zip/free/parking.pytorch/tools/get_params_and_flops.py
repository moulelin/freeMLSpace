import argparse
import sys

import torch

sys.path.insert(0, "../")
from lib.models.model_factory import create_model
from lib.utils.common import init_opt

from torchstat import stat


def get_model(opt):
    print("initializing network...")
    model = create_model(opt, "pred")
    net = model.eval()
    stat(net, (3, 800, 800))
    return net


def main(opt):
    net = get_model(opt)


def get_parse():
    parser = argparse.ArgumentParser(description="Parking PyTorch Test On Imgs For Vis")
    parser.add_argument("--config", default="", type=str, help="path to config")
    return parser


if __name__ == "__main__":

    opt = get_parse().parse_args()
    init_opt(opt)
    opt.val_batch = 1
    opt.onnx = 1
    print(opt)

    main(opt)
