import torch
from torch.utils import data
from model.parkingslotstatus import ParkingSlotStatusNet
from dataset.parkingslotstatus_dataset import ParkingSlotStatusDataset
import os
import numpy as np
from tqdm import tqdm
import argparse
from torchvision import transforms as T
import os
import cv2
from PIL import Image, ImageDraw

parser = argparse.ArgumentParser(description='PyTorch ParkingSlotClsNet Testing')
parser.add_argument('--pth', default='checkpoint/ParkingSlotStatus-best.pth', type=str, help='model ckpt')
parser.add_argument('--W', default=64, type=int, help='input width')
parser.add_argument('--H', default=64, type=int, help='input height')
parser.add_argument('--onnx', default=0, type=int, help='output onnx')
parser.add_argument('--batch', default=1, type=int, help='batch size')
parser.add_argument('--datadir', default='', type=str, help='detection dataset dir')
parser.add_argument('--show', default=1, type=int, help='show result with image')
args = parser.parse_args()

status_names = ['occupied', 'empty']
colors = [(0, 0, 255), (0, 255, 0)]

transform = T.Compose([T.ToTensor()])

net = ParkingSlotStatusNet(args.W, args.H, status_num=2)
checkpoint = torch.load(args.pth)
net.load_state_dict(checkpoint['net'])
net = net.cuda().eval()

with open(os.path.join(args.datadir, 'val_list.txt')) as f:
    for img_path in tqdm(f.readlines()):
        img_show = cv2.imread(os.path.join(args.datadir, img_path.strip()))
        img_ori = Image.open(os.path.join(args.datadir, img_path.strip()))
        h, w = img_ori.size
        l = max(w, h)
        scaled_img = Image.new('RGB', (l, l))
        x0 = (l - w) // 2
        y0 = (l - h) // 2
        scaled_img.paste(img_ori, (x0, y0))
        img = scaled_img.resize((args.W, args.H))
        image = transform(img)
        image = image.cuda().unsqueeze(0)
        pred = net(image)
        _, status_pred = torch.max(pred, dim=1)
        status_pred_cpu = status_pred.cpu()
        cv2.rectangle(img_show, (0, 0), (h, w), colors[status_pred_cpu[0]], 4)
        cv2.imshow('img_show', img_show)
        cv2.waitKey(2000)



