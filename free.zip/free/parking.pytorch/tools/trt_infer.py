import pycuda.driver as cuda
import pycuda.autoinit
import numpy as np
import tensorrt as trt


class HostDeviceMem(object):
    def __init__(self, host_mem, device_mem):
        self.host = host_mem
        self.device = device_mem

    def __str__(self):
        return "Host:\n" + str(self.host) + "\nDevice:\n" + str(self.device)

    def __repr__(self):
        return self.__str__()


class TRTModule:
    def __init__(self, model_path):
        TRT_LOGGER = trt.Logger()
        with open(model_path, "rb") as f, trt.Runtime(TRT_LOGGER) as runtime:
            self._engine = runtime.deserialize_cuda_engine(f.read())

        self._context = self._engine.create_execution_context()
        self._inputs = []
        self._outputs = []
        self._bindings = []
        self._stream = cuda.Stream()
        self._allocate_buffers()

        self._model_type = "trt"

    @property
    def model_type(self):
        return self._model_type

    def _allocate_buffers(self):
        for binding in self._engine:
            size = (
                trt.volume(self._engine.get_binding_shape(binding))
                * self._engine.max_batch_size
            )
            dtype = trt.nptype(self._engine.get_binding_dtype(binding))
            # Allocate host and device buffers
            host_mem = cuda.pagelocked_empty(size, dtype)
            device_mem = cuda.mem_alloc(host_mem.nbytes)
            # Append the device buffer to device bindings.
            self._bindings.append(int(device_mem))
            # Append to the appropriate list.
            if self._engine.binding_is_input(binding):
                self._inputs.append(HostDeviceMem(host_mem, device_mem))
            else:
                self._outputs.append(HostDeviceMem(host_mem, device_mem))

    def _do_inference_v2(self):
        # Transfer input data to the GPU.
        [
            cuda.memcpy_htod_async(inp.device, inp.host, self._stream)
            for inp in self._inputs
        ]
        # Run inference.
        self._context.execute_async_v2(
            bindings=self._bindings, stream_handle=self._stream.handle
        )
        # Transfer predictions back from the GPU.
        [
            cuda.memcpy_dtoh_async(out.host, out.device, self._stream)
            for out in self._outputs
        ]
        # Synchronize the stream
        self._stream.synchronize()

    def inference(self, tensor1, tensor2):
        self._inputs[0].host = tensor1
        self._inputs[1].host = tensor2
        # 开始推理
        self._do_inference_v2()
        # Return only the host outputs.
        return [out.host for out in self._outputs]


if __name__ == "__main__":

    model_path = "/media/zeekr/zdrive/code/parking/parking.pytorch/trt/bisenetv2_zeekr_seg-best_800x800_1.trt"

    trt_module = TRTModule(model_path)

    image = np.random.rand(1, 3, 800, 800).astype("float32")
    # 开始推理
    trt_outputs = trt_module.inference(image)
    print(trt_outputs)
