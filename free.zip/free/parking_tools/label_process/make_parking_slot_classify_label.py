import os
import cv2
import numpy as np
import json
import argparse
from tqdm import tqdm
import random


parser = argparse.ArgumentParser(description='make segmentation label')
parser.add_argument('--ori_dir', default='', type=str, help='original image dir')
parser.add_argument('--dst_dir', default='', type=str, help='training dataset dir')
parser.add_argument('--pad_size', default=5, type=int, help='thickness of slot line')
parser.add_argument('--split_ratio', default=0.85, type=float, help='training dataset dir')
opt = parser.parse_args()


class MakeClassifyLabel(object):
    def __init__(self, opt):
        self.ori_dir = opt.ori_dir
        self.dst_dir = opt.dst_dir
        self.pad_size = opt.pad_size
        self.split_ratio = opt.split_ratio
        self.w = 800
        self.h = 800
        if not os.path.isdir(self.dst_dir):
            os.makedirs(self.dst_dir)

    def crop_slot(self, result, img):
        corner = np.array(result['corner_points']).astype(np.int32)
        x1, y1 = corner[:, 0].min() - self.pad_size, corner[:, 1].min() - self.pad_size
        x2, y2 = corner[:, 0].max() + self.pad_size, corner[:, 1].max() + self.pad_size
        x1, y1, x2, y2 = np.maximum(np.array([x1, y1, x2, y2]), 0)
        cropped_img = img[y1:y2, x1:x2]
        return cropped_img
        # cv2.imshow('mask', croped_img)
        # cv2.waitKey(1000)

    def make_train_val_list(self):
        scenes = os.listdir(os.path.join(self.dst_dir, 'image'))
        print("make train val list")
        for scene in scenes:
            scene_path = os.path.join(self.dst_dir, 'image', scene)
            images = os.listdir(scene_path)
            split_number = len(images) * self.split_ratio
            train_images = random.sample(images, int(split_number))
            test_images = [image for image in images if image not in train_images]
            print('The number of train images is : ' + str(len(train_images)) + '\n'
                  + 'The number of test images is : ' + str(len(test_images)) + '\n')
            with open(os.path.join(self.dst_dir, 'train_list.txt'), 'a') as f:
                for image in train_images:
                    f.write(os.path.join("image", scene, image) + '\n')

            with open(os.path.join(self.dst_dir, 'val_list.txt'), 'a') as f:
                for image in test_images:
                    f.write(os.path.join("image", scene, image) + '\n')

    def make_label(self):
        print("make train val labels")
        for sence in os.listdir(self.ori_dir):
            label_dir = os.path.join(self.ori_dir, sence, 'json')
            image_dir = os.path.join(self.ori_dir, sence, 'png')
            for label_json in tqdm(os.listdir(label_dir)):
                img = cv2.imread(os.path.join(image_dir, label_json.replace('.json', '.png')))
                with open(os.path.join(label_dir, label_json)) as f:
                    raw_label = json.load(f)
                    num_index = 0
                    for result in raw_label['results']:
                        obj = {}
                        if 'corner_points' in result.keys():
                            img_cropped = self.crop_slot(result, img)
                            status = result['status']
                            type = result['type']
                            obj['status'] = status
                            obj['type'] = type

                            img_save_dir = os.path.join(self.dst_dir, 'image', sence)
                            label_save_dir = os.path.join(self.dst_dir, 'label', sence)
                            if not os.path.isdir(img_save_dir):
                                os.makedirs(img_save_dir)
                            if not os.path.isdir(label_save_dir):
                                os.makedirs(label_save_dir)

                            img_name = label_json.replace('.json', '_' + str(num_index) + '.png')
                            label_name = img_name.replace('png', 'json')
                            cv2.imwrite(os.path.join(img_save_dir, img_name), img_cropped)
                            obj_json = json.dumps(obj)
                            with open(os.path.join(label_save_dir, label_name), 'w') as f2:
                                f2.write(obj_json)
                        num_index += 1


if __name__ == '__main__':
    make_classify_label = MakeClassifyLabel(opt)
    make_classify_label.make_label()
    make_classify_label.make_train_val_list()
