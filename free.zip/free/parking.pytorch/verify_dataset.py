import argparse
import cv2

from lib.datasets.dataset_factory import get_dataset
from lib.utils.common import init_opt


def vis_dataset(opt):
    Dataset = get_dataset(opt.task)
    trainset = Dataset(opt, "val")
    for index in range(trainset.__len__()):
        combined_img = trainset.verify(index)
        cv2.imshow("combined_img", combined_img)
        key = cv2.waitKey(0)
        if key == 27:
            exit()
        cv2.destroyAllWindows()


def get_parse():
    parser = argparse.ArgumentParser(description="Parking PyTorch Vis Datasets")
    parser.add_argument("--config", default="", type=str, help="path to config")
    parser.add_argument(
        "--train_datasets", default="", type=str, help="str of dict: path to train txt"
    )
    parser.add_argument(
        "--test_datasets", default="", type=str, help="str of dict: path to test txt"
    )
    parser.add_argument(
        "--dataset_root",
        default="",
        type=str,
        help="path to origin data",
    )
    return parser


if __name__ == "__main__":

    opt = get_parse().parse_args()
    init_opt(opt)
    print(opt)
    vis_dataset(opt)
