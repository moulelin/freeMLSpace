import os
import cv2
import numpy as np
import json
import argparse
from tqdm import tqdm

import sys

sys.path.insert(0, "../")
from lib.datasets.dataset.lidar import labels_info


parser = argparse.ArgumentParser(description="Make Lidar Segmentation Label")
parser.add_argument("--is_preprocess", default=1, type=int, help="is generate label")
parser.add_argument(
    "--train_datasets",
    default="{}",
    type=str,
    help="str of dict include path to train txt",
)
parser.add_argument(
    "--test_datasets",
    default="{}",
    type=str,
    help="str of dict include path to test txt",
)
parser.add_argument(
    "--dataset_root",
    default="/data/perception/datasets",
    type=str,
    help="path to origin data",
)
opt = parser.parse_args()

color_infos = {}
id_infos = {}
for info in labels_info:
    name = info["name"]
    color_infos[name] = info["color"]
    id_infos[name] = info["id"]


def read_pcd(file_path):
    points = []
    with open(file_path) as f:
        start = False
        for line in f.readlines():
            line_list = line.strip().split(" ")
            if line_list[0] == "DATA":
                start = True
                continue
            if start:
                line_array = np.array(line_list).astype(np.float32)
                line_array[3] /= 255.0
                points.append(line_array)
    return np.asarray(points)


def read_json(file_path):
    with open(file_path, "r") as f:
        str_f = f.read()
        json_f = json.loads(str_f)
    #         print(json_f)
    return json_f


class MakeSegTrainLabel(object):
    def __init__(self, opt):
        self.train_list_dict = eval(opt.train_datasets)
        self.test_list_dict = eval(opt.test_datasets)
        self.dataset_path = opt.dataset_root
        self.w = 2048
        self.h = 64

    def get_data_list(self):
        pcd_list = []
        json_list = []
        bin_list = []
        lable_list = []

        # train
        file_list = []
        for key in self.train_list_dict:
            with open(self.train_list_dict[key], "r") as f:
                lines = f.read().splitlines()
                file_list.extend(lines)
        # rm repeat
        lines = list(dict.fromkeys(file_list))
        print("train data num: ", len(lines))

        for line in lines:
            pcd_sub_path = line
            json_sub_path = line.replace("pcd", "json").replace("pcd", "json")
            bin_sub_path = line.replace("pcd", "bin").replace("pcd", "bin")
            label_sub_path = line.replace("pcd", "label").replace("pcd", "label")
            pcd_list.append(os.path.join(self.dataset_path, pcd_sub_path))
            json_list.append(os.path.join(self.dataset_path, json_sub_path))
            bin_list.append(os.path.join(self.dataset_path, bin_sub_path))
            lable_list.append(os.path.join(self.dataset_path, label_sub_path))

        # test
        # train
        file_list = []
        for key in self.test_list_dict:
            with open(self.test_list_dict[key], "r") as f:
                lines = f.read().splitlines()
                file_list.extend(lines)
        # rm repeat
        lines = list(dict.fromkeys(file_list))
        print("test data num: ", len(lines))

        for line in lines:
            pcd_sub_path = line
            json_sub_path = line.replace("pcd", "json")
            bin_sub_path = line.replace("pcd", "bin")
            label_sub_path = line.replace("pcd", "label")
            pcd_list.append(os.path.join(self.dataset_path, pcd_sub_path))
            json_list.append(os.path.join(self.dataset_path, json_sub_path))
            bin_list.append(os.path.join(self.dataset_path, bin_sub_path))
            lable_list.append(os.path.join(self.dataset_path, label_sub_path))

        return pcd_list, json_list, bin_list, lable_list

    def make_label(self):
        pcd_list, json_list, bin_list, lable_list = self.get_data_list()

        count = 0
        for pcd_path, json_path, bin_path, label_path in tqdm(
            zip(pcd_list, json_list, bin_list, lable_list)
        ):
            if os.path.exists(label_path):
                continue

            count += 1

            label_dir = os.path.dirname(label_path)
            if not os.path.exists(label_dir):
                os.makedirs(label_dir)

            bin_dir = os.path.dirname(bin_path)
            if not os.path.exists(bin_dir):
                os.makedirs(bin_dir)

            pcd_data = read_pcd(pcd_path)
            json_data = read_json(json_path)

            bin_data = pcd_data[:, :4]
            label_data = np.array(json_data["results"]).astype(np.int32)

            bin_data.tofile(bin_path)
            label_data.tofile(label_path)

        print("finish preprocess data, preprocess new data {}".format(count))


if __name__ == "__main__":
    if int(opt.is_preprocess):
        make_seg_train_label = MakeSegTrainLabel(opt)
        make_seg_train_label.make_label()
    else:
        print("skip preprocess")
