import torch
import torch.nn as nn
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
import torch.multiprocessing as mp
from torch.utils import data
import argparse
import numpy as np
import yaml

from dataset.nuscenes import BEVNuscenesLoader
from model.ipmdet import IpmDet
from utils.trainer import Trainer

parser = argparse.ArgumentParser(description='PyTorch DD3D Training')
parser.add_argument('--resume', '-r', action='store_true', help='resume from checkpoint')
parser.add_argument('--ckpt', default='checkpoint/ipmdet-backup.pth', type=str, help='resume checkpoint')
parser.add_argument('--exp_id', type=str, required=True, help='experiment short description')
parser.add_argument('--output_dir', default='./runs', type=str, help='checkpoint and log output dir')
parser.add_argument('--hyp', default='config/hyp.ipmdet.nusc.yaml', type=str, help='learning rate')
parser.add_argument('--half', default=0, type=int, help='using half precision training')
parser.add_argument('--adam', default=1, type=int, help='use adam optimizer')
parser.add_argument('--workers', default=4, type=int, help='image height')
parser.add_argument('--batch', default=1, type=int, help='batch size')
parser.add_argument('--detdir', default='/media/tianming/data/nuScenes_v1.0-mini/', type=str, help='detection dataset dir')   # _v1.0-mini
parser.add_argument('--disturl', default='tcp://localhost:23456', type=str, help='torch distributed node0 IP and port')
parser.add_argument('--worldsize', default=1, type=int, help='the number of machines for distributed training')
parser.add_argument('--rank', default=0, type=int, help='the order of machines for distributed training')
args = parser.parse_args()

def setup(gpu_rank, world_size):
    ngpus_per_node = torch.cuda.device_count()
    args.worldsize = ngpus_per_node * args.worldsize
    args.rank = args.rank * ngpus_per_node + gpu_rank
    dist.init_process_group("nccl", init_method=args.disturl, rank=args.rank, world_size=args.worldsize)
    print('rank/total: %d/%d'%(args.rank, args.worldsize))

def cleanup():
    dist.destroy_process_group()

def dist_train(rank, world_size):
    setup(rank, world_size)

    with open(args.hyp) as f:
        hyp = yaml.load(f, Loader=yaml.SafeLoader)  # load hyps
    grid_conf = {
        'xbound': hyp['xbound'],
        'ybound': hyp['ybound'],
        'zbound': hyp['zbound']
    }

    # if rank == 0:
    #     print('Start debug...')
    #     import ptvsd
    #     ptvsd.enable_attach(address=('localhost', 5678))
    #     ptvsd.wait_for_attach()

    trainset = BEVNuscenesLoader(args.detdir, None, hyp['width'], hyp['height'], grid_conf,
                                 hyp['image_aug'], hyp['bev_aug'])
    valset = BEVNuscenesLoader(args.detdir, trainset.nusc, hyp['width'], hyp['height'], grid_conf,
                               hyp['image_aug'], hyp['bev_aug'], mode='val')
    train_sampler = torch.utils.data.distributed.DistributedSampler(trainset)
    val_sampler = torch.utils.data.distributed.DistributedSampler(valset)
    loader_train = data.DataLoader(trainset, batch_size=args.batch, shuffle=False, \
                    num_workers=args.workers, pin_memory=True, sampler=train_sampler, drop_last=True)
    loader_val = data.DataLoader(valset, batch_size=args.batch, shuffle=False, \
                    num_workers=args.workers, pin_memory=True, sampler=val_sampler, drop_last=True)

    print('initializing network...')
    network = IpmDet(hyp)
    torch.backends.cudnn.benchmark = True
    net = network.cuda(rank)
    # criterion
    # criterion = SimOTALoss(10, grid_conf, w_obj=hyp['w_obj'], w_cls=hyp['w_cls'], w_box=hyp['w_box'], rank=rank).cuda(rank)
    dist.barrier() # sync point

    trainer = Trainer(net, loader_train, loader_val, args, hyp, rank, random_resize=hyp['random_resize'])
    trainer.run()
    # trainer.debug()

    cleanup()

if __name__ == '__main__':
    ngpus = torch.cuda.device_count()
    mp.spawn(dist_train, args=(ngpus,), nprocs=ngpus, join=True)