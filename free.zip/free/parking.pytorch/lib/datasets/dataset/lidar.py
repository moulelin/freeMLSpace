import numpy as np
import os

from .base_dataset import BaseDataset


# labels_info = [
#     {"name": "unlabeled", "id": 0, "color": [0, 0, 0], "train_id": 0},  # ignore
#     {"name": "VRU", "id": 1, "color": [0, 97, 255], "train_id": 1},
#     {"name": "tricycle", "id": 2, "color": [226, 43, 138], "train_id": 1},
#     {"name": "Car", "id": 3, "color": [255, 0, 255], "train_id": 2},
#     {"name": "truck", "id": 4, "color": [31, 23, 176], "train_id": 2},
#     {"name": "Ground", "id": 5, "color": [192, 192, 192], "train_id": 3},
#     {"name": "pedestrian", "id": 6, "color": [143, 143, 188], "train_id": 1},
#     {"name": "pillar", "id": 7, "color": [255, 0, 0], "train_id": 9},
#     {"name": "sidewalk", "id": 8, "color": [128, 148, 163], "train_id": 9},
#     {"name": "Vegetation", "id": 9, "color": [0, 252, 124], "train_id": 10},
#     {"name": "high-vegetation", "id": 10, "color": [34, 139, 34], "train_id": 10},
#     {"name": "universal obstacle", "id": 11, "color": [0, 255, 255], "train_id": 4},
#     {"name": "building", "id": 12, "color": [140, 230, 240], "train_id": 9},
#     {"name": "terrain", "id": 13, "color": [255, 255, 0], "train_id": 0}, # ignore
#     {"name": "mist", "id": 14, "color": [208, 224, 64], "train_id": 0}, # ignore
#     {"name": "fence", "id": 15, "color": [84, 46, 8], "train_id": 8},
#     {"name": "potholes", "id": 16, "color": [179, 222, 245], "train_id": 3},
#     {"name": "outlier", "id": 17, "color": [0, 0, 255], "train_id": 11},
#     {"name": "other", "id": 18, "color": [240, 225, 240], "train_id": 9},
#     {"name": "animal", "id": 19, "color": [214, 112, 218], "train_id": 4},
#     {"name": "curb", "id": 20, "color": [225, 105, 65], "train_id": 6},
#     {"name": "pillor2", "id": 21, "color": [96, 164, 244], "train_id": 7},
#     {"name": "mirror", "id": 22, "color": [225, 225, 225], "train_id": 11},
# ]

labels_info = [
    # {"name": "unlabeled", "id": 0, "color": [0, 0, 0], "train_id": 0},
    {"name": "VRU", "id": 1, "color": [0, 97, 255], "train_id": 0},
    {"name": "Car", "id": 2, "color": [226, 43, 138], "train_id": 1},
    {"name": "Ground", "id": 3, "color": [192, 192, 192], "train_id": 2},
    {"name": "Other obstacle", "id": 4, "color": [143, 143, 188], "train_id": 3},
    {"name": "Terrain", "id": 5, "color": [255, 0, 0], "train_id": 4},
    {"name": "Pillar", "id": 6, "color": [128, 148, 163], "train_id": 5},
    {"name": "Fence", "id": 7, "color": [0, 252, 124], "train_id": 6},
    {"name": "Other", "id": 8, "color": [34, 139, 34], "train_id": 7},
    {"name": "Vegetation", "id": 9, "color": [0, 255, 255], "train_id": 8},
    {"name": "Wall", "id": 10, "color": [140, 230, 240], "train_id": 9},
    {"name": "Crubs", "id": 11, "color": [255, 255, 0], "train_id": 10},
    {"name": "unnormal", "id": 12, "color": [208, 224, 64], "train_id": 11},
]


class LidarDataset(BaseDataset):
    def __init__(self, opt, mode):
        super(LidarDataset, self).__init__(opt, mode)

        self.label_ignore = opt.ignore_label
        self._label_map = np.arange(256).astype(np.uint8)
        self._labels_info = labels_info
        for el in self._labels_info:
            self._label_map[el["id"]] = el["train_id"]
        self._get_dataset()
        self.len = len(self.label_dict["pcd_list"])

    @property
    def label_dict(self):
        return self._label_dict

    @property
    def label_map(self):
        return self._label_map

    @property
    def labels_info(self):
        return self._labels_info

    def _get_dataset(self):
        if self.mode == "train":
            datalist_dict = self.train_path_dict
        else:
            datalist_dict = self.test_path_dict

        for key in datalist_dict:
            file_list = []
            with open(datalist_dict[key], "r") as f:
                lines = f.read().splitlines()
                file_list.extend(lines)
        # rm repeat
        lines = list(dict.fromkeys(file_list))

        pcd_list = []
        bin_list = []
        label_seg_list = []
        for line in lines:
            pcd_path = os.path.join(self.root, line)
            bin_path = os.path.join(
                self.root, line.replace("pcd", "bin").replace("pcd", "bin")
            )
            label_path = os.path.join(
                self.root, line.replace("pcd", "label").replace("pcd", "label")
            )
            pcd_list.append(pcd_path)
            bin_list.append(bin_path)
            label_seg_list.append(label_path)
        self._label_dict = dict(
            pcd_list=pcd_list,
            bin_list=bin_list,
            label_seg_list=label_seg_list,
        )

    def __len__(self):
        return self.len
