import numpy as np 
import math


def gaussian_radius(det_size, min_overlap=0.5):
    """Get radius of gaussian.

    Args:
        det_size (tuple[torch.Tensor]): Size of the detection result.
        min_overlap (float, optional): Gaussian_overlap. Defaults to 0.5.

    Returns:
        torch.Tensor: Computed radius.
    """
    height, width = det_size

    a1 = 1
    b1 = (height + width)
    c1 = width * height * (1 - min_overlap) / (1 + min_overlap)
    sq1 = np.sqrt(b1**2 - 4 * a1 * c1)
    r1 = (b1 + sq1) / 2

    a2 = 4
    b2 = 2 * (height + width)
    c2 = (1 - min_overlap) * width * height
    sq2 = np.sqrt(b2**2 - 4 * a2 * c2)
    r2 = (b2 + sq2) / 2

    a3 = 4 * min_overlap
    b3 = -2 * min_overlap * (height + width)
    c3 = (min_overlap - 1) * width * height
    sq3 = np.sqrt(b3**2 - 4 * a3 * c3)
    r3 = (b3 + sq3) / 2
    return min(r1, r2, r3)


def make_gaussian_2d(cx, rx, cy, ry, yaw, w_output, h_output):
    x = np.arange(w_output)
    y = np.arange(h_output)
    X, Y = np.meshgrid(x, y)
    X = X - cx
    Y = Y - cy
    C = np.concatenate(
        (X.reshape(1, h_output, w_output), Y.reshape(1, h_output, w_output)), 0
    ).copy()
    C = C.reshape(2, -1)
    R = np.array([[math.cos(yaw), -math.sin(yaw)], [math.sin(yaw), math.cos(yaw)]])
    C1 = np.dot(R, C)
    C1 = C1.reshape(2, h_output, w_output)
    X = C1[0, :, :]
    Y = C1[1, :, :]
    expo = (X**2) / (rx**2) + (Y**2) / (ry**2)
    expo = expo * (-0.5)
    im = np.exp(expo)
    return im