import numpy as np
import math
import json
from PIL import Image

import torch
import torch.nn.functional as F

import lib.datasets.transform.common_transform as T
import lib.datasets.transform.bev_transform as bt
from lib.utils.vis_util import *
from lib.datasets.dataset.fisheye_bev import FishEyeBEVDataset
from lib.datasets.utils.quaternion import Quaternion
from lib.datasets.utils.point_utils import gaussian_radius, make_gaussian_2d
from lib.utils.bev_utils import pix_camera2image, bev_feature_to_image, visualize_bev_gt, visualize_bev_gt_v2
from lib.models.common_opr.grid_point import bilinear_grid_sample_wb, bilinear_grid_sample_4d

def convert_yaw(yaw):
    yaw_degrees = math.degrees(yaw)
    
    if yaw_degrees > 90:
        yaw_degrees -= 180
    elif yaw_degrees < -90:
        yaw_degrees += 180
    return math.radians(yaw_degrees)

def add_mask(opt, heatmap):
    size = heatmap.shape
    bev_out_h, bev_out_w = size[0], size[1]
    center_h = bev_out_h // 2
    center_w = bev_out_w // 2
    pix_dis_x = opt.xbound[-1]
    pix_dis_y = opt.ybound[-1]
    mask_h_0 = int((4.94 / pix_dis_x) / opt.scale_bev)
    mask_h_1 = -int((2.06 / pix_dis_x) / opt.scale_bev)
    mask_w_0 = int((2 / pix_dis_y) / opt.scale_bev)
    mask_w_1 = -int((2 / pix_dis_y) / opt.scale_bev)

    heatmap[center_h - mask_h_0 : center_h - mask_h_1, center_w - mask_w_0 : center_w - mask_w_1] = 255
    return heatmap

class FishEyeBEVDetDataset(FishEyeBEVDataset):
    def __init__(self, opt, mode):
        super(FishEyeBEVDetDataset, self).__init__(opt, mode)
        self.size = (self.opt.h_input, self.opt.w_input)
        self.max_box_num = self.opt.max_box_num
        if self.mode == "train":
            self.transform = T.Compose(
                [
                    # T.RandomResizedCrop(0.5, (0.9, 1.1), self.size),
                    # T.RandomAffine(0.3, self.size, degrees=15),
                    # T.RandomHorizontalFlip(0.5),
                    # T.RandomVerticalFlip(0.5),
                    T.ColorJitter(0.5, 0.5, 0.5, 0.5, 0.5),
                    T.GaussianNoise(0.3, 0, 0.1),
                    T.AddBlur(0.1, "all"),
                    T.ToTensor(),
                ]
            )
        else:
            self.transform = T.Compose([T.Resize(self.size), T.ToTensor()])

        self.image_augmentation = bt.ImageAugmentation(
            enable=self.opt.image_aug["enable"],
            random_flip=self.opt.image_aug["random_flip"],
            resize=self.opt.image_aug["resize"],
            rotate=self.opt.image_aug["rotate"],
            crop_origin=self.opt.image_aug["crop_origin"],
            fH=self.opt.h_input,
            fW=self.opt.w_input,
        )

        self.bev_augmentation = bt.BEVAugmentation(
            enable=self.opt.bev_aug["enable"],
            bev_rot=self.opt.bev_aug["bev_rot"],
        )

        self.N = opt.num_cameras
        self.xbound = opt.xbound
        self.ybound = opt.ybound
        self.zbound = opt.zbound
        self.bev_range = np.array(
            [
                self.xbound[0],
                self.xbound[1],
                self.ybound[0],
                self.ybound[1],
                self.zbound[0],
                self.zbound[1],
            ],
            dtype=np.float32,
        )
        self.bev_resolution = np.array(
            [self.xbound[-1], self.ybound[-1], self.zbound[-1]], dtype=np.float32
        )
        self.bev_length, self.bev_width, self.bev_height = (
            (self.bev_range[1::2] - self.bev_range[0::2]) / self.bev_resolution
        ).astype(np.int32)

        self.sample_heights = (
            opt.sample_heights if hasattr(opt, "sample_heights") and getattr(opt, "sample_heights") else None
        )

        if self.sample_heights is None:
            meshgrid = np.meshgrid(
                range(self.bev_height),
                range(self.bev_length),
                range(self.bev_width),
                indexing="ij",
            )
            grid_points = np.stack(
                [
                    (meshgrid[1] + 0.5) * self.bev_resolution[0] + self.bev_range[0],
                    (meshgrid[2] + 0.5) * self.bev_resolution[1] + self.bev_range[2],
                    (meshgrid[0]) * self.bev_resolution[2] + self.bev_range[4],
                ],
                axis=0,
            ).astype(np.float32)
        else:
            self.bev_height = len(self.sample_heights)
            meshgrid = np.meshgrid(
                self.sample_heights,
                range(self.bev_length),
                range(self.bev_width),
                indexing="ij",
            )
            grid_points = np.stack(
                [
                    (meshgrid[1] + 0.5) * self.bev_resolution[0] + self.bev_range[0],
                    (meshgrid[2] + 0.5) * self.bev_resolution[1] + self.bev_range[2],
                    meshgrid[0],
                ],
                axis=0,
            ).astype(np.float32)
        self.grid_points = torch.from_numpy(grid_points)
        print("grid_points shape: ", self.grid_points.shape)

        self.downsample_factor = self.opt.scale_point

    def _get_img_data(self, img_dict, calib_dict, cam):
        img_path = img_dict[cam]

        affine = calib_dict[cam]["affine"]
        distortion_center = calib_dict[cam]["distortion_center"]
        world2cam = calib_dict[cam]["world2cam"]
        rot_CV = calib_dict[cam]["rot_CV"]
        trans_CV = calib_dict[cam]["trans_CV"]
        while len(world2cam) < 11:
            world2cam = np.append(world2cam, 0.0)

        return img_path, affine, distortion_center, world2cam, rot_CV, trans_CV

    def _get_box_data(self, ann_dict):
        box3d_list = []
        for object_i in ann_dict.keys():
            if object_i == 'filename':
                continue
            inst = ann_dict[object_i]
            category = inst["category_name"]

            if category is None or category not in self.train_category:
                continue

            cat_id = self.train_category[category]["train_id"]
            box = {
                "center": np.array(inst["translation"]),
                "size": np.array(inst["size"]),
                "orientation": Quaternion(matrix=inst["rotation"]),
                "label": int(cat_id),
            }
            # box = Box(inst['translation'], inst['size'], Quaternion(matrix=inst['rotation']), label=cat_id)
            box3d_list.append(box)
        return box3d_list

    def _nusc_box3d_to_array(self, box):
        yaw, roll, pitch = box["orientation"].yaw_pitch_roll
        # cls_id, cx, cy, cz, w, l, h, yaw
        new_box = np.array(
            [
                box["label"],
                box["center"][0],
                box["center"][1],
                box["center"][2],
                box["size"][0],
                box["size"][1],
                box["size"][2],
                yaw,
            ]
        )
        return new_box
    
    def _get_box3d_label(self, box3d_array):
        # bev : x -> h, y -> w
        bev_h = self.bev_length
        bev_w = self.bev_width
        
        bev_out_h = bev_h // self.opt.scale_bev
        bev_out_w = bev_w // self.opt.scale_bev
        # truth = np.zeros((bev_out_h, bev_out_w, 9)) # 1(heatmap) + 2(offset) + 1(height) + 3(lwh) + 2(yaw)
        truth = np.zeros((bev_out_h, bev_out_w, 13)) # 3(heatmap) + 6(offset) + 1(height) + 3(lwh) + 2(yaw)

        if len(box3d_array) == 0:
            return truth
        
        # cls_id, cx, cy, cz, w, l, h, yaw
        # mask = (
        #     (box3d_array[:, 4] > 0)
        #     * (box3d_array[:, 5] > 0)
        #     * (box3d_array[:, 6] > 0)
        # )
        # box3d_array = box3d_array[mask, :]

        if len(box3d_array) > 0:
            # heat_list = []
            heat1_list = []
            heat2_list = []
            heat3_list = []
            for j in range(len(box3d_array)):
                box3d = box3d_array[j, :]
                box_cx, box_cy, box_cz = box3d[1], box3d[2], box3d[3]
                box_w, box_l, box_h = box3d[4], box3d[5], box3d[6]
                yaw = box3d[7]
                yaw = convert_yaw(yaw)

                ### offset
                cy = (box_cx - self.xbound[0]) / self.xbound[2] / self.opt.scale_bev
                cx = (box_cy - self.ybound[0]) / self.ybound[2] / self.opt.scale_bev

                if cx < 0 or cx >= bev_out_w:
                    continue
                if cy < 0 or cy >= bev_out_h:
                    continue
                
                ux = int(cx)
                uy = int(cy)
                tx = cx - ux
                ty = cy - uy

                ### box height & lwh
                cz = box_cz

                ### wlh
                box_out_w = box_w / self.ybound[2] / self.opt.scale_bev
                box_out_l = box_l / self.xbound[2] / self.opt.scale_bev
                box_out_h = box_h

                ### sin(yaw), cos(yaw)
                sin_rot = math.sin(yaw)
                cos_rot = math.cos(yaw)
                rot_vector = np.array([cos_rot, sin_rot])
                rot_90_vector = np.array([sin_rot, - cos_rot])

                # corners
                front_mid = np.array([box_cx, box_cy]) + 0.5 * rot_vector * box_l
                corner0 = front_mid + rot_90_vector * 0.5 * box_w
                corner1 = corner0 - rot_vector * box_l
                corner2 = corner1 - rot_90_vector * box_w
                corner3 = corner2 + rot_vector * box_l
                corner_list = [corner0, corner1, corner2, corner3]

                dist0 = (corner0[0] - 2.158) ** 2 + corner0[1] ** 2
                dist1 = (corner1[0] - 2.158) ** 2 + corner1[1] ** 2
                dist2 = (corner2[0] - 2.158) ** 2 + corner2[1] ** 2
                dist3 = (corner3[0] - 2.158) ** 2 + corner3[1] ** 2
                dist_list = [dist0, dist1, dist2, dist3]
                # find nearest
                import copy 
                t = copy.deepcopy(dist_list)
                min_number = []
                min_index = []
                for _ in range(1):
                    number = min(t)
                    index = t.index(number)
                    t[index] = 1000
                    min_number.append(number)
                    min_index.append(index)
                t = []
                nearcorner = corner_list[min_index[0]]
                # nearcorner1 = corner_list[min_index[1]]
                # nearcorner2 = corner_list[min_index[2]]  
                             
                # long side first
                if min_index[0] % 2 == 0:
                    nearcorner1 = corner_list[(min_index[0] + 1) % 4]
                    nearcorner2 = corner_list[(min_index[0] + 3) % 4]
                else:
                    nearcorner2 = corner_list[(min_index[0] + 1) % 4]
                    nearcorner1 = corner_list[(min_index[0] + 3) % 4]
                front_mid = (nearcorner + nearcorner1) / 2
                front_mid1 = (nearcorner + nearcorner2) / 2
                # 2 vectors
                vector_x = (front_mid[0] - nearcorner[0]) / self.xbound[2] / self.opt.scale_bev
                vector_y = (front_mid[1] - nearcorner[1]) / self.ybound[2] / self.opt.scale_bev
                vector1_x = (front_mid1[0] - nearcorner[0]) / self.xbound[2] / self.opt.scale_bev
                vector1_y = (front_mid1[1] - nearcorner[1]) / self.ybound[2] / self.opt.scale_bev
                # offset of nearcorner
                ny = (nearcorner[0] - self.xbound[0]) / self.xbound[2] / self.opt.scale_bev
                nx = (nearcorner[1] - self.ybound[0]) / self.ybound[2] / self.opt.scale_bev

                if nx < 0 or nx >= bev_out_w:
                    continue
                if ny < 0 or ny >= bev_out_h:
                    continue
                
                ux1 = int(nx)
                uy1 = int(ny)
                tx1 = nx - ux1
                ty1 = ny - uy1

                # offset of frontmid
                fy = (front_mid[0] - self.xbound[0]) / self.xbound[2] / self.opt.scale_bev
                fx = (front_mid[1] - self.ybound[0]) / self.ybound[2] / self.opt.scale_bev

                if fx < 0 or fx >= bev_out_w:
                    continue
                if fy < 0 or fy >= bev_out_h:
                    continue
                
                ux2 = int(fx)
                uy2 = int(fy)
                tx2 = fx - ux2
                ty2 = fy - uy2

                # offset of frontmid1
                f1y = (front_mid1[0] - self.xbound[0]) / self.xbound[2] / self.opt.scale_bev
                f1x = (front_mid1[1] - self.ybound[0]) / self.ybound[2] / self.opt.scale_bev

                if f1x < 0 or f1x >= bev_out_w:
                    continue
                if f1y < 0 or f1y >= bev_out_h:
                    continue
                
                ux3 = int(f1x)
                uy3 = int(f1y)
                tx3 = f1x - ux3
                ty3 = f1y - uy3

                ### make label
                truth[uy1, ux1, 3] = tx1
                truth[uy1, ux1, 4] = ty1
                truth[uy2, ux2, 5] = tx2
                truth[uy2, ux2, 6] = ty2
                truth[uy3, ux3, 7] = tx3
                truth[uy3, ux3, 8] = ty3
                truth[uy1, ux1, 9] = vector_x
                truth[uy1, ux1, 10] = vector_y
                truth[uy1, ux1, 11] = vector1_x
                truth[uy1, ux1, 12] = vector1_y

                ### gaussian map
                
                radius = gaussian_radius((box_out_l, box_out_w), min_overlap=0.1)
                radius = max(2, int(radius))
                # heat = make_gaussian_2d(ux, radius, uy, radius, 0, bev_out_w, bev_out_h)
                heat1 = make_gaussian_2d(ux1, radius, uy1, radius, 0, bev_out_w, bev_out_h)
                heat2 = make_gaussian_2d(ux2, radius, uy2, radius, 0, bev_out_w, bev_out_h)
                heat3 = make_gaussian_2d(ux3, radius, uy3, radius, 0, bev_out_w, bev_out_h)
                # heat_list.append(heat)
                heat1_list.append(heat1)
                heat2_list.append(heat2)
                heat3_list.append(heat3)

            # if len(heat_list) > 0:
            #     heat = np.stack(heat_list, axis=0)
            #     heatmap = heat.max(axis=0)
            #     # heat-map = add_mask(self.opt, heatmap)
            #     truth[..., 0] = heatmap           
            if len(heat1_list) > 0:
                heat1 = np.stack(heat1_list, axis=0)
                heatmap1 = heat1.max(axis=0)
                truth[..., 0] = heatmap1
            if len(heat2_list) > 0:
                heat2 = np.stack(heat2_list, axis=0)
                heatmap2 = heat2.max(axis=0)
                truth[..., 1] = heatmap2
            if len(heat3_list) > 0:
                heat3 = np.stack(heat3_list, axis=0)
                heatmap3 = heat3.max(axis=0)
                truth[..., 2] = heatmap3
        
        # print(heatmap.shape, heatmap.max(), heatmap.min())
        # cv2.imshow("heatmap", heatmap)
        # cv2.waitKey(0)
        return truth

    def _calc_pix_coords(
        self,
        affines,
        distortion_centers,
        world2cams,
        T_c2v,
        img_post_rot=None,
        img_post_trans=None,
        bev_rot=None,
        normalize=True,
        downsample_factor=1,
    ):
        """
        params:
            K: B*N*3*3, camera intrinsic
            T_c2v: B*N*4*4, transform from camera to vehicle
            bev_range: [x_min, x_max, y_min, y_max, z_min, z_max]
            bev_resolution: [res_x, res_y, res_z] (m/pixel)
            sample_heights: List[float]
        return:
            pix_coords: (B*N)*bev_L*bev_W*bev_H*2
        """
        B, N, _, _ = T_c2v.shape

        grid_points = self.grid_points.clone()
        grid_points = grid_points.view(1, 1, 3, -1)
        if bev_rot is not None:
            grid_points = torch.linalg.inv(bev_rot) @ grid_points

        T_v2c = torch.inverse(T_c2v)  # B*N*4*4
        cam_points = T_v2c[:, :, 0:3, 0:3] @ grid_points + T_v2c[:, :, 0:3, 3:]

        eps = 1e-7
        pix_coords = cam_points / cam_points[:, :, 2:, :]
        pix_coords = pix_camera2image(pix_coords, affines, distortion_centers, world2cams)

        if img_post_rot is not None and img_post_trans is not None:
            pix_coords = img_post_rot @ pix_coords + img_post_trans[..., None]
        pix_coords = pix_coords[:, :, :2, :]
        output_w, output_h = (
            self.opt.w_input // downsample_factor,
            self.opt.h_input // downsample_factor,
        )
        # set invalid coordinate
        pix_coords = torch.where(
            (cam_points[:, :, 2:, :] > eps)
            & torch.isfinite(pix_coords)
            & (pix_coords[:, :, :1, :] >= 0)
            & (pix_coords[:, :, :1, :] < output_w)
            & (pix_coords[:, :, 1:2, :] >= 0)
            & (pix_coords[:, :, 1:2, :] < output_h),
            pix_coords,
            -pix_coords.new_ones(1) * 1e5,
        )
        pix_coords = (
            pix_coords.permute(0, 1, 3, 2)
            .view(B * N, self.bev_height, self.bev_length * self.bev_width, 2)
            .contiguous()
        )
        if normalize:
            # convert pix_coords to [-1, 1]
            pix_coords = (
                pix_coords
                * pix_coords.new_tensor([1.0 / (output_w - 1), 1.0 / (output_h - 1)])
                - 0.5
            ) * 2

        return pix_coords

    def __getitem__(self, index):
        img_dict, calib_dict, ann_dict = (
            self.label_dict["img_list"][index],
            self.label_dict["calib_list"][index],
            self.label_dict["ann_list"][index],
        )

        imgs = []
        rots = []
        trans = []
        affines = []
        world2cams = []
        distortion_centers = []
        img_post_rot = []
        img_post_trans = []
        for cam in self.camera_names:
            (
                img_path,
                affine,
                distortion_center,
                world2cam,
                rot_CV,
                trans_CV,
            ) = self._get_img_data(img_dict, calib_dict, cam)

            img = Image.open(img_path)
            img, post_rot_out, post_tran_out = self.image_augmentation(img, self.mode)

            im_lb = dict(im=img)
            im_lb = self.transform(im_lb)

            imgs.append(im_lb["im"])
            rots.append(torch.Tensor(rot_CV.rotation_matrix))
            trans.append(torch.Tensor(trans_CV))
            affines.append(torch.Tensor(affine))
            distortion_centers.append(torch.Tensor(distortion_center))
            world2cams.append(torch.Tensor(world2cam))
            img_post_rot.append(post_rot_out)
            img_post_trans.append(post_tran_out)

        ### box process
        box_list = self._get_box_data(ann_dict)
        bev_rot, box_list = self.bev_augmentation(box_list, self.mode)

        box_list_out = []
        for idx, box in enumerate(box_list):
            mask = (
                (box["center"][0] > self.opt.xbound[0])
                * (box["center"][0] < self.opt.xbound[1])
                * (box["center"][1] > self.opt.ybound[0])
                * (box["center"][1] < self.opt.ybound[1])
                * (box["center"][2] > self.opt.zbound[0])
                * (box["center"][2] < self.opt.zbound[1])
            )
            if mask:
                box_list_out.append(box)

        if len(box_list_out) > 0:
            box3d_list = [self._nusc_box3d_to_array(box) for box in box_list_out]
            box3d_array = np.stack(box3d_list, axis=0)

            car_box3d_mask = box3d_array[:, 0] == self.train_category["Car"]["train_id"]
            car_box3d_array = box3d_array[car_box3d_mask]
            car_box3d_label = torch.from_numpy(self._get_box3d_label(car_box3d_array))

            # person_box3d_mask = box3d_array[:, 0] == self.train_category["Pedestrian"]["train_id"]
            # person_box3d_array = box3d_array[person_box3d_mask]
            # person_box3d_label = torch.from_numpy(self._get_box3d_label(person_box3d_array))
        else:
            # bev : x -> h, y -> w
            bev_h = self.bev_length
            bev_w = self.bev_width
            
            bev_out_h = bev_h // self.opt.scale_bev
            bev_out_w = bev_w // self.opt.scale_bev
            # car_box3d_label = torch.zeros(bev_out_h, bev_out_w, 9) # 1(heatmap) + 2(offset) + 1(height) + 3(lwh) + 2(yaw)
            car_box3d_label = torch.zeros(bev_out_h, bev_out_w, 13) # 3(heatmap) + 6(offset) + 1(height) + 3(lwh) + 2(yaw)
            # person_box3d_label = torch.zeros(bev_out_h, bev_out_w, 9) # 1(heatmap) + 2(offset) + 1(height) + 3(lwh) + 2(yaw)

        rots = torch.stack(rots)
        trans = torch.stack(trans)
        affines = torch.stack(affines)
        distortion_centers = torch.stack(distortion_centers)
        world2cams = torch.stack(world2cams)

        img_post_rot = torch.stack(img_post_rot)
        img_post_trans = torch.stack(img_post_trans)
        bev_rot = bev_rot.unsqueeze(0).repeat(len(imgs), 1, 1)

        scale_w, scale_h = 1.0 / self.downsample_factor, 1.0 / self.downsample_factor
        img_post_rot[:, 0, :] *= scale_w
        img_post_rot[:, 1, :] *= scale_h
        img_post_trans[:, 0] *= scale_w
        img_post_trans[:, 1] *= scale_h

        ### pix_coords
        T_c2v = torch.eye(4).type_as(affines)
        T_c2v = T_c2v.repeat(1, self.opt.num_cameras, 1, 1)
        T_c2v[:, :, 0:3, 0:3] = rots.unsqueeze(0)
        T_c2v[:, :, 0:3, 3] = trans.unsqueeze(0)

        pix_coords = self._calc_pix_coords(
            affines.unsqueeze(0),
            distortion_centers.unsqueeze(0),
            world2cams.unsqueeze(0),
            T_c2v,
            img_post_rot.unsqueeze(0),
            img_post_trans.unsqueeze(0),
            bev_rot.unsqueeze(0),
            normalize=True,
            downsample_factor=self.downsample_factor,
        )

        data_dict = {
            "image": torch.stack(imgs),
            "pix_coords": pix_coords,
        }

        label_dict = {
            "car_box3d": car_box3d_label,
            # "person_box3d": person_box3d_label,
            "rots": rots,
            "trans": trans,
            "affines": affines,
            "distortion_centers": distortion_centers,
            "world2cams": world2cams,
            "bev_rot": bev_rot,
            "img_post_rot": img_post_rot,
            "img_post_trans": img_post_trans,
            
        }
        return data_dict, label_dict

    def reduce_mean_bev_feature(self, bev_feature):
        """
        params:
            bev_Feature: B*N*C*H*W
        """
        eps = 1e-7
        mask = (torch.abs(bev_feature) > 0).float()
        numer = torch.sum(bev_feature, dim=1)
        denom = torch.sum(mask, dim=1) + torch.tensor([eps]).type_as(numer)
        mean = numer / denom

        return mean

    def vis_bev_transform(self, data_dict, label_dict):

        image = data_dict["image"]
        if len(image.size()) == 4:
            N, C_raw, H_raw, W_raw = image.size()

            # f_h = H_raw // self.downsample_factor
            # f_w = W_raw // self.downsample_factor
            # pix_coords = data_dict["pix_coords"].clone()

            affines = label_dict["affines"].clone()
            distortion_centers = label_dict["distortion_centers"].clone()
            world2cams = label_dict["world2cams"].clone()

            img_post_rot = label_dict["img_post_rot"].clone()
            img_post_trans = label_dict["img_post_trans"].clone()
            bev_rot = label_dict["bev_rot"].clone()

            T_c2v = torch.eye(4).type_as(affines)
            T_c2v = T_c2v.repeat(1, N, 1, 1)
            T_c2v[:, :, 0:3, 0:3] = label_dict["rots"]
            T_c2v[:, :, 0:3, 3] = label_dict["trans"]
        else:
            B, N, C_raw, H_raw, W_raw = image.size()
            image = image.clone()[0]

            # f_h = H_raw // self.downsample_factor
            # f_w = W_raw // self.downsample_factor
            # pix_coords = data_dict["pix_coords"][0].clone()

            affines = label_dict["affines"].clone()[0]
            distortion_centers = label_dict["distortion_centers"].clone()[0]
            world2cams = label_dict["world2cams"].clone()[0]

            img_post_rot = label_dict["img_post_rot"].clone()[0]
            img_post_trans = label_dict["img_post_trans"].clone()[0]
            bev_rot = label_dict["bev_rot"].clone()[0]

            T_c2v = torch.eye(4).type_as(affines)
            T_c2v = T_c2v.repeat(1, N, 1, 1)
            T_c2v[:, :, 0:3, 0:3] = label_dict["rots"][0]
            T_c2v[:, :, 0:3, 3] = label_dict["trans"][0]          

        scale_w, scale_h = self.downsample_factor, self.downsample_factor
        img_post_rot[:, 0, :] *= scale_w
        img_post_rot[:, 1, :] *= scale_h
        img_post_trans[:, 0] *= scale_w
        img_post_trans[:, 1] *= scale_h

        # self.downsample_factor = 1  # reset downsample_factor
        pix_coords = self._calc_pix_coords(
            affines.unsqueeze(0),
            distortion_centers.unsqueeze(0),
            world2cams.unsqueeze(0),
            T_c2v,
            img_post_rot.unsqueeze(0),
            img_post_trans.unsqueeze(0),
            bev_rot.unsqueeze(0),
            normalize=True,
            downsample_factor=1,
        )

        # image = F.interpolate(image, size=(f_h, f_w), mode="bilinear")

        # feature_img = image
        # bev_feature = bilinear_grid_sample_wb(
        #     feature_img, pix_coords, align_corners=False
        # )  # B*N, C, bev_length, bev_width*bev_height

        feature_img = image.unsqueeze(2).repeat(1, 1, self.bev_height, 1, 1)
        print(feature_img.shape, pix_coords.shape)
        bev_feature = bilinear_grid_sample_4d(
            feature_img, pix_coords, align_corners=False
        )  # B*N, C, bev_length, bev_width*bev_height
        bev_feature = self.reduce_mean_bev_feature(
            bev_feature.view(
                1, N, C_raw, self.bev_height, self.bev_length * self.bev_width
            )
        )
        bev_feature = (
            bev_feature.permute(0, 2, 1, 3)
            .contiguous()
            .view(1, self.bev_height * C_raw, self.bev_length, self.bev_width)
        )

        bev_images = []
        for idx in range(self.bev_height):
            bev_image = bev_feature_to_image(bev_feature, idx)
            bev_image = (bev_image * 255).astype(np.uint8)
            bev_images.append(bev_image)
        return bev_images

    def verify(self, index):
        data_dict, label_dict = self.__getitem__(index)

        image = data_dict["image"]

        bev_images = self.vis_bev_transform(data_dict, label_dict)
        for i, bev_image in enumerate(bev_images):
            cv2.imshow(f"bev_image_{i}", bev_image)
        cv2.waitKey(0)
        exit()

        # show_img = visualize_bev_gt(bev_images[0], image, label_dict, self.xbound, self.ybound, self.opt.img_w, self.opt.img_h)
        show_img = visualize_bev_gt_v2(bev_images[0], label_dict, self.xbound, self.ybound, self.opt.scale_bev)
        return show_img
        cv2.imshow("combined_img", combined_img)
        cv2.waitKey(0)
