import numpy as np
from PIL import Image
import os
import math

import torch

import lib.datasets.transform.common_transform as T
import lib.datasets.transform.bev_transform as bt
import lib.datasets.transform.fisheye_transform as FT
from lib.utils.vis_util import *
from lib.datasets.dataset.fisheye_freespace import FishEyeFSDataset
from lib.datasets.utils.projections import FishEyeProjection
from lib.utils.bev_utils import pix_camera2image, bev_feature_to_image, visualize_bev_gt, visualize_bev_gt_v2
from lib.models.common_opr.grid_point import bilinear_grid_sample_wb, bilinear_grid_sample_4d


camera_names = ["front", "left", "right", "rear"]

class FishEyeFSSegDataset(FishEyeFSDataset):
    def __init__(self, opt, mode):
        super(FishEyeFSSegDataset, self).__init__(opt, mode)
        self.size = (self.opt.h_input, self.opt.w_input)
        if self.mode == "train":
            self.transform = T.Compose(
                [
                    T.ColorJitter(0.5, 0.5, 0.5, 0.5, 0.5),
                    T.GaussianNoise(0.3, 0, 0.1),
                    T.AddBlur(0.1, "all"),
                    T.ToTensor(),
                ]
            )
        else:
            self.transform = T.Compose([T.Resize(self.size), T.ToTensor()])

        self.image_augmentation = bt.ImageAugmentation(
            enable=self.opt.image_aug["enable"],
            random_flip=self.opt.image_aug["random_flip"],
            resize=self.opt.image_aug["resize"],
            rotate=self.opt.image_aug["rotate"],
            crop_origin=self.opt.image_aug["crop_origin"],
            fH=self.opt.h_input,
            fW=self.opt.w_input,
        )

        self.bev_augmentation = bt.BEVAugmentation(
            enable=self.opt.bev_aug["enable"],
            bev_rot=self.opt.bev_aug["bev_rot"],
        )

        self.N = opt.num_cameras
        self.xbound = opt.xbound
        self.ybound = opt.ybound
        self.zbound = opt.zbound
        self.bev_range = np.array(
            [
                self.xbound[0],
                self.xbound[1],
                self.ybound[0],
                self.ybound[1],
                self.zbound[0],
                self.zbound[1],
            ],
            dtype=np.float32,
        )
        self.bev_resolution = np.array(
            [self.xbound[-1], self.ybound[-1], self.zbound[-1]], dtype=np.float32
        )
        self.bev_length, self.bev_width, self.bev_height = (
            (self.bev_range[1::2] - self.bev_range[0::2]) / self.bev_resolution
        ).astype(np.int32)

        self.sample_heights = (
            opt.sample_heights if hasattr(opt, "sample_heights") and getattr(opt, "sample_heights") else None
        )

        if self.sample_heights is None:
            meshgrid = np.meshgrid(
                range(self.bev_height),
                range(self.bev_length),
                range(self.bev_width),
                indexing="ij",
            )
            grid_points = np.stack(
                [
                    (meshgrid[1] + 0.5) * self.bev_resolution[0] + self.bev_range[0],
                    (meshgrid[2] + 0.5) * self.bev_resolution[1] + self.bev_range[2],
                    (meshgrid[0]) * self.bev_resolution[2] + self.bev_range[4],
                ],
                axis=0,
            ).astype(np.float32)
        else:
            self.bev_height = len(self.sample_heights)
            meshgrid = np.meshgrid(
                self.sample_heights,
                range(self.bev_length),
                range(self.bev_width),
                indexing="ij",
            )
            grid_points = np.stack(
                [
                    (meshgrid[1] + 0.5) * self.bev_resolution[0] + self.bev_range[0],
                    (meshgrid[2] + 0.5) * self.bev_resolution[1] + self.bev_range[2],
                    meshgrid[0],
                ],
                axis=0,
            ).astype(np.float32)
        self.grid_points = torch.from_numpy(grid_points)
        print("grid_points shape: ", self.grid_points.shape)

        self.downsample_factor = self.opt.scale_point

    def _get_img_data(self, img_dict, calib_dict, cam):
        img_path = img_dict[cam]

        affine = calib_dict[cam]["affine"]
        distortion_center = calib_dict[cam]["distortion_center"]
        world2cam = calib_dict[cam]["world2cam"]
        rot_CV = calib_dict[cam]["rot_CV"]
        trans_CV = calib_dict[cam]["trans_CV"]
        while len(world2cam) < 11:
            world2cam = np.append(world2cam, 0.0)

        return img_path, affine, distortion_center, world2cam, rot_CV, trans_CV

    def _calc_pix_coords(
        self,
        affines,
        distortion_centers,
        world2cams,
        T_c2v,
        img_post_rot=None,
        img_post_trans=None,
        # bev_rot=None,
        normalize=True,
        downsample_factor=1,
    ):
        """
        params:
            K: B*N*3*3, camera intrinsic
            T_c2v: B*N*4*4, transform from camera to vehicle
            bev_range: [x_min, x_max, y_min, y_max, z_min, z_max]
            bev_resolution: [res_x, res_y, res_z] (m/pixel)
            sample_heights: List[float]
        return:
            pix_coords: (B*N)*bev_L*bev_W*bev_H*2
        """
        B, N, _, _ = T_c2v.shape

        grid_points = self.grid_points.clone()
        grid_points = grid_points.view(1, 1, 3, -1)
        # if bev_rot is not None:
        #     grid_points = torch.linalg.inv(bev_rot) @ grid_points

        T_v2c = torch.inverse(T_c2v)  # B*N*4*4
        cam_points = T_v2c[:, :, 0:3, 0:3] @ grid_points + T_v2c[:, :, 0:3, 3:]

        eps = 1e-7
        pix_coords = cam_points / cam_points[:, :, 2:, :]
        pix_coords = pix_camera2image(pix_coords, affines, distortion_centers, world2cams)

        if img_post_rot is not None and img_post_trans is not None:
            pix_coords = img_post_rot @ pix_coords + img_post_trans[..., None]
        pix_coords = pix_coords[:, :, :2, :]
        output_w, output_h = (
            self.opt.w_input // downsample_factor,
            self.opt.h_input // downsample_factor,
        )

        # set invalid coordinate
        pix_coords = torch.where(
            (cam_points[:, :, 2:, :] > eps)
            & torch.isfinite(pix_coords)
            & (pix_coords[:, :, :1, :] >= 0)
            & (pix_coords[:, :, :1, :] < output_w)
            & (pix_coords[:, :, 1:2, :] >= 0)
            & (pix_coords[:, :, 1:2, :] < output_h),
            pix_coords,
            -pix_coords.new_ones(1) * 1e5,
        )

        pix_coords = (
            pix_coords.permute(0, 1, 3, 2)
            .view(B * N, self.bev_height, self.bev_length * self.bev_width, 2)
            .contiguous()
        )
        if normalize:
            # convert pix_coords to [-1, 1]
            pix_coords = (
                pix_coords
                * pix_coords.new_tensor([1.0 / (output_w - 1), 1.0 / (output_h - 1)])
                - 0.5
            ) * 2

        return pix_coords

    def __getitem__(self, index):
        img_dict, calib_dict, label_path = (
            self.label_dict["img_list"][index],
            self.label_dict["calib_list"][index],
            self.label_dict["ann_list"][index],
        )

        # hans
        freespace_label = Image.open(label_path)
        freespace_label = np.array(freespace_label)
        freespace_label = torch.from_numpy(freespace_label).long()

        imgs = []
        rots = []
        trans = []
        affines = []
        world2cams = []
        distortion_centers = []
        img_post_rot = []
        img_post_trans = []
        for cam in self.camera_names:
            (
                img_path,
                affine,
                distortion_center,
                world2cam,
                rot_CV,
                trans_CV,
            ) = self._get_img_data(img_dict, calib_dict, cam)

            img = Image.open(img_path)
            img, post_rot_out, post_tran_out = self.image_augmentation(img, self.mode)

            im_lb = dict(im=img)
            im_lb = self.transform(im_lb)

            imgs.append(im_lb["im"])
            rots.append(torch.Tensor(rot_CV.rotation_matrix))
            trans.append(torch.Tensor(trans_CV))
            affines.append(torch.Tensor(affine))
            distortion_centers.append(torch.Tensor(distortion_center))
            world2cams.append(torch.Tensor(world2cam))
            img_post_rot.append(post_rot_out)
            img_post_trans.append(post_tran_out)
        
        rots = torch.stack(rots)
        trans = torch.stack(trans)
        affines = torch.stack(affines)
        distortion_centers = torch.stack(distortion_centers)
        world2cams = torch.stack(world2cams)

        img_post_rot = torch.stack(img_post_rot)
        img_post_trans = torch.stack(img_post_trans)
        # bev_rot = bev_rot.unsqueeze(0).repeat(len(imgs), 1, 1)

        scale_w, scale_h = 1.0 / self.downsample_factor, 1.0 / self.downsample_factor
        img_post_rot[:, 0, :] *= scale_w
        img_post_rot[:, 1, :] *= scale_h
        img_post_trans[:, 0] *= scale_w
        img_post_trans[:, 1] *= scale_h

        ### pix_coords
        T_c2v = torch.eye(4).type_as(affines)
        T_c2v = T_c2v.repeat(1, self.opt.num_cameras, 1, 1)
        T_c2v[:, :, 0:3, 0:3] = rots.unsqueeze(0)
        T_c2v[:, :, 0:3, 3] = trans.unsqueeze(0)

        pix_coords = self._calc_pix_coords(
            affines.unsqueeze(0),
            distortion_centers.unsqueeze(0),
            world2cams.unsqueeze(0),
            T_c2v,
            img_post_rot.unsqueeze(0),
            img_post_trans.unsqueeze(0),
            # bev_rot.unsqueeze(0),
            normalize=True,
            downsample_factor=self.downsample_factor,
        )

        data_dict = {
            "image": torch.stack(imgs),
            "pix_coords": pix_coords,
        }

        label_dict = {
            "freespace": freespace_label,
            "rots": rots,
            "trans": trans,
            "affines": affines,
            "distortion_centers": distortion_centers,
            "world2cams": world2cams,
            # "bev_rot": bev_rot,
            "img_post_rot": img_post_rot,
            "img_post_trans": img_post_trans,
            
        }
        return data_dict, label_dict

    def reduce_mean_bev_feature(self, bev_feature):
        """
        params:
            bev_Feature: B*N*C*H*W
        """
        eps = 1e-7
        mask = (torch.abs(bev_feature) > 0).float()
        numer = torch.sum(bev_feature, dim=1)
        denom = torch.sum(mask, dim=1) + torch.tensor([eps]).type_as(numer)
        mean = numer / denom

        return mean

    def vis_bev_transform(self, data_dict, label_dict):

        image = data_dict["image"]
        if len(image.size()) == 4:
            N, C_raw, H_raw, W_raw = image.size()

            # f_h = H_raw // self.downsample_factor
            # f_w = W_raw // self.downsample_factor
            # pix_coords = data_dict["pix_coords"].clone()

            affines = label_dict["affines"].clone()
            distortion_centers = label_dict["distortion_centers"].clone()
            world2cams = label_dict["world2cams"].clone()

            img_post_rot = label_dict["img_post_rot"].clone()
            img_post_trans = label_dict["img_post_trans"].clone()
            # bev_rot = label_dict["bev_rot"].clone()

            T_c2v = torch.eye(4).type_as(affines)
            T_c2v = T_c2v.repeat(1, N, 1, 1)
            T_c2v[:, :, 0:3, 0:3] = label_dict["rots"]
            T_c2v[:, :, 0:3, 3] = label_dict["trans"]
        else:
            B, N, C_raw, H_raw, W_raw = image.size()
            image = image.clone()[0]

            # f_h = H_raw // self.downsample_factor
            # f_w = W_raw // self.downsample_factor
            # pix_coords = data_dict["pix_coords"][0].clone()

            affines = label_dict["affines"].clone()[0]
            distortion_centers = label_dict["distortion_centers"].clone()[0]
            world2cams = label_dict["world2cams"].clone()[0]

            img_post_rot = label_dict["img_post_rot"].clone()[0]
            img_post_trans = label_dict["img_post_trans"].clone()[0]
            # bev_rot = label_dict["bev_rot"].clone()[0]

            T_c2v = torch.eye(4).type_as(affines)
            T_c2v = T_c2v.repeat(1, N, 1, 1)
            T_c2v[:, :, 0:3, 0:3] = label_dict["rots"][0]
            T_c2v[:, :, 0:3, 3] = label_dict["trans"][0]          

        scale_w, scale_h = self.downsample_factor, self.downsample_factor
        img_post_rot[:, 0, :] *= scale_w
        img_post_rot[:, 1, :] *= scale_h
        img_post_trans[:, 0] *= scale_w
        img_post_trans[:, 1] *= scale_h

        # self.downsample_factor = 1  # reset downsample_factor
        pix_coords = self._calc_pix_coords(
            affines.unsqueeze(0),
            distortion_centers.unsqueeze(0),
            world2cams.unsqueeze(0),
            T_c2v,
            img_post_rot.unsqueeze(0),
            img_post_trans.unsqueeze(0),
            # bev_rot.unsqueeze(0),
            normalize=True,
            downsample_factor=1,
        )

        # image = F.interpolate(image, size=(f_h, f_w), mode="bilinear")

        # feature_img = image
        # bev_feature = bilinear_grid_sample_wb(
        #     feature_img, pix_coords, align_corners=False
        # )  # B*N, C, bev_length, bev_width*bev_height

        feature_img = image.unsqueeze(2).repeat(1, 1, self.bev_height, 1, 1)
        print(feature_img.shape, pix_coords.shape)
        bev_feature = bilinear_grid_sample_4d(
            feature_img, pix_coords, align_corners=False
        )  # B*N, C, bev_length, bev_width*bev_height
        bev_feature = self.reduce_mean_bev_feature(
            bev_feature.view(
                1, N, C_raw, self.bev_height, self.bev_length * self.bev_width
            )
        )
        bev_feature = (
            bev_feature.permute(0, 2, 1, 3)
            .contiguous()
            .view(1, self.bev_height * C_raw, self.bev_length, self.bev_width)
        )

        bev_images = []
        for idx in range(self.bev_height):
            bev_image = bev_feature_to_image(bev_feature, idx)
            bev_image = (bev_image * 255).astype(np.uint8)
            bev_images.append(bev_image)
        return bev_images

    def verify(self, index):
        data_dict, label_dict = self.__getitem__(index)

        image = data_dict["image"]

        bev_images = self.vis_bev_transform(data_dict, label_dict)
        for i, bev_image in enumerate(bev_images):
            cv2.imshow(f"bev_image_{i}", bev_image)
        cv2.waitKey(0)
        exit()

        # show_img = visualize_bev_gt(bev_images[0], image, label_dict, self.xbound, self.ybound, self.opt.img_w, self.opt.img_h)
        show_img = visualize_bev_gt_v2(bev_images[0], label_dict, self.xbound, self.ybound, self.opt.scale_bev)
        return show_img
        cv2.imshow("combined_img", combined_img)
        cv2.waitKey(0)
