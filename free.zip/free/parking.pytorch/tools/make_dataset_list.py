import argparse
import os


parser = argparse.ArgumentParser(description="Make Dataset List")
parser.add_argument("--dir", default="/test_data/hans/freespace_new/parkingBEV", type=str, help="path to dir")
parser.add_argument("--out_path", default="/test_data/hans/freespace_new", type=str, help="path to out")
opt = parser.parse_args()


out_file = os.path.join(opt.out_path, "test.txt")
out = open(out_file, "w")

for root, dirs, files in os.walk(opt.dir):
    last_part = os.path.split(root)[-1]
    if last_part == 'pcd':
        for file in files:
            full_path = os.path.join(root, file)
            out.write(full_path+ "\n")
out.close()
