import torch
import numpy as np
import cv2


def image_to_tensor(image, width, height, cuda=1):
    b, g, r = cv2.split(image)
    img_raw1 = cv2.merge([r, g, b])
    img = cv2.resize(img_raw1, (width, height))
    img = torch.from_numpy(img).permute(2, 0, 1).unsqueeze(0).float()
    if cuda:
        img = img.cuda()
    img = img / 255
    return img


def tensor_to_image(tensor):
    tensor = tensor.cpu().squeeze(0)
    img = tensor.permute(1, 2, 0).contiguous()
    img = img.numpy() * 255
    img = img[:, :, ::-1].astype(np.uint8)
    return img
