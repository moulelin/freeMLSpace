import sys
import numpy as np
import torch

sys.path.insert(0, "../")
from lib.models.model_factory import create_model


class PTHModule:
    def __init__(self, model_path, opt):
        self.opt = opt

        model = create_model(opt, "eval")
        checkpoint = torch.load(model_path)
        model.load_state_dict(checkpoint["net"], strict=False)

        self.net = model.cuda()
        self.net.mode = "eval"
        self.net.eval()

        self._model_type = "pth"

    @property
    def model_type(self):
        return self._model_type

    def inference(self, tensor):
        output = self.net(tensor)
        # Return only the host outputs.
        return output
