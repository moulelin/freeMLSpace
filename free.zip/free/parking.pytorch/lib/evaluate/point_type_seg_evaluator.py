import math
import numpy as np

import torch

from .point_seg_evaluator import PointSegEvaluator


class PointTypeSegEvaluator(PointSegEvaluator):
    def __init__(self, opt, decoder, dataset):
        super(PointTypeSegEvaluator, self).__init__(opt, decoder, dataset)

    def _get_results(self, avg_inference_t):
        self.generate_seg_results()
        self.generate_point_results()
        self.results["inference_time"] = avg_inference_t
        self.results["batchsize"] = self.opt.val_batch

    def _get_infer_buffer(self):
        buffer = {}
        buffer["hist"] = torch.zeros(self.num_classes, self.num_classes).cuda()
        buffer["point_pred"] = []
        buffer["point_tp_offset"] = []
        buffer["point_truth"] = []
        buffer["center_pred"] = []
        buffer["center_tp_offset"] = []
        buffer["center_truth"] = []
        buffer["center_type_pred"] = []
        buffer["center_type_label"] = []
        return buffer

    def slot_type_metric(self, slot_type_preds, slot_type_labels):
        slot_type_preds = np.array(slot_type_preds).astype("int32")
        slot_type_labels = np.array(slot_type_labels).astype("int32")

        type_cls = self.opt.slot_type

        type_tps = np.zeros((len(type_cls),))
        type_fps = np.zeros((len(type_cls),))
        type_fns = np.zeros((len(type_cls),))
        type_num = np.zeros((len(type_cls),))

        for i in range(len(slot_type_preds)):
            if slot_type_labels[i] == self.opt.ignore_label:
                continue
            if slot_type_preds[i] == slot_type_labels[i]:
                type_tps[slot_type_preds[i]] += 1.0
            else:
                type_fps[slot_type_preds[i]] += 1.0
                type_fns[slot_type_labels[i]] += 1.0

            type_num[slot_type_labels[i]] += 1.0

        precision = type_tps / (type_tps + type_fps + 0.001)
        recall = type_tps / (type_tps + type_fns + 0.001)
        F1 = 2 * precision * recall / (precision + recall + 0.001)
        return F1, precision, recall, type_num

    def generate_point_results(self):
        point_pred_list = self._infer_buffer["point_pred"]
        point_truth_list = self._infer_buffer["point_truth"]
        center_pred_list = self._infer_buffer["center_pred"]
        center_truth_list = self._infer_buffer["center_truth"]

        (
            point_mAP,
            point_AP,
            point_Precision,
            point_Recall,
            point_F1,
            point_PR_list,
        ) = self._calc_mAP(point_pred_list, point_truth_list, 2)
        (
            center_mAP,
            center_AP,
            center_Precision,
            center_Recall,
            center_F1,
            center_PR_list,
        ) = self._calc_mAP(center_pred_list, center_truth_list, 2)

        point_tp_offset = np.mean(self._infer_buffer["point_tp_offset"])
        center_tp_offset = np.mean(self._infer_buffer["center_tp_offset"])

        self.results["point"] = {
            "mAP": point_mAP,
            "AP": point_AP,
            "Precision": point_Precision,
            "Recall": point_Recall,
            "F1-score": point_F1,
            "PR": point_PR_list,
            "tp_offset": point_tp_offset,
        }
        self.results["center"] = {
            "mAP": center_mAP,
            "AP": center_AP,
            "Precision": center_Precision,
            "Recall": center_Recall,
            "F1-score": center_F1,
            "PR": center_PR_list,
            "tp_offset": center_tp_offset,
        }

        F1, precision, recall, type_num = self.slot_type_metric(
            self._infer_buffer["center_type_pred"],
            self._infer_buffer["center_type_label"],
        )

        self.results["cls"] = {
            "F1": F1,
            "Precision": precision,
            "Recall": recall,
            "slot_num": type_num,
        }

        if self.opt.scene:
            for scene_name in self._scene_infer_buffers:
                if scene_name not in self.scene_results:
                    self.scene_results[scene_name] = {}
                for scene_value in self._scene_infer_buffers[scene_name]:
                    point_pred_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["point_pred"]
                    point_truth_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["point_truth"]
                    point_tp_offset = np.mean(
                        self._scene_infer_buffers[scene_name][scene_value][
                            "point_tp_offset"
                        ]
                    )
                    center_pred_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["center_pred"]
                    center_truth_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["center_truth"]
                    center_tp_offset = np.mean(
                        self._scene_infer_buffers[scene_name][scene_value][
                            "center_tp_offset"
                        ]
                    )

                    (
                        point_mAP,
                        point_AP,
                        point_Precision,
                        point_Recall,
                        point_F1,
                        point_PR_list,
                    ) = self._calc_mAP(point_pred_list, point_truth_list, 2)
                    (
                        center_mAP,
                        center_AP,
                        center_Precision,
                        center_Recall,
                        center_F1,
                        center_PR_list,
                    ) = self._calc_mAP(center_pred_list, center_truth_list, 2)

                    if scene_value not in self.scene_results[scene_name]:
                        self.scene_results[scene_name][scene_value] = {}
                    self.scene_results[scene_name][scene_value]["point"] = {
                        "mAP": point_mAP,
                        "AP": point_AP,
                        "Precision": point_Precision,
                        "Recall": point_Recall,
                        "F1-score": point_F1,
                        "PR": point_PR_list,
                        "tp_offset": point_tp_offset,
                    }
                    self.scene_results[scene_name][scene_value]["center"] = {
                        "mAP": center_mAP,
                        "AP": center_AP,
                        "Precision": center_Precision,
                        "Recall": center_Recall,
                        "F1-score": center_F1,
                        "PR": center_PR_list,
                        "tp_offset": center_tp_offset,
                    }

    def _match_point_pred_truth(self, pred, truth, th, mode="point"):
        num_preds = pred.size(0)
        num_truth = truth.size(0)
        mask_TPFP = torch.zeros(num_preds).cuda()
        mask_TPFN = torch.zeros(num_truth).cuda()

        tp_offset = 0
        tp_count = 0
        for i in range(num_preds):
            if num_truth > 0:
                dis = torch.sqrt(
                    (truth[:, 2] - pred[i, 2]) ** 2 + (truth[:, 3] - pred[i, 3]) ** 2
                )
                min_dis, idx = dis.min(0)
                if (
                    (min_dis < th)
                    and (pred[i, 0] == truth[idx, 0])
                    and (mask_TPFN[idx] == 0)
                ):
                    mask_TPFN[idx] = 1
                    mask_TPFP[i] = 1
                    tp_offset += min_dis.cpu().numpy()
                    tp_count += 1
                    if mode == "center":
                        if int(truth[idx, 4].cpu().numpy()) != self.opt.ignore_label:
                            pred_type = pred[i, -3:].clone().argmax(dim=0).cpu().numpy()
                            gt_type = truth[idx, -1].cpu().numpy()

                            if gt_type == self.opt.ignore_label:
                                continue
                            self._infer_buffer["center_type_pred"].append(pred_type)
                            self._infer_buffer["center_type_label"].append(gt_type)

        pred_out = torch.cat([pred[:, :2], mask_TPFP.view(-1, 1)], dim=1)

        if tp_count:
            tp_offset = tp_offset / tp_count
        else:
            tp_offset = None
        return pred_out, tp_offset

    def _eval_point(self, label, pred, sample_idx, mode="point"):
        B = label.size(0)
        if mode == "point":
            thresh_point_dis = self.opt.thresh_point_dis
            thresh_point_score = self.opt.thresh_point
        elif mode == "center":
            thresh_point_dis = self.opt.thresh_center_dis
            thresh_point_score = self.opt.thresh_center
        else:
            print("{} not support".format(mode))
            exit()

        for i in range(B):
            truth = label[i].clone()
            truth = truth[truth[:, 1] == 1]
            pre = pred[i].clone()
            pre = pre[pre[:, 1] > thresh_point_score]
            if pre != None:
                if mode == "center":
                    pred_out, tp_offset = self._match_point_pred_truth(
                        pre, truth, thresh_point_dis, mode
                    )
                    if self.opt.scene:
                        scene_infos = self.opt.scene_infos_list[sample_idx]
                        for scene_name, scene_value in scene_infos.items():
                            if scene_value in self.opt.filter_keys:
                                continue
                else:
                    pred_out, tp_offset = self._match_point_pred_truth(
                        pre, truth, thresh_point_dis, mode
                    )
                self._infer_buffer[f"{mode}_pred"].append(pred_out)
                if tp_offset:
                    self._infer_buffer[f"{mode}_tp_offset"].append(tp_offset)
                if self.opt.scene:
                    scene_infos = self.opt.scene_infos_list[sample_idx]
                    for scene_name, scene_value in scene_infos.items():
                        if scene_value in self.opt.filter_keys:
                            continue
                        self._scene_infer_buffers[scene_name][scene_value][
                            f"{mode}_pred"
                        ].append(pred_out)
                        if tp_offset:
                            self._scene_infer_buffers[scene_name][scene_value][
                                f"{mode}_tp_offset"
                            ].append(tp_offset)

            if truth != None:
                self._infer_buffer[f"{mode}_truth"].append(truth[:, 0].view(-1, 1))
                if self.opt.scene:
                    scene_infos = self.opt.scene_infos_list[sample_idx]
                    for scene_name, scene_value in scene_infos.items():
                        if scene_value in self.opt.filter_keys:
                            continue
                        self._scene_infer_buffers[scene_name][scene_value][
                            f"{mode}_truth"
                        ].append(truth[:, 0].view(-1, 1))
