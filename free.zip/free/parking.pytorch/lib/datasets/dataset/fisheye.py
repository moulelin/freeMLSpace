import numpy as np
import os
import time
import json

from .base_dataset import BaseDataset


labels_info = [
    {
        "name": "background",
        "id": 0,
        "color": [0, 0, 0],
        "train_id": 0,
    },
    {
        "name": "ego car",
        "id": 24,
        "color": [0, 0, 0],
        "train_id": 8,
    },
    {
        "name": "free space",
        "id": 25,
        "color": [0, 0, 0],
        "train_id": 9,
    },
    {
        "name": "wheel stop",
        "id": 1,
        "color": [255, 0, 102],
        "train_id": 9,
    },
    {
        "name": "speed bump",
        "id": 2,
        "color": [240, 240, 245],
        "train_id": 9,
    },
    {
        "name": "lane",
        "id": 3,
        "color": [255, 204, 0],
        "train_id": 9,
    },
    {
        "name": "wall",
        "id": 4,
        "color": [138, 138, 153],
        "train_id": 0,
    },
    {
        "name": "pillar",
        "id": 5,
        "color": [255, 153, 153],
        "train_id": 1,
    },
    {
        "name": "high obstacle",
        "id": 6,
        "color": [0, 245, 255],
        "train_id": 0,
    },
    {
        "name": "park lock open",
        "id": 7,
        "color": [30, 144, 255],
        "train_id": 0,
    },
    {
        "name": "park lock closed",
        "id": 8,
        "color": [255, 85, 0],
        "train_id": 9,
    },
    {
        "name": "vehicle",
        "id": 9,
        "color": [242, 0, 0],
        "train_id": 2,
    },
    {
        "name": "wheel",
        "id": 10,
        "color": [204, 0, 204],
        "train_id": 0,
    },
    {
        "name": "curb",
        "id": 11,
        "color": [255, 255, 0],
        "train_id": 3,
    },
    {
        "name": "pedestrian",
        "id": 12,
        "color": [0, 238, 0],
        "train_id": 4,
    },
    {
        "name": "drains",
        "id": 13,
        "color": [0, 100, 0],
        "train_id": 9,
    },
    {
        "name": "reflective stripe",
        "id": 14,
        "color": [255, 102, 255],
        "train_id": 255,
    },
    {
        "name": "others",
        "id": 15,
        "color": [140, 56, 0],
        "train_id": 255,
    },
    {
        "name": "vegetation",
        "id": 16,
        "color": [0, 56, 140],
        "train_id": 0,
    },
    {
        "name": "cone",
        "id": 17,
        "color": [56, 56, 10],
        "train_id": 5,
    },
    {
        "name": "ground arrow",
        "id": 18,
        "color": [140, 56, 0],
        "train_id": 9,
    },
    {
        "name": "enclosure",
        "id": 19,
        "color": [0, 140, 140],
        "train_id": 6,
    },
    {
        "name": "fallen pedestrian",
        "id": 20,
        "color": [0, 140, 220],
        "train_id": 4,
    },
    {
        "name": "animal",
        "id": 21,
        "color": [70, 80, 100],
        "train_id": 7,
    },
    {
        "name": "low obstacle",
        "id": 22,
        "color": [200, 80, 0],
        "train_id": 255,
    },
    {
        "name": "ignore",
        "id": 23,
        "color": [0, 0, 0],
        "train_id": 255,
    },
]


class FishEyeDataset(BaseDataset):
    def __init__(self, opt, mode):
        super(FishEyeDataset, self).__init__(opt, mode)

        self.label_ignore = opt.ignore_label
        self._label_map = np.arange(256).astype(np.uint8)
        self._labels_info = labels_info
        for el in self._labels_info:
            self._label_map[el["id"]] = el["train_id"]

        self._seg_map = {}
        for el in self._labels_info:
            self._seg_map[el["name"]] = el["id"]

        # self._crop_items = {"cone": [], "enclosure":[]}
        self._crop_items = {"enclosure": []}

        self._get_dataset()
        self.len = len(self.label_dict["image_list"])

    @property
    def label_dict(self):
        return self._label_dict

    @property
    def label_map(self):
        return self._label_map

    @property
    def labels_info(self):
        return self._labels_info

    @property
    def crop_items(self):
        return self._crop_items

    def _get_dataset(self):
        if self.mode == "train":
            datalist_dict = self.train_path_dict
        else:
            datalist_dict = self.test_path_dict

        print(datalist_dict)

        st = time.time()
        file_list = []
        for key in datalist_dict:
            if datalist_dict[key] in ["", " "]:
                continue
            with open(datalist_dict[key], "r") as f:
                lines = f.read().splitlines()
                file_list.extend(lines)
        # rm repeat
        lines = list(dict.fromkeys(file_list))
        lines.sort()
        et = time.time()
        print("read txt: ", et - st, flush=True)

        st = time.time()
        image_list = []
        resize_image_list = []
        label_seg_list = []
        for i, line in enumerate(lines):
            image_path = os.path.join(self.data_root, line).replace("(0)", "")
            resize_image_path = os.path.join(
                self.proc_root,
                line.replace("image", "resize_img").replace("jpg", "png"),
            )
            label_path = os.path.join(
                self.proc_root, line.replace("image", "label").replace("jpg", "png")
            )
            image_list.append(image_path)
            resize_image_list.append(resize_image_path)
            label_seg_list.append(label_path)

            # json_path = os.path.join(
            #     self.data_root, line.replace("image", "json").replace("jpg", "json")
            # )
            # self._get_crop_obj(json_path, resize_image_path, label_path)

        self._label_dict = dict(
            image_list=image_list,
            resize_image_list=resize_image_list,
            label_seg_list=label_seg_list,
        )
        et = time.time()
        print("init label", et - st, flush=True)

    def _get_crop_obj(self, json_path, img_path, seg_path):
        with open(json_path, "r") as f:
            results = json.load(f)["results"]

        for item in results:
            if "segmentation" not in item:
                continue
            if item["type"] not in self._crop_items:
                continue

            points = np.array(item["segmentation"])
            x1 = points[:, 0].min() / 1920 * self.opt.w_input
            x2 = points[:, 0].max() / 1920 * self.opt.w_input
            y1 = points[:, 1].min() / 1536 * self.opt.h_input
            y2 = points[:, 1].max() / 1536 * self.opt.h_input
            if (x2 - x1) * (y2 - y1) < 400:
                continue

            crop_item = {
                "box": [x1, y1, x2, y2],
                "img_path": img_path,
                "seg_path": seg_path,
                "seg_id": self._seg_map[item["type"]],
            }
            self._crop_items[item["type"]].append(crop_item)
            # points[:, 0] = points[:, 0] / 1920 * self.opt.w_input
            # points[:, 1] = points[:, 1] / 1536 * self.opt.h_input

    def __len__(self):
        return self.len
