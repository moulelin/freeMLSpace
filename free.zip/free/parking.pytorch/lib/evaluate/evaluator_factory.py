from .seg_evaluator import SegEvaluator
from .point_seg_evaluator import PointSegEvaluator
from .point_angle_seg_evaluator import PointAngleSegEvaluator
from .point_type_seg_evaluator import PointTypeSegEvaluator
from .point_type_seg_offset_evaluator import PointTypeSegOffsetEvaluator
from .point_mid_ws_evaluator import PointMidWSEvaluator
from .freespace_seg_evaluator import FreeSpaceSegEvaluator
from .fisheye_bev_evaluator import FisheyeBevEvaluator


evaluator_factory = {
    "parking_slot_seg": PointSegEvaluator,
    "parking_slot_point": PointSegEvaluator,
    "parking_slot_seg_angle": PointAngleSegEvaluator,
    "fisheye_seg": FreeSpaceSegEvaluator,
    "lidar_seg": SegEvaluator,
    "parking_slot_point_cls": PointTypeSegEvaluator,
    "parking_center_point_cls": PointTypeSegOffsetEvaluator,
    "parking_slot_mid_ws": PointMidWSEvaluator,
    "fisheye_bev_det": FisheyeBevEvaluator,
}


def create_evaluator(opt, decoder, dataset=None):
    get_evaluator = evaluator_factory[opt.task]
    evaluator = get_evaluator(opt, decoder, dataset)
    return evaluator
