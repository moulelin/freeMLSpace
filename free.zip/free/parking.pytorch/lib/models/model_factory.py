from .backbone.bisenetv2 import BiSeNetV2
from .backbone.hrnetv2 import HighResolutionNet
from .backbone.hrnetv2_lite import HighResolutionLiteNet
from .backbone.salsanext import SalsaNext
from .backbone.darknet import DarkNetEncoder
from .backbone.resnet import GeneralizedResNet
from .decode.parking_slot_seg_decode import ParkingSlotSegDecoder
from .decode.parking_slot_point_decode import ParkingSlotPointDecoder
from .decode.parking_slot_seg_angle_decode import ParkingSlotSegAngleDecoder
from .decode.parking_mid_point_cls_decode import ParkingMidPointClsDecoder
from .decode.fisheye_freespace_seg_decode import FishEyeFSSegDecoder
from .decode.lidar_seg_decode import LidarSegDecoder
from .decode.parking_slot_point_cls_decode import ParkingSlotPointClsDecoder
from .decode.parking_center_point_cls_decode import ParkingCenterPointClsDecoder
from .decode.parking_mid_ws_decode import ParkingMidWSDecoder
from .decode.fisheye_bev_det_decode import FishEyeBEVDetDecoder
from .head.parking_slot_seg_head import ParkingSlotSegHead
from .head.parking_slot_point_head import ParkingSlotPointHead
from .head.parking_slot_seg_angle_head import ParkingSlotSegAngleHead
from .head.fisheye_seg_head import FishEyeSegHead
from .head.fisheye_freespace_seg_head import FishEyeFSSegHead
from .head.lidar_seg_head import LidarSegHead
from .head.parking_slot_point_cls_head import ParkingSlotPointClsHead
from .head.parking_center_point_cls_head import ParkingCenterPointClsHead
from .head.parking_point_mid_cls_head import ParkingMidPointClsHead
from .head.parking_point_mid_ws_head import ParkingMidWSHead
from .head.fisheye_bev_det_head import FishEyeBevDetHead
from .head.fisheye_bev_height_det_head import FishEyeBevHeightDetHead


backbone_factory = {
    "bisenetv2": BiSeNetV2,
    "hrnet18": HighResolutionNet,
    "hrnet32": HighResolutionNet,
    "hrnet48": HighResolutionNet,
    "hrnet16_lite": HighResolutionLiteNet,
    "hrnet18_lite": HighResolutionLiteNet,
    "hrnet32_lite": HighResolutionLiteNet,
    "hrnet48_lite": HighResolutionLiteNet,
    "salsanext": SalsaNext,
    "yolo-m": DarkNetEncoder,
    "yolo-l": DarkNetEncoder,
    "resnet18": GeneralizedResNet,
}


decoder_factory = {
    "parking_slot_seg": ParkingSlotSegDecoder,
    "parking_slot_point": ParkingSlotPointDecoder,
    "parking_slot_seg_angle": ParkingSlotSegAngleDecoder,
    "lidar_seg": LidarSegDecoder,
    "parking_slot_point_cls": ParkingSlotPointClsDecoder,
    "parking_center_point_cls": ParkingCenterPointClsDecoder,
    "parking_slot_mid_point_cls": ParkingMidPointClsDecoder,
    "parking_slot_mid_ws": ParkingMidWSDecoder,
    "fisheye_bev_det": FishEyeBEVDetDecoder,
    "fisheye_freespace_seg": FishEyeFSSegDecoder,
}


head_factory = {
    "parking_slot_seg": ParkingSlotSegHead,
    "parking_slot_point": ParkingSlotPointHead,
    "parking_slot_seg_angle": ParkingSlotSegAngleHead,
    "fisheye_seg": FishEyeSegHead,
    "lidar_seg": LidarSegHead,
    "parking_slot_point_cls": ParkingSlotPointClsHead,
    "parking_center_point_cls": ParkingCenterPointClsHead,
    "parking_slot_mid_point_cls": ParkingMidPointClsHead,
    "parking_slot_mid_ws": ParkingMidWSHead,
    "fisheye_bev_det": FishEyeBevHeightDetHead,
    "fisheye_freespace_seg": FishEyeFSSegHead,
}


def create_model(opt, mode):
    get_backbone = backbone_factory[opt.backbone]
    backbone = get_backbone(opt, mode)

    get_decoder = decoder_factory[opt.decoder]
    decoder = get_decoder(opt)

    get_head = head_factory[opt.head]
    model = get_head(opt, backbone, decoder, mode)
    return model


def creat_decoder(opt):
    get_decoder = decoder_factory[opt.decoder]
    decoder = get_decoder(opt)
    return decoder
