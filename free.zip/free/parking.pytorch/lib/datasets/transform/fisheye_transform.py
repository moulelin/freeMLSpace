import cv2
import math
import numpy as np
import os
from PIL import Image


def make_gaussian_2d(ux, rx, uy, ry, yaw, w_output, h_output):
    x = np.arange(w_output)
    y = np.arange(h_output)
    X, Y = np.meshgrid(x, y)
    X = X - ux
    Y = Y - uy
    C = np.concatenate(
        (X.reshape(1, h_output, w_output), Y.reshape(1, h_output, w_output)), 0
    ).copy()
    C = C.reshape(2, -1)
    R = np.array([[math.cos(yaw), -math.sin(yaw)], [math.sin(yaw), math.cos(yaw)]])
    C1 = np.dot(R, C)
    C1 = C1.reshape(2, h_output, w_output)
    X = C1[0, :, :]
    Y = C1[1, :, :]
    expo = (X**2) / (rx**2) + (Y**2) / (ry**2)
    expo = expo * (-0.5)
    im = np.exp(expo)
    return im.reshape(h_output, w_output, 1)


class AddReflective(object):
    def __init__(
        self,
        p=0.2,
        min_r=10,
        max_r=80,
    ):
        self.p = p
        self.min_r = min_r
        self.max_r = max_r

        assert (
            self.max_r > self.min_r
        ), f"min_r must < max_r, but {self.min_r} > {self.max_r}"

    def __call__(self, image):
        if np.random.rand() > self.p:
            return image

        h, w, _ = image.shape

        g_w = np.random.randint(self.min_r, self.max_r, 1)
        g_h = np.random.randint(self.min_r, self.max_r, 1)

        ctr_x = np.random.randint(self.max_r, w - self.max_r, 1)
        ctr_y = np.random.randint(self.max_r, h - self.max_r, 1)

        yaw = np.random.randint(0, 45, 1)

        reflective_ratio = np.random.rand() * 0.5 + 0.7
        gaussian_map = (
            make_gaussian_2d(ctr_x, g_w, ctr_y, g_h, yaw, w, h) * reflective_ratio
        )
        gaussian_map = np.minimum(gaussian_map, 1.0)

        if np.random.rand() > 0.5:
            if np.random.rand() > 0.5:
                image = image * (1 - gaussian_map) + 255 * gaussian_map
            else:
                image = image * (1 - gaussian_map)
        else:
            ratio1 = np.random.rand() * 0.1
            ratio2 = np.random.rand() * 0.1
            if np.random.rand() > 0.5:
                gaussian_map = np.concatenate(
                    [gaussian_map, gaussian_map * ratio1, gaussian_map * ratio2], axis=2
                )
                image = image * (1 - gaussian_map) + 255 * gaussian_map
            elif np.random.rand() > 0.25:
                gaussian_map = np.concatenate(
                    [gaussian_map * ratio1, gaussian_map, gaussian_map * ratio2], axis=2
                )
                image = image * (1 - gaussian_map) + 255 * gaussian_map
            else:
                gaussian_map = np.concatenate(
                    [gaussian_map * ratio1, gaussian_map * ratio2, gaussian_map], axis=2
                )
                image = image * (1 - gaussian_map)
        return image


class AddObjInvert(object):
    def __init__(
        self,
        p=0.1,
        invert_cls_ids=[],
        freespace_id=25,
    ):
        self.p = p
        self.invert_cls_ids = invert_cls_ids
        self.freespace_id = freespace_id

    def __call__(self, image, seg):
        if np.random.rand() > self.p:
            return image

        invert_map = np.zeros(image.shape, dtype=image.dtype)
        gaussian_map_list = []
        freespace_mask = (seg == self.freespace_id) * 1.0
        for cls_id in self.invert_cls_ids:
            cls_mask = (seg == cls_id) * 1.0
            contours, _ = cv2.findContours(
                cls_mask.astype("uint8"), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE
            )  # opencv 4.1.2.30
            for i, contour in enumerate(contours):
                if np.random.rand() > self.p:
                    continue
                x1 = contour[:, 0, 0].min()
                y1 = contour[:, 0, 1].min()
                x2 = contour[:, 0, 0].max()
                y2 = contour[:, 0, 1].max()
                if (y2 - y1) * (x2 - x1) < 200:
                    continue
                crop_mask = cls_mask[y1 : y2 + 1, x1 : x2 + 1][:, :, None]
                crop_img = crop_mask * image[y1 : y2 + 1, x1 : x2 + 1, :].astype(
                    "uint8"
                )
                invert_img = crop_img[::-1, :, :]

                # resize
                scale = [0.7, 1.2]
                invert_w = int(
                    np.random.rand() * (scale[1] - scale[0])
                    + scale[0] * invert_img.shape[1]
                )
                invert_h = int(
                    np.random.rand() * (scale[1] - scale[0])
                    + scale[0] * invert_img.shape[0]
                )
                fill_x1 = x1
                fill_x2 = min(x1 + invert_w, image.shape[1] - 1)
                fill_y1 = min(y2 + 1, image.shape[0] - 1)
                fill_y2 = min(y2 + 1 + invert_h, image.shape[0] - 1)

                if (fill_x2 - fill_x1 + 1) < 10 or (fill_y2 - fill_y1 + 1) < 10:
                    continue
                ctr_x = (fill_x2 + fill_x1) // 2
                ctr_y = (fill_y2 + fill_y1) // 2
                gaussian_map = make_gaussian_2d(
                    ctr_x,
                    (fill_x2 - fill_x1 + 1) // 2,
                    ctr_y,
                    (fill_y2 - fill_y1 + 1) // 2,
                    0,
                    image.shape[1],
                    image.shape[0],
                )
                gaussian_map_list.append(gaussian_map)

                resized_invert_img = cv2.resize(
                    invert_img, (fill_x2 - fill_x1 + 1, fill_y2 - fill_y1 + 1)
                )
                resized_invert_img = cv2.blur(resized_invert_img, [5, 5])
                invert_map[
                    fill_y1 : fill_y2 + 1, fill_x1 : fill_x2 + 1, :
                ] = resized_invert_img

        if len(gaussian_map_list) > 0:
            gaussian_map = np.concatenate(gaussian_map_list, axis=2).max(
                axis=2, keepdims=True
            )
            invert_mask = (
                (invert_map.sum(axis=2, keepdims=True) > 0)
                * freespace_mask[:, :, None]
                * 1.0
            )

            image = (
                image * (1 - invert_mask)
                + image * invert_mask * (1 - gaussian_map * 0.5)
                + invert_map * invert_mask * gaussian_map * 0.5
            )

        return image


class AddEgoInvert(object):
    def __init__(
        self,
        p=0.1,
        ego_id=24,
    ):
        self.p = p
        self.ego_id = ego_id

    def __call__(self, image, seg):
        if np.random.rand() > self.p:
            return image

        h, w, _ = image.shape
        half_h = h // 2
        top_half = image[0:half_h, :, :]
        top_half_invert = top_half[::-1, :, :]
        if np.random.rand() < 0.5:
            top_half_invert = top_half_invert[:, ::-1, :]

        down_half_ego_mask = (seg == self.ego_id)[half_h:, :] * 1.0
        down_half_ego_mask = down_half_ego_mask[:, :, None]

        scale = 0.3 + np.random.rand() * 0.2

        if np.random.rand() < 0.5:
            ctr_x = w // 2
            ctr_y = h // 2
            w_r = np.random.randint(w // 8, w // 4)
            h_r = np.random.randint(h // 8, h // 4)

            gaussian_scale = 1.0 + np.random.rand()
            gaussian_map = make_gaussian_2d(
                ctr_x, w_r, ctr_y, h_r, 0, image.shape[1], image.shape[0]
            )
            half_gaussian_map = 1 - gaussian_map[half_h:, :, :] * gaussian_scale
            if np.random.rand() < 0.5:
                half_gaussian_map = (
                    (half_gaussian_map > 0.7) * 0.8 + 0.2
                ) * half_gaussian_map
            half_gaussian_map = np.maximum(half_gaussian_map, 0)
        else:
            half_gaussian_map = 1.0

        image[half_h:, :, :] = (
            image[half_h:, :, :] * (1 - down_half_ego_mask)
            + image[half_h:, :, :]
            * down_half_ego_mask
            * (1 - scale)
            * half_gaussian_map
            + top_half_invert * down_half_ego_mask * scale * half_gaussian_map
        )

        return image


class AddFreeSpace(object):
    def __init__(
        self,
        p=0.1,
        img_dir="/proc_data/parking/fisheye/hard_freespace",  # /mnt/data/data/fisheye/hard_freespace
    ):
        self.p = p
        self.img_dir = img_dir

    def __call__(self, image, seg):
        if np.random.rand() > self.p:
            return image

        img_names = os.listdir(self.img_dir)
        num_imgs = len(img_names)
        img_idx = int(np.random.randint(0, num_imgs, 1))
        img_path = os.path.join(self.img_dir, img_names[img_idx])
        freespace_img = cv2.imread(img_path)[:, :, ::-1]

        freespace_mask = (seg == 25) * 1.0
        new_fs_map = np.zeros(image.shape, dtype=image.dtype)
        # new_fs_map = image.copy()

        h, w, _ = image.shape

        x1 = int(np.random.randint(80, w - 200, 1))
        y1 = int(np.random.randint(80, h - 200, 1))

        # [0.9, 1.5]
        f_h, f_w, _ = freespace_img.shape
        f_h = int((np.random.rand() * 0.6 + 0.9) * f_h)
        f_w = int((np.random.rand() * 0.6 + 0.9) * f_w)
        freespace_img = cv2.resize(freespace_img, (f_w, f_h))

        x2 = x1 + f_w
        y2 = y1 + f_h
        delta_w = max(x2 - w, 0)
        delta_h = max(y2 - h, 0)

        new_fs_map[y1:y2, x1:x2, :] = freespace_img[
            0 : f_h - delta_h, 0 : f_w - delta_w, :
        ]
        new_fs_map = new_fs_map * freespace_mask[:, :, None]
        new_fs_mask = new_fs_map.sum(axis=2, keepdims=True) > 0
        new_image = (
            image * (1 - new_fs_mask) + image * new_fs_mask * 0.3 + new_fs_map * 0.7
        )

        # image = image * (1 - freespace_mask[:, :, None]) + freespace_img * freespace_mask[:, :, None]
        return new_image


class CopyAndPaste(object):
    def __init__(self, p=0.1, crop_items=[]):
        self.p = p
        self.crop_items = crop_items

    def __call__(self, image, seg):
        if np.random.rand() > self.p:
            return image

        np_image = image
        np_seg = seg
        for key in self.crop_items:
            if len(self.crop_items[key]) == 0:
                continue
            idx = int(np.random.randint(len(self.crop_items[key])))
            corp_img_path = self.crop_items[key][idx]["img_path"]
            corp_seg_path = self.crop_items[key][idx]["seg_path"]
            corp_seg_id = self.crop_items[key][idx]["seg_id"]
            corp_box = self.crop_items[key][idx]["box"]

            crop_img = cv2.imread(corp_img_path)
            crop_seg = np.array(Image.open(corp_seg_path))
            crop_mask = (crop_seg == corp_seg_id)[:, :, None] * 1.0

            crop_x1 = int(corp_box[0])
            crop_y1 = int(corp_box[1])
            crop_x2 = int(corp_box[2])
            crop_y2 = int(corp_box[3])
            copy_obj = crop_img[crop_y1 : crop_y2 + 1, crop_x1 : crop_x2 + 1, :]
            copy_mask = crop_mask[crop_y1 : crop_y2 + 1, crop_x1 : crop_x2 + 1, :]

            if np.random.rand() < 0.5:
                copy_obj = copy_obj[:, ::-1, :]
                copy_mask = copy_mask[:, ::-1, :]

            crop_h, crop_w, _ = copy_obj.shape
            x1 = int(np.random.randint(40, np_image.shape[1] - crop_w - 40, 1))
            y1 = int(np.random.randint(80, np_image.shape[0] - crop_h - 100, 1))

            x2 = x1 + crop_w
            y2 = y1 + crop_h

            if np_seg[y1, x1] == 24:
                continue
            if np_seg[y1, x2] == 24:
                continue
            if np_seg[y2, x2] == 24:
                continue
            if np_seg[y2, x1] == 24:
                continue

            np_image[y1 : y1 + crop_h, x1 : x1 + crop_w, :] = (
                np_image[y1 : y1 + crop_h, x1 : x1 + crop_w, :] * (1 - copy_mask)
                + copy_obj * copy_mask
            )
            np_seg[y1 : y1 + crop_h, x1 : x1 + crop_w] = (
                np_seg[y1 : y1 + crop_h, x1 : x1 + crop_w] * (1 - copy_mask[:, :, 0])
                + copy_mask[:, :, 0] * corp_seg_id
            )
        return np_image, np_seg
