import argparse
import os
from re import sub
import subprocess
import signal
import time
import traceback

import torch
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.utils import data

from lib.datasets.dataset_factory import get_dataset
from lib.models.model_factory import create_model, creat_decoder
from lib.models.loss_factory import create_loss
from lib.manager.trainer import Trainer
from lib.utils.common import init_opt
from tools.profiler import Profiler


def setup(gpu_rank, opt):
    opt.rank = opt.rank * opt.ngpus + gpu_rank
    dist.init_process_group(
        "nccl", init_method=opt.disturl, rank=opt.rank, world_size=opt.worldsize
    )
    print("rank/total: %d/%d" % (opt.rank, opt.worldsize))


def cleanup():
    dist.destroy_process_group()


def dist_train(rank, opt, decoder, profile_func=None):
    # 配置单机多卡
    if opt.profile and rank == 0:
        profile_func.add_node_profile("setup_env", "start")
    setup(rank, opt)
    if opt.profile and rank == 0:
        profile_func.add_node_profile("setup_env", "end")

    # init dataset
    if opt.profile and rank == 0:
        profile_func.add_node_profile("init_dataset", "start")

    Dataset = get_dataset(opt.task)

    trainset = Dataset(opt, "train")
    print("Train number: " + str(trainset.__len__()))
    valset = Dataset(opt, "val")
    print("Test number: " + str(valset.__len__()))
    train_sampler = torch.utils.data.distributed.DistributedSampler(trainset)
    val_sampler = torch.utils.data.distributed.DistributedSampler(valset)
    loader_train = data.DataLoader(
        trainset,
        batch_size=opt.train_batch,
        shuffle=False,
        num_workers=opt.workers,
        pin_memory=True,
        sampler=train_sampler,
        drop_last=True,
    )
    loader_val = data.DataLoader(
        valset,
        batch_size=opt.val_batch,
        shuffle=False,
        num_workers=opt.workers,
        pin_memory=False,
        sampler=val_sampler,
        drop_last=True,
    )
    if opt.profile and rank == 0:
        profile_func.add_node_profile("init_dataset", "end")

    print("initializing network...")
    if opt.profile and rank == 0:
        profile_func.add_node_profile("init_network", "start")
    model = create_model(opt, "train")
    torch.backends.cudnn.benchmark = True
    net = model.cuda(rank)
    criterion = create_loss(opt).cuda(rank)
    if opt.profile and rank == 0:
        profile_func.add_node_profile("init_network", "end")

    dist.barrier()

    trainer = Trainer(
        net,
        loader_train,
        loader_val,
        criterion,
        opt,
        rank,
        decoder,
        profiler=profile_func,
    )
    trainer.run()
    cleanup()


def get_parse():
    parser = argparse.ArgumentParser(description="Parking PyTorch Training")
    parser.add_argument(
        "--config", default="./configs/bev_freespace_seg.yaml", type=str, help="path to config"
        )
    parser.add_argument(
        "--ckpt_output", default="/test_output/hans/checkpoint", type=str, help="path to checkpoint"
        )
    parser.add_argument(
        "--log_output", default="/test_output/hans/runs", type=str, help="path to log"
        )
    parser.add_argument(
        "--result_output", default="/test_output/hans/result", type=str, help="file to save epoch result"
        )
    parser.add_argument("--train_datasets", default="", type=str, help="str of dict: path to train txt")
    parser.add_argument("--test_datasets", default="", type=str, help="str of dict: path to test txt")
    parser.add_argument(
        "--dataset_root", default="/test_data/hans/freespace_more_data", type=str, help="path to origin data"
        )
    parser.add_argument("--preprocess_root", default="", type=str, help="path to preprocess data")
    parser.add_argument("--resume", default="", type=str, help="path to resume train checkpoint")
    parser.add_argument("--debug", "-d", action="store_true", help="debug train")
    parser.add_argument("--profile", "-p", action="store_true", help="generate profile log")
    return parser


if __name__ == "__main__":

    opt = get_parse().parse_args()
    init_opt(opt)
    print(opt)
    ngpus = torch.cuda.device_count()
    opt.ngpus = ngpus
    opt.worldsize = opt.ngpus * opt.worldsize
    opt.onnx = 0

    # gpu profile
    if not os.path.exists(opt.log_output):
        os.makedirs(opt.log_output)

    if opt.profile:
        opt.profile_path = os.path.join(opt.log_output, "profile_log")
        cmd = f"exec python3 tools/profiler.py --log {opt.profile_path}"
        profile_process = subprocess.Popen(cmd, shell=True)
        print("profile subprocess pid: ", profile_process.pid)
        profile_func = Profiler(opt.ngpus, opt.profile_path)
    else:
        profile_process = None
        profile_func = None

    decoder = creat_decoder(opt)

    try:
        if opt.debug:
            print("DEBUG: TRAIN")
            dist_train(0, opt, decoder)
        else:
            mp.spawn(
                dist_train, args=(opt, decoder, profile_func), nprocs=ngpus, join=True
            )

        if opt.profile:
            profile_process.terminate()
            profile_process.wait()

    except Exception as e:
        traceback.print_exc()
        if opt.profile:
            os.killpg(os.getpgid(profile_process.pid), signal.SIGTERM)
