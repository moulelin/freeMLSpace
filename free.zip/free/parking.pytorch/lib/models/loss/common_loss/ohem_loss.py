import math

import torch
import torch.nn as nn


class OhemCELoss(nn.Module):
    def __init__(self, thresh, ignore_label, norm_value, reduction="none", weight=None):
        super(OhemCELoss, self).__init__()
        self.thresh = -math.log(thresh)
        self.ignore_label = ignore_label
        self.norm_value = norm_value
        self.reduction = reduction
        self.criteria = nn.CrossEntropyLoss(
            ignore_index=self.ignore_label,
            reduction="none",
            weight=weight,
        )

    def forward(self, pred, truth):
        n_min = truth[truth != self.ignore_label].numel() // self.norm_value
        loss = self.criteria(pred, truth).view(-1)
        loss_hard = loss[loss > self.thresh]
        if loss_hard.numel() < n_min:
            loss_hard, _ = loss.topk(n_min)

        if self.reduction == "mean":
            loss = torch.mean(loss_hard)
        elif self.reduction == "sum":
            loss = torch.sum(loss_hard)
        else:
            loss = loss_hard
        return loss
