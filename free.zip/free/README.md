# Parking Train Codebase
This codebase includes parking_slot detection, fisheye segmentation and lidar segmentation. You can train these model by setting configs.

## Train
```
cd parking.pytorch
python3 train.py \
    --config ./configs/{task}.yaml \ 
    --train_datasets '{"train":"DATA_PATH/train_list.txt"}' \ # you can set this in your config
    --test_datasets '{"test":"DATA_PATH/test_list.txt"}' \    # you can set this in your config
    --dataset_root DATA_ROOT \                                # you can set this in your config
    --ckpt_output SAVE_PATH/checkpoint/ \
    --log_output SAVE_PATH/log
```
## Eval
```
cd parking.pytorch
python3 eval.py \
    --config ./configs/{task}.yaml \ 
    --test_datasets '{"test":"DATA_PATH/test_list.txt"}' \    # you can set this in your config
    --dataset_root DATA_ROOT \                                # you can set this in your config
    --pth PYTORCH_MODEL_PATH
```
## Vis
```
cd parking.pytorch
python3 test_imgs.py \
    --config ./configs/{task}.yaml \ 
    --test_datasets '{"test":"DATA_PATH/test_list.txt"}' \    # you can set this in your config
    --dataset_root DATA_ROOT \                                # you can set this in your config
    --pth PYTORCH_MODEL_PATH \
    --save_path SAVE_PATH
```



