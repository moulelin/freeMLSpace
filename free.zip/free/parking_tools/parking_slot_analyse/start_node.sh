source /zdrive/perception/modules/parking/parkingslot/env_x86.sh

export GLOG_log_dir=/zdrive/log
export GLOG_logtostderr=0
export GLOG_colorlogtostderr=1
export GLOG_minloglevel=0
export GLOG_alsologtostderr=1
export GLOG_v=0

cd /zdrive/install/x86_64/
./perception/parking_slot/bin/percp_parking_slot