import torch.nn as nn
import torch.optim as optim


def get_parking_slot_seg_optimizer(model, opt):
    (
        wd_params,
        nowd_params,
        lr_mul10_wd_params,
        lr_mul10_nowd_params,
        lr_mul2_wd_params,
        lr_mul2_nowd_params,
    ) = model.get_params()
    wd_val = 0
    params_list = [
        {
            "params": wd_params,
        },
        {"params": nowd_params, "weight_decay": wd_val},
        {"params": lr_mul10_wd_params, "lr": opt.lr_base * 10},
        {
            "params": lr_mul10_nowd_params,
            "weight_decay": wd_val,
            "lr": opt.lr_base * 10,
        },
        {"params": lr_mul2_wd_params, "lr": opt.lr_base * 2},
        {"params": lr_mul2_nowd_params, "weight_decay": wd_val, "lr": opt.lr_base * 2},
    ]
    if opt.adam:
        optimizer = optim.Adam(
            params_list,
            lr=opt.lr_base,
            betas=(opt.momentum, 0.999),
            weight_decay=opt.weight_decay,
        )
    else:
        optimizer = optim.SGD(
            params_list,
            lr=opt.lr_base,
            momentum=opt.momentum,
            weight_decay=opt.weight_decay,
        )
    return optimizer


optim_factory = {
    "parking_slot_seg": get_parking_slot_seg_optimizer,
    "parking_slot_point": get_parking_slot_seg_optimizer,
    "parking_slot_seg_angle": get_parking_slot_seg_optimizer,
    "fisheye_seg": get_parking_slot_seg_optimizer,
    "lidar_seg": get_parking_slot_seg_optimizer,
    "parking_slot_point_cls": get_parking_slot_seg_optimizer,
    "parking_slot_mid_point_cls": get_parking_slot_seg_optimizer,
    "parking_slot_mid_ws": get_parking_slot_seg_optimizer,
}


def make_optimizer(model, opt):
    optimizer_func = optim_factory.get(opt.optimizer, get_parking_slot_seg_optimizer)
    return optimizer_func(model, opt)
