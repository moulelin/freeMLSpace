from sqlite3 import DateFromTicks
from tracemalloc import start
import matplotlib.pyplot as plt
import matplotlib.dates as mdate
import datetime
import argparse
import math
import re
import numpy as np
from reader import Reader

parser = argparse.ArgumentParser(description='analyse parking_slot from rosbag')
parser.add_argument('--bag_file', default='', type=str, help='bag path')
parser.add_argument('--slot_id', default=0, type=int, help='slot id')
parser.add_argument('--parking_only', default=0, type=int, help='draw slot curve line only when apa_state=parking')
opt = parser.parse_args()

apa_state = {"OFF": 0, "INITIAL": 1, "STANDBY": 2, "SEARCH": 3, "PREPARK": 4, "PARKING": 5}

class AnalyseRosbag(object):
    def __init__(self, bag_file, slot_id):
        self.bag_file = bag_file
        self.slot_id = slot_id
        self.ego_tf = []
        self.parking_slot = []
        self.fsm_state = []
        self.reader = Reader(self.bag_file)
        
        
    def read_topic(self):
        for topic, msg, t in self.reader.read_messages():
            if topic == "/loc/ego_tf_relative":
                self.ego_tf.append([datetime.datetime.fromtimestamp(t * 1e-9), msg])
            elif topic == "/pnc/fsm_state": 
                self.fsm_state.append([datetime.datetime.fromtimestamp(t * 1e-9), msg])
            elif topic == "/percp/parking_slot":
                self.parking_slot.append([datetime.datetime.fromtimestamp(t * 1e-9), msg])

        self.ego_tf.sort(key=takeFirst)
        self.fsm_state.sort(key=takeFirst)
        self.parking_slot.sort(key=takeFirst)
        if opt.parking_only == 1:
            self.select_since_parking()
    
    
    def analyse_data(self):
        self.analyse_slot_data()
        self.analyse_ego_tf_data()
        
    
    def draw_result(self):
        self.draw_ego_tf_result()
        self.draw_slot_result()
        plt.show()
        
    
    def analyse_slot_data(self):
        self.slot_timestamp = []
        self.c0_x = []
        self.c0_y = []
        self.c1_x = []
        self.c1_y = []
        self.slot_width = []
        self.slot_theta = []
        self.ws_dis = []
        self.ws_timestamp = []
        last_theta = 0
        for (t, msg) in self.parking_slot:   
            for slot in msg.apa_slots:
                if slot.id == self.slot_id:
                    self.slot_timestamp.append(t)
                    corners = slot.slot_points
                    ws = slot.block_points
                    self.c0_x.append(corners[0].x)
                    self.c0_y.append(corners[0].y)
                    self.c1_x.append(corners[1].x)
                    self.c1_y.append(corners[1].y)
                    width = math.sqrt((corners[0].x - corners[1].x) ** 2 + (corners[0].y - corners[1].y) ** 2)
                    self.slot_width.append(width)
                    theta = math.atan2(corners[3].y - corners[0].y, corners[3].x - corners[0].x) / math.pi * 180
                    if theta - last_theta > 180:
                        theta -= 360
                    elif theta - last_theta < -180:
                        theta += 360
                    last_theta = theta
                    self.slot_theta.append(theta)
                    cls = slot.type
                    if len(ws) > 0:
                        point = [corners[0].x + (corners[1].x - corners[0].x) / 2, corners[0].y + (corners[1].y - corners[0].y) / 2]
                        if cls == 1:
                            point = [corners[1].x + (corners[2].x - corners[1].x) / 2, corners[1].y + (corners[2].y - corners[1].y) / 2]
                        line = [ws[0].x, ws[0].y, ws[1].x, ws[1].y]
                        ws_dis = get_distance_point2line(point, line)
                        self.ws_dis.append(ws_dis)
                        self.ws_timestamp.append(t)
                   
                
    def analyse_ego_tf_data(self):
        self.ego_tf_timestamp = [elem[0] for elem in self.ego_tf]
        self.fsm_state_timestamp = [elem[0] for elem in self.fsm_state]
        self.odom_x = []
        self.odom_y = []
        self.ego_tf_status = []
        self.apa_state = []
        for (_, msg) in self.ego_tf:
            self.odom_x.append(msg.x)
            self.odom_y.append(msg.y)
            self.ego_tf_status.append(msg.status)
        for (_, msg) in self.fsm_state:
            self.apa_state.append(msg.apa_state)
    
    
    def select_since_parking(self):
        start_ind = -1
        for ind, (_, msg) in enumerate(self.fsm_state):
            if msg.apa_state == apa_state["PARKING"] and msg.selected_slot_id == self.slot_id:
                start_ind = ind
                break
        if start_ind < 0:
            print("No select slot id in this slice!")
            exit(0)
        start_timestamp = self.fsm_state[start_ind][0]
        start_ind = -1
        for ind, (t, _) in enumerate(self.parking_slot):
            if (t > start_timestamp):
                start_ind = ind
                break
        if start_ind < 0:
            print("timestamp is wrong!")
            exit(0)
        self.parking_slot = self.parking_slot[start_ind:]
        
        
    def draw_ego_tf_result(self):
        fig,axes = plt.subplots(nrows=2, ncols=2)
        fig.tight_layout()
        axes[0, 0].plot(self.ego_tf_timestamp, self.odom_x, label="odom_x", color="r", alpha=1, linewidth=1)
        axes[0, 0].legend()
        axes[0, 0].set_title("odom_x")
        axes[0, 0].set_xlabel("timestamp(s)")
        axes[0, 0].set_ylabel("position(m)")
        axes[0, 0].grid()
        
        axes[0, 1].plot(self.ego_tf_timestamp, self.odom_y, label="odom_y", color="r", alpha=1, linewidth=1)
        axes[0, 1].legend()
        axes[0, 1].set_title("odom_y")
        axes[0, 1].set_xlabel("timestamp(s)")
        axes[0, 1].set_ylabel("position(m)")
        axes[0, 1].grid()
        
        axes[1, 0].plot(self.ego_tf_timestamp, self.ego_tf_status, label="ego_tf_status", color="r", alpha=1, linewidth=1)
        axes[1, 0].legend()
        axes[1, 0].set_title("ego_tf_status")
        axes[1, 0].set_xlabel("timestamp(s)")
        axes[1, 0].set_ylabel("status")
        axes[1, 0].grid()
        
        axes[1, 1].plot(self.fsm_state_timestamp, self.apa_state, label="apa_state", color="r", alpha=1, linewidth=1)
        axes[1, 1].legend()
        axes[1, 1].set_title("apa_state")
        axes[1, 1].set_xlabel("timestamp(s)")
        axes[1, 1].set_ylabel("status")
        axes[1, 1].grid()
    
    
    def draw_slot_result(self):
        fig,axes = plt.subplots(nrows=4, ncols=2)
        fig.tight_layout()
        
        axes[0, 0].plot(self.slot_timestamp, self.c0_x, label="c0_x", color="r", alpha=1, linewidth=1)
        axes[0, 0].legend()
        axes[0, 0].set_title("c0_x")
        axes[0, 0].set_xlabel("timestamp(s)")
        axes[0, 0].set_ylabel("position(m)")
        axes[0, 0].grid()
        
        axes[0, 1].plot(self.slot_timestamp, self.c0_y, label="c0_y", color="r", alpha=1, linewidth=1)
        axes[0, 1].legend()
        axes[0, 1].set_title("c0_y")
        axes[0, 1].set_xlabel("timestamp(s)")
        axes[0, 1].set_ylabel("position(m)")
        axes[0, 1].grid()
        
        axes[1, 0].plot(self.slot_timestamp, self.c1_x, label="c1_x", color="r", alpha=1, linewidth=1)
        axes[1, 0].legend()
        axes[1, 0].set_title("c1_x")
        axes[1, 0].set_xlabel("timestamp(s)")
        axes[1, 0].set_ylabel("position(m)")
        axes[1, 0].grid()  
        
        axes[1, 1].plot(self.slot_timestamp, self.c1_y, label="c1_y", color="r", alpha=1, linewidth=1)
        axes[1, 1].legend()
        axes[1, 1].set_title("c1_y")
        axes[1, 1].set_xlabel("timestamp(s)")
        axes[1, 1].set_ylabel("position(m)")
        axes[1, 1].grid()  
        
        axes[2, 0].plot(self.slot_timestamp, self.slot_width, label="slot_width", color="r", alpha=1, linewidth=1)
        axes[2, 0].legend()
        axes[2, 0].set_title("slot_width")
        axes[2, 0].set_xlabel("timestamp(s)")
        axes[2, 0].set_ylabel("width(m)")
        axes[2, 0].grid() 
        
        axes[2, 1].plot(self.slot_timestamp, self.slot_theta, label="slot_theta", color="r", alpha=1, linewidth=1)
        axes[2, 1].legend()
        axes[2, 1].set_title("slot_theta")
        axes[2, 1].set_xlabel("timestamp(s)")
        axes[2, 1].set_ylabel("theta(degree)")
        axes[2, 1].grid()  
        
        axes[3, 0].plot(self.ws_timestamp, self.ws_dis, label="ws_dis", color="r", alpha=1, linewidth=1)
        axes[3, 0].legend()
        axes[3, 0].set_title("ws_dis")
        axes[3, 0].set_xlabel("timestamp(s)")
        axes[3, 0].set_ylabel("dis(m)")
        axes[3, 0].grid()
       

def takeFirst(elem):
    return elem[0]

def get_distance_point2line(point, line):
    """
    Args:
        point: [x0, y0]
        line: [x1, y1, x2, y2]
    """
    line_point1, line_point2 = np.array(line[0:2]), np.array(line[2:])
    vec1 = line_point1 - point
    vec2 = line_point2 - point
    distance = np.abs(np.cross(vec1, vec2)) / np.linalg.norm(line_point1 - line_point2)
    return distance

if __name__ == '__main__':
    analyser = AnalyseRosbag(opt.bag_file, opt.slot_id)
    analyser.read_topic()
    analyser.analyse_data()
    analyser.draw_result()
