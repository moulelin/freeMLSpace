import cv2

import torch
import torch.nn as nn
import torch.nn.functional as F

from .common_loss.ohem_loss import OhemCELoss
from .common_loss.focal_loss import CenterFocalLoss, FocalLoss
from .common_loss.dice_loss import MultiClassDiceLoss, DiceLoss
from .common_loss.lovasz_softmax import Lovasz_softmax


class SegLoss(nn.Module):
    def __init__(self, opt):
        super(SegLoss, self).__init__()
        self.opt = opt
        self.ohemce_loss = OhemCELoss(
            thresh=self.opt.thresh_ohem,
            ignore_label=self.opt.ignore_label,
            norm_value=self.opt.n_cats - 1,
            reduction="mean",
        )
        self.multi_dice_loss = DiceLoss(
            num_class=self.opt.n_cats,
            ignore_label=self.opt.ignore_label,
        )
        # self.ls = Lovasz_softmax(ignore=self.opt.ignore_label)

    def forward(self, pred, truth):
        loss_logits = self.ohemce_loss(pred["logits"], truth)
        loss_dice = self.multi_dice_loss(pred["logits"], truth)
        # loss_lovasz = self.ls(pred["logits"], truth)

        d_truth = (
            F.interpolate(truth.float().unsqueeze(1), scale_factor=0.125)
            .squeeze(1)
            .long()
        )

        loss_logits_aux2 = self.ohemce_loss(pred["logits_aux2"], d_truth)
        loss_logits_aux3 = self.ohemce_loss(pred["logits_aux3"], d_truth)
        loss_logits_aux4 = self.ohemce_loss(pred["logits_aux4"], d_truth)
        loss_logits_aux5 = self.ohemce_loss(pred["logits_aux5"], d_truth)
        loss = (
            loss_logits
            + loss_dice
            + loss_logits_aux2
            + loss_logits_aux3
            + loss_logits_aux4
            + loss_logits_aux5
            # + loss_lovasz
        )
        loss_tags = {
            "seg_loss": loss_logits.clone().detach().cpu().numpy(),
            "dice_loss": loss_dice.clone().detach().cpu().numpy(),
            "aux0_loss": loss_logits_aux2.clone().detach().cpu().numpy(),
            "aux1_loss": loss_logits_aux3.clone().detach().cpu().numpy(),
            "aux2_loss": loss_logits_aux4.clone().detach().cpu().numpy(),
            "aux3_loss": loss_logits_aux5.clone().detach().cpu().numpy(),
            # "lovasz_loss": loss_lovasz.clone().detach().cpu().numpy(),
        }
        return loss, loss_tags


class PointLoss(nn.Module):
    def __init__(self, opt):
        super(PointLoss, self).__init__()
        self.opt = opt
        self.pred_len = 4
        self.focal_cls = CenterFocalLoss(alpha=4, beta=2)
        self.F1off = nn.SmoothL1Loss()
        self.mse_loss = nn.MSELoss()
        self.bce = nn.BCEWithLogitsLoss()

        self.w_map = self.opt.loss_point_weight_dict["w_map"]
        self.w_mse = self.opt.loss_point_weight_dict["w_mse"]
        self.w_cls = self.opt.loss_point_weight_dict["w_cls"]
        self.w_off = self.opt.loss_point_weight_dict["w_off"]

    def forward(self, pred, truth):
        device = pred.device
        lcls, loff = torch.zeros(1, device=device), torch.zeros(1, device=device)
        pred = pred.permute(0, 2, 3, 1).contiguous().view(-1, self.pred_len)
        truth = truth.view(-1, self.pred_len)

        pmap = pred[:, 0:1].float().sigmoid()
        pcls = pred[:, 1:2].float()
        poff = pred[:, 2:4].float().sigmoid()

        tmap = truth[:, 0:1]
        tcls = truth[:, 1:2]
        toff = truth[:, 2:4]

        l_map = self.focal_cls(pmap, tmap)
        l_mse = self.mse_loss(pmap, tmap)

        mask = tmap[:, 0].eq(1)
        if mask.sum() > 0:
            lcls = self.bce(pcls[mask].view(-1), tcls[mask].view(-1))
            loff = self.F1off(poff[mask], toff[mask])

        l_map = l_map * self.w_map
        l_mse = l_mse * self.w_mse
        lcls = lcls * self.w_cls
        loff = loff * self.w_off

        loss = l_map + l_mse + lcls + loff

        loss_tags = {
            "point_map": l_map.clone().detach().cpu().numpy(),
            "point_mse": l_mse.clone().detach().cpu().numpy(),
            "point_cls": lcls.clone().detach().cpu().numpy(),
            "point_off": loff.clone().detach().cpu().numpy(),
            "point_loss": loss.clone().detach().cpu().numpy(),
        }
        return loss, loss_tags


class CenterLoss(nn.Module):
    def __init__(self, opt):
        super(CenterLoss, self).__init__()
        self.opt = opt
        self.pred_len = 7
        self.gt_len = 5
        self.focal_cls = CenterFocalLoss(alpha=4, beta=2)
        self.F1off = nn.SmoothL1Loss()
        self.mse_loss = nn.MSELoss()
        self.bce = nn.BCEWithLogitsLoss()
        # self.ce = nn.CrossEntropyLoss(ignore_index=self.opt.ignore_label)
        self.fl = FocalLoss(
            class_num=len(self.opt.slot_type),
            alpha=self.opt.type_weights["alpha"],
            gamma=self.opt.type_weights["gamma"],
            ignore_label=self.opt.ignore_label,
        )

        self.w_map = self.opt.loss_center_weight_dict["w_map"]
        self.w_mse = self.opt.loss_center_weight_dict["w_mse"]
        self.w_cls = self.opt.loss_center_weight_dict["w_cls"]
        self.w_off = self.opt.loss_center_weight_dict["w_off"]
        self.w_type = self.opt.loss_center_weight_dict["w_type"]

    def forward(self, pred, truth):
        device = pred.device
        lcls, loff, ltype = (
            torch.zeros(1, device=device),
            torch.zeros(1, device=device),
            torch.zeros(1, device=device),
        )
        pred = pred.permute(0, 2, 3, 1).contiguous().view(-1, self.pred_len)
        truth = truth.view(-1, self.gt_len)

        pmap = pred[:, 0:1].sigmoid()
        pcls = pred[:, 1:2]
        poff = pred[:, 2:4].sigmoid()
        ptype = pred[:, 4:7]

        tmap = truth[:, 0:1]
        tcls = truth[:, 1:2]
        toff = truth[:, 2:4]
        ttype = truth[:, 4].long()

        l_map = self.focal_cls(pmap, tmap)
        l_mse = self.mse_loss(pmap, tmap)

        mask = tmap[:, 0].eq(1)
        if mask.sum() > 0:

            sample_pcls = pcls[mask].view(-1)
            sample_tcls = tcls[mask].view(-1)
            cls_mask = sample_tcls.not_equal(self.opt.ignore_label)

            if cls_mask.sum() > 0:
                lcls = self.bce(sample_pcls[cls_mask], sample_tcls[cls_mask])

            loff = self.F1off(poff[mask], toff[mask])
            ltype = self.fl(ptype[mask], ttype[mask])

        l_map = l_map * self.w_map
        l_mse = l_mse * self.w_mse
        lcls = lcls * self.w_cls
        loff = loff * self.w_off
        ltype = ltype * self.w_type

        loss = l_map + l_mse + lcls + loff + ltype

        loss_tags = {
            "center_map": l_map.clone().detach().cpu().numpy(),
            "center_mse": l_mse.clone().detach().cpu().numpy(),
            "center_cls": lcls.clone().detach().cpu().numpy(),
            "center_off": loff.clone().detach().cpu().numpy(),
            "center_type": ltype.clone().detach().cpu().numpy(),
            "center_loss": loss.clone().detach().cpu().numpy(),
        }
        return loss, loss_tags


class ParkingSlotPointClsLoss(nn.Module):
    def __init__(self, opt):
        super(ParkingSlotPointClsLoss, self).__init__()
        self.opt = opt
        self.seg_loss = SegLoss(self.opt)
        self.point_loss = PointLoss(self.opt)
        self.center_loss = CenterLoss(self.opt)
        self.w_seg = self.opt.w_seg
        self.w_point = self.opt.w_point
        self.w_center = self.opt.w_center

    def forward(self, pred, truth):
        point_pred, center_pred, seg_pred = pred
        loss_point, point_tags = self.point_loss(point_pred, truth["label_point"])
        loss_center, center_tags = self.center_loss(center_pred, truth["label_center"])
        loss_seg, seg_tags = self.seg_loss(seg_pred, truth["label_seg"])
        loss = (
            loss_point * self.w_point
            + loss_center * self.w_center
            + loss_seg * self.w_seg
        )
        loss_tags = {**point_tags, **center_tags, **seg_tags}
        loss_tags["loss"] = (
            loss_tags["seg_loss"] + loss_tags["point_loss"] + loss_tags["center_loss"]
        )
        return loss, loss_tags
