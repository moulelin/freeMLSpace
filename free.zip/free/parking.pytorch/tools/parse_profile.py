import argparse
import os
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = ["SimHei"]


def get_parse():
    parser = argparse.ArgumentParser(description="Profiler")
    parser.add_argument(
        "--log", default="./profile_log", type=str, help="path to save_log"
    )
    parser.add_argument("--save_path", default="./", type=str, help="path to save vis")
    return parser


if __name__ == "__main__":
    opt = get_parse().parse_args()

    if not os.path.exists(opt.save_path):
        os.makedirs(opt.save_path)

    with open(opt.log, "r") as f:
        lines = [line.strip("\n") for line in f.readlines()]
    print(lines[0])

    first_time = float(lines[0].split(" ")[0].split(":")[-1])
    print(first_time)

    gpu_mem_rates = []
    gpu_util_rates = []
    gpu_time_list = []

    io_read_values = []
    io_write_values = []
    io_time_list = []

    train_epochs = []
    val_epochs = []
    train_iters = []
    val_iters = []

    first_batch_list = []
    begin_infer_list = []

    for line in lines:
        items = line.split(" ")
        cur_time = float(items[0].split(":")[-1])
        if "gpu_memory_rate" in line and "gpu_util_rate" in line:
            # if len(train_epochs) == 0:
            #     continue
            for item in items:
                if "gpu_memory_rate" in item:
                    gpu_mem_rates.append(float(item.split(":")[-1]))
                if "gpu_util_rate" in item:
                    gpu_util_rates.append(float(item.split(":")[-1]))
            gpu_time_list.append(cur_time - first_time)

        if "read_speed" in line and "write_speed" in line:
            for item in items:
                if "read_speed" in item:
                    io_read_values.append(float(item.split(":")[-1]))
                if "write_speed" in item:
                    io_write_values.append(float(item.split(":")[-1]))
            io_time_list.append(cur_time - first_time)

        if "train_epoch" in line:
            train_epochs.append(cur_time - first_time)

        if "val_epoch" in line:
            val_epochs.append(cur_time - first_time)

        if "train_iter:end" in line:
            train_iters.append(cur_time - first_time)

        if "val_iter:end" in line:
            val_iters.append(cur_time - first_time)

        if "first_batch:start" in line:
            first_batch_list.append(cur_time - first_time)

        if "begin_infer:start" in line:
            begin_infer_list.append(cur_time - first_time)

    plt.figure()
    # gpu_mem_rate
    plt.subplot(3, 1, 1)
    plt.plot(gpu_time_list, gpu_mem_rates)

    # if len(train_epochs) > 0:
    #     train_epoch_y = np.zeros(len(train_epochs)).tolist()
    #     plt.scatter(train_epochs, train_epoch_y, c="r")

    #     for i in range(len(train_epochs)):
    #         cur_epoch = i // 2
    #         plt.text(train_epochs[i], 10, f"e{cur_epoch}")

    # val_epoch_y = np.zeros(len(val_epochs)).tolist()
    # plt.scatter(val_epochs, val_epoch_y, c="c")

    # train_iter_y = np.zeros(len(train_iters)).tolist()
    # plt.scatter(train_iters, train_iter_y, c=[0, 0, 0])

    # val_iter_y = np.zeros(len(val_iters)).tolist()
    # plt.scatter(val_iters, val_iter_y, c="c")

    # if len(first_batch_list) > 0:
    #     first_batch_y = np.zeros(len(first_batch_list)).tolist()
    #     plt.scatter(first_batch_list, first_batch_y, c="g")

    # begin_infer_y = np.zeros(len(begin_infer_list)).tolist()
    # plt.scatter(begin_infer_list, begin_infer_y, c="c")

    plt.title("gpu_men_rate")
    plt.xlabel("time/s")
    plt.ylabel("rate/%")

    # gpu_util_rate
    plt.subplot(3, 1, 3)
    plt.plot(gpu_time_list, gpu_util_rates)

    # if len(train_epochs) > 0:
    #     train_epoch_y = np.zeros(len(train_epochs)).tolist()
    #     plt.scatter(train_epochs, train_epoch_y, c="r")

    #     for i in range(len(train_epochs)):
    #         cur_epoch = i // 2
    #         plt.text(train_epochs[i], 10, f"e{cur_epoch}")

    # val_epoch_y = np.zeros(len(val_epochs)).tolist()
    # plt.scatter(val_epochs, val_epoch_y, c="c")

    # train_iter_y = np.zeros(len(train_iters)).tolist()
    # plt.scatter(train_iters, train_iter_y, c="c")

    # val_iter_y = np.zeros(len(val_iters)).tolist()
    # plt.scatter(val_iters, val_iter_y, c="c")

    # if len(first_batch_list) > 0:
    #     first_batch_y = np.zeros(len(first_batch_list)).tolist()
    #     plt.scatter(first_batch_list, first_batch_y, c="g")

    # begin_infer_y = np.zeros(len(begin_infer_list)).tolist()
    # plt.scatter(begin_infer_list, begin_infer_y, c="c")

    plt.title("gpu_util_rate")
    plt.xlabel("time/s")
    plt.ylabel("rate/%")

    plt.savefig(os.path.join(opt.save_path, "./gpu_profile.jpg"))
    plt.close()

    plt.figure()
    # io_read_values
    plt.subplot(3, 1, 1)
    plt.plot(io_time_list, io_read_values)

    plt.title("io_write")
    plt.xlabel("time/s")
    plt.ylabel("value/Mb")

    # io_write_values
    plt.subplot(3, 1, 3)
    plt.plot(io_time_list, io_write_values)

    plt.title("io_read")
    plt.xlabel("time/s")
    plt.ylabel("value/Mb")

    plt.savefig(os.path.join(opt.save_path, "./io_profile.jpg"))
    plt.close()
