import os
import cv2
import numpy as np
import json
import argparse
import sys
from tqdm import tqdm

sys.path.insert(0, "../")
from lib.datasets.dataset.parking_slot import labels_info


parser = argparse.ArgumentParser(description="Make Parking Slot Segmentation Label")
parser.add_argument("--is_preprocess", default=1, type=int, help="is generate label")
parser.add_argument(
    "--train_datasets",
    default="{}",
    type=str,
    help="str of dict include path to train txt",
)
parser.add_argument(
    "--test_datasets",
    default="{}",
    type=str,
    help="str of dict include path to test txt",
)
parser.add_argument(
    "--dataset_root",
    default="/data/perception/datasets",
    type=str,
    help="path to origin data",
)
parser.add_argument(
    "--preprocess_root",
    default="/proc_data/perception/datasets",
    type=str,
    help="path to preprocess data",
)
parser.add_argument("--check_label", default=0, type=int, help="check label or not")
parser.add_argument("--thickness", default=8, type=int, help="thickness of slot line")
parser.add_argument(
    "--force", action="store_true", help="force makeing preprocess for each image"
)
opt = parser.parse_args()


color_infos = {}
id_infos = {}
for info in labels_info:
    name = info["name"]
    color_infos[name] = info["color"]
    id_infos[name] = info["id"]


class MakeSegTrainLabel(object):
    def __init__(self, opt):
        self.opt = opt
        self.force = opt.force
        self.ignore_label = 255
        self.train_list_dict = eval(opt.train_datasets)
        self.test_list_dict = eval(opt.test_datasets)
        self.data_root = opt.dataset_root
        self.proc_root = opt.preprocess_root
        self.check_label = opt.check_label
        self.thickness = opt.thickness
        self.w = 800
        self.h = 800
        self.ego_car_pos = np.array([[348, 274], [452, 526]], dtype=np.int32)

    def get_data_list(self):
        image_list = []
        json_list = []
        lable_list = []

        # train
        file_list = []
        for key in self.train_list_dict:
            if self.train_list_dict[key] in ["", " "]:
                continue
            with open(self.train_list_dict[key], "r") as f:
                lines = f.read().splitlines()
                file_list.extend(lines)
        # rm repeat
        lines = list(dict.fromkeys(file_list))
        print("train data num: ", len(lines))

        for line in lines:
            image_sub_path = line
            json_sub_path = line.replace("image", "json").replace("png", "json")
            label_sub_path = line.replace("image", "label")
            image_list.append(os.path.join(self.data_root, image_sub_path))
            json_list.append(os.path.join(self.data_root, json_sub_path))
            lable_list.append(os.path.join(self.proc_root, label_sub_path))

        # test
        # train
        file_list = []
        for key in self.test_list_dict:
            if self.test_list_dict[key] in ["", " "]:
                continue
            with open(self.test_list_dict[key], "r") as f:
                lines = f.read().splitlines()
                file_list.extend(lines)
        # rm repeat
        lines = list(dict.fromkeys(file_list))
        print("test data num: ", len(lines))

        for line in lines:
            image_sub_path = line
            json_sub_path = line.replace("image", "json").replace("png", "json")
            label_sub_path = line.replace("image", "label")
            image_list.append(os.path.join(self.data_root, image_sub_path))
            json_list.append(os.path.join(self.data_root, json_sub_path))
            lable_list.append(os.path.join(self.proc_root, label_sub_path))

        return image_list, json_list, lable_list

    def make_slot_label(self, result, img):
        if self.check_label:
            zero_mask = np.zeros((img.shape), dtype=np.uint8)
            corner_points = np.array(result["corner_points"], dtype=np.int32)
            cv2.line(
                zero_mask,
                (corner_points[0][0], corner_points[0][1]),
                (corner_points[1][0], corner_points[1][1]),
                thickness=self.thickness,
                color=color_infos["separate line"],
            )
            cv2.line(
                zero_mask,
                (corner_points[2][0], corner_points[2][1]),
                (corner_points[3][0], corner_points[3][1]),
                thickness=self.thickness,
                color=color_infos["separate line"],
            )
            cv2.line(
                zero_mask,
                (corner_points[0][0], corner_points[0][1]),
                (corner_points[3][0], corner_points[3][1]),
                thickness=self.thickness,
                color=color_infos["entry line"],
            )
            img = cv2.addWeighted(src1=img, alpha=1, src2=zero_mask, beta=1, gamma=0)
            return img

        else:
            corner_points = np.array(result["corner_points"], dtype=np.int32)
            cv2.line(
                img,
                (corner_points[0][0], corner_points[0][1]),
                (corner_points[1][0], corner_points[1][1]),
                thickness=self.thickness,
                color=id_infos["separate line"],
            )
            cv2.line(
                img,
                (corner_points[2][0], corner_points[2][1]),
                (corner_points[3][0], corner_points[3][1]),
                thickness=self.thickness,
                color=id_infos["separate line"],
            )
            cv2.line(
                img,
                (corner_points[0][0], corner_points[0][1]),
                (corner_points[3][0], corner_points[3][1]),
                thickness=self.thickness,
                color=id_infos["entry line"],
            )
            return img

    def make_object_label(self, result, img):
        if self.check_label:
            zero_mask = np.zeros((img.shape), dtype=np.uint8)
            color = color_infos[result["type"]]
            mask = cv2.fillPoly(
                zero_mask,
                [np.array(result["segmentation"]).astype(np.int32)],
                color=color,
            )
            img = cv2.addWeighted(src1=img, alpha=1, src2=mask, beta=1, gamma=0)
            return img
        else:
            if result["type"] not in id_infos:
                print("{} not in id_infos".format(result["type"]))
                color = self.ignore_label
            else:
                color = id_infos[result["type"]]
            cv2.fillPoly(
                img, [np.array(result["segmentation"]).astype(np.int32)], color=color
            )
            return img

    def make_ego_pose_label(self, img, ego_car_pos):
        if self.check_label:
            color = color_infos["ego car"]
            cv2.rectangle(
                img,
                (ego_car_pos[0][0], ego_car_pos[0][1]),
                (ego_car_pos[1][0], ego_car_pos[1][1]),
                color=color,
                thickness=-1,
            )
            return img
        else:
            color = id_infos["ego car"]
            cv2.rectangle(
                img,
                (ego_car_pos[0][0], ego_car_pos[0][1]),
                (ego_car_pos[1][0], ego_car_pos[1][1]),
                color=color,
                thickness=-1,
            )
            return img

    def make_label(self):
        image_list, json_list, lable_list = self.get_data_list()

        count = 0
        for image_path, json_path, label_path in tqdm(
            zip(image_list, json_list, lable_list)
        ):

            if not self.force and os.path.exists(label_path):
                continue

            count += 1

            label_dir = os.path.dirname(label_path)
            if not os.path.exists(label_dir):
                os.makedirs(label_dir)

            if self.check_label:
                img = cv2.imread(image_path)
            else:
                img = np.zeros((self.w, self.h), dtype=np.uint8)
            img = self.make_ego_pose_label(img, self.ego_car_pos)

            try:
                with open(json_path, "r") as f:
                    raw_label = json.load(f)
                    for result in raw_label["results"]:
                        if "segmentation" in result.keys():
                            img = self.make_object_label(result, img)
                    # for result in raw_label["results"]:
                    #     if "corner_points" in result.keys():
                    #         img = self.make_slot_label(result, img)
            except Exception as e:
                print(f"skip {json_path}")
                print(e)
                img = (np.ones((self.h, self.w)) * self.ignore_label).astype("uint8")

            if self.check_label:
                cv2.imshow("mask", img)
                cv2.waitKey(1000)
            else:
                cv2.imwrite(label_path, img)
        print("finish preprocess data, preprocess new data {}".format(count))


if __name__ == "__main__":
    opt.is_preprocess = 1
    if int(opt.is_preprocess):
        make_seg_train_label = MakeSegTrainLabel(opt)
        make_seg_train_label.make_label()
    else:
        print("skip preprocess")
