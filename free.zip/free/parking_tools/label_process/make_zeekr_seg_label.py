import os
import shutil
import random
import cv2
import numpy as np
from collections import namedtuple
import json
import argparse
from tqdm import tqdm
from os.path import join as opj


parser = argparse.ArgumentParser(description='make segmentation label')
parser.add_argument('--src_dir', default='', type=str, help='original image dir')
parser.add_argument('--dst_dir', default='', type=str, help='training dataset dir')
parser.add_argument('--check_label', default=1, type=int, help='check label or not')
parser.add_argument('--thickness', default=8, type=int, help='thickness of slot line')
parser.add_argument('--point_radius', default=6, type=int, help='radius of slot point')
parser.add_argument('--split_ratio', default=0.8, type=float, help='training dataset dir')
opt = parser.parse_args()


APAClass = namedtuple('APAClass', ['name', 'train_id', 'color'])
classes = [APAClass('background',       0, (200, 0, 200)),
           APAClass('entry line',       1, (0, 255, 0)),
           APAClass('separate line',    2, (20, 20, 255)),
            APAClass('wheel stop',      3, (185, 122, 87)),
           APAClass('speed bump',       4, (110, 110, 0)),
           APAClass('lane',             5, (255, 193, 37)),
           APAClass('wall',             6, (241, 230, 255)),
           APAClass('pillar',           7, (255, 246, 143)),
           APAClass('high obstacle',    8, (233, 100, 0)),
           APAClass('low obstacle',     9, (233, 134, 100)),
           APAClass('park lock open',   10, (233, 100, 200)),
           APAClass('park lock closed', 11, (233, 50, 50)),
           APAClass('vehicle',          12, (255, 0, 0)),
           APAClass('vegetation',       13, (147, 253, 194)),
           APAClass('curb',             14, (128, 128, 0)),
           APAClass('pedestrian',       15, (204, 153, 255)),
           APAClass('drains',           16, (238, 162, 173)),
           APAClass('ego car',          0, (255, 20, 255))]

class_color = {}
class_train_id = {}
for c in classes:
    class_color[c.name.lower()] = c.color
    class_train_id[c.name.lower()] = c.train_id


class MakeSegTrainLabel(object):
    def __init__(self, opt):
        self.src_dir = opt.src_dir
        self.dst_dir = opt.dst_dir
        self.dst_image_dir = opj(self.dst_dir, "image")
        self.dst_json_dir = opj(self.dst_dir, "json")
        self.dst_label_dir = opj(self.dst_dir, "label")
        self.check_label = opt.check_label
        self.thickness = opt.thickness
        self.point_radius = opt.point_radius
        self.split_ratio = opt.split_ratio
        self.w = 800
        self.h = 800
        self.ego_car_pos = np.array([[348, 274], [452, 526]], dtype=np.int32)
        if not os.path.isdir(self.dst_image_dir):
            os.makedirs(self.dst_image_dir)
        if not os.path.isdir(self.dst_json_dir):
            os.makedirs(self.dst_json_dir)
        if not os.path.isdir(self.dst_label_dir):
            os.makedirs(self.dst_label_dir)

    def make_images_and_labels(self):
        exist_dir = os.listdir(self.dst_image_dir)
        for sub_dir in os.listdir(self.src_dir):
            if sub_dir not in exist_dir:
                self.make_label(sub_dir)
                if not self.check_label:
                    self.copy_images_and_jsons(sub_dir)
                
    def copy_images_and_jsons(self, sub_dir):
        images = os.listdir(opj(self.src_dir, sub_dir, "png"))
        labels = os.listdir(opj(self.src_dir, sub_dir, "json"))
        assert(len(images) == len(labels))
        shutil.copytree(opj(self.src_dir, sub_dir, "png"), opj(self.dst_image_dir, sub_dir))
        shutil.copytree(opj(self.src_dir, sub_dir, "json"), opj(self.dst_json_dir, sub_dir))
        self.split_image(sub_dir, images)

    def split_image(self, sub_dir, images):
        split_number = self.split_ratio * len(images)
        train_images = random.sample(images, int(split_number))
        test_images = [image for image in images if image not in train_images]
        print('The number of train images is : ' + str(len(train_images)) + '\n'
              + 'The number of test images is : ' + str(len(test_images)) + '\n')
        with open(os.path.join(self.dst_dir, 'train_list.txt'), 'a') as f:
            for image in train_images:
                f.write(opj("image", sub_dir, image) + '\n')

        with open(os.path.join(self.dst_dir, 'test_list.txt'), 'a') as f:
            for image in test_images:
                f.write(opj("image", sub_dir, image) + '\n')

    def make_slot_label(self, result, img):
        if self.check_label:
            zero_mask = np.zeros((img.shape), dtype=np.uint8)
            corner_points = np.array(result['corner_points'], dtype=np.int32)
            cv2.line(zero_mask, corner_points[0], corner_points[1], thickness=self.thickness, color=class_color["separate line"])
            cv2.line(zero_mask, corner_points[2], corner_points[3], thickness=self.thickness, color=class_color["separate line"])
            cv2.line(zero_mask, corner_points[0], corner_points[3], thickness=self.thickness, color=class_color["entry line"])
            img = cv2.addWeighted(src1=img, alpha=1, src2=zero_mask, beta=1, gamma=0)
            return img

        else:
            corner_points = np.array(result['corner_points'], dtype=np.int32)   
            cv2.line(img, corner_points[0], corner_points[1], thickness=self.thickness, color=class_train_id["separate line"])
            cv2.line(img, corner_points[2], corner_points[3], thickness=self.thickness, color=class_train_id["separate line"])
            cv2.line(img, corner_points[0], corner_points[3], thickness=self.thickness, color=class_train_id["entry line"])
            return img

    def make_object_label(self, result, img):
        if self.check_label:
            zero_mask = np.zeros((img.shape), dtype=np.uint8)
            color = class_color[result['type']]
            mask = cv2.fillPoly(zero_mask, [np.array(result['segmentation']).astype(np.int32)], color=color)
            img = cv2.addWeighted(src1=img, alpha=1, src2=mask, beta=1, gamma=0)
            return img
        else:
            color = class_train_id[result['type']]
            cv2.fillPoly(img, [np.array(result['segmentation']).astype(np.int32)], color=color)
            return img

    def make_ego_pose_label(self, img, ego_car_pos):
        if self.check_label:
            color = class_color['ego car']
            cv2.rectangle(img, ego_car_pos[0], ego_car_pos[1], color=color, thickness=-1)
            return img
        else:
            color = class_train_id['ego car']
            cv2.rectangle(img, ego_car_pos[0], ego_car_pos[1], color=color, thickness=-1)
            return img

    def make_label(self, sub_dir):
        if not os.path.isdir(opj(self.dst_label_dir, sub_dir)):
            os.makedirs(opj(self.dst_label_dir, sub_dir))
        for label_json in tqdm(os.listdir(opj(self.src_dir, sub_dir, "json"))):
            if self.check_label:
                img = cv2.imread(opj(self.src_dir, sub_dir, "png", label_json.replace('.json', '.png')))
            else:
                img = np.zeros((self.w, self.h), dtype=np.uint8)
            img = self.make_ego_pose_label(img, self.ego_car_pos)
            with open(opj(self.src_dir, sub_dir, "json", label_json)) as f:
                raw_label = json.load(f)
                for result in raw_label['results']:
                    if 'segmentation' in result.keys():
                        img = self.make_object_label(result, img)
                for result in raw_label['results']:
                    if 'corner_points' in result.keys():
                        img = self.make_slot_label(result, img)
            if self.check_label:
                cv2.imshow('mask', img)
                cv2.waitKey(1000)
            else:
                cv2.imwrite(opj(self.dst_label_dir, sub_dir, label_json.replace('.json', '.png')), img)


if __name__ == '__main__':
    make_seg_train_label = MakeSegTrainLabel(opt)
    make_seg_train_label.make_images_and_labels()
