#!/bin/bash

cd /workspace/network/parking.pytorch/
export PYTHONPATH=./

python3 generate_labels/generate_fisheye_seg_label.py \
    --is_preprocess $IS_PREPROCESSING \
    --train_datasets $TRAIN_PATH \
    --test_datasets $TEST_PATH \
    --dataset_root /data/perception/datasets \
    --preprocess_root /proc_data/perception/datasets \
    $ENV
