import os
import json
import yaml


def init_opt(opt):
    with open(opt.config) as f:
        cfg = yaml.load(f, Loader=yaml.SafeLoader)
    for k in cfg.keys():
        # 如果opt有值，则不用config的值，否则使用config的值
        if hasattr(opt, k):
            if not getattr(opt, k):
                setattr(opt, k, cfg[k])
        else:
            setattr(opt, k, cfg[k])


chinese_to_english = {
    "车位线类型": "parking_space_line_type",
    "T形线": "t_shape_line",
    "封闭口线": "sealing_line",
    "U形线": "u_shape_line",
    "椭圆形线": "ellipse_line",
    "石砖线": "stone_brick_line",
    "草砖线": "grass_brick_line",
    "特殊车位线": "special_parking_line",
    "混合车位线": "mixed_parking_line",
    "车位类型": "parking_space_type",
    "水平车位": "horizontal_slot",
    "垂直车位": "vertical_slot",
    "斜列车位": "oblique_slot",
    "混合车位": "mixed_slot",
    "地面材质类型": "ground_material_type",
    "环氧漆面": "epoxy_finish",
    "石砖路": "stone_road",
    "柏油路": "asphalt_road",
    "水泥路": "cement_road",
    "草地": "grassland",
    "特殊路面": "special_road",
    "草砖路面": "straw_brick_road",
    "环境要素": "environment",
    "明亮": "bright",
    "昏暗": "dim",
    "雨天": "rainy",
    "地理要素": "geographical_elements",
    "地上": "overground",
    "地下": "underground",
    "反光程度": "reflection",
    "无反光": "no_reflection",
    "轻微反光": "slight_reflection",
    "严重反光": "severe_reflection",
    "磨损程度": "wear_degree",
    "无磨损": "no_wear",
    "轻微磨损": "slight_wear",
    "严重磨损": "severe_wear",
    "雾天": "foggy",
    "雪天": "snowy",
    "晴天多云": "sunny_cloudy",
}

english_to_chinese = {}
for key, value in chinese_to_english.items():
    english_to_chinese[value] = key


def get_test_list(test_path: dict):
    file_list = []
    for key in test_path:
        with open(test_path[key], "r") as f:
            lines = f.read().splitlines()
            file_list.extend(lines)
    # rm repeat
    lines = list(dict.fromkeys(file_list))
    lines.sort()
    return lines


# def get_scene_infos_list_from_test_dict(root_dir, test_path: dict):
#     file_list = get_test_list(test_path)

#     scene_infos_list = []

#     for file_path in file_list:
#         json_path = file_path.replace('image', 'json').replace('png', 'json').replace('jpg', 'json').replace('pcd',
#                                                                                                              'json')
#         try:
#             with open(os.path.join(root_dir, json_path), 'r') as f:
#                 scene_infos = json.load(f)["classification"]
#         except:
#             print("error path: ", os.path.join(root_dir, json_path))
#         scene_infos_list.append(scene_infos)
#     return scene_infos_list


def get_scene_infos_list_from_test_dict(
    root_dir, test_path: dict, filter_keys=["unkonwn"]
):
    file_list = get_test_list(test_path)

    scene_infos_list = []

    for file_path in file_list:
        tags_path = (
            file_path.replace("image", "tags")
            .replace("png", "json")
            .replace("jpg", "json")
            .replace("pcd", "json")
        )
        try:
            with open(os.path.join(root_dir, tags_path), "r") as f:
                scene_info_list = json.load(f)["tags"]
        except:
            print("error path: ", os.path.join(root_dir, tags_path))
            scene_info_list = []

        scene_infos = {}
        for info in scene_info_list:
            scene_name = english_to_chinese.get(info["tagName"], info["tagName"])
            scene_value = english_to_chinese.get(info["tagValue"], info["tagValue"])
            if scene_name in ["天气", "光线条件", "车位线颜色"]:
                print(f"{scene_name}: ", file_path)
                continue
            if scene_value in filter_keys:
                continue
            scene_infos[scene_name] = scene_value
        scene_infos_list.append(scene_infos)
    return scene_infos_list


def get_scene_infos_list(root_dir, test_file):
    with open(test_file, "r") as f:
        file_list = [line.strip() for line in f.readlines()]

    scene_infos_list = []

    for file_path in file_list:
        json_path = file_path.replace("image", "json").replace("png", "json")
        try:
            with open(os.path.join(root_dir, json_path), "r") as f:
                scene_infos = json.load(f)["classification"]
        except:
            print("error path: ", os.path.join(root_dir, json_path))
        scene_infos_list.append(scene_infos)
    return scene_infos_list


def get_scene_count_info(scene_infos_list, filter_keys=["unkonwn"]):
    scene_count_info = {}
    for scene_infos in scene_infos_list:
        for scene_name, scene_value in scene_infos.items():
            if scene_value in filter_keys:
                continue
            if scene_name not in scene_count_info:
                scene_count_info[scene_name] = {}
            if scene_value not in scene_count_info[scene_name]:
                scene_count_info[scene_name][scene_value] = 0
            scene_count_info[scene_name][scene_value] += 1
    return scene_count_info


def train_id_to_name_map(labels_info):
    train_id_map = {}
    for info in labels_info:
        if info["train_id"] not in train_id_map:
            train_id_map[info["train_id"]] = info["name"]
    return train_id_map


def metric_name_to_camel(metric_name):
    flag = False
    out = ""
    for c in metric_name:
        if c in [" ", "-", "_", "."]:
            flag = True
            continue

        if flag:
            out += c.upper()
            flag = False
        else:
            out += c
    return out
