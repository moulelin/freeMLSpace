import cv2

import torch
import torch.nn as nn
import torch.nn.functional as F

from .common_loss.ohem_loss import OhemCELoss


class SegLoss(nn.Module):
    def __init__(self, opt):
        super(SegLoss, self).__init__()
        self.opt = opt
        self.ohemce_loss = OhemCELoss(
            thresh=self.opt.thresh_ohem,
            ignore_label=self.opt.ignore_label,
            norm_value=self.opt.n_cats - 1,
            reduction="mean",
        )
        # self.seg_loss = nn.BCEWithLogitsLoss()
        self.mask_loss = nn.CrossEntropyLoss(
            ignore_index=self.opt.ignore_label,
            reduction="none",
            weight=None,
        )


    def forward(self, pred, truth, mask=None):
        loss_logits = self.mask_loss(pred["freespace_logits"], truth)
        loss_logits = loss_logits.mean()

        if mask is not None:
            loss_mask = self.mask_loss(pred["freespace_logits"], truth)
            loss_mask = loss_mask * (mask + 1.0)
            loss_mask = loss_mask.mean()
        else:
            loss_mask = 0

        loss = (
            loss_logits
            + loss_mask
        )

        loss_tags = {
            "seg_loss": loss_logits.clone().detach().cpu().numpy()
        }

        if mask is not None:
            loss_tags["mask_loss"] = loss_mask.clone().detach().cpu().numpy()
        else:
            loss_tags["mask_loss"] = 0

        return loss, loss_tags


class FishEyeFSSegLoss(nn.Module):
    def __init__(self, opt):
        super(FishEyeFSSegLoss, self).__init__()
        self.opt = opt
        self.seg_loss = SegLoss(self.opt)
        self.w_seg = self.opt.w_seg

    def forward(self, pred, truth):
        seg_pred = pred
        loss_seg, seg_tags = self.seg_loss(
            seg_pred, truth["freespace"], mask=truth.get("mask", None)
        )
        loss = loss_seg * self.w_seg
        loss_tags = {**seg_tags}
        loss_tags["loss"] = loss_tags["seg_loss"]
        return loss, loss_tags
