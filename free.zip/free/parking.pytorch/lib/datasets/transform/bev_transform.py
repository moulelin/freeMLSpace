import numpy as np
import torch
from PIL import Image
import math

from lib.datasets.utils.quaternion import Quaternion


class ImageAugmentation(object):
    def __init__(
        self,
        enable=False,
        random_flip=False,
        resize=[0.40, 0.43],
        rotate=[-5.4, 5.4],
        crop_origin=[0, 0],
        fH=512,
        fW=640,
    ):
        self.enable = enable
        self.random_flip = random_flip
        self.resize = resize
        self.rotate = rotate
        self.crop_origin = crop_origin
        self.fH = fH
        self.fW = fW

    def _get_rot(self, h):
        return torch.Tensor(
            [
                [np.cos(h), np.sin(h)],
                [-np.sin(h), np.cos(h)],
            ]
        )

    def __call__(self, img, mode="train"):
        post_rot = torch.eye(2)
        post_tran = torch.zeros(2)
        raw_width, raw_height = img.size

        if self.enable and mode == "train":
            resize = np.random.uniform(*self.resize)
            resize_dims = (int(raw_width * resize), int(raw_height * resize))
            newW, newH = resize_dims
            crop_h = int(
                np.random.uniform(0, max(0, newH - self.fH))
            )  # max(0, newH - fH)
            crop_w = int(np.random.uniform(0, max(0, newW - self.fW)))
            crop = (crop_w, crop_h, crop_w + self.fW, crop_h + self.fH)

            flip = False
            if self.random_flip and np.random.choice([0, 1]):
                flip = True
            rotate = np.random.uniform(*self.rotate)
        else:
            resize = max(self.fW / raw_width, self.fH / raw_height)
            resize_dims = (int(raw_width * resize), int(raw_height * resize))
            newW, newH = resize_dims
            crop = (
                self.crop_origin[0],
                self.crop_origin[1],
                self.crop_origin[0] + self.fW,
                self.crop_origin[1] + self.fH,
            )
            flip = False
            rotate = 0

        img = img.resize(resize_dims)
        img = img.crop(crop)
        if flip:
            img = img.transpose(method=Image.FLIP_LEFT_RIGHT)
        img = img.rotate(rotate)

        # post-homography transformation
        post_rot *= resize
        post_tran -= torch.Tensor(crop[:2])
        if flip:
            A = torch.Tensor([[-1, 0], [0, 1]])
            b = torch.Tensor([crop[2] - crop[0], 0])
            post_rot = A.matmul(post_rot)
            post_tran = A.matmul(post_tran) + b
        A = self._get_rot(rotate / 180 * np.pi)
        b = torch.Tensor([crop[2] - crop[0], crop[3] - crop[1]]) / 2
        b = A.matmul(-b) + b
        post_rot = A.matmul(post_rot)
        post_tran = A.matmul(post_tran) + b

        post_tran_out = torch.zeros(3)
        post_rot_out = torch.eye(3)
        post_tran_out[:2] = post_tran
        post_rot_out[:2, :2] = post_rot
        return img, post_rot_out, post_tran_out


class BEVAugmentation(object):
    def __init__(
        self,
        enable=False,
        bev_rot=[-22.5, 22.5],
    ):
        self.enable = enable
        self.bev_rot = bev_rot

    def _get_rot_matrix(self, theta):
        rot = torch.Tensor(
            [
                [math.cos(theta / 180 * np.pi), math.sin(-theta / 180 * np.pi)],
                [math.sin(theta / 180 * np.pi), math.cos(theta / 180 * np.pi)],
            ]
        )
        return rot

    def __call__(self, box_list, mode="train"):

        if mode != "train":
            bev_rot = torch.Tensor([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
            return bev_rot, box_list

        angle = np.random.uniform(*self.bev_rot)
        rot = self._get_rot_matrix(angle)
        rot_mat = torch.eye(3)
        rot_mat[:2, :2] = rot
        for box_rot in box_list:
            xyz = torch.from_numpy(box_rot["center"]).float()
            xyz = torch.matmul(rot_mat, xyz.unsqueeze(1))
            rot_q = Quaternion._from_matrix(rot_mat.double().numpy())
            box_rot["orientation"] = box_rot["orientation"] * rot_q
            box_rot["center"] = xyz.squeeze(1).numpy()
        return rot_mat, box_list
