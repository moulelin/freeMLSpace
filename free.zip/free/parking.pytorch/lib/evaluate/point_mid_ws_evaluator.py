import cv2
import math
import numpy as np

import torch

from .point_type_seg_evaluator import PointTypeSegEvaluator


def ccw(A, B, C):
    return (C[1] - A[1]) * (B[0] - A[0]) > (B[1] - A[1]) * (C[0] - A[0])


# Return true if line segments AB and CD intersect
def intersect(A, B, C, D):
    return ccw(A, C, D) != ccw(B, C, D) and ccw(A, B, C) != ccw(A, B, D)


class PointMidWSEvaluator(PointTypeSegEvaluator):
    def __init__(self, opt, decoder, dataset):
        super(PointTypeSegEvaluator, self).__init__(opt, decoder, dataset)

    def _eval(self, preds, label, net, sample_idx):
        (
            point_pred,
            center_pred,
            seg_pred,
            ws_pred,
            sp_pred,
            mid_point_pred,
        ) = self.align_outputs(preds, net)

        point_label, mid_point_label, center_label, seg_label, ws_label, sp_label = (
            label["label_point"],
            label["label_mid"],
            label["label_center"],
            label["label_seg"],
            label["label_ws"],
            label["label_sp"],
        )
        (
            point_label,
            mid_point_label,
            center_label,
            seg_label,
            ws_label,
            sp_label,
        ) = self.decoder.extract_truth(
            point_label, mid_point_label, center_label, seg_label, ws_label, sp_label
        )
        self._get_parking_slot_pr(point_pred, center_pred, center_label, sample_idx)
        self._eval_point(point_label, point_pred, sample_idx, "point")
        self._eval_point(center_label, center_pred, sample_idx, "center")
        self._eval_seg(seg_label, seg_pred, sample_idx)
        self._eval_kp(ws_label, ws_pred, sample_idx, "ws")
        self._eval_kp(sp_label, sp_pred, sample_idx, "sp")
        self._eval_kp(mid_point_label, mid_point_pred, sample_idx, "mid")
        return point_pred, mid_point_pred, center_pred, seg_pred, ws_pred, sp_pred

    def _get_results(self, avg_inference_t):
        self.generate_seg_results()
        self.generate_point_results()
        self.results["inference_time"] = avg_inference_t
        self.results["batchsize"] = self.opt.val_batch

    def _get_infer_buffer(self):
        buffer = {}
        buffer["hist"] = torch.zeros(self.num_classes, self.num_classes).cuda()
        buffer["edge_point_tp"] = np.zeros(
            self.num_classes,
        )
        buffer["edge_point_fp"] = np.zeros(
            self.num_classes,
        )
        buffer["edge_point_fn"] = np.zeros(
            self.num_classes,
        )
        buffer["edge_point_diff"] = [[] for i in range(self.opt.n_cats)]
        buffer["point_pred"] = []
        buffer["point_tp_offset"] = []
        buffer["point_truth"] = []
        buffer["center_pred"] = []
        buffer["center_tp_offset"] = []
        buffer["center_truth"] = []
        buffer["center_type_pred"] = []
        buffer["center_type_label"] = []
        buffer["center_offset_true"] = 0
        buffer["center_offset_num"] = 0
        buffer["ws_pred"] = []
        buffer["ws_tp_offset"] = []
        buffer["ws_truth"] = []
        buffer["sp_pred"] = []
        buffer["sp_tp_offset"] = []
        buffer["sp_truth"] = []
        buffer["mid_pred"] = []
        buffer["mid_tp_offset"] = []
        buffer["mid_truth"] = []
        buffer["slot_tp_num"] = np.zeros((4,))
        buffer["slot_fp_num"] = np.zeros((4,))
        buffer["slot_fn_num"] = np.zeros((4,))
        return buffer

    def align_outputs(self, preds, net):
        if net.model_type == "pth":
            point_pred, mid_point_pred, center_pred, seg_pred, ws_pred, sp_pred = preds
        else:
            if len(preds) == 6:
                seg_pred = torch.tensor(
                    preds[0]
                    .reshape(self.opt.val_batch, self.opt.h_input, self.opt.w_input)
                    .astype("int32")
                ).cuda()
                point_pred = (
                    torch.tensor(preds[1].reshape(self.opt.val_batch, 128, -1))
                    .float()
                    .cuda()
                )
                mid_point_pred = (
                    torch.tensor(preds[2].reshape(self.opt.val_batch, 128, -1))
                    .float()
                    .cuda()
                )
                center_pred = (
                    torch.tensor(preds[3].reshape(self.opt.val_batch, 128, -1))
                    .float()
                    .cuda()
                )
                ws_pred = (
                    torch.tensor(preds[4].reshape(self.opt.val_batch, 128, -1))
                    .float()
                    .cuda()
                )
                sp_pred = (
                    torch.tensor(preds[5].reshape(self.opt.val_batch, 128, -1))
                    .float()
                    .cuda()
                )
            else:
                seg_pred = torch.tensor(
                    preds[0]
                    .reshape(self.opt.val_batch, self.opt.h_input, self.opt.w_input)
                    .astype("int32")
                ).cuda()
                point_pred = (
                    torch.tensor(preds[1].reshape(self.opt.val_batch, 128, -1))
                    .float()
                    .cuda()
                )
                mid_point_pred = (
                    torch.tensor(preds[3].reshape(self.opt.val_batch, 128, -1))
                    .float()
                    .cuda()
                )
                center_pred = (
                    torch.tensor(preds[2].reshape(self.opt.val_batch, 128, -1))
                    .float()
                    .cuda()
                )
                ws_pred = (
                    torch.tensor(preds[3].reshape(self.opt.val_batch, 128, -1))
                    .float()
                    .cuda()
                )
                sp_pred = (
                    torch.tensor(preds[4].reshape(self.opt.val_batch, 128, -1))
                    .float()
                    .cuda()
                )
        point_cls = (point_pred[:, :, 0:1] > self.opt.point_cls_thresh) * 1.0
        new_point_pred = torch.cat([point_cls, point_pred[:, :, 1:]], dim=2)
        center_cls = (center_pred[:, :, 0:1] > self.opt.center_cls_thresh) * 1.0
        new_center_pred = torch.cat([center_cls, center_pred[:, :, 1:]], dim=2)
        return (
            new_point_pred,
            new_center_pred,
            seg_pred,
            ws_pred,
            sp_pred,
            mid_point_pred,
        )

    def generate_point_results(self):
        point_pred_list = self._infer_buffer["point_pred"]
        point_truth_list = self._infer_buffer["point_truth"]
        center_pred_list = self._infer_buffer["center_pred"]
        center_truth_list = self._infer_buffer["center_truth"]

        (
            point_mAP,
            point_AP,
            point_Precision,
            point_Recall,
            point_F1,
            point_PR_list,
        ) = self._calc_mAP(point_pred_list, point_truth_list, 2)
        (
            center_mAP,
            center_AP,
            center_Precision,
            center_Recall,
            center_F1,
            center_PR_list,
        ) = self._calc_mAP(center_pred_list, center_truth_list, 2)

        point_tp_offset = np.mean(self._infer_buffer["point_tp_offset"])
        center_tp_offset = np.mean(self._infer_buffer["center_tp_offset"])

        self.results["point"] = {
            "mAP": point_mAP,
            "AP": point_AP,
            "Precision": point_Precision,
            "Recall": point_Recall,
            "F1-score": point_F1,
            "PR": point_PR_list,
            "tp_offset": point_tp_offset,
        }
        self.results["center"] = {
            "mAP": center_mAP,
            "AP": center_AP,
            "Precision": center_Precision,
            "Recall": center_Recall,
            "F1-score": center_F1,
            "PR": center_PR_list,
            "tp_offset": center_tp_offset,
        }

        F1, precision, recall, type_num = self.slot_type_metric(
            self._infer_buffer["center_type_pred"],
            self._infer_buffer["center_type_label"],
        )

        self.results["cls"] = {
            "F1": F1,
            "Precision": precision,
            "Recall": recall,
            "slot_num": type_num,
        }

        self.results["offset"] = (
            self._infer_buffer["center_offset_true"]
            * 1.0
            / self._infer_buffer["center_offset_num"]
        )

        ws_pred_list = self._infer_buffer["ws_pred"]
        ws_truth_list = self._infer_buffer["ws_truth"]
        sp_pred_list = self._infer_buffer["sp_pred"]
        sp_truth_list = self._infer_buffer["sp_truth"]
        mid_pred_list = self._infer_buffer["mid_pred"]
        mid_truth_list = self._infer_buffer["mid_truth"]

        if len(ws_truth_list) > 0:
            (
                ws_mAP,
                ws_AP,
                ws_Precision,
                ws_Recall,
                ws_F1,
                ws_PR_list,
            ) = self._calc_mAP(ws_pred_list, ws_truth_list, 1)
            ws_tp_offset = np.mean(self._infer_buffer["ws_tp_offset"])
            self.results["ws"] = {
                "mAP": ws_mAP,
                "AP": ws_AP,
                "Precision": ws_Precision,
                "Recall": ws_Recall,
                "F1-score": ws_F1,
                "PR": ws_PR_list,
                "tp_offset": ws_tp_offset,
            }

        if len(sp_truth_list) > 0:
            (
                sp_mAP,
                sp_AP,
                sp_Precision,
                sp_Recall,
                sp_F1,
                sp_PR_list,
            ) = self._calc_mAP(sp_pred_list, sp_truth_list, 1)
            sp_tp_offset = np.mean(self._infer_buffer["sp_tp_offset"])
            self.results["sp"] = {
                "mAP": sp_mAP,
                "AP": sp_AP,
                "Precision": sp_Precision,
                "Recall": sp_Recall,
                "F1-score": sp_F1,
                "PR": sp_PR_list,
                "tp_offset": sp_tp_offset,
            }

        if len(mid_truth_list) > 0:
            (
                mid_mAP,
                mid_AP,
                mid_Precision,
                mid_Recall,
                mid_F1,
                mid_PR_list,
            ) = self._calc_mAP(mid_pred_list, mid_truth_list, 1)
            mid_tp_offset = np.mean(self._infer_buffer["mid_tp_offset"])
            self.results["mid"] = {
                "mAP": mid_mAP,
                "AP": mid_AP,
                "Precision": mid_Precision,
                "Recall": mid_Recall,
                "F1-score": mid_F1,
                "PR": mid_PR_list,
                "tp_offset": mid_tp_offset,
            }

        # parking slot detect
        slot_precision = self._infer_buffer["slot_tp_num"] / (
            self._infer_buffer["slot_tp_num"]
            + self._infer_buffer["slot_fp_num"]
            + 0.0001
        )
        slot_recall = self._infer_buffer["slot_tp_num"] / (
            self._infer_buffer["slot_tp_num"]
            + self._infer_buffer["slot_fn_num"]
            + 0.0001
        )
        self.results["slot"] = {
            "Precision": slot_precision,
            "Recall": slot_recall,
            "F1-score": 2
            * slot_precision
            * slot_recall
            / (slot_precision + slot_recall + 0.0001),
        }

        if self.opt.scene:
            for scene_name in self._scene_infer_buffers:
                if scene_name not in self.scene_results:
                    self.scene_results[scene_name] = {}
                for scene_value in self._scene_infer_buffers[scene_name]:
                    point_pred_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["point_pred"]
                    point_truth_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["point_truth"]
                    point_tp_offset = np.mean(
                        self._scene_infer_buffers[scene_name][scene_value][
                            "point_tp_offset"
                        ]
                    )
                    center_pred_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["center_pred"]
                    center_truth_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["center_truth"]
                    center_tp_offset = np.mean(
                        self._scene_infer_buffers[scene_name][scene_value][
                            "center_tp_offset"
                        ]
                    )

                    (
                        point_mAP,
                        point_AP,
                        point_Precision,
                        point_Recall,
                        point_F1,
                        point_PR_list,
                    ) = self._calc_mAP(point_pred_list, point_truth_list, 2)
                    (
                        center_mAP,
                        center_AP,
                        center_Precision,
                        center_Recall,
                        center_F1,
                        center_PR_list,
                    ) = self._calc_mAP(center_pred_list, center_truth_list, 2)

                    if scene_value not in self.scene_results[scene_name]:
                        self.scene_results[scene_name][scene_value] = {}
                    self.scene_results[scene_name][scene_value]["point"] = {
                        "mAP": point_mAP,
                        "AP": point_AP,
                        "Precision": point_Precision,
                        "Recall": point_Recall,
                        "F1-score": point_F1,
                        "PR": point_PR_list,
                        "tp_offset": point_tp_offset,
                    }
                    self.scene_results[scene_name][scene_value]["center"] = {
                        "mAP": center_mAP,
                        "AP": center_AP,
                        "Precision": center_Precision,
                        "Recall": center_Recall,
                        "F1-score": center_F1,
                        "PR": center_PR_list,
                        "tp_offset": center_tp_offset,
                    }
                    # parking slot detect
                    slot_tp_num = self._scene_infer_buffers[scene_name][scene_value][
                        "slot_tp_num"
                    ]
                    slot_fp_num = self._scene_infer_buffers[scene_name][scene_value][
                        "slot_fp_num"
                    ]
                    slot_fn_num = self._scene_infer_buffers[scene_name][scene_value][
                        "slot_fn_num"
                    ]
                    slot_precision = slot_tp_num / (slot_tp_num + slot_fp_num + 0.0001)
                    slot_recall = slot_tp_num / (slot_tp_num + slot_fn_num + 0.0001)
                    self.scene_results[scene_name][scene_value]["slot"] = {
                        "Precision": slot_precision,
                        "Recall": slot_recall,
                        "F1-score": 2
                        * slot_precision
                        * slot_recall
                        / (slot_precision + slot_recall + 0.0001),
                    }

    def _match_point_pred_truth(self, pred, truth, th, mode="point"):
        num_preds = pred.size(0)
        num_truth = truth.size(0)
        mask_TPFP = torch.zeros(num_preds).cuda()
        mask_TPFN = torch.zeros(num_truth).cuda()

        if mode == "center":
            center_type_pred = []
            center_type_label = []
            center_offset_num = 0
            center_offset_true = 0

        tp_offset = 0
        tp_count = 0
        for i in range(num_preds):
            if num_truth > 0:
                dis = torch.sqrt(
                    (truth[:, 2] - pred[i, 2]) ** 2 + (truth[:, 3] - pred[i, 3]) ** 2
                )
                min_dis, idx = dis.min(0)
                if (
                    (min_dis < th)
                    and (pred[i, 0] == truth[idx, 0])
                    and (mask_TPFN[idx] == 0)
                ):
                    mask_TPFN[idx] = 1
                    mask_TPFP[i] = 1
                    tp_offset += min_dis.cpu().numpy()
                    tp_count += 1
                    if mode == "center":
                        if int(truth[idx, 4].cpu().numpy()) != self.opt.ignore_label:
                            pred_type = pred[i, -3:].clone().argmax(dim=0).cpu().numpy()
                            gt_type = truth[idx, -1].cpu().numpy()
                            if gt_type != self.opt.ignore_label:
                                center_type_pred.append(pred_type)
                                center_type_label.append(gt_type)

                            pred_xy_offset = (
                                pred[i, 4:12].clone().cpu().numpy().reshape(4, 2)
                            )
                            gt_xy_offset = (
                                truth[idx, 4:12].clone().cpu().numpy().reshape(4, 2)
                            )
                            xy_diff = np.sqrt(
                                ((pred_xy_offset - gt_xy_offset) ** 2).sum(axis=1)
                            )
                            for offset_idx in range(4):
                                center_offset_num += 1
                                if xy_diff[offset_idx] <= self.opt.thresh_offset_dis:
                                    center_offset_true += 1

        if mode == "center":
            self._infer_buffer["center_type_pred"].extend(center_type_pred)
            self._infer_buffer["center_type_label"].extend(center_type_label)
            self._infer_buffer["center_offset_num"] += center_offset_num
            self._infer_buffer["center_offset_true"] += center_offset_true

        if self.opt.badcase:
            self.cur_infos["metric"][mode] = {}
            self.cur_infos["metric"][mode]["tp"] = int(mask_TPFN.sum().cpu())
            self.cur_infos["metric"][mode]["fp"] = int(
                num_preds - mask_TPFN.sum().cpu()
            )
            self.cur_infos["metric"][mode]["fn"] = int(
                num_truth - mask_TPFN.sum().cpu()
            )

            if mode == "center":
                self.cur_infos["metric"]["offset"] = {}
                self.cur_infos["metric"]["offset"]["fp"] = (
                    center_offset_num - center_offset_true
                )
                self.cur_infos["metric"]["offset"]["tp"] = center_offset_true

                self.cur_infos["metric"]["type"] = {}
                type_tp = 0
                type_fp = 0
                for i in range(len(center_type_pred)):
                    if center_type_pred[i] == center_type_label[i]:
                        type_tp += 1
                    else:
                        type_fp += 1
                self.cur_infos["metric"]["type"]["fp"] = type_fp
                self.cur_infos["metric"]["type"]["tp"] = type_tp

        pred_out = torch.cat([pred[:, :2], mask_TPFP.view(-1, 1)], dim=1)

        if tp_count:
            tp_offset = tp_offset / tp_count
        else:
            tp_offset = None
        return pred_out, tp_offset

    ### get parking slot metric
    def _get_nearest_point(self, offsets, points, points_cls):
        """
        offsets: 4 x 2
        points: N x 2
        points_cls: N
        """
        assert len(offsets) == 4, "ERROR: offsets shape {}".format(offsets.shape)
        out_points = []
        out_cls = []
        count = 0
        cls_sum = 0
        for i in range(4):
            min_dist = 1000
            min_idx = -1
            for j in range(len(points)):
                dist = np.sqrt(((offsets[i] - points[j]) ** 2).sum())
                if dist < min_dist:
                    min_dist = dist
                    min_idx = j

            if min_dist > self.opt.thresh_center_dis:
                out_points.append(offsets[i].tolist())
                out_cls.append(-1)
            else:
                out_points.append(points[min_idx].tolist())
                out_cls.append(int(points_cls[min_idx]))
                cls_sum += int(points_cls[min_idx])
                count += 1

        if count < 2:
            return None, None

        if count == 2 and cls_sum == 1:
            return None, None

        return out_points, out_cls

    def _point_cmp(self, points, points_cls):

        points = np.array(points)
        points_cls = np.array(points_cls)

        center = points.mean(axis=0)
        angles = np.zeros(len(points))
        for i in range(len(points)):
            angles[i] = math.atan2(points[i][0] - center[0], points[i][1] - center[1])
        idxs = angles.argsort()

        flag = True
        for i in range(len(points)):
            if (
                int(points_cls[idxs[0]]) in [0, -1]
                and int(points_cls[idxs[1]]) in [1, -1]
                and int(points_cls[idxs[2]]) in [1, -1]
                and int(points_cls[idxs[3]]) in [0, -1]
            ):
                flag = False
                break
            tmp = idxs[-1]
            idxs[1:] = idxs[:-1]
            idxs[0] = tmp
        if flag:
            return None
        points = points[idxs]
        points_cls = points_cls[idxs]

        if intersect(points[0], points[1], points[3], points[2]):
            return None
        return points

    def _filter_out_slot(self, slot, w_pad, h_pad):
        l_th = w_pad
        r_th = self.opt.w_input - w_pad
        t_th = h_pad
        d_th = self.opt.h_input - h_pad

        center = slot.mean(axis=0)

        if center[0] < l_th or center[0] > r_th:
            return True
        if center[1] < t_th or center[1] > d_th:
            return True
        return False

    def _get_pred_slots(self, point_pred, center_pred):
        pred_slots = []
        if len(point_pred) < 2:
            return pred_slots
        if len(center_pred) == 0:
            return pred_slots

        for i in range(len(center_pred)):
            slot_status_idx = (center_pred[i, 0] > self.opt.center_cls_thresh) * 1
            offsets = center_pred[i, 4:12].reshape(4, 2)
            slot_type_idx = center_pred[i, -3:].argmax()
            points, points_cls = self._get_nearest_point(
                offsets, point_pred[:, 2:4], point_pred[:, 0]
            )
            if points is None:
                continue
            points = self._point_cmp(points, points_cls)
            if points is None:
                continue
            if self._filter_out_slot(points, 50, 50):
                continue

            points = points.astype("int32")
            slot = {
                "status": slot_status_idx,
                "type": slot_type_idx,
                "points": points,
            }
            pred_slots.append(slot)
        return pred_slots

    def _get_gt_slots(self, center_label):
        gt_slots = []
        center_label = center_label[center_label[:, 1] == 1]
        if len(center_label) == 0:
            return gt_slots

        for i in range(len(center_label)):
            slot_status_idx = center_label[i, 0]
            offsets = center_label[i, 4:12].reshape(4, 2)
            slot_type_idx = center_label[i, -1]

            if self._filter_out_slot(offsets, 50, 50):
                continue

            points = offsets.astype("int32")
            slot = {
                "status": slot_status_idx,
                "type": slot_type_idx,
                "points": points,
            }
            gt_slots.append(slot)
        return gt_slots

    def _get_parking_slot_pr(self, point_pred, center_pred, center_label, sample_idx):
        point_pred = point_pred.detach().cpu().squeeze(0).numpy()
        center_pred = center_pred.detach().cpu().squeeze(0).numpy()
        center_label = center_label.detach().cpu().squeeze(0).numpy()

        point_mask = point_pred[:, 1] > self.opt.thresh_point
        point_pred = point_pred[point_mask]
        point_pred[:, 0] = (point_pred[:, 0] > self.opt.point_cls_thresh) * 1.0

        center_mask = center_pred[:, 1] > self.opt.thresh_center
        center_pred = center_pred[center_mask]

        pred_slots = self._get_pred_slots(point_pred, center_pred)
        gt_slots = self._get_gt_slots(center_label)

        tp_nums = np.zeros((4,))
        fp_nums = np.zeros((4,))
        fn_nums = np.zeros((4,))

        gt_masks = np.zeros((4, len(gt_slots)))

        if len(pred_slots) == 0:
            fn_nums += len(gt_slots)
        elif len(gt_slots) == 0:
            fp_nums += len(pred_slots)
        else:
            pred_mask = (
                np.ones((self.opt.h_input, self.opt.w_input), dtype=np.uint8) * 255
            )
            gt_mask = (
                np.ones((self.opt.h_input, self.opt.w_input), dtype=np.uint8) * 255
            )

            for i in range(len(pred_slots)):
                cv2.fillPoly(pred_mask, [pred_slots[i]["points"]], color=i)
            for j in range(len(gt_slots)):
                cv2.fillPoly(gt_mask, [gt_slots[j]["points"]], color=j)

            for i in range(len(pred_slots)):
                max_iou = -1
                max_idx = -1
                pred_poly_area = (pred_mask == i).sum()
                for j in range(len(gt_slots)):
                    gt_poly_area = (gt_mask == j).sum()
                    inter_area = ((pred_mask == i) * (gt_mask == j)).sum()
                    iou = inter_area / (pred_poly_area + gt_poly_area - inter_area)
                    if max_iou < iou:
                        max_iou = iou
                        max_idx = j
                if max_iou < 0.5:
                    continue
                if gt_masks[0, max_idx] == 0:
                    tp_nums[0] += 1
                    gt_masks[0, max_idx] = 1

                    if pred_slots[i]["status"] == gt_slots[max_idx]["status"]:
                        tp_nums[1] += 1
                    if pred_slots[i]["type"] == gt_slots[max_idx]["type"]:
                        tp_nums[2] += 1
                    if (
                        pred_slots[i]["status"] == gt_slots[max_idx]["status"]
                        and pred_slots[i]["type"] == gt_slots[max_idx]["type"]
                    ):
                        tp_nums[3] += 1
            fp_nums = len(pred_slots) - tp_nums
            fn_nums = len(gt_slots) - tp_nums
        self._infer_buffer["slot_tp_num"] += tp_nums
        self._infer_buffer["slot_fp_num"] += fp_nums
        self._infer_buffer["slot_fn_num"] += fn_nums

        if self.opt.badcase:
            self.cur_infos["metric"]["slot"] = {}
            self.cur_infos["metric"]["slot"]["tp"] = int(tp_nums[0])
            self.cur_infos["metric"]["slot"]["fp"] = int(fp_nums[0])
            self.cur_infos["metric"]["slot"]["fn"] = int(fn_nums[0])

        if self.opt.scene:
            scene_infos = self.opt.scene_infos_list[sample_idx]
            for scene_name, scene_value in scene_infos.items():
                if scene_value in self.opt.filter_keys:
                    continue
                self._scene_infer_buffers[scene_name][scene_value][
                    "slot_tp_num"
                ] += tp_nums
                self._scene_infer_buffers[scene_name][scene_value][
                    "slot_fp_num"
                ] += fp_nums
                self._scene_infer_buffers[scene_name][scene_value][
                    "slot_fn_num"
                ] += fn_nums

    def _eval_point(self, label, pred, sample_idx, mode="point"):
        B = label.size(0)
        if mode == "point":
            thresh_point_dis = self.opt.thresh_point_dis
            thresh_point_score = self.opt.thresh_point
        elif mode == "center":
            thresh_point_dis = self.opt.thresh_center_dis
            thresh_point_score = self.opt.thresh_center
        else:
            print("{} not support".format(mode))
            exit()

        for i in range(B):
            truth = label[i].clone()
            truth = truth[truth[:, 1] == 1]
            pre = pred[i].clone()
            pre = pre[pre[:, 1] > thresh_point_score]
            if pre != None:
                if mode == "center":
                    pred_out, tp_offset = self._match_point_pred_truth(
                        pre, truth, thresh_point_dis, mode
                    )
                    if self.opt.scene:
                        scene_infos = self.opt.scene_infos_list[sample_idx]
                        for scene_name, scene_value in scene_infos.items():
                            if scene_value in self.opt.filter_keys:
                                continue
                else:
                    pred_out, tp_offset = self._match_point_pred_truth(
                        pre, truth, thresh_point_dis, mode
                    )
                self._infer_buffer[f"{mode}_pred"].append(pred_out)
                if tp_offset:
                    self._infer_buffer[f"{mode}_tp_offset"].append(tp_offset)
                if self.opt.scene:
                    scene_infos = self.opt.scene_infos_list[sample_idx]
                    for scene_name, scene_value in scene_infos.items():
                        if scene_value in self.opt.filter_keys:
                            continue
                        self._scene_infer_buffers[scene_name][scene_value][
                            f"{mode}_pred"
                        ].append(pred_out)
                        if tp_offset:
                            self._scene_infer_buffers[scene_name][scene_value][
                                f"{mode}_tp_offset"
                            ].append(tp_offset)

            if truth != None:
                self._infer_buffer[f"{mode}_truth"].append(truth[:, 0].view(-1, 1))
                if self.opt.scene:
                    scene_infos = self.opt.scene_infos_list[sample_idx]
                    for scene_name, scene_value in scene_infos.items():
                        if scene_value in self.opt.filter_keys:
                            continue
                        self._scene_infer_buffers[scene_name][scene_value][
                            f"{mode}_truth"
                        ].append(truth[:, 0].view(-1, 1))

    def _match_kp_pred_truth(self, pred, truth, th, mode="ws"):
        num_preds = pred.size(0)
        num_truth = truth.size(0)
        mask_TPFP = torch.zeros(num_preds).cuda()
        mask_TPFN = torch.zeros(num_truth).cuda()
        kp_cls = torch.zeros(num_preds).cuda().view(-1, 1)

        tp_offset = 0
        tp_count = 0
        for i in range(num_preds):
            if num_truth > 0:
                dis = torch.sqrt(
                    (truth[:, 1] - pred[i, 1]) ** 2 + (truth[:, 2] - pred[i, 2]) ** 2
                )
                min_dis, idx = dis.min(0)
                if (min_dis < th) and (mask_TPFN[idx] == 0):
                    mask_TPFN[idx] = 1
                    mask_TPFP[i] = 1
                    tp_offset += min_dis.cpu().numpy()
                    tp_count += 1

        if self.opt.badcase:
            self.cur_infos["metric"][mode] = {}
            self.cur_infos["metric"][mode]["tp"] = int(mask_TPFN.sum().cpu())
            self.cur_infos["metric"][mode]["fp"] = int(
                num_preds - mask_TPFN.sum().cpu()
            )
            self.cur_infos["metric"][mode]["fn"] = int(
                num_truth - mask_TPFN.sum().cpu()
            )

        pred_out = torch.cat([kp_cls, pred[:, :1], mask_TPFP.view(-1, 1)], dim=1)

        if tp_count:
            tp_offset = tp_offset / tp_count
        else:
            tp_offset = None
        return pred_out, tp_offset

    def _eval_kp(self, label, pred, sample_idx, mode="ws"):
        B = label.size(0)
        if mode == "ws":
            thresh_point_dis = self.opt.thresh_ws_dis
            thresh_point_score = self.opt.thresh_ws
        elif mode == "sp":
            thresh_point_dis = self.opt.thresh_sp_dis
            thresh_point_score = self.opt.thresh_sp
        elif mode == "mid":
            thresh_point_dis = self.opt.thresh_mid_dis
            thresh_point_score = self.opt.thresh_mid
        else:
            print("{} not support".format(mode))
            exit()

        for i in range(B):

            truth = label[i].clone()
            if (truth[:, 0] == self.opt.ignore_label).sum() > 0:
                continue

            truth = truth[truth[:, 0] == 1]
            pre = pred[i].clone()
            pre = pre[pre[:, 0] > thresh_point_score]
            if pre != None:
                pred_out, tp_offset = self._match_kp_pred_truth(
                    pre, truth, thresh_point_dis, mode
                )

                self._infer_buffer[f"{mode}_pred"].append(pred_out)
                if tp_offset:
                    self._infer_buffer[f"{mode}_tp_offset"].append(tp_offset)
                if self.opt.scene:
                    scene_infos = self.opt.scene_infos_list[sample_idx]
                    for scene_name, scene_value in scene_infos.items():
                        if scene_value in self.opt.filter_keys:
                            continue
                        self._scene_infer_buffers[scene_name][scene_value][
                            f"{mode}_pred"
                        ].append(pred_out)
                        if tp_offset:
                            self._scene_infer_buffers[scene_name][scene_value][
                                f"{mode}_tp_offset"
                            ].append(tp_offset)

            if truth != None:
                truth_out = torch.zeros(truth.size(0)).cuda().view(-1, 1)
                self._infer_buffer[f"{mode}_truth"].append(truth_out)
                if self.opt.scene:
                    scene_infos = self.opt.scene_infos_list[sample_idx]
                    for scene_name, scene_value in scene_infos.items():
                        if scene_value in self.opt.filter_keys:
                            continue
                        self._scene_infer_buffers[scene_name][scene_value][
                            f"{mode}_truth"
                        ].append(truth_out)
