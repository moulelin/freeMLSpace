import os

from torch.utils import data


class BaseDataset(data.Dataset):
    def __init__(self, opt, mode):
        self.opt = opt
        self.train_path_dict = (
            eval(self.opt.train_datasets)
            if type(self.opt.train_datasets) == str
            else self.opt.train_datasets
        )
        self.test_path_dict = (
            eval(self.opt.test_datasets)
            if type(self.opt.test_datasets) == str
            else self.opt.test_datasets
        )
        self.data_root = self.opt.dataset_root
        # self.proc_root = self.opt.preprocess_root
        self.mode = mode
        self.name = opt.task

        # self._get_dataset()

    def _get_dataset(self):
        if self.mode == "train":
            datalist_dict = self.train_path_dict
        else:
            datalist_dict = self.test_path_dict

        for key in datalist_dict:
            file_list = []
            with open(datalist_dict[key], "r") as f:
                lines = f.read().splitlines()
                file_list.extend(lines)
        # rm repeat
        lines = list(dict.fromkeys(file_list))

        image_list = []
        for line in lines:
            image_path = os.path.join(self.data_root, line)
            image_list.append(image_path)
        self.label_dict = dict(image_list=image_list)
