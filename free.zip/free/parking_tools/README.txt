# parking_tools

1.label_process
## find_image.py
This script is used to match the dataset label with the corresponding image.
python find_image.py --image_path xxx/ --json_path xxx/ --save_path xxx/

## make_parking_slot_classify_label.py

## make_zeekr_apa_label.py

## make_zeekr_seg_label.py


2.parking_slot_analyse
## analyse_ulog.py
This script is used to analyse parkingslot module's ulog files.
First you should open the ulog switch in config file.
    1. product logfiles:
    1.1 run percp_parking_slot
        ./start_node.sh
    1.2 play bag in another terminal
        ros2 bag play xxx.db3
    1.3 log files will save in /zdrive/log, two files are all useful, but we send .INFO to script.
        
    2. use tool to analyse result
        python analyse_ulog.py --log_path /zdrive/log/percp_parking_slot.INFO --slot_id selected_slot_id --parking_only 0/1
    
## analyse_rosbag.py
   python3 analyse_rosbag.py --bag_file ***.db3 --slot_id selected_slot_id --parking_only 0/1 


