import numpy as np
from PIL import Image

import torch

import lib.datasets.transform.common_transform as T
import lib.datasets.transform.lidar_transform as LT
from lib.utils.vis_util import *
from lib.datasets.dataset.lidar import LidarDataset
from lib.datasets.utils.projections import SphericalProjection


np.random.seed(1234)
colors = np.random.randint(0, 256, (256, 3), dtype=np.uint8)


class LidarSegDataset(LidarDataset):
    def __init__(self, opt, mode):
        super(LidarSegDataset, self).__init__(opt, mode)
        self.size = (self.opt.h_input, self.opt.w_input)
        self.projection_module = SphericalProjection(
            proj_w=self.opt.w_input,
            proj_h=self.opt.h_input,
            fov_up=self.opt.fov_up,
            fov_down=self.opt.fov_down,
            ignore_label=self.opt.ignore_label,
        )
        self.means = torch.tensor(self.opt.means, dtype=torch.float)
        self.stds = torch.tensor(self.opt.stds, dtype=torch.float)

        if self.mode == "train":
            self.transform = T.Compose(
                [
                    LT.DropPoints(p=0.2, drop_ratio=0.001),
                    LT.FlipPoints(p=0.2),
                    LT.RandomShiftPoints(p=0.2),
                    LT.RandomRotatePoints(p=0.2),
                ]
            )
        else:
            self.transform = None

    def __getitem__(self, index):
        bin_path, label_path = (
            self.label_dict["bin_list"][index],
            self.label_dict["label_seg_list"][index],
        )
        scans = np.fromfile(bin_path, dtype=np.float32)
        scans = scans.reshape((-1, 4))

        remissions = scans[:, 3]
        points = scans[:, 0:3]

        labels = np.fromfile(label_path, dtype=np.int32)
        labels = self.label_map[labels]
        labels = labels.reshape((-1))

        im_lb = dict(points=points, remissions=remissions, labels=labels)
        if self.transform:
            im_lb = self.transform(im_lb)

        if im_lb["remissions"] is None:
            im_lb["remissions"] = np.zeros((im_lb["points"].shape[0]), dtype=np.float32)

        proj_data, proj_labels, proj_masks = self.projection_module.run(
            im_lb["points"], im_lb["remissions"], im_lb["labels"]
        )
        proj = torch.from_numpy(proj_data.transpose((2, 0, 1))).float()
        lb_seg = torch.from_numpy(proj_labels).long()
        proj_masks = torch.from_numpy(proj_masks)

        proj = (proj - self.means[:, None, None]) / self.stds[:, None, None]
        proj = proj * proj_masks.float()

        label = dict(label_seg=lb_seg)
        return proj, label

    def verify(self, index):
        image, label = self.__getitem__(index)
        image = image.numpy().transpose((1, 2, 0))
        label_seg = label["label_seg"].squeeze(0).numpy()
        label_seg = colors[label_seg]
        depth = image[:, :, 0]
        depth = (
            cv2.normalize(
                depth,
                None,
                alpha=0,
                beta=1,
                norm_type=cv2.NORM_MINMAX,
                dtype=cv2.CV_32F,
            )
            * 255.0
        ).astype(np.uint8)

        depth = depth.reshape(self.opt.h_input, self.opt.w_input, 1).repeat(3, axis=2)

        combined_img = np.concatenate([depth, label_seg], axis=0)
        return combined_img
        cv2.imshow("combined_img", combined_img)
        cv2.waitKey(0)
