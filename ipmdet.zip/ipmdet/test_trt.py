import argparse
import os
import cv2
import torch
import tensorrt as trt
import yaml
from model.ipmdet import IpmDetOnnx, IpmDet
from torch.utils import data
from dataset.nuscenes import BEVNuscenesLoader
from utils.tools import sample_to_cuda
from mmdet3d.core.bbox import LiDARInstance3DBoxes
from utils.bev_visualizer import visualize_bev
from typing import Union, Optional, Sequence, Dict
import time
from model.centerpoint import clip_sigmoid

TRT_LOGGER = trt.Logger(trt.Logger.WARNING)
trt.init_libnvinfer_plugins(TRT_LOGGER, "")
EXPLICIT_BATCH = 1 << (int)(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH)

def build_engine(onnx_file_path, output_engine_file_path, fp16):
    """Takes an ONNX file and creates a TensorRT engine to run inference with"""
    with trt.Builder(TRT_LOGGER) as builder, builder.create_network(
        EXPLICIT_BATCH
    ) as network, builder.create_builder_config() as config, trt.OnnxParser(
        network, TRT_LOGGER
    ) as parser:
        config.max_workspace_size = 1 << 28  # 256MiB
        builder.max_batch_size = 1
        if fp16:
            config.set_flag(trt.BuilderFlag.GPU_FALLBACK)
            config.set_flag(trt.BuilderFlag.FP16)

        # Parse model file
        print("Loading ONNX file from path {}...".format(onnx_file_path))
        if not os.path.exists(onnx_file_path):
            print("ONNX file {} not found.".format(onnx_file_path))
            return

        with open(onnx_file_path, "rb") as model:
            print("Beginning ONNX file parsing")
            if not parser.parse(model.read()):
                print("ERROR: Failed to parse the ONNX file.")
                for error in range(parser.num_errors):
                    print(parser.get_error(error))
                return

        print("Completed parsing of ONNX file")
        print(
            "Building an engine from file {}; this may take a while...".format(
                onnx_file_path
            )
        )
        engine = builder.build_engine(network, config)
        print("Completed creating Engine")
        with open(output_engine_file_path, "wb") as f:
            f.write(engine.serialize())

def get_engine(engine_file_path):
    if os.path.exists(engine_file_path):
        # If a serialized engine exists, use it instead of building an engine.
        print("Reading engine from file {}".format(engine_file_path))
        with open(engine_file_path, "rb") as f, trt.Runtime(TRT_LOGGER) as runtime:
            return runtime.deserialize_cuda_engine(f.read())
    else:
        raise FileExistsError

class TRTWrapper(torch.nn.Module):
    def __init__(self, engine: Union[str, trt.ICudaEngine],
                 output_names: Optional[Sequence[str]] = None) -> None:
        super().__init__()
        self.engine = engine
        if isinstance(self.engine, str):
            with trt.Logger() as logger, trt.Runtime(logger) as runtime:
                with open(self.engine, mode='rb') as f:
                    engine_bytes = f.read()
                self.engine = runtime.deserialize_cuda_engine(engine_bytes)
        self.context = self.engine.create_execution_context()
        names = [_ for _ in self.engine]
        input_names = list(filter(self.engine.binding_is_input, names))
        self._input_names = input_names
        self._output_names = output_names

        if self._output_names is None:
            output_names = list(set(names) - set(input_names))
            self._output_names = output_names

    def forward(self, inputs: Dict[str, torch.Tensor]):
        assert self._input_names is not None
        assert self._output_names is not None
        bindings = [None] * (len(self._input_names) + len(self._output_names))
        profile_id = 0
        for input_name, input_tensor in inputs.items():
            # check if input shape is valid
            profile = self.engine.get_profile_shape(profile_id, input_name)
            assert input_tensor.dim() == len(
                profile[0]), 'Input dim is different from engine profile.'
            for s_min, s_input, s_max in zip(profile[0], input_tensor.shape,
                                             profile[2]):
                assert s_min <= s_input <= s_max, \
                    'Input shape should be between ' \
                    + f'{profile[0]} and {profile[2]}' \
                    + f' but get {tuple(input_tensor.shape)}.'
            idx = self.engine.get_binding_index(input_name)

            # All input tensors must be gpu variables
            assert 'cuda' in input_tensor.device.type
            input_tensor = input_tensor.contiguous()
            if input_tensor.dtype == torch.long:
                input_tensor = input_tensor.int()
            self.context.set_binding_shape(idx, tuple(input_tensor.shape))
            bindings[idx] = input_tensor.contiguous().data_ptr()

        # create output tensors
        outputs = {}
        for output_name in self._output_names:
            idx = self.engine.get_binding_index(output_name)
            dtype = torch.float32
            shape = tuple(self.context.get_binding_shape(idx))

            device = torch.device('cuda')
            output = torch.empty(size=shape, dtype=dtype, device=device)
            outputs[output_name] = output
            bindings[idx] = output.data_ptr()
        self.context.execute_async_v2(bindings,
                                      torch.cuda.current_stream().cuda_stream)
        torch.cuda.current_stream().synchronize()
        return outputs

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', default='export_trt', type=str, choices=['export_trt', 'test_trt', 'compare_diff'])
    parser.add_argument("--onnx_model", help="File path of onnx model.", type=str)
    parser.add_argument("--trt_model", help="File path of tensorrt engine.", type=str)
    parser.add_argument('--pth', default='checkpoint/ipmdet-nuscenes-best.pth', type=str)
    parser.add_argument("--output", help="File path save visualization result.", type=str)
    parser.add_argument('--hyp', default='config/hyp.ipmdet.nusc.yaml', type=str)
    parser.add_argument("--fp16", help="Enable FP16.", action="store_true")
    parser.add_argument('--detdir', default='/media/tianming/data/nuScenes', type=str, help='detection dataset dir')
    args = parser.parse_args()

    if args.mode == 'export_trt':
        assert args.onnx_model, f'onnx_model is none, please specify the onnx_model file!'
        build_engine(args.onnx_model, args.trt_model, args.fp16)
        return

    print('=============== start inference with tensorrt ===============')
    # Build pytorch model
    with open(args.hyp) as f:
        hyp = yaml.load(f, Loader=yaml.SafeLoader)
        grid_conf = {
            'xbound': hyp['xbound'],
            'ybound': hyp['ybound'],
            'zbound': hyp['zbound']
        }

    net = IpmDetOnnx(hyp).cuda()
    checkpoint = torch.load(args.pth, map_location=torch.device('cpu'))
    net.load_state_dict(checkpoint['net'])
    print(f'Success to load checkpoint {args.pth}')
    net = net.cuda().eval()

    # Build trt model
    model = TRTWrapper(args.trt_model)

    if args.mode == 'test_trt':
        valset = BEVNuscenesLoader(args.detdir, None, hyp['width'], hyp['height'], grid_conf,
                                    hyp['image_aug'], hyp['bev_aug'], use_lidar=True, mode='val')
        valloader = data.DataLoader(valset, batch_size=1, shuffle=False, num_workers=0, pin_memory=True, drop_last=True)

        for i, data_dict in enumerate(valloader):
            data_dict = sample_to_cuda(data_dict)

            intrins = data_dict['intrins'].clone()
            T_c2v = torch.eye(4).type_as(intrins)
            T_c2v = T_c2v.repeat(1, 6, 1, 1)
            T_c2v[:, :, 0:3, 0:3] = data_dict['rots']
            T_c2v[:, :, 0:3, 3] = data_dict['trans']

            if 'img_post_rot' in data_dict and 'img_post_trans' in data_dict:
                img_post_rot = data_dict['img_post_rot'].clone()
                img_post_trans = data_dict['img_post_trans'].clone()
                img_post_rot[:, :, 0:2, :] /= hyp['downsample_factor']
                img_post_trans[:, :, 0:2] /= hyp['downsample_factor']

            pix_coords = net.calc_pix_coords(intrins, T_c2v, img_post_rot=img_post_rot, img_post_trans=img_post_trans, normalize=True)
            input = dict(image=data_dict['image'],
                         pix_coords=pix_coords)

            t0 = time.time()
            output = model(input)
            t1 = time.time()
            print(f"Tensorrt fp16{args.fp16} inference {i} time is {(t1 - t0)*1000} ms")
            pred_dict = [[{
                'reg':  output['task_0/bbox'][:, :2, ...],
                'height': output['task_0/bbox'][:, 2:3, ...],
                'dim': output['task_0/bbox'][:, 3:6, ...],
                'rot': output['task_0/bbox'][:, 6:, ...],
                'heatmap': clip_sigmoid(output['task_0/heatmap']),
            }], [{
                'reg':  output['task_1/bbox'][:, :2, ...],
                'height': output['task_1/bbox'][:, 2:3, ...],
                'dim': output['task_1/bbox'][:, 3:6, ...],
                'rot': output['task_1/bbox'][:, 6:, ...],
                'heatmap': clip_sigmoid(output['task_1/heatmap']),
            }], [{
                'reg':  output['task_2/bbox'][:, :2, ...],
                'height': output['task_2/bbox'][:, 2:3, ...],
                'dim': output['task_2/bbox'][:, 3:6, ...],
                'rot': output['task_2/bbox'][:, 6:, ...],
                'heatmap': clip_sigmoid(output['task_2/heatmap']),}]]
            pred_bboxes = net.head.get_bboxes(pred_dict, [{'box_type_3d': LiDARInstance3DBoxes} for _ in range(1)])

            # draw visual image
            data_dict.update({
                'box3d_preds': torch.cat([pred_bboxes[0][2].unsqueeze(1), pred_bboxes[0][0].tensor], dim=1),
                'pred_heatmap': pred_dict[0][0]['heatmap'].detach().cpu().numpy(),
            })
            show_img = visualize_bev(data_dict)
            cv2.imshow('show_img', show_img)
            cv2.waitKey(0)

    elif args.mode == 'compare_diff':
        n_cams = 6
        batch = 1
        image = torch.randn(batch, n_cams, 3, hyp['height'], hyp['width'], device='cuda')
        intrins = torch.randn(batch, n_cams, 3, 3, device='cuda')
        rots = torch.randn(batch, n_cams, 3, 3, device='cuda')
        trans = torch.randn(batch, n_cams, 3, device='cuda')

        T_c2v = torch.eye(4).type_as(intrins)
        T_c2v = T_c2v.repeat(batch, n_cams, 1, 1)
        T_c2v[:, :, 0:3, 0:3] = rots
        T_c2v[:, :, 0:3, 3] = trans

        pix_coords = net.calc_pix_coords(intrins, T_c2v, normalize=True)
        dummy_input = dict(image=image, pix_coords=pix_coords)

        for i in range(10):
            t0 = time.time()
            output_trt = model(dummy_input)
            t1 = time.time()
            print(f"Tensorrt inference {i} time is {(t1 - t0)*1000} ms")

        for i in range(10):
            t1 = time.time()
            output_pt = net(**dummy_input)
            torch.cuda.synchronize()
            t2 = time.time()
            print(f"Pytorch inference {i} time is {(t2 - t1)*1000} ms")

        check_output_name = 'task_1/heatmap'
        diff = torch.abs(output_trt[check_output_name] - output_pt[2]) / (torch.abs(output_pt[4]))
        print(f'diff_max: {diff.max()}, diff_mean: {diff.mean()}')

if __name__ == "__main__":
    main()
