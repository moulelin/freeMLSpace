import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from model.image_encoder import CamEncoder
from utils.bev_visualizer import visualize_bev, bev_feature_to_image
from model.resnet import GeneralizedResNet
from model.lss import LSSFPN
from model.centerpoint import CenterHead
from model.segmentation_head import BEVSegmentationHead
from mmdet3d.core.bbox import LiDARInstance3DBoxes
from dataset.nuscenes import CATEGORY_FOR_TRAINING
import cv2

class IpmDet(nn.Module):
    def __init__(self, config):
        super(IpmDet, self).__init__()
        self.name = 'ipmdet'

        self.N = config['num_cameras']
        self.xbound = config['xbound']
        self.ybound = config['ybound']
        self.zbound = config['zbound']
        self.bev_range = np.array([self.xbound[0], self.xbound[1],
                                   self.ybound[0], self.ybound[1],
                                   self.zbound[0], self.zbound[1]], dtype=np.float32)
        self.bev_resolution = np.array([self.xbound[-1], self.ybound[-1], self.zbound[-1]], dtype=np.float32)
        self.bev_length, self.bev_width, self.bev_height = ((self.bev_range[1::2] - self.bev_range[0::2]) // self.bev_resolution).astype(np.int32)
        self.sample_heights = config['sample_heights'] if 'sample_heights' in config else None

        if self.sample_heights is None:
            meshgrid = np.meshgrid(range(self.bev_height), range(self.bev_length), range(self.bev_width), indexing='ij')
            grid_points = np.stack([(meshgrid[1] + 0.5) * self.bev_resolution[0] + self.bev_range[0],
                                    (meshgrid[2] + 0.5) * self.bev_resolution[1] + self.bev_range[2],
                                    (meshgrid[0] + 0.5) * self.bev_resolution[2] + self.bev_range[4]], axis=0).astype(np.float32)
        else:
            self.bev_height = len(self.sample_heights)
            meshgrid = np.meshgrid(self.sample_heights, range(self.bev_length), range(self.bev_width), indexing='ij')
            grid_points = np.stack([(meshgrid[1] + 0.5) * self.bev_resolution[0] + self.bev_range[0],
                                    (meshgrid[2] + 0.5) * self.bev_resolution[1] + self.bev_range[2],
                                     meshgrid[0]], axis=0).astype(np.float32)
        # grid_points: 3 * bev_height * bev_length * bev_width
        # self.grid_points = nn.Parameter(torch.from_numpy(grid_points), requires_grad=False)
        self.register_buffer('grid_points',
                             torch.from_numpy(grid_points))

        self.img_encoder = CamEncoder(config['output_channels'], backbone=config['backbone'])
        self.input_width = config['width']
        self.input_height = config['height']
        self.downsample_factor = config['downsample_factor']
        # self.feat_conv = nn.Conv2d(cam_C, 64, 1, 1)
        # self.bev_conv = nn.Conv2d(64 * cam_num, 64, 1, 1)
        self.bev_compressor = nn.Sequential(
            nn.Conv2d(config['output_channels'] * self.bev_height, config['output_channels'], kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(config['output_channels']),
            nn.ReLU(),
        )
        self.bev_backbone = GeneralizedResNet(96, [[2, 128, 2], [2, 256, 2], [2, 256, 2]])
        self.bev_fpn = LSSFPN(
            in_indices=[-1, 0],
            in_channels=[256, 128],
            out_channels=128,
            scale_factor=1
        )

        pointcloud_range = [self.xbound[0], self.ybound[0], self.zbound[0],
                            self.xbound[1], self.ybound[1], self.zbound[1]]
        self.head = CenterHead(
            in_channels=128,
            tasks=CATEGORY_FOR_TRAINING,
            train_cfg={
                'point_cloud_range': pointcloud_range,
                'grid_size': [self.bev_length, self.bev_width, self.bev_height],
                'voxel_size': list(self.bev_resolution),
                'out_size_factor': 2,
                'dense_reg': 1,
                'gaussian_overlap': 0.1,
                'max_objs': 128,
                'min_radius': 2,
                'code_weights': [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
            },
            test_cfg={
                'post_center_limit_range': pointcloud_range,
                'max_per_img': 128,
                'max_pool_nms': False,
                'min_radius': [4, 12, 10, 1, 0.85, 1],
                'score_threshold': 0.1,
                'voxel_size': list(self.bev_resolution)[:2],
                'nms_type': 'circle',
                'pre_max_size': 1000,
                'post_max_size': 83,
                'nms_thr': 0.01,
            },
            bbox_coder={
                'type': 'MyCenterPointBBoxCoder',
                'pc_range': pointcloud_range,
                'post_center_range': pointcloud_range,
                'max_num': 500,
                'score_threshold': 0.1,
                'out_size_factor': 2,
                'voxel_size': list(self.bev_resolution)[:2],
                'code_size': 7,
            },
            common_heads={
                'reg': [2, 2],
                'height': [1, 2],
                'dim': [3, 2],
                'rot': [2, 2],
            },
            loss_cls=dict(type="GaussianFocalLoss", reduction="mean"),
            loss_bbox=dict(type="L1Loss", reduction="mean", loss_weight=0.25),
            separate_head=dict(type="SeparateHead", init_bias=-2.19, final_kernel=3),
            share_conv_channel=64,
            num_heatmap_convs=2,
            conv_cfg=dict(type="Conv2d"),
            norm_cfg=dict(type="BN2d"),
            bias="auto",
            norm_bbox=True,
            init_cfg=None,
        )

        self.use_seg_head = True
        if self.use_seg_head:
            self.seg_head = BEVSegmentationHead(in_channels=128, classes=['vehicle'], loss='focal')

        self.init_parameters()

    def init_parameters(self):
        prior_prob = 0.01
        bias_value = -math.log((1 - prior_prob) / prior_prob)

    def freeze_bn(self):
        '''Freeze BatchNorm layers.'''
        for layer in self.img_encoder.trunk.modules():
            if isinstance(layer, nn.BatchNorm2d):
                layer.eval()

    def reduce_mean_bev_feature(self, bev_feature):
        """
        params:
            bev_Feature: B*N*C*H*W
        """
        eps = 1e-7
        mask = (torch.abs(bev_feature) > 0).float()
        numer = torch.sum(bev_feature, dim=1)
        denom = torch.sum(mask, dim=1) + torch.tensor([eps]).type_as(numer)
        mean = numer / denom
        return mean

    def bilinear_sample(self, image, params):
        """
        :param image: sampling source of shape [N, C, H, W]
        :param grid: integer sampling pixel coordinates of shape [N, grid_H, grid_W, 2]
        :return: sampling result of shape [N, C, grid_H, grid_W]
        """
        _, C, _, _ = image.shape
        x0, x1, y0, y1 = params['x0'].long(), params['x1'].long(), params['y0'].long(), params['y1'].long()
        wa, wb, wc, wd = params['wa'], params['wb'], params['wc'], params['wd']
        ind=params['ind'].long()
        mask=params['mask']
        image = image.permute(1, 0, 2, 3)
        output_tensor = (image[:, ind, y0, x0] * wa + image[:, ind, y1, x0] * wb + image[:, ind, y0, x1] * wc + image[:, ind, y1, x1] * wd)
        output_tensor *= mask
        output_tensor = output_tensor.permute(1, 0, 2, 3)
        return output_tensor, mask

    def calc_bilinear_sample_params(self, pix_coords, feat2d_H, feat2d_W):
        BN, bev_L, bev_W, bev_H, _ = pix_coords.shape

        grid_H, grid_W = bev_L, bev_W
        sample_params = []
        for h_idx in range(bev_H):
            grid = pix_coords[:, :, :, h_idx, :]
            xgrid, ygrid = grid.split([1, 1], dim=-1)
            mask = ((xgrid >= 0) & (ygrid >= 0) & (xgrid < feat2d_W - 1) & (ygrid < feat2d_H - 1)).float()
            x0 = torch.floor(xgrid)
            x1 = x0 + 1.
            y0 = torch.floor(ygrid)
            y1 = y0 + 1.
            wa = ((x1 - xgrid) * (y1 - ygrid)).permute(3, 0, 1, 2)
            wb = ((x1 - xgrid) * (ygrid - y0)).permute(3, 0, 1, 2)
            wc = ((xgrid - x0) * (y1 - ygrid)).permute(3, 0, 1, 2)
            wd = ((xgrid - x0) * (ygrid - y0)).permute(3, 0, 1, 2)
            x0 = (x0 * mask).view(BN, grid_H, grid_W).int()
            y0 = (y0 * mask).view(BN, grid_H, grid_W).int()
            x1 = (x1 * mask).view(BN, grid_H, grid_W).int()
            y1 = (y1 * mask).view(BN, grid_H, grid_W).int()
            ind = torch.arange(BN, device=pix_coords.device) #torch.linspace(0, Nt - 1, Nt, device=image.device)
            ind = ind.view(BN, 1).expand(-1, grid_H).view(BN, grid_H, 1).expand(-1, -1, grid_W).int()
            sample_params.append(dict(
                x0=x0, x1=x1, y0=y0, y1=y1,
                wa=wa, wb=wb, wc=wc, wd=wd,
                ind=ind, mask=mask.permute(3, 0, 1, 2).expand(96, -1, -1, -1)
            ))
        return sample_params

    def calc_pix_coords(self, K, T_c2v,
                        img_post_rot=None, img_post_trans=None,
                        bev_rot=None,
                        normalize=True):
        """
        params:
            K: B*N*3*3, camera intrinsic
            T_c2v: B*N*4*4, transform from camera to vehicle
            bev_range: [x_min, x_max, y_min, y_max, z_min, z_max]
            bev_resolution: [res_x, res_y, res_z] (m/pixel)
            sample_heights: List[float]
        return:
            pix_coords: (B*N)*bev_L*bev_W*bev_H*2
        """
        B, N, _, _ = K.shape

        grid_points = self.grid_points.view(1, 1, 3, -1)
        if bev_rot is not None:
            grid_points = torch.linalg.inv(bev_rot) @ grid_points

        T_v2c = torch.inverse(T_c2v)  # B*N*4*4
        cam_points = T_v2c[:, :, 0:3, 0:3] @ grid_points + T_v2c[:, :, 0:3, 3:]

        eps = 1e-7
        pix_coords = cam_points / torch.clamp((cam_points[:, :, 2:, :]), min=eps)
        pix_coords = torch.matmul(K, pix_coords)
        if img_post_rot is not None and img_post_trans is not None:
            pix_coords = img_post_rot @ pix_coords + img_post_trans[..., None]
        pix_coords = pix_coords[:, :, :2, :]
        output_w, output_h = self.input_width // self.downsample_factor, self.input_height // self.downsample_factor
        # set invalid coordinate
        pix_coords = torch.where((cam_points[:, :, 2:, :] > eps) & torch.isfinite(pix_coords) &
                                 (pix_coords[:, :, :1, :] >= 0) & (pix_coords[:, :, :1, :] < output_w) &
                                 (pix_coords[:, :, 1:2, :] >= 0) & (pix_coords[:, :, 1:2, :] < output_h),
                                 pix_coords,
                                 -pix_coords.new_ones(1) * 1e5)
        pix_coords = pix_coords.permute(0, 1, 3, 2)\
                                .view(B * N, self.bev_height, self.bev_length * self.bev_width, 2)\
                                .contiguous()
        if normalize:
            # convert pix_coords to [-1, 1]
            pix_coords = (pix_coords * pix_coords.new_tensor([1. / (output_w - 1),
                                                              1. / (output_h - 1)]) - 0.5) * 2

        return pix_coords

    def view_transfomer(self, feature_img, pix_coords):
        """
        params:
            feature_img: B*N*C*H*W
            pix_coords: (B*N)*bev_L*bev_W*bev_H*2
        """
        B, N, C, H, W = feature_img.shape

        feature_img = feature_img.view(B * N, C, H, W)
        bev_feature = F.grid_sample(feature_img, pix_coords, padding_mode='zeros')      # B*N, C, bev_length, bev_width*bev_height
        bev_feature = self.reduce_mean_bev_feature(bev_feature.view(B, N, C, self.bev_height, self.bev_length * self.bev_width))
        bev_feature = self.bev_compressor(bev_feature.view(B, C * self.bev_height, self.bev_length, self.bev_width))

        return bev_feature

    def debug_view_transformer(self, input):
        B, N, C_raw, H_raw, W_raw = input['image'].size()

        intrins = input['intrins'].clone()
        img_post_rot = input['img_post_rot'].clone()
        img_post_trans = input['img_post_trans'].clone()
        bev_rot = input['bev_rot'].clone()

        T_c2v = torch.eye(4).type_as(intrins)
        T_c2v = T_c2v.repeat(B, N, 1, 1)
        T_c2v[:, :, 0:3, 0:3] = input['rots']
        T_c2v[:, :, 0:3, 3] = input['trans']

        self.downsample_factor = 1  # reset downsample_factor
        pix_coords = self.calc_pix_coords(intrins, T_c2v, img_post_rot, img_post_trans, bev_rot, normalize=True)

        feature_img = input['image'].view(B * N, C_raw, H_raw, W_raw)
        bev_feature = F.grid_sample(feature_img, pix_coords, padding_mode='zeros')      # B*N, C, bev_length, bev_width*bev_height
        bev_feature = self.reduce_mean_bev_feature(bev_feature.view(B, N, C_raw, self.bev_height, self.bev_length * self.bev_width))
        bev_feature = bev_feature.permute(0, 2, 1, 3).contiguous().view(B, self.bev_height*C_raw, self.bev_length, self.bev_width)

        for idx in range(self.bev_height):
            bev_image = bev_feature_to_image(bev_feature, idx)

            # draw visual image
            input.update({
                'bev_image': bev_image,
            })
            show_img = visualize_bev(input)
            cv2.imshow('show_img', show_img)
            cv2.waitKey(0)

    def forward(self, input):
        B, N, C_raw, H_raw, W_raw = input['image'].size()

        x = self.img_encoder(input['image'].view(-1, C_raw, H_raw, W_raw))
        BN, C, H, W = x.size()
        # feat2d = self.feat_conv(x)
        feat2d = x.view(B, N, C, H, W)

        intrins = input['intrins'].clone()

        T_c2v = torch.eye(4).type_as(intrins)
        T_c2v = T_c2v.repeat(B, N, 1, 1)
        T_c2v[:, :, 0:3, 0:3] = input['rots']
        T_c2v[:, :, 0:3, 3] = input['trans']

        img_post_rot = None
        img_post_trans = None
        # TODO (jingsen): move following code into calc_pix_coords func to enable in onnx export
        if 'img_post_rot' in input and 'img_post_trans' in input:
            img_post_rot = input['img_post_rot'].clone()
            img_post_trans = input['img_post_trans'].clone()
            scale_w, scale_h = W / W_raw, H / H_raw
            # intrins[:, :, 0, :] *= (W / W_raw)
            # intrins[:, :, 1, :] *= (H / H_raw)
            img_post_rot[:, :, 0, :] *= scale_w
            img_post_rot[:, :, 1, :] *= scale_h
            img_post_trans[:, :, 0] *= scale_w
            img_post_trans[:, :, 1] *= scale_h
        bev_rot = input['bev_rot'].clone()

        pix_coords = self.calc_pix_coords(intrins, T_c2v, img_post_rot, img_post_trans, bev_rot, normalize=True)
        bev_feature = self.view_transfomer(feat2d, pix_coords)
        # bev_feature = self.bev_conv(bev_feature)
        bev_feature = self.bev_backbone(bev_feature)
        bev_feature = self.bev_fpn(bev_feature)

        pred_dict = self.head(bev_feature, None)

        gt_bboxes_3d = [LiDARInstance3DBoxes(input['label'][batch_idx, :, [1, 2 ,3, 5, 4, 6, 7]], origin=(0.5, 0.5, 0.5))
                        for batch_idx in range(B)]  # convert wlh to lwh
        gt_labels_3d = [input['label'][batch_idx, :, 0] for batch_idx in range(B)]

        losses, visual_dict = self.head.loss(gt_bboxes_3d, gt_labels_3d, pred_dict)
        pred_bboxes = self.head.get_bboxes(pred_dict, [{'box_type_3d': LiDARInstance3DBoxes} for _ in range(B)])

        # segmentation
        if self.use_seg_head:
            seg_dict = self.seg_head(bev_feature, input['segmentation_anno'].permute(0, 3, 1, 2))
            for k, v in seg_dict.items():
                if 'loss' in k:
                    losses.update({k: v})

            input.update({
                'seg_feature_map': seg_dict['seg_feature_map'].detach().cpu().numpy(),
            })

        # draw visual image
        input.update({
            'box3d_preds': torch.cat([pred_bboxes[0][2].unsqueeze(1), pred_bboxes[0][0].tensor], dim=1),
            'pred_heatmap': visual_dict['pred_heatmap/task0'].detach().cpu().numpy(),
            'gt_heatmap': visual_dict['gt_heatmap/task0'].detach().cpu().numpy(),
        })

        loss = sum(v for _, v in losses.items())
        losses.update({'loss': loss})

        return loss, losses, input

    def visualize_result(self, data_dict, tensorboard=False):
        show_img = visualize_bev(data_dict)
        if tensorboard:
            show_img = cv2.cvtColor(show_img, cv2.COLOR_RGB2BGR)
            show_img = np.transpose(show_img, (2, 0, 1))

        return show_img

class IpmDetOnnx(IpmDet):
    def forward(self, image, pix_coords):
        B, N, C_raw, H_raw, W_raw = image.size()

        x = self.img_encoder(image.view(-1, C_raw, H_raw, W_raw))
        BN, C, H, W = x.size()
        # feat2d = self.feat_conv(x)
        feat2d = x.view(B, N, C, H, W)

        bev_feature = self.view_transfomer(feat2d, pix_coords)
        # bev_feature = self.bev_conv(bev_feature)
        bev_feature = self.bev_backbone(bev_feature)
        bev_feature = self.bev_fpn(bev_feature)

        pred_dict = self.head(bev_feature, None)
        rets = []
        for task_id in range(len(pred_dict)):
            rets.append(pred_dict[task_id][0]['heatmap'])
            rets.append(torch.cat([pred_dict[task_id][0]['reg'],
                                   pred_dict[task_id][0]['height'],
                                   pred_dict[task_id][0]['dim'],
                                   pred_dict[task_id][0]['rot']], dim=1))
            # for k, v, in pred_dict[task_id][0].items():
                # print(f'task_{task_id}/{k}: {v.shape}')
        return rets
