import numpy as np
import os
import json
import pdb
import torch
import math


def on_onesite(left_x, top_y):
    count = 0
    for i in range(2):
        if left_x[i] in [top_y[0], top_y[1]]:
            count += 1
    if count != 1:
        return True
    return False


def order_points(pt):
    left_x = np.argsort(pt[:, 0])
    top_y = np.argsort(pt[:, 1])
    is_onesite = on_onesite(left_x, top_y)
    if not is_onesite:
        lef = pt[left_x, :]
        lef = lef[:2, :]
        l_t = left_x[np.argsort(lef[:, 1])[0]]
    else:
        top = pt[top_y, :]
        top = top[:2, :]
        l_t = top_y[np.argsort(top[:, 0])[0]]
    left = np.array([pt[l_t, :], pt[(l_t + 1) % 4, :]])
    right = np.array([pt[(l_t + 2) % 4, :], pt[(l_t + 3) % 4, :]])
    return np.concatenate((left, right), axis=0)


def order_points_v2(pt):
    left_x = np.argsort(pt[:, 0])
    top_y = np.argsort(pt[:, 1])
    is_onesite = on_onesite(left_x, top_y)
    if not is_onesite:
        raw = pt[left_x, :]
        lef = raw[:2, :]
        rig = raw[2:, :]
        l_t = left_x[np.argsort(lef[:, 1])[0]]
        l_d = left_x[np.argsort(lef[:, 1])[1]]
        r_t = left_x[2 + np.argsort(rig[:, 1])[0]]
        r_d = left_x[2 + np.argsort(rig[:, 1])[1]]

    else:
        raw = pt[top_y, :]
        top = raw[:2, :]
        dow = raw[2:, :]
        l_t = top_y[np.argsort(top[:, 0])[0]]
        r_t = top_y[np.argsort(top[:, 0])[1]]
        l_d = top_y[2 + np.argsort(dow[:, 0])[0]]
        r_d = top_y[2 + np.argsort(dow[:, 0])[1]]

    # print(l_t, l_d, r_d, r_t)

    # left = np.array([pt[l_t, :], pt[l_d, :]])
    # right = np.array([pt[r_d, :], pt[r_t, :]])
    return l_t


def order_points_v3(pt):
    left_ids = np.argsort(pt[:, 0])
    if pt[left_ids[0], 1] <= pt[left_ids[1], 1]:
        return left_ids[0]
    else:
        return left_ids[1]


def sort_points(pts):
    pts = pts.detach().numpy()
    pts = pts.reshape(len(pts), 4, 2)
    for i in range(len(pts)):
        pts[i] = order_points(pts[i])
    pts = pts.reshape(len(pts), -1)
    pts = torch.from_numpy(pts)
    return pts


def sort_points_v2(pts):
    pts = pts.detach().numpy()
    pts = pts.reshape(len(pts), 4, 2)
    # new_pts = []
    for i in range(len(pts)):
        first_id = order_points_v3(pts[i].copy())
        order_pt = point_cmp(pts[i].copy(), first_id)
        pts[i] = order_pt
    pts = pts.reshape(len(pts), -1)
    pts = torch.from_numpy(pts)
    return pts


def point_cmp(points, first_id):
    center = points.mean(axis=0)
    angles = np.zeros(len(points))
    for i in range(len(points)):
        angles[i] = math.atan2(points[i][0] - center[0], points[i][1] - center[1])
    idxs = angles.argsort()
    for i in range(len(points)):
        if idxs[0] == first_id:
            break
        tmp = idxs[-1]
        idxs[1:] = idxs[:-1]
        idxs[0] = tmp
    points = points[idxs]
    return points


if __name__ == "__main__":
    pts = torch.tensor(
        [[128, 128, 256, 256, 256, 100, 128, 256], [100, 56, 56, 100, 56, 56, 100, 100]]
    )
    pts = sort_points_v2(pts)
