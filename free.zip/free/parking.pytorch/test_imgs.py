import argparse
import os
import cv2
from PIL import Image
from tqdm import tqdm
import numpy as np

import torch
import torchvision.transforms as T
import torchvision.transforms.functional as tf
from torch.utils import data

from lib.datasets.dataset_factory import get_dataset
from lib.models.model_factory import create_model
from lib.utils.vis_util import tensor_to_image
from lib.utils.common import init_opt
from lib.post.post_factory import create_post
from lib.models.loss_factory import create_loss
# from tools.trt_infer import TRTModule

def get_model(opt):
    print("initializing network...")
    model = create_model(opt, "pred")
    checkpoint = torch.load(opt.pth)
    model.load_state_dict(checkpoint["net"], strict=False)
    net = model.cuda().eval()
    return net


def image_to_tensor(image, size=(800, 800), to_tensor=T.ToTensor()):
    image = tf.resize(image, size)
    tensor = to_tensor(image).unsqueeze(0)
    return tensor


def main(opt):
    net = get_model(opt)

    # net = TRTModule(opt.pth)

    poster = create_post(opt, opt.draw)

    if opt.video:
        vw = cv2.VideoWriter(
            os.path.join(opt.save_path, "result.mp4"),
            cv2.VideoWriter_fourcc(*"mp4v"),
            2.0,
            # (opt.w_input * 2, opt.h_input),
            (600, 300),
        )

    if opt.img_dir:
        img_names = os.listdir(opt.img_dir)
        img_names.sort()
        for img_name in tqdm(img_names):
            img_path = os.path.join(opt.img_dir, img_name)
            image = Image.open(img_path)
            tensor = image_to_tensor(image, (opt.h_input, opt.w_input)).cuda()
            output = net(tensor)

            img_show = tensor_to_image(tensor)
            result_img = poster.run(output, img_show)

            if opt.video:
                vw.write(result_img)
            else:
                cv2.imwrite(os.path.join(opt.save_path, img_name), result_img)
    else:
        Dataset = get_dataset(opt.task)
        valset = Dataset(opt, "eval")
        loader_val = data.DataLoader(
            valset,
            batch_size=opt.val_batch,
            shuffle=False,
            num_workers=opt.workers,
            drop_last=True,
        )
        pbar = tqdm(enumerate(loader_val), total=len(loader_val))


        for i, (input, truth) in pbar:
            if opt.task == 'fisheye_freespace_seg':
                image = input["image"].cuda()
                pix_coords = input["pix_coords"].cuda() 

                output = net(image, pix_coords)

                bev_images = valset.vis_bev_transform(input, truth)
                result_img = poster.run(output, bev_images, i)
                # for i, bev_image in enumerate(bev_images):
                #     cv2.imshow(f"bev_image_{i}", bev_image)
                # cv2.waitKey(0)
                
            else:
                image = input.cuda()
                output = net(image)
                img_show = tensor_to_image(image)
                result_img = poster.run(output, img_show)
            cv2.imwrite(os.path.join(opt.save_path, "{}.png".format(i).zfill(8)), result_img)
            # exit()
            if i == 800:
                break


def get_parse():
    parser = argparse.ArgumentParser(description="Parking PyTorch Test On Imgs For Vis")
    parser.add_argument(
        "--config", default="./configs/bev_freespace_seg.yaml", type=str, help="path to config"
        )
    parser.add_argument("--test_datasets", default="", type=str, help="str of dict: path to test txt")
    parser.add_argument("--dataset_root", default="", type=str, help="path to origin data")
    parser.add_argument(
        "--pth", default="/test_output/hans/checkpoint/fisheye_freespace_seg-049.pth", type=str, help="path to model"
        )
    parser.add_argument("--img_dir", default="", type=str, help="path to imgs")
    parser.add_argument(
        "--save_path", default="/test_output/hans/result_freespace", type=str, help="path to save results"
        )
    parser.add_argument("--video", action="store_true", help="save video")
    parser.add_argument("--draw", action="store_true", help="draw result on window")
    return parser


if __name__ == "__main__":

    opt = get_parse().parse_args()
    init_opt(opt)
    opt.val_batch = 1
    opt.onnx = 1
    print(opt)

    torch.cuda.init()

    if not os.path.exists(opt.save_path):
        os.makedirs(opt.save_path)

    main(opt)
