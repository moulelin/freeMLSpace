import torch
from torch.utils import data
import numpy as np
import yaml
import argparse
import json
import cv2
from tqdm import tqdm
from pyquaternion import Quaternion
from utils.bev_visualizer import visualize_bev

from model.ipmdet import IpmDet, IpmDetOnnx
from dataset.nuscenes import BEVNuscenesLoader, BEVNuscenesEvalLoader, CATEGORY_FOR_TRAINING
from utils.tools import sample_to_cuda
from nuscenes.eval.common.config import config_factory
from nuscenes.utils.data_classes import Box
from nuscenes.eval.detection.constants import DETECTION_NAMES
from nuscenes.eval.detection.evaluate import DetectionEval
from nuscenes.eval.detection.utils import category_to_detection_name, detection_name_to_rel_attributes
from model.centerpoint import clip_sigmoid
from mmdet3d.core.bbox import LiDARInstance3DBoxes

parser = argparse.ArgumentParser(description='PyTorch ipmdet Testing')
parser.add_argument('--pth', default='checkpoint/ipmdet-nuscenes-backup.pth', type=str, help='model ckpt')
parser.add_argument('--hyp', default='config/hyp.ipmdet.nusc.yaml', type=str, help='learning rate')
parser.add_argument('--batch', default=1, type=int, help='batch size')
parser.add_argument('--detdir', default='/media/tianming/data/nuScenes', type=str, help='detection dataset dir')
args = parser.parse_args()

torch.set_grad_enabled(False)

def random_attr(name: str) -> str:
    """
    This is the most straight-forward way to generate a random attribute.
    Not currently used b/c we want the test fixture to be back-wards compatible.
    """
    # Get relevant attributes.
    rel_attributes = detection_name_to_rel_attributes(name)
    if len(rel_attributes) == 0:
        # Empty string for classes without attributes.
        return ''
    else:
        # Pick a random attribute otherwise.
        return rel_attributes[np.random.randint(0, len(rel_attributes))]

# print('Start debug...')
# import ptvsd
# ptvsd.enable_attach(address=('localhost', 5678))
# ptvsd.wait_for_attach()

if __name__ == '__main__':
    torch.set_grad_enabled(False)

    with open(args.hyp) as f:
        hyp = yaml.load(f, Loader=yaml.SafeLoader)  # load hyps
        grid_conf = {
            'xbound': hyp['xbound'],
            'ybound': hyp['ybound'],
            'zbound': hyp['zbound']
        }

    valset = BEVNuscenesEvalLoader(args.detdir, hyp['width'], hyp['height'], grid_conf)
    # valset = BEVNuscenesLoader(args.detdir, None, hyp['width'], hyp['height'], grid_conf,
    #                             hyp['image_aug'], hyp['bev_aug'], use_lidar=True, mode='val')
    valloader = data.DataLoader(valset, batch_size=args.batch, shuffle=False, num_workers=0, pin_memory=True, drop_last=True)

    net = IpmDetOnnx(hyp).cuda()
    checkpoint = torch.load(args.pth, map_location=torch.device('cpu'))
    print('epoch: ', checkpoint['epoch'])
    net.load_state_dict(checkpoint['net'])
    net = net.cuda().eval()

    results = {}
    meta = {
                'use_camera': True,
                'use_lidar': False,
                'use_radar': False,
                'use_map': False,
                'use_external': False,
            }

    category_names = list()
    for task_category_list in CATEGORY_FOR_TRAINING:
        category_names.extend(task_category_list)
    pbar = tqdm(enumerate(valloader), total=len(valloader))
    for i, data_dict in pbar:
        data_dict = sample_to_cuda(data_dict)

        intrins = data_dict['intrins'].clone()
        intrins[:, :, 0:2, :] /= hyp['downsample_factor']
        T_c2v = torch.eye(4).type_as(intrins)
        T_c2v = T_c2v.repeat(1, 6, 1, 1)
        T_c2v[:, :, 0:3, 0:3] = data_dict['rots']
        T_c2v[:, :, 0:3, 3] = data_dict['trans']

        img_post_rot = None
        img_post_trans = None
        if 'img_post_rot' in data_dict and 'img_post_trans' in data_dict:
            img_post_rot = data_dict['img_post_rot'].clone()
            img_post_trans = data_dict['img_post_trans'].clone()

        with torch.cuda.amp.autocast(enabled=True):
            pix_coords = net.calc_pix_coords(intrins, T_c2v,
                                             img_post_rot=img_post_rot,
                                             img_post_trans=img_post_trans,
                                             normalize=True)
            output = net(image=data_dict['image'], pix_coords=pix_coords)

        pred_dict = [[{
            'reg':  output[1][:, :2, ...],
            'height': output[1][:, 2:3, ...],
            'dim': output[1][:, 3:6, ...],
            'rot': output[1][:, 6:, ...],
            'heatmap': clip_sigmoid(output[0]),
        }], [{
            'reg':  output[3][:, :2, ...],
            'height': output[3][:, 2:3, ...],
            'dim': output[3][:, 3:6, ...],
            'rot': output[3][:, 6:, ...],
            'heatmap': clip_sigmoid(output[2]),
        }], [{
            'reg':  output[5][:, :2, ...],
            'height': output[5][:, 2:3, ...],
            'dim': output[5][:, 3:6, ...],
            'rot': output[5][:, 6:, ...],
            'heatmap': clip_sigmoid(output[4]),
        }], [{
            'reg':  output[7][:, :2, ...],
            'height': output[7][:, 2:3, ...],
            'dim': output[7][:, 3:6, ...],
            'rot': output[7][:, 6:, ...],
            'heatmap': clip_sigmoid(output[6]),
        }], [{
            'reg':  output[9][:, :2, ...],
            'height': output[9][:, 2:3, ...],
            'dim': output[9][:, 3:6, ...],
            'rot': output[9][:, 6:, ...],
            'heatmap': clip_sigmoid(output[8]),
        }], [{
            'reg':  output[11][:, :2, ...],
            'height': output[11][:, 2:3, ...],
            'dim': output[11][:, 3:6, ...],
            'rot': output[11][:, 6:, ...],
            'heatmap': clip_sigmoid(output[10]),
        }]]
        preds = net.head.get_bboxes(pred_dict, [{'box_type_3d': LiDARInstance3DBoxes} for _ in range(1)])

        # # draw visual image
        # data_dict.update({
        #     'box3d_preds': torch.cat([preds[0][2].unsqueeze(1), preds[0][0].tensor], dim=1),
        #     'pred_heatmap': pred_dict[0][0]['heatmap'].detach().cpu().numpy(),
        # })
        # show_img = visualize_bev(data_dict)
        # image_file = 'show_results/result_%06d.jpg'%i
        # cv2.imwrite(image_file, show_img)
        # cv2.imshow('show_img', show_img)
        # cv2.waitKey(0)

        for b in range(len(preds)): # batch
            eval_results = []
            sample_token = data_dict['sample_token'][b]
            ego_rot = data_dict['rot_pose'][b].cpu().numpy()
            ego_trans = data_dict['trans_pose'][b].cpu().numpy()
            pred = [val.cpu().numpy() if isinstance(val, torch.Tensor) else val.tensor.cpu().numpy() \
                    for val in preds[b]]
            for box3d, score, label in zip(*pred):
                detection_name = category_names[label]
                xyz, wlh, yaw = box3d[0:3], box3d[[4, 3, 5]], box3d[-1]
                box3d = Box(xyz.tolist(), wlh.tolist(), Quaternion([np.cos(yaw / 2.), 0., 0., np.sin(yaw / 2.)]))
                box3d.rotate(Quaternion(ego_rot))
                box3d.translate(ego_trans)
                eval_results.append(
                        {
                            'sample_token': sample_token,
                            'translation': list(box3d.center),
                            'size': list(box3d.wlh),
                            'rotation': list(box3d.orientation.q),
                            'velocity': [0.0, 0.0],
                            'detection_name': detection_name,
                            'detection_score': float(score),
                            'attribute_name': random_attr(detection_name)
                        })
            results[sample_token] = eval_results

    submission = {
        'meta': meta,
        'results': results
    }
    with open('nuscenes_detection_eval.json', 'w') as f:
        json.dump(submission, f)

    cfg = config_factory('detection_cvpr_2019')
    nusc_eval = DetectionEval(valset.nusc, cfg, 'nuscenes_detection_eval.json', eval_set='val', output_dir='eval_results/', verbose=True)
    metrics = nusc_eval.main()