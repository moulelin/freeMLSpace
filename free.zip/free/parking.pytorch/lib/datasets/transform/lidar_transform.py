import numpy as np
from scipy.spatial.transform import Rotation as R

import torch


class DropPoints(object):
    def __init__(self, p=0.2, drop_ratio=0.01):
        self.p = p
        self.drop_ratio = drop_ratio

    def __call__(self, im_lb):
        points, remissions, labels = (
            im_lb["points"],
            im_lb["remissions"],
            im_lb["labels"],
        )
        if np.random.rand() > self.p:
            return dict(points=points, remissions=remissions, labels=labels)

        drop_indexs = np.random.randint(
            0, len(points) - 1, int(len(points) * self.drop_ratio)
        )
        points = np.delete(points, drop_indexs, axis=0)
        if remissions is not None:
            remissions = np.delete(remissions, drop_indexs)
        if labels is not None:
            labels = np.delete(labels, drop_indexs)
        return dict(points=points, remissions=remissions, labels=labels)


class FlipPoints(object):
    def __init__(self, p=0.2):
        self.p = p

    def __call__(self, im_lb):
        points, remissions, labels = (
            im_lb["points"],
            im_lb["remissions"],
            im_lb["labels"],
        )
        if np.random.rand() > self.p:
            return dict(points=points, remissions=remissions, labels=labels)

        points[:, 1] = -points[:, 1]
        return dict(points=points, remissions=remissions, labels=labels)


class RandomShiftPoints(object):
    def __init__(self, p=0.2):
        self.p = p

    def __call__(self, im_lb):
        points, remissions, labels = (
            im_lb["points"],
            im_lb["remissions"],
            im_lb["labels"],
        )
        if np.random.rand() > self.p:
            return dict(points=points, remissions=remissions, labels=labels)

        jitter_x = np.random.uniform(-5, 5)
        jitter_y = np.random.uniform(-3, 3)
        jitter_z = np.random.uniform(-1, 0)
        points[:, 0] += jitter_x
        points[:, 1] += jitter_y
        points[:, 2] += jitter_z
        return dict(points=points, remissions=remissions, labels=labels)


class RandomRotatePoints(object):
    def __init__(self, p=0.2):
        self.p = p

    def __call__(self, im_lb):
        points, remissions, labels = (
            im_lb["points"],
            im_lb["remissions"],
            im_lb["labels"],
        )
        if np.random.rand() > self.p:
            return dict(points=points, remissions=remissions, labels=labels)

        points = points @ R.random(random_state=1234).as_matrix().T
        return dict(points=points, remissions=remissions, labels=labels)
