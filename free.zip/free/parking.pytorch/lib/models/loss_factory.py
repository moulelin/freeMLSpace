from .loss.parking_slot_seg_loss import ParkingSlotSegLoss
from .loss.parking_slot_point_loss import ParkingSlotPointLoss
from .loss.parking_slot_seg_angle_loss import ParkingSlotSegAngleLoss
from .loss.fisheye_seg_loss import FishEyeSegLoss
from .loss.fisheye_freespace_seg_loss import FishEyeFSSegLoss
from .loss.lidar_seg_loss import LidarSegLoss
from .loss.parking_slot_point_cls_loss import ParkingSlotPointClsLoss
from .loss.parking_center_point_cls_loss import ParkingCenterPointClsLoss
from .loss.parking_mid_point_cls_loss import ParkingMidPointClsLoss
from .loss.parking_mid_ws_loss import ParkingMidWSLoss
from .loss.fisheye_bev_det_loss import FishEyeBEVDetLoss


loss_factory = {
    "parking_slot_seg": ParkingSlotSegLoss,
    "parking_slot_point": ParkingSlotPointLoss,
    "parking_slot_seg_angle": ParkingSlotSegAngleLoss,
    "fisheye_seg": FishEyeSegLoss,
    "fisheye_freespace_seg": FishEyeFSSegLoss,
    "lidar_seg": LidarSegLoss,
    "parking_slot_point_cls": ParkingSlotPointClsLoss,
    "parking_center_point_cls": ParkingCenterPointClsLoss,
    "parking_slot_mid_point_cls": ParkingMidPointClsLoss,
    "parking_slot_mid_ws": ParkingMidWSLoss,
    "fisheye_bev_det": FishEyeBEVDetLoss,
}


def create_loss(opt):
    get_loss = loss_factory[opt.loss]
    loss = get_loss(opt)
    return loss
