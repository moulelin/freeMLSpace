from .post import (
    ParkingSlotSegPost,
    ParkingSlotPointPost,
    ParkingSlotPointClsPost,
    ParkingSlotSegAnglePost,
    ParkingCenterPointClsPost,
    ParkingMidClsPost,
    ParkingMidWSPost,
    FishEyeSegPost,
    LidarSegPost,
    FishEyeDetPost,
    FishEyeFSSegPost
)


post_factory = {
    "parking_slot_seg": ParkingSlotSegPost,
    "parking_slot_point": ParkingSlotPointPost,
    "parking_slot_seg_angle": ParkingSlotSegAnglePost,
    "fisheye_seg": FishEyeSegPost,
    "lidar_seg": LidarSegPost,
    "parking_slot_point_cls": ParkingSlotPointClsPost,
    "parking_center_point_cls": ParkingCenterPointClsPost,
    "parking_slot_mid_point_cls": ParkingMidClsPost,
    "parking_slot_mid_ws": ParkingMidWSPost,
    "fisheye_bev_det": FishEyeDetPost,
    "fisheye_freespace_seg": FishEyeFSSegPost,
}


def create_post(opt, draw=False):
    get_post = post_factory[opt.task]
    poster = get_post(opt, draw)
    return poster
