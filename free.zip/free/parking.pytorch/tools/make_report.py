import os
from re import L
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = ["SimHei"]

from docx import Document
from docx.oxml.ns import qn
from docx.shared import RGBColor


task_metric_map = {
    "parking_slot_seg": {"point": True, "center": True, "seg": True},
    "parking_slot_point": {"point": True, "center": True, "seg": True},
    "parking_slot_seg_angle": {"point": True, "center": True, "seg": True},
    "fisheye_seg": {"point": False, "center": False, "seg": True, "edge": True},
    "lidar_seg": {"point": False, "center": False, "seg": True},
    "fisheye_bev_det": { "center": True},
    "parking_slot_point_cls": {
        "point": True,
        "center": True,
        "seg": True,
        "type": True,
    },
    "parking_center_point_cls": {
        "point": True,
        "center": True,
        "seg": True,
        "type": True,
        "offset": True,
    },
    "parking_slot_mid_ws": {
        "point": True,
        "center": True,
        "seg": True,
        "type": True,
        "offset": True,
        "ws": True,
        "sp": True,
        "mid": True,
        "slot": True,
    },
}

task_important_scenes = {
    "parking_slot_seg": ["昏暗", "明亮", "雨天", "地下", "地上", "无磨损", "轻微磨损"],
    "parking_slot_point": ["昏暗", "明亮", "雨天", "地下", "地上", "无磨损", "轻微磨损"],
    "parking_slot_seg_angle": ["昏暗", "明亮", "雨天", "地下", "地上", "无磨损", "轻微磨损"],
    "fisheye_seg": ["昏暗", "明亮", "雨天", "地下", "地上", "无磨损", "轻微磨损"],
    "lidar_seg": ["雾天", "雪天", "雨天", "晴天多云", "地上", "地下"],
    "parking_slot_point_cls": ["昏暗", "明亮", "雨天", "地下", "地上", "无磨损", "轻微磨损"],
    "parking_center_point_cls": ["昏暗", "明亮", "雨天", "地下", "地上", "无磨损", "轻微磨损"],
    "parking_slot_mid_ws": ["昏暗", "明亮", "雨天", "地下", "地上", "无磨损", "轻微磨损"],
}


def add_title(doc, title, level=1):
    # doc.add_heading(title, level)
    t = doc.add_heading(level=level)
    text = t.add_run(title)
    text.font.name = "Times New Roman"
    text.element.rPr.rFonts.set(qn("w:eastAsia"), "微软雅黑")


def add_table(doc, infos, merge_rows=[], merge_cols=[], color_rows=[], color_cols=[]):
    rows = len(infos)
    cols = len(infos[0])
    table = doc.add_table(rows=rows, cols=cols)
    for i in range(rows):
        for j in range(cols):
            cell = table.cell(i, j)
            value = infos[i][j]
            if type(value) in [float, np.float32, np.float64, np.ndarray]:
                cell.text = "{:.4f}".format(value)
            else:
                cell.text = str(value)

            if type(value) != str:
                run = cell.paragraphs[0].runs[0]
                if j in color_cols or i in color_rows:
                    if value > 0:
                        run.font.color.rgb = RGBColor(0, 255, 0)
                    elif value < 0:
                        run.font.color.rgb = RGBColor(255, 0, 0)

    for i in merge_rows:
        for j in range(cols - 1):
            if infos[i][j + 1] == infos[i][j]:
                base = table.cell(i, j)
                table.cell(i, j + 1).text = ""
                base.merge(table.cell(i, j + 1))

    for j in merge_cols:
        for i in range(rows - 1):
            if infos[i + 1][j] == infos[i][j]:
                base = table.cell(i, j)
                table.cell(i + 1, j).text = ""
                base.merge(table.cell(i + 1, j))

    return table


def add_table_T(doc, infos, merge_rows=[], merge_cols=[], color_rows=[], color_cols=[]):
    infos_T = []
    for i in range(len(infos[0])):
        tmp = []
        for j in range(len(infos)):
            tmp.append(infos[j][i])
        infos_T.append(tmp)
    table = add_table(
        doc,
        infos_T,
        merge_rows=merge_cols,
        merge_cols=merge_rows,
        color_rows=color_cols,
        color_cols=color_rows,
    )

    return table


def generate_bar_image(
    save_path, labels, x_ticks, y_list, x_label, y_label, title, bar_width=0.2
):

    scale = len(labels) // 4 + 1
    base_x = np.arange(len(x_ticks)) * scale
    tmp_x = base_x.copy()

    plt.figure()

    # 绘制柱形图
    for i in range(len(labels)):
        base_x = base_x + bar_width
        plt.bar(base_x, y_list[i], label=labels[i], width=bar_width)
    plt.xticks(tmp_x + bar_width, x_ticks)
    plt.title(title)
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    plt.legend()
    plt.savefig(save_path)
    plt.close()


def generate_barh_image(
    save_path, labels, y_ticks, x_list, x_label, y_label, title, bar_height=0.2
):

    scale = len(labels) // 4 + 1
    base_y = np.arange(len(y_ticks)) * scale
    tmp_y = base_y.copy()

    plt.figure()

    # 绘制柱形图
    for i in range(len(labels)):
        base_y = base_y + bar_height
        plt.barh(base_y, x_list[i], label=labels[i], height=bar_height)
    plt.yticks(tmp_y + bar_height, y_ticks)
    plt.title(title)
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    plt.legend()
    plt.savefig(save_path)
    plt.close()


def generate_plot_image(save_path, labels, xs, ys, x_label, y_label, title):
    plt.figure()
    for i in range(len(labels)):
        plt.plot(xs[i], ys[i], label=labels[i])
    plt.title(title)
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    plt.legend()
    plt.savefig(save_path)
    plt.close()


def doc_model_info(doc, model_names, results):
    infos = [
        ["model type", "model path"],
    ]
    for idx, model_name in enumerate(model_names):
        infos.append([model_name, results[model_name]["model_path"]])
    add_table(doc, infos)


def doc_data_info(doc, test_file_dict, scene_count_info):
    doc.add_paragraph("test_file: ")
    for scene_value in test_file_dict:
        doc.add_paragraph("{}: {}".format(scene_value, test_file_dict[scene_value]))
    if scene_count_info:
        doc.add_paragraph("scene distribution: ")
        infos = [["class", "subclass", "num imgs"]]
        for scene_name in scene_count_info:
            for scene_value in scene_count_info[scene_name]:
                infos.append(
                    [scene_name, scene_value, scene_count_info[scene_name][scene_value]]
                )
        add_table(doc, infos, merge_cols=[0])
    else:
        doc.add_paragraph("scene distribution: None")


def doc_speed_info(doc, model_names, results):
    infos = [
        ["model_version", "batchsize=1 (s)"],
    ]
    for idx, model_name in enumerate(model_names):
        infos.append([model_name, results[model_name]["inference_time"]])
    add_table(doc, infos)


def doc_point_info(
    doc, model_names, results, opt, doc_lib_dir, mode="point", name="all"
):
    # accuracy table
    add_title(doc, f"{mode} result", level=3)
    if mode == "point":
        doc.add_paragraph("score threshold: {}".format(opt.thresh_point))
        cls_names = opt.point_cls
    elif mode == "center":
        doc.add_paragraph("score threshold: {}".format(opt.thresh_center))
        cls_names = opt.center_cls

    metric_names = ["Precision", "Recall", "F1-score", "AP"]

    infos = [
        ["model_version", "mAP", "tp_offset"],
        ["", "", ""],
    ]

    for idx, model_name in enumerate(model_names):
        infos.append(
            [
                model_name,
                results[model_name][mode]["mAP"],
                -results[model_name][mode]["tp_offset"],
            ]
        )

    for i in range(len(cls_names)):
        for j in range(len(metric_names)):
            infos[0].append(cls_names[i])
            infos[1].append(metric_names[j])
            for idx, model_name in enumerate(model_names):
                infos[idx + 2].append(results[model_name][mode][metric_names[j]][i])

    color_rows = []
    if len(model_names) == 2:
        infos.append(["{} vs {}".format(model_names[-1], model_names[-2])])
        for i in range(1, len(infos[0])):
            infos[-1].append(infos[-2][i] - infos[-3][i])
        color_rows.append(len(infos) - 1)

    add_table(doc, infos, color_rows=color_rows, merge_rows=[0])

    # draw PR
    x_label = "Recall"
    y_label = "Precision"
    for i in range(len(cls_names)):
        save_path = os.path.join(
            doc_lib_dir, "{}_{}_{}_pr.png".format(name, mode, cls_names[i])
        )
        xs, ys = [], []
        for idx, model_name in enumerate(model_names):
            infos[idx + 2].append(results[model_name][mode][metric_names[j]][i])
            xs.append(results[model_name][mode]["PR"][i][:, 0])
            ys.append(results[model_name][mode]["PR"][i][:, 1])

        title = "{} PR Compare: {}".format(mode, cls_names[i])
        generate_plot_image(save_path, model_names, xs, ys, x_label, y_label, title)
        doc.add_picture(save_path)


def doc_scene_point_info(
    doc, model_names, results, opt, doc_lib_dir, mode="point", name="all"
):
    # accuracy table
    add_title(doc, f"{mode} result", level=4)
    if mode == "point":
        doc.add_paragraph("score threshold: {}".format(opt.thresh_point))
        cls_names = opt.point_cls
    elif mode == "center":
        doc.add_paragraph("score threshold: {}".format(opt.thresh_center))
        cls_names = opt.center_cls

    metric_names = ["Precision", "Recall", "F1-score", "AP"]

    infos = [
        ["subclass", "model_version", "mAP"],
        ["", "", ""],
    ]

    color_rows = []
    scene_values = list(results[model_names[0]][name].keys())
    for scene_value in scene_values:
        for model_name in model_names:
            infos.append(
                [
                    scene_value,
                    model_name,
                    results[model_name][name][scene_value][mode]["mAP"],
                ]
            )
        if len(model_names) == 2:
            infos.append(
                [
                    scene_value,
                    "{} vs {}".format(model_names[-1], model_names[-2]),
                    infos[-1][-1] - infos[-2][-1],
                ]
            )
            color_rows.append(len(infos) - 1)

    for i in range(len(cls_names)):
        for j in range(len(metric_names)):
            infos[0].append(cls_names[i])
            infos[1].append(metric_names[j])
            idx = 0
            for scene_value in scene_values:
                for model_name in model_names:
                    infos[idx + 2].append(
                        results[model_name][name][scene_value][mode][metric_names[j]][i]
                    )
                    idx += 1
                if len(model_names) == 2:
                    infos[idx + 2].append(infos[idx + 1][-1] - infos[idx][-1])
                    idx += 1

    add_table(doc, infos, color_rows=color_rows, merge_rows=[0], merge_cols=[0])

    # # draw bar
    # mAP
    save_path = os.path.join(doc_lib_dir, "{}_{}_mAP.png".format(name, mode))

    x_ticks = scene_values
    y_list = []
    for model_name in model_names:
        tmp = []
        for scene_value in scene_values:
            tmp.append(results[model_name][name][scene_value][mode]["mAP"])
        y_list.append(tmp)

    x_label = "subclass"
    y_label = "mAP"
    title = f"{name} {mode} mAP Compare"
    generate_bar_image(save_path, model_names, x_ticks, y_list, x_label, y_label, title)
    doc.add_picture(save_path)

    for i in range(len(cls_names)):
        for j in range(len(metric_names)):
            save_path = os.path.join(
                doc_lib_dir,
                "{}_{}_{}_{}.png".format(name, mode, cls_names[i], metric_names[j]),
            )

            x_ticks = scene_values
            y_list = []
            for model_name in model_names:
                tmp = []
                for scene_value in scene_values:
                    tmp.append(
                        results[model_name][name][scene_value][mode][metric_names[j]][i]
                    )
                y_list.append(tmp)

            x_label = "subclass"
            y_label = metric_names[j]
            title = f"{name} {mode} {cls_names[i]} {metric_names[j]} Compare"
            generate_bar_image(
                save_path, model_names, x_ticks, y_list, x_label, y_label, title
            )
            doc.add_picture(save_path)


def doc_seg_info(doc, model_names, results, opt, doc_lib_dir, name="all"):
    # accuracy table
    add_title(doc, "seg result", level=3)

    infos = [
        ["", "mean-iou"],
    ]
    for idx, model_name in enumerate(model_names):
        infos.append([model_name, results[model_name]["seg"]["miou"]])

    for i in range(opt.n_cats):
        infos[0].append(opt.train_id_map[i])
        for idx, model_name in enumerate(model_names):
            infos[idx + 1].append(results[model_name]["seg"]["ious"][i])

    color_rows = []
    if len(model_names) == 2:
        infos.append(["{} vs {}".format(model_names[-1], model_names[-2])])
        for i in range(1, len(infos[0])):
            infos[-1].append(infos[-2][i] - infos[-3][i])
        color_rows.append(len(infos) - 1)

    add_table_T(doc, infos, color_rows=color_rows)

    # draw bar
    save_path = os.path.join(doc_lib_dir, "{}_seg_iou.png".format(name))

    y_ticks = infos[0][1:]
    x_list = []
    for idx, model_name in enumerate(model_names):
        x_list.append(infos[idx + 1][1:])

    x_label = "iou"
    y_label = "class"
    title = "Seg ious Compare"
    generate_barh_image(
        save_path, model_names, y_ticks, x_list, x_label, y_label, title
    )
    doc.add_picture(save_path)

    # add hist
    for model_name in model_names:
        add_title(doc, "seg hist {}".format(model_name), level=4)
        hist = results[model_name]["seg"]["hist"]
        h, w = hist.shape
        infos = []
        for i in range(h + 1):
            row = []
            for j in range(w + 1):
                if i == 0:
                    if j == 0:
                        row.append("")
                    else:
                        row.append(j - 1)
                else:
                    if j == 0:
                        row.append(i - 1)
                    else:
                        row.append(int(hist[i - 1, j - 1]))
            infos.append(row)
        add_table(doc, infos)


def doc_type_info(doc, model_names, results, opt, doc_lib_dir, name="all"):
    # accuracy table
    add_title(doc, "slot type result", level=3)

    infos = [
        ["slot_type", "model_version"],
    ]

    metric_names = ["slot_num", "Precision", "Recall", "F1"]
    infos[0].extend(metric_names)

    for i, cls_name in enumerate(opt.slot_type):
        for idx, model_name in enumerate(model_names):
            infos.append(
                [
                    cls_name,
                    model_name,
                ]
            )

    count = 1
    for i, cls_name in enumerate(opt.slot_type):
        for idx, model_name in enumerate(model_names):
            for j, metric_name in enumerate(metric_names):
                infos[count].append(results[model_name]["cls"][metric_name][i])
            count += 1
    add_table(doc, infos, merge_cols=[0])


def doc_offset_info(doc, model_names, results, opt, doc_lib_dir, name="all"):
    # accuracy table
    add_title(doc, "offset result", level=3)

    infos = [
        ["model_version", "acc"],
    ]

    for idx, model_name in enumerate(model_names):
        infos.append([model_name, results[model_name]["offset"]])

    add_table(doc, infos)


def doc_scene_seg_info(doc, model_names, results, opt, doc_lib_dir, name="all"):
    # accuracy table
    add_title(doc, "seg result", level=4)

    infos = [
        [""],
        [""],
    ]

    for idx, model_name in enumerate(model_names):
        infos.append([model_name])

    scene_values = list(results[model_names[0]][name].keys())
    for scene_value in scene_values:
        infos[0].append(scene_value)
        infos[1].append("mean-ious")
        for idx, model_name in enumerate(model_names):
            infos[idx + 2].append(results[model_name][name][scene_value]["seg"]["miou"])

        for i in range(opt.n_cats):
            infos[0].append(scene_value)
            infos[1].append(opt.train_id_map[i])
            for idx, model_name in enumerate(model_names):
                infos[idx + 2].append(
                    results[model_name][name][scene_value]["seg"]["ious"][i]
                )

    color_rows = []
    if len(model_names) == 2:
        infos.append(["{} vs {}".format(model_names[-1], model_names[-2])])
        for i in range(1, len(infos[0])):
            infos[-1].append(infos[-2][i] - infos[-3][i])
        color_rows.append(len(infos) - 1)

    add_table_T(doc, infos, merge_rows=[0], color_rows=color_rows)

    # # draw bar
    # mAP
    save_path = os.path.join(doc_lib_dir, "{}_seg_mean-ious.png".format(name))

    x_ticks = scene_values
    y_list = []
    for model_name in model_names:
        tmp = []
        for scene_value in scene_values:
            tmp.append(results[model_name][name][scene_value]["seg"]["miou"])
        y_list.append(tmp)

    x_label = "subclass"
    y_label = "mean-ious"
    title = f"{name} seg mean-ious Compare"
    generate_bar_image(save_path, model_names, x_ticks, y_list, x_label, y_label, title)
    doc.add_picture(save_path)

    # draw barh
    for scene_value in scene_values:
        save_path = os.path.join(
            doc_lib_dir, "{}_{}_seg_iou.png".format(name, scene_value)
        )
        y_ticks = [opt.train_id_map[i] for i in range(opt.n_cats)]
        x_list = []
        for idx, model_name in enumerate(model_names):
            x_tmp = []
            for i in range(opt.n_cats):
                x_tmp.append(results[model_name][name][scene_value]["seg"]["ious"][i])
            x_list.append(x_tmp)

        x_label = "iou"
        y_label = "seg cls"
        title = "{}:{} Seg ious Compare".format(name, scene_value)
        generate_barh_image(
            save_path, model_names, y_ticks, x_list, x_label, y_label, title
        )
        doc.add_picture(save_path)


def doc_kp_info(doc, model_names, results, opt, doc_lib_dir, mode="ws", name="all"):
    # accuracy table
    add_title(doc, f"{mode} result", level=3)

    for idx, model_name in enumerate(model_names):
        if mode not in results[model_name]:
            doc.add_paragraph("None")
            return

    if mode == "ws":
        doc.add_paragraph("score threshold: {}".format(opt.thresh_ws))
    elif mode == "sp":
        doc.add_paragraph("score threshold: {}".format(opt.thresh_sp))

    metric_names = ["Precision", "Recall", "F1-score", "AP", "tp_offset"]

    infos = [
        [
            "model_version",
        ],
    ]
    infos[0].extend(metric_names)

    for idx, model_name in enumerate(model_names):
        cur_info = []
        cur_info.append(model_name)
        for j in range(len(metric_names)):
            value = results[model_name][mode][metric_names[j]]
            if metric_names[j] == "tp_offset":
                cur_info.append(-value)
            else:
                cur_info.append(value[0])
        infos.append(cur_info)

    color_rows = []
    if len(model_names) == 2:
        infos.append(["{} vs {}".format(model_names[-1], model_names[-2])])
        for i in range(1, len(infos[0])):
            infos[-1].append(infos[-2][i] - infos[-3][i])
        color_rows.append(len(infos) - 1)

    add_table(doc, infos, color_rows=color_rows, merge_rows=[0])

    # draw PR
    x_label = "Recall"
    y_label = "Precision"
    save_path = os.path.join(doc_lib_dir, "{}_{}_pr.png".format(name, mode))
    xs, ys = [], []
    for idx, model_name in enumerate(model_names):
        xs.append(results[model_name][mode]["PR"][0][:, 0])
        ys.append(results[model_name][mode]["PR"][0][:, 1])

    title = "{} PR Compare".format(mode)
    generate_plot_image(save_path, model_names, xs, ys, x_label, y_label, title)
    doc.add_picture(save_path)


def doc_scene_kp_info(
    doc, model_names, results, opt, doc_lib_dir, mode="ws", name="all"
):
    # accuracy table
    add_title(doc, f"{mode} result", level=4)

    for idx, model_name in enumerate(model_names):
        for scene_value in results[model_name][name]:
            if mode not in results[model_name][name][scene_value]:
                doc.add_paragraph("None")
                return

    if mode == "ws":
        doc.add_paragraph("score threshold: {}".format(opt.thresh_ws))
    elif mode == "sp":
        doc.add_paragraph("score threshold: {}".format(opt.thresh_sp))

    metric_names = ["Precision", "Recall", "F1-score", "AP", "tp_offset"]

    infos = [
        ["subclass", "model_version"],
        ["", ""],
    ]

    color_rows = []
    scene_values = list(results[model_names[0]][name].keys())
    for scene_value in scene_values:
        for model_name in model_names:
            infos.append(
                [
                    scene_value,
                    model_name,
                ]
            )
        if len(model_names) == 2:
            infos.append(
                [
                    scene_value,
                    "{} vs {}".format(model_names[-1], model_names[-2]),
                ]
            )
            color_rows.append(len(infos) - 1)

    for j in range(len(metric_names)):
        infos[0].append(metric_names[j])
        idx = 0
        for scene_value in scene_values:
            for model_name in model_names:
                cur_info = []
                value = results[model_name][name][scene_value][mode][metric_names[j]]
                if metric_names[j] == "tp_offset":
                    cur_info.append(-value)
                else:
                    cur_info.append(value[0])
                idx += 1

            if len(model_names) == 2:
                infos[idx + 1].append(infos[idx][-1] - infos[idx - 1][-1])
                idx += 1

    add_table(doc, infos, color_rows=color_rows, merge_cols=[0])

    # # # draw bar
    # # mAP
    # save_path = os.path.join(doc_lib_dir, "{}_{}_mAP.png".format(name, mode))

    # x_ticks = scene_values
    # y_list = []
    # for model_name in model_names:
    #     tmp = []
    #     for scene_value in scene_values:
    #         tmp.append(results[model_name][name][scene_value][mode]["mAP"])
    #     y_list.append(tmp)

    # x_label = "subclass"
    # y_label = "mAP"
    # title = f"{name} {mode} mAP Compare"
    # generate_bar_image(save_path, model_names, x_ticks, y_list, x_label, y_label, title)
    # doc.add_picture(save_path)

    # for i in range(len(cls_names)):
    #     for j in range(len(metric_names)):
    #         save_path = os.path.join(doc_lib_dir, "{}_{}_{}_{}.png".format(name, mode, cls_names[i], metric_names[j]))

    #         x_ticks = scene_values
    #         y_list = []
    #         for model_name in model_names:
    #             tmp = []
    #             for scene_value in scene_values:
    #                 tmp.append(results[model_name][name][scene_value][mode][metric_names[j]][i])
    #             y_list.append(tmp)

    #         x_label = "subclass"
    #         y_label = metric_names[j]
    #         title = f"{name} {mode} {cls_names[i]} {metric_names[j]} Compare"
    #         generate_bar_image(save_path, model_names, x_ticks, y_list, x_label, y_label, title)
    #         doc.add_picture(save_path)


def doc_important_seg(
    doc,
    model_names,
    general_results,
    scene_results,
    important_scene_values,
    opt,
    doc_lib_dir,
):
    # # draw bar
    # mAP
    save_path = os.path.join(doc_lib_dir, "important_scenes_seg_mean-ious.png")

    x_ticks = []
    y_list = []

    x_ticks.append("general")
    x_ticks.extend(important_scene_values)

    for model_name in model_names:
        tmp = []
        tmp.append(general_results[model_name]["seg"]["miou"])
        for important_scene_value in important_scene_values:
            for scene_name in scene_results[model_name]:
                for scene_value in scene_results[model_name][scene_name]:
                    if important_scene_value == scene_value:
                        tmp.append(
                            scene_results[model_name][scene_name][scene_value]["seg"][
                                "miou"
                            ]
                        )
        y_list.append(tmp)

    x_label = "subclass"
    y_label = "mean-ious"
    title = f"important scene seg mean-ious Compare"
    generate_bar_image(save_path, model_names, x_ticks, y_list, x_label, y_label, title)
    doc.add_picture(save_path)


def generate_doc(
    doc_save_path,
    test_file_dict,
    general_results,
    scene_results,
    scene_count_info,
    opt,
):
    if not os.path.exists(doc_save_path):
        os.makedirs(doc_save_path)
    doc_save_file = os.path.join(doc_save_path, "eval_report.docx")
    doc_lib_dir = os.path.join(doc_save_path, "doc_lib")
    if not os.path.exists(doc_lib_dir):
        os.makedirs(doc_lib_dir)

    model_names = list(general_results.keys())

    doc = Document()

    ### main title
    add_title(doc, "泊车模型评测结果-20220519")

    ## model info
    add_title(doc, "Model Info: 模型信息", level=2)
    doc_model_info(doc, model_names, general_results)

    ## conclusion
    add_title(doc, "Conclusion: 结果分析", level=2)
    p = doc.add_paragraph()
    text = p.add_run("请将分析的结论写在这里")
    text.font.name = "Times New Roman"
    text.element.rPr.rFonts.set(qn("w:eastAsia"), "微软雅黑")

    # ## important results
    # if scene_results:
    #     add_title(doc, "Important Results: 重要结果展示", level=2)
    #     important_scene_values = task_important_scenes[opt.task]
    #     doc_important_seg(
    #         doc,
    #         model_names,
    #         general_results,
    #         scene_results,
    #         important_scene_values,
    #         opt,
    #         doc_lib_dir
    #     )

    ## data info
    add_title(doc, "Data Info: 评测数据信息", level=2)
    doc_data_info(doc, test_file_dict, scene_count_info)

    ## speed info
    add_title(doc, "speed Info: 模型速度信息", level=2)
    doc_speed_info(doc, model_names, general_results)

    ## all scenes eval general_results
    add_title(doc, "Eval Results For All Scenes: 整体评测结果", level=2)
    # point
    if task_metric_map[opt.task].get("point", False):
        doc_point_info(
            doc,
            model_names,
            general_results,
            opt,
            doc_lib_dir,
            mode="point",
            name="all",
        )
    # center
    if task_metric_map[opt.task].get("center", False):
        doc_point_info(
            doc,
            model_names,
            general_results,
            opt,
            doc_lib_dir,
            mode="center",
            name="all",
        )
    # seg
    if task_metric_map[opt.task].get("seg", False):
        doc_seg_info(doc, model_names, general_results, opt, doc_lib_dir, name="all")
    # type
    if task_metric_map[opt.task].get("type", False):
        doc_type_info(doc, model_names, general_results, opt, doc_lib_dir, name="all")
    # offset
    if task_metric_map[opt.task].get("offset", False):
        doc_offset_info(doc, model_names, general_results, opt, doc_lib_dir, name="all")
    # ws
    if task_metric_map[opt.task].get("ws", False):
        doc_kp_info(
            doc, model_names, general_results, opt, doc_lib_dir, mode="ws", name="all"
        )
    # sp
    if task_metric_map[opt.task].get("sp", False):
        doc_kp_info(
            doc, model_names, general_results, opt, doc_lib_dir, mode="sp", name="all"
        )
    # mid
    if task_metric_map[opt.task].get("mid", False):
        doc_kp_info(
            doc, model_names, general_results, opt, doc_lib_dir, mode="mid", name="all"
        )

    if scene_results:
        ## each scenes eval general_results
        add_title(doc, "Eval Results For Each Scene: 分场景评测结果", level=2)
        scene_names = list(scene_count_info.keys())
        for scene_name in scene_names:
            add_title(doc, f"Scene: {scene_name}", level=3)
            if task_metric_map[opt.task]["point"]:
                doc_scene_point_info(
                    doc,
                    model_names,
                    scene_results,
                    opt,
                    doc_lib_dir,
                    mode="point",
                    name=scene_name,
                )
            if task_metric_map[opt.task]["center"]:
                doc_scene_point_info(
                    doc,
                    model_names,
                    scene_results,
                    opt,
                    doc_lib_dir,
                    mode="center",
                    name=scene_name,
                )
            if task_metric_map[opt.task]["seg"]:
                doc_scene_seg_info(
                    doc, model_names, scene_results, opt, doc_lib_dir, name=scene_name
                )

    doc.save(doc_save_file)


if __name__ == "__main__":
    pass
