import argparse
import os
import sys
from PIL import Image
import numpy as np

import tensorrt as trt
import pycuda.driver as cuda
import pycuda.autoinit

sys.path.insert(0, "../")
from lib.utils.common import init_opt


def get_data_from_imgdir(img_dir, img_shape):
    file_names = os.listdir(img_dir)
    data = []
    for file_name in file_names:
        if file_name.split(".")[-1] not in ["jpg", "png", "PNG", "bmp", "jpeg"]:
            continue
        img = Image.open(os.path.join(img_dir, file_name))
        img = img.resize(img_shape)
        img = (np.array(img) / 255.0).astype("float32")
        img = np.ascontiguousarray(img.transpose((2, 0, 1))[None])
        data.append(img)
    return np.concatenate(data, axis=0)


class ImgDirCalibrator(trt.IInt8EntropyCalibrator2):
    def __init__(self, img_dir, img_shape, batch_size=1):
        trt.IInt8EntropyCalibrator2.__init__(self)

        self.data = get_data_from_imgdir(img_dir, img_shape)
        self.batch_size = batch_size
        self.current_index = 0

        self.device_input = cuda.mem_alloc(self.data[0].nbytes * self.batch_size)

    def get_batch_size(self):
        return self.batch_size

    def get_batch(self, names):
        if self.current_index + self.batch_size > self.data.shape[0]:
            return None

        current_batch = int(self.current_index / self.batch_size)
        if current_batch % 10 == 0:
            print(
                "Calibrating batch {:}, containing {:} images".format(
                    current_batch, self.batch_size
                )
            )

        batch = self.data[
            self.current_index : self.current_index + self.batch_size
        ].ravel()
        cuda.memcpy_htod(self.device_input, batch)
        self.current_index += self.batch_size
        return [self.device_input]

    def read_calibration_cache(self):
        pass

    def write_calibration_cache(self, cache):
        pass


def main(
    model_path,
    save_path,
    fp16_mode,
    int8_mode,
    img_dir=None,
    is_trt8=True,
):

    model_name = model_path.split("/")[-1]
    base_name = model_name[: -(len(model_name.split(".")[-1]) + 1)]
    mode = "fp32"
    if fp16_mode:
        mode = "fp16"
    if int8_mode:
        mode = "int8"
    engine_file_path = os.path.join(save_path, f"{base_name}_{mode}.trt")

    TRT_LOGGER = trt.Logger()
    EXPLICIT_BATCH = 1 << (int)(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH)

    if is_trt8:

        with trt.Builder(TRT_LOGGER) as builder, builder.create_network(
            EXPLICIT_BATCH
        ) as network, builder.create_builder_config() as config, trt.OnnxParser(
            network, TRT_LOGGER
        ) as parser:

            config.max_workspace_size = 1 << 28  # 256MiB
            builder.max_batch_size = 1

            if fp16_mode:
                config.set_flag(trt.BuilderFlag.FP16)

            if int8_mode:
                # config.set_flag(trt.BuilderFlag.FP16)
                config.set_flag(trt.BuilderFlag.INT8)
                config.int8_calibrator = ImgDirCalibrator(
                    img_dir=img_dir,
                    img_shape=(opt.w_input, opt.h_input),
                    batch_size=opt.val_batch,
                )
            # config.set_flag(trt.BuilderFlag.OBEY_PRECISION_CONSTRAINTS)

            print(network)
            # Parse model file
            if not os.path.exists(model_path):
                print("ONNX file {} not found.".format(model_path))
                exit(0)
            print("Loading ONNX file from path {}...".format(model_path))
            with open(model_path, "rb") as model:
                print("Beginning ONNX file parsing")
                if not parser.parse(model.read()):
                    print("ERROR: Failed to parse the ONNX file.")
                    for error in range(parser.num_errors):
                        print(parser.get_error(error))
                    return None

            network.get_input(0).shape = [1, 4, 3, 512, 640]
            network.get_input(1).shape = [1, 4, 10, 6400, 2]
            # print(network)
            # print(network.num_layers)
            # for i in range(network.num_layers):

            #     layer = network.get_layer(i)
            #     print(i,"%s,in=%d,out=%d,%s"%(str(layer.type)[10:],layer.num_inputs,layer.num_outputs,layer.name))
            #     print(layer, type(layer.type), layer.precision)
            #     exit()
            #     # print(i,"%s,in=%d,out=%d,%s"%(str(layer.type)[10:],layer.num_inputs,layer.num_outputs,layer.name))
            #     # if "ACTIVATION" in str(layer.type) or "CONVOLUTION" in str(layer.type):
            #     #     layer.precision = trt.float16
            #     #     layer.set_output_type(0, trt.float16)
            #     # layer.set_output_type(0, trt.float16)
            #     if "RESIZE" in str(layer.type):
            #         print(i,"%s,in=%d,out=%d,%s"%(str(layer.type)[10:],layer.num_inputs,layer.num_outputs,layer.name))
            #     #     print(layer.precision_is_set, layer.precision)
            #     #     # layer.precision = trt.DataType.FP16
            #     #     # layer.set_output_type(0, trt.DataType.FP16)
            #         layer.precision = trt.float32
            #         layer.set_output_type(0, trt.float32)
            #     #     print(layer.precision_is_set, layer.precision)
            print("Completed parsing of ONNX file")
            print(
                "Building an engine from file {}; this may take a while...".format(
                    model_path
                )
            )
            plan = builder.build_serialized_network(network, config)
            with open(engine_file_path, "wb") as f:
                f.write(plan)
                print("save  trt success!!")
    else:
        with trt.Builder(TRT_LOGGER) as builder, builder.create_network(
            EXPLICIT_BATCH
        ) as network, trt.OnnxParser(network, TRT_LOGGER) as parser:

            builder.max_workspace_size = 1 << 28
            builder.max_batch_size = 1
            builder.fp16_mode = fp16_mode
            builder.int8_mode = int8_mode

            if int8_mode:
                builder.int8_calibrator = ImgDirCalibrator(
                    img_dir=img_dir,
                    img_shape=(opt.w_input, opt.h_input),
                    batch_size=1,
                )
            print(network)
            if not os.path.exists(model_path):
                print("ONNX file {} not found.".format(model_path))
                exit(0)
            print("Loading ONNX file from path {}...".format(model_path))
            with open(model_path, "rb") as model:
                print("Beginning ONNX file parsing")
                if not parser.parse(model.read()):
                    print("ERROR: Failed to parse the ONNX file.")
                    for error in range(parser.num_errors):
                        print("parser.get_error(error)", parser.get_error(error))

            network.get_input(0).shape = [
                1,
                opt.input_channel,
                opt.h_input,
                opt.w_input,
            ]
            print("Completed parsing of ONNX file")
            engine = builder.build_cuda_engine(network)
            with open(engine_file_path, "wb") as f:
                f.write(engine.serialize())
                print("save  trt success!!")


def get_model_infos(model_info_str):
    model_infos = {}
    tmp_infos = eval(model_info_str)
    for model_name in tmp_infos:
        model_path = tmp_infos[model_name]
    return model_path


def get_parse():
    parser = argparse.ArgumentParser(description="ONNX To TRT")
    parser.add_argument("--config", default="", type=str, help="path to config")
    parser.add_argument("--model_info", default="", type=str, help="onnx model infos")
    parser.add_argument(
        "--onnx_path", default="./onnx/", type=str, help="dir to onnx model"
    )
    parser.add_argument(
        "--save_path", default="./trt_models/", type=str, help="path to save trt models"
    )
    parser.add_argument("--fp16", default=False, action="store_true", help="use fp16")
    parser.add_argument("--int8", default=False, action="store_true", help="use int8")
    parser.add_argument(
        "--img_dir", default="", type=str, help="calibrator imgs for int8"
    )
    parser.add_argument("--trt8", default=False, action="store_true", help="use TRT8")
    parser.add_argument("--batch", default=1, type=int, help="batchsize")
    return parser


if __name__ == "__main__":

    opt = get_parse().parse_args()
    init_opt(opt)
    opt.val_batch = opt.batch
    print(opt)

    if not os.path.exists(opt.save_path):
        os.makedirs(opt.save_path)

    # model_name = f"{opt.task}_{opt.backbone}_{opt.w_input}x{opt.h_input}_bs{opt.val_batch}.onnx"
    # onnx_model = os.path.join(opt.onnx_path, model_name)
    print(opt.model_info)
    model_path = get_model_infos(opt.model_info)
    print(model_path)

    main(
        model_path,
        opt.save_path,
        opt.fp16,
        opt.int8,
        opt.img_dir,
        opt.trt8,
    )
