import math
import sys
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
# from model.image_encoder import CamEncoder
# from utils.bev_visualizer import visualize_bev_v2, bev_feature_to_image
# from model.resnet import GeneralizedResNet
# from model.lss import LSSFPN
# from model.centerpoint import CenterHead
# from mmdet3d.core.bbox import LiDARInstance3DBoxes
# from mmcv.ops.point_sample import bilinear_grid_sample
# from dataset.parking_dataset import CATEGORY_FOR_TRAINING

from lib.models.common_opr.grid_point import bilinear_grid_sample_wb
from lib.models.common_opr.lss import LSSFPN
from lib.models.head.base_head import PointHead, chan_infos
from lib.models.backbone.resnet import GeneralizedResNet


class FishEyeBevDetHead(nn.Module):
    def __init__(self, opt, backbone, decoder, mode="train"):
        super(FishEyeBevDetHead, self).__init__()

        self.name = "fisheye_bevdet"
        self.opt = opt
        self.mode = mode
        self.backbone = backbone

        ### bev config 
        self.N = opt.num_cameras
        self.xbound = opt.xbound
        self.ybound = opt.ybound
        self.zbound = opt.zbound
        self.bev_range = np.array([self.xbound[0], self.xbound[1],
                                   self.ybound[0], self.ybound[1],
                                   self.zbound[0], self.zbound[1]], dtype=np.float32)
        self.bev_resolution = np.array([self.xbound[-1], self.ybound[-1], self.zbound[-1]], dtype=np.float32)
        self.bev_length, self.bev_width, self.bev_height = ((self.bev_range[1::2] - self.bev_range[0::2]) / self.bev_resolution).astype(np.int32)
        
        self.sample_heights = opt.sample_heights if hasattr(opt, "sample_heights") and getattr(opt, "sample_heights") else None

        if self.sample_heights is not None:
            self.bev_height = len(self.sample_heights)

        self.base_chan = chan_infos[self.opt.backbone]

        self.bev_compressor = nn.Sequential(
            nn.Conv2d(self.base_chan * self.bev_height, self.base_chan, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(self.base_chan),
            nn.ReLU(),
        )
        self.bev_backbone = GeneralizedResNet(self.base_chan, [[2, self.base_chan * 2, 2], [2, self.base_chan * 4, 2], [2, self.base_chan * 4, 2]])
        self.bev_fpn = LSSFPN(
            in_indices=[-1, 0],
            in_channels=[self.base_chan * 4, self.base_chan * 2],
            out_channels=self.base_chan * 2,
            scale_factor=1
        )

        ### bev head info
        car_center_chan = 6  # 2heatmap + 4(off)
        car_center_height_chan = 1 # center height
        car_lwh_chan = 3 # box length, width, height
        car_yaw_chan = 2 # box yaw x, y
        # person_center_chan = 3  # heatmap + 2(off)
        # person_center_height_chan = 1
        # person_lwh_chan = 3
        # person_yaw_chan = 2

        self.car_center_head = PointHead(self.base_chan * 2, 64, car_center_chan)      
        self.car_center_height_head = PointHead(self.base_chan * 2, 64, car_center_height_chan)      
        self.car_lwh_head = PointHead(self.base_chan * 2, 64, car_lwh_chan)        
        self.car_yaw_head = PointHead(self.base_chan * 2, 64, car_yaw_chan)      
        # self.person_center_head = PointHead(self.base_chan * 2, 64, person_center_chan)      
        # self.person_center_height_head = PointHead(self.base_chan * 2, 64, person_center_height_chan)      
        # self.person_lwh_head = PointHead(self.base_chan * 2, 64, person_lwh_chan)        
        # self.person_yaw_head = PointHead(self.base_chan * 2, 64, person_yaw_chan)     

        if self.mode not in ["train", "val"]:  
            self.decoder = decoder

        self.init_weights()

    def reduce_mean_bev_feature(self, bev_feature):
        """
        params:
            bev_Feature: B*N*C*H*W
        """
        eps = 1e-7
        mask = (torch.abs(bev_feature) > 0).float()
        numer = torch.sum(bev_feature, dim=1)
        denom = torch.sum(mask, dim=1) + torch.tensor([eps]).type_as(numer)
        mean = numer / denom

        return mean

    def view_transformer(self, feature_img, pix_coords):
        """
        params:
            feature_img: (B*N)*C*H*W
            pix_coords: (B*N)*1*(bev_L*bev_W*bev_H)*2
        """
        BN, C, H, W = feature_img.shape

        B = BN // self.N

        # bev_feature = F.grid_sample(feature_img, pix_coords, padding_mode='zeros', align_corners=False)      # B*N, C, bev_length, bev_width*bev_height
        bev_feature = bilinear_grid_sample_wb(feature_img, pix_coords, align_corners=False)
        bev_feature = self.reduce_mean_bev_feature(
            bev_feature.view(B, self.N, self.base_chan, self.bev_height, self.bev_length * self.bev_width)
        )
        bev_feature = self.bev_compressor(
            bev_feature.view(B, self.base_chan * self.bev_height, self.bev_length, self.bev_width)
        )

        return bev_feature
    

    def forward(self, input, input2=None):
        if not hasattr(self.opt, "onnx"):
            self.opt.onnx = 0
        if self.opt.onnx == 1:
            image = input
            pix_coords = input2 
        else:
            image = input["image"]
            pix_coords = input["pix_coords"]

        B, N, C_raw, H_raw, W_raw = image.size()
        _, _, bev_height, bev_hw, _ =  pix_coords.size()

        pix_coords = pix_coords.view(B*N, bev_height, bev_hw, 2)

        # get image feature
        x_dict = self.backbone(image.view(B*N, C_raw, H_raw, W_raw))
        feat = x_dict["feat"]

        # get bev feature
        bev_feature = self.view_transformer(feat, pix_coords)
        bev_feature = self.bev_backbone(bev_feature)
        bev_feature = self.bev_fpn(bev_feature)

        # get pred
        car_center_pred = self.car_center_head(bev_feature)
        car_center_height_pred = self.car_center_height_head(bev_feature)
        car_lwh_pred = self.car_lwh_head(bev_feature)
        car_yaw_pred = self.car_yaw_head(bev_feature)
        # person_center_pred = self.person_center_head(bev_feature)
        # person_center_height_pred = self.person_center_height_head(bev_feature)
        # person_lwh_pred = self.person_lwh_head(bev_feature)
        # person_yaw_pred = self.person_yaw_head(bev_feature)     

        if self.mode in ["train", "val"]:
            car_pred = torch.cat([car_center_pred, car_center_height_pred, car_lwh_pred, car_yaw_pred], dim=1)
            # person_pred = torch.cat([person_center_pred, person_center_height_pred, person_lwh_pred, person_yaw_pred], dim=1) 
            # return car_pred, person_pred
            return car_pred
        else:
            pred_dict = [[{
                'reg': car_center_pred[:, 2:4, ...],
                'reg1': car_center_pred[:, 4:6, ...],
                'height': car_center_height_pred,
                'dim': car_lwh_pred,
                'rot': car_yaw_pred,
                'heatmap': car_center_pred[:, 0:1, ...],
                'heatmap1': car_center_pred[:, 1:2, ...],
            }]
            # ,[{
            #     'reg': person_center_pred[:, :2, ...],
            #     'height': person_center_height_pred[:, :2, ...],
            #     'dim': person_lwh_pred,
            #     'rot': person_yaw_pred,
            #     'heatmap': person_center_pred[:, 0:1, ...],
            # }]
            ]
            return self.decoder.run(
                pred_dict
            )
    
    def init_weights(self):
        for name, module in self.named_modules():
            if isinstance(module, (nn.Conv2d, nn.Linear)):
                # nn.init.kaiming_normal_(module.weight, mode='fan_out')
                continue
            elif isinstance(module, nn.modules.batchnorm._BatchNorm):
                if hasattr(module, "last_bn") and module.last_bn:
                    nn.init.zeros_(module.weight)
                else:
                    nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)
        self.load_pretrain()

    def load_pretrain(self):
        if self.opt.head_pretrain_path:
            print("load head pretrain model: ", self.opt.head_pretrain_path)
            state_dict = torch.load(self.opt.head_pretrain_path, map_location="cpu")
            if "net" in state_dict:
                state_dict = state_dict["net"]

            # filter_keys = []
            # for key in state_dict:
            #     if "seghead" in key:
            #         filter_keys.append(key)
            #     if "aux" in key:
            #         filter_keys.append(key)

            # for key in filter_keys:
            #     print(key)
            #     state_dict.pop(key)

            self.load_state_dict(state_dict, strict=False)
            print("finished load")
        else:
            print("no head pretrain model!!!")

    def get_params(self):
        def add_param_to_list(mod, wd_params, nowd_params):
            for param in mod.parameters():
                if param.dim() == 1:
                    nowd_params.append(param)
                elif param.dim() == 4:
                    wd_params.append(param)
                else:
                    print(name)

        (
            wd_params,
            nowd_params,
            lr_mul10_wd_params,
            lr_mul10_nowd_params,
            lr_mul2_wd_params,
            lr_mul2_nowd_params,
        ) = ([], [], [], [], [], [])
        for name, child in self.named_children():
            if "head" in name:
                add_param_to_list(child, lr_mul2_wd_params, lr_mul2_nowd_params)
            else:
                add_param_to_list(child, wd_params, nowd_params)
        return (
            wd_params,
            nowd_params,
            lr_mul10_wd_params,
            lr_mul10_nowd_params,
            lr_mul2_wd_params,
            lr_mul2_nowd_params,
        )
