import psutil
import time

# psutil.disk_io_counters.cache_clear()

for i in range(100):

    disk_info = psutil.disk_io_counters()
    print(disk_info)
    time.sleep(1)
# print(".....................")
# print(disk_info['sda1'])
# print(disk_info['sda1'].read_bytes)
# # for i in range(1000)
