
import torch
import torch.nn as nn
import math

from lib.models.common_opr.network_blocks import BaseConv, CSPLayer, DWConv, Focus, ResLayer, SPPBottleneck


Cfgs = {
    "yolo-m": {
        "out_channel": 64,
        "depth_scale": 0.67,
        "width_scale": 0.75,
        "out_features": ("dark3", "dark4", "dark5"),
        "depthwise": False,
        "active": "relu",
        "stem": "conv",
    },
    "yolo-l": {
        "out_channel": 96,
        "depth_scale": 1.0,
        "width_scale": 1.0,
        "out_features": ("dark3", "dark4", "dark5"),
        "depthwise": False,
        "active": "silu",
        "stem": "focus",
    },
}


def ceil(c, stride=8):
    return math.ceil(c / stride) * stride


class CSPDarknet(nn.Module):
    def __init__(
        self,
        dep_mul,
        wid_mul,
        out_features=("dark3", "dark4", "dark5"),
        depthwise=False,
        stem='conv',
        act="silu",
    ):
        super().__init__()
        assert out_features, "please provide output features of Darknet"
        self.out_features = out_features
        if 'dark6' in self.out_features:
            base_out_channels = [256, 512, 768, 1024]
        else:
            base_out_channels = [256, 512, 1024]
        self.out_channels = [ceil(x * wid_mul) for x in base_out_channels]
        Conv = DWConv if depthwise else BaseConv

        base_channels = int(wid_mul * 64)  # 64
        base_depth = max(round(dep_mul * 3), 1)  # 3

        # stem
        # self.stem = Focus(3, base_channels, ksize=3, act=act)
        # self.stem = Conv(3, base_channels, 3, 2, act=act)
        if stem == 'conv':
            self.stem = nn.Sequential(
                Conv(3, base_channels//2, 3, 1, act=act),
                Conv(base_channels//2, base_channels, 3, 2, act=act)
            )
        else:
            self.stem = Focus(3, base_channels, ksize=3, act=act)

        # dark2
        self.dark2 = nn.Sequential(
            Conv(base_channels, base_channels * 2, 3, 2, act=act),
            CSPLayer(
                base_channels * 2,
                base_channels * 2,
                n=base_depth,
                depthwise=depthwise,
                act=act,
            ),
        )

        # dark3
        self.dark3 = nn.Sequential(
            Conv(base_channels * 2, base_channels * 4, 3, 2, act=act),
            CSPLayer(
                base_channels * 4,
                base_channels * 4,
                n=base_depth * 3,
                depthwise=depthwise,
                act=act,
            ),
        )

        # dark4
        self.dark4 = nn.Sequential(
            Conv(base_channels * 4, base_channels * 8, 3, 2, act=act),
            CSPLayer(
                base_channels * 8,
                base_channels * 8,
                n=base_depth * 3,
                depthwise=depthwise,
                act=act,
            ),
        )

        if 'dark6' in self.out_features:
            # dark5
            self.dark5 = nn.Sequential(
                Conv(base_channels * 8, base_channels * 12, 3, 2, act=act), # channel base 768
                CSPLayer(
                    base_channels * 12,
                    base_channels * 12,
                    n=base_depth,
                    shortcut=False,
                    depthwise=depthwise,
                    act=act,
                ),
            )

            # dark6
            self.dark6 = nn.Sequential(
                Conv(base_channels * 12, base_channels * 16, 3, 2, act=act), # channel base 1024
                SPPBottleneck(base_channels * 16, base_channels * 16, activation=act),
                CSPLayer(
                    base_channels * 16,
                    base_channels * 16,
                    n=base_depth,
                    shortcut=False,
                    depthwise=depthwise,
                    act=act,
                ),
            )
        else:
            # dark5
            self.dark5 = nn.Sequential(
                Conv(base_channels * 8, base_channels * 16, 3, 2, act=act),
                SPPBottleneck(base_channels * 16, base_channels * 16, activation=act), # channel base 1024
                CSPLayer(
                    base_channels * 16,
                    base_channels * 16,
                    n=base_depth,
                    shortcut=False,
                    depthwise=depthwise,
                    act=act,
                ),
            )

    def forward(self, x):
        outputs = {}
        x = self.stem(x)
        outputs["stem"] = x
        x = self.dark2(x)
        outputs["dark2"] = x
        x = self.dark3(x)
        outputs["dark3"] = x
        x = self.dark4(x)
        outputs["dark4"] = x
        x = self.dark5(x)
        outputs["dark5"] = x
        if 'dark6' in self.out_features:
            x = self.dark6(x)
            outputs["dark6"] = x
        return {k: v for k, v in outputs.items() if k in self.out_features}


class UpFuse2(nn.Module):
    def __init__(self, in_chan1, in_chan2, out_chan, scale_factor=2):
        super(UpFuse2, self).__init__()
        # self.up = nn.Upsample(scale_factor=scale_factor, mode='nearest')
        self.up = nn.ConvTranspose2d(
            in_chan1, in_chan1, scale_factor, scale_factor, 0, groups=1, bias=False
        )

        in_chan = in_chan1 + in_chan2

        self.conv = nn.Sequential(
            nn.Conv2d(in_chan, out_chan, kernel_size=1, padding=0, bias=False),
            # nn.GroupNorm(16, out_channels),
            nn.BatchNorm2d(out_chan),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_chan, out_chan, kernel_size=3, padding=1, bias=False),
            # nn.GroupNorm(16, out_channels),
            nn.BatchNorm2d(out_chan),
            nn.ReLU(inplace=True)
        )

    def forward(self, x1, x2):
        x1 = self.up(x1)
        x1 = torch.cat([x2, x1], dim=1)
        return self.conv(x1)


class DarkNetEncoder(nn.Module):
    def __init__(self, opt, mode="train"):
        super(DarkNetEncoder, self).__init__()
        self.mode = mode
        self.opt = opt
        self.name = self.opt.backbone

        cfg = Cfgs[opt.backbone]

        self.darknet = CSPDarknet(
            dep_mul=cfg["depth_scale"], 
            wid_mul=cfg["width_scale"],
            out_features=cfg["out_features"],
            depthwise=cfg["depthwise"],
            stem=cfg["stem"],
            act=cfg["active"],
        )

        base_chan = cfg["out_channel"]
        # dark5, dark4
        dark5_chan = int(base_chan * 16 * cfg["width_scale"])
        dark4_chan = int(base_chan * 8 * cfg["width_scale"])
        dark3_chan = int(base_chan * 4 * cfg["width_scale"])

        self.up_fuse = UpFuse2(dark5_chan, dark4_chan, base_chan)

        self.init_weights()

    def init_weights(self):
        for name, module in self.named_modules():
            if isinstance(module, (nn.Conv2d, nn.Linear)):
                nn.init.kaiming_normal_(module.weight, mode="fan_out")
            elif isinstance(module, nn.modules.batchnorm._BatchNorm):
                if hasattr(module, "last_bn") and module.last_bn:
                    nn.init.zeros_(module.weight)
                else:
                    nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)
        self.load_pretrain()

    def load_pretrain(self):
        if self.opt.backbone_pretrain_path:
            print("loading backbone pretrain model: ", self.opt.backbone_pretrain_path)
            state_dict = torch.load(self.opt.backbone_pretrain_path, map_location="cpu")
            if "net" in state_dict:
                state_dict = state_dict["net"]

            self.darknet.load_state_dict(state_dict, strict=False)
            print("finish loading")
        else:
            print("no backbone pretrain model!!!")

    def forward(self, x):

        x_dict = self.darknet(x)
        x = self.up_fuse(x_dict['dark5'], x_dict['dark4'])
        return {
            "feat": x,
            "dark5": x_dict['dark5'],
            "dark4": x_dict['dark4'],
        }