import torch
import numpy as np
import cv2


point_cls_color_list = [(255, 0, 0), (0, 0, 255)]
center_cls_color_list = [(0, 255, 0), (244, 35, 232)]

np.random.seed(1234)
palette = np.random.randint(0, 256, (256, 3), dtype=np.uint8)


def tensor_to_image(tensor):
    if len(tensor.size()) == 4:
        if tensor.size(1) == 3:
            tensor = tensor.cpu().squeeze(0)
            img = tensor.permute(1, 2, 0).contiguous()
            img = img.numpy() * 255
            img = img[:, :, ::-1].astype(np.uint8)
        else:
            tensor = tensor.cpu().squeeze(0)
            img = tensor.permute(1, 2, 0).contiguous()
            img = img.numpy()
    elif len(tensor.size()) == 3:
        if tensor.size(0) == 3:
            tensor = tensor.cpu()
            img = tensor.permute(1, 2, 0).contiguous()
            img = img.numpy() * 255
            img = img[:, :, ::-1].astype(np.uint8)
        else:
            tensor = tensor.cpu()
            img = tensor.permute(1, 2, 0).contiguous()
            img = img.numpy()

    return img


def draw_seg_images(output, img):
    seg_img = palette[output]
    draw_seg_id(output, seg_img)
    combined_img = cv2.addWeighted(img[0], 1.0, seg_img, 0.3, 0)
    return combined_img, seg_img


def draw_seg_id(seg_out, seg_img):
    max_id = seg_out.max()
    for cls_idx in range(1, max_id + 1):
        mask = seg_out == cls_idx
        if mask.sum() < 5:
            continue
        mask = (mask * 255.0).astype("uint8")

        cv_version = cv2.__version__
        if int(cv_version.split(".")[0]) > 3:
            contours, _ = cv2.findContours(
                mask.astype("uint8"), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE
            )  # opencv 4.1.2.30
        else:
            _, contours, _ = cv2.findContours(
                mask.astype("uint8"), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE
            )  # opencv 3.4.11
        # contours, _ = cv2.findContours(mask.astype("uint8"), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE) # opencv 4.1.2.30
        # _, contours, _ = cv2.findContours(mask.astype("uint8"), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE) # opencv 3.4.11
        for contour in contours:
            if cv2.contourArea(contour) < 5:
                continue
            contour = contour.reshape(-1, 2)
            center = contour.mean(axis=0).astype("int32").tolist()
            cv2.putText(
                seg_img,
                str(cls_idx),
                (center[0], center[1]),
                cv2.FONT_HERSHEY_COMPLEX,
                1,
                (255, 255, 255),
                1,
            )


def plot_points(img, points, color=(0, 0, 255)):
    points = points.astype(np.int32)
    # print(points)
    for i in range(points.shape[0]):
        x, y = points[i, :]
        cv2.circle(img, (x, y), 1, color, 8)
    return img


def plot_point_types(img, points, cls_ids, color=(0, 0, 255)):
    points = points.astype(np.int32)
    cls_ids = cls_ids.astype(np.int32)
    # print(points)
    for i in range(points.shape[0]):
        x, y = points[i, :]
        cls_id = cls_ids[i]
        cv2.putText(
            img, "{}".format(cls_id), (x, y), cv2.FONT_HERSHEY_COMPLEX, 2, color, 2
        )
    return img


def plot_angle(img, points, angle, color=(0, 255, 0)):
    points = points.astype(np.int32)
    for i in range(points.shape[0]):
        dx, dy = angle[i, :]
        x, y = points[i, :]
        cv2.arrowedLine(img, (x, y), (x + int(100 * dx), y + int(100 * dy)), color)
    return img


def sort_points(points):
    num = points.shape[0]
    xc = points[:, 0].float().mean()
    yc = points[:, 1].float().mean()
    theta = torch.atan2(points[:, 1] - yc, points[:, 0] - xc)
    theta[theta < 0] += 2 * 3.14159
    theta, idx = torch.sort(theta)
    points_sorted = torch.index_select(points, 0, idx)
    return points_sorted


def plot_polygon(img, points=None, bbox=None, color=None):
    color = (0, 255, 0) if color is None else color
    if points != None:
        if points.shape[0] > 1:
            points = sort_points(points).numpy().astype(np.int)
            for i in range(points.shape[0] - 1):
                p1 = (points[i, 0], points[i, 1])
                p2 = (points[i + 1, 0], points[i + 1, 1])
                cv2.line(img, p1, p2, color)
            p1 = (points[i + 1, 0], points[i + 1, 1])
            p2 = (points[0, 0], points[0, 1])
            cv2.line(img, p1, p2, color)
    if bbox != None:
        cv2.rectangle(img, (bbox[0], bbox[1]), (bbox[2], bbox[3]), color)
    return img


def get_line_point(x1, y1, x2, y2):
    points = []
    if (x2 - x1) == 0:
        if y2 < y1:
            for j in range(y1, y2 - 1, -1):
                points.append([x2, j])
        else:
            for j in range(y1, y2 + 1, 1):
                points.append([x2, j])
    elif (y2 - y1) == 0:
        if x2 < x1:
            for i in range(x1, x2 - 1, -1):
                points.append([i, y2])
        else:
            for i in range(x1, x2 + 1, 1):
                points.append([i, y2])
    else:
        # y = k*x + b, b = y - k*x, x = (y - b) / k
        slope = (y2 - y1) * 1.0 / (x2 - x1)
        intercept = y1 - slope * x1

        if abs(slope) < 1:
            if x2 < x1:
                for i in range(x1, x2 - 1, -1):
                    y_ = round(i * slope + intercept)
                    points.append([i, y_])
            else:
                for i in range(x1, x2 + 1, 1):
                    y_ = round(i * slope + intercept)
                    points.append([i, y_])
        else:
            if y2 < y1:
                for j in range(y1, y2 - 1, -1):
                    x_ = round((j - intercept) / slope)
                    points.append([x_, j])
            else:
                for j in range(y1, y2 + 1, 1):
                    x_ = round((j - intercept) / slope)
                    points.append([x_, j])
    return points


def polygon_area(points):
    """返回多边形面积"""
    points = np.array(points)
    min_coord = np.array(points).min()

    if min_coord < 0:
        pad = -min_coord + 1
    else:
        pad = 0
    points += pad

    area = 0
    q = points[-1]
    for p in points:
        area += p[0] * q[1] - p[1] * q[0]
        q = p
    return area / 2
