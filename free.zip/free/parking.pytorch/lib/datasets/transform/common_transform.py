import random
import math

import numpy as np
import torch
from PIL import Image, ImageFilter
import torchvision.transforms.functional as tf
import torchvision.transforms as T
from torchvision.transforms import InterpolationMode


POINT_KEYS = ["lb_slot", "lb_ws", "lb_sp"]


class RandomResizedCrop(object):
    """
    size should be a tuple of (H, W)
    """

    def __init__(self, p=0.5, scales=(0.5, 1.0), size=(384, 384)):
        self.p = p
        self.scales = scales
        self.size = size

    def __call__(self, im_lb):
        if np.random.random() > self.p:
            return im_lb
        if self.size is None:
            return im_lb

        im = im_lb["im"]
        lb_seg = im_lb.get("lb_seg", None)

        crop_h, crop_w = self.size
        scale = random.uniform(min(self.scales), max(self.scales))
        im_h, im_w = [math.ceil(el * scale) for el in im.size[:2]]

        im = tf.resize(im, (im_h, im_w))

        if lb_seg is not None:
            lb_seg = tf.resize(
                lb_seg, (im_h, im_w), interpolation=InterpolationMode.NEAREST
            )

        if (im_h, im_w) == (crop_h, crop_w):
            im_lb["im"] = im
            if lb_seg is not None:
                im_lb["lb_seg"] = lb_seg
            return im_lb

        pad_h, pad_w = 0, 0
        if im_h < crop_h:
            pad_h = (crop_h - im_h) // 2 + 1
        if im_w < crop_w:
            pad_w = (crop_w - im_w) // 2 + 1
        if pad_h > 0 or pad_w > 0:
            im = tf.pad(im, (pad_w, pad_h))
            if lb_seg is not None:
                lb_seg = tf.pad(lb_seg, (pad_w, pad_h), fill=255)

        p_im_w, p_im_h = im.size
        sh, sw = random.random(), random.random()
        sh, sw = int(sh * (p_im_h - crop_h)), int(sw * (p_im_w - crop_w))

        im = tf.crop(im, sh, sw, crop_h, crop_w)
        im_lb["im"] = im
        if lb_seg is not None:
            lb_seg = tf.crop(lb_seg, sh, sw, crop_h, crop_w)
            im_lb["lb_seg"] = lb_seg

        for point_key in POINT_KEYS:
            points = im_lb.get(point_key, None)
            if points is None:
                continue
            points[:, 0::2] = points[:, 0::2] * im_w
            points[:, 1::2] = points[:, 1::2] * im_h
            points[:, 0::2] = (points[:, 0::2] + pad_w - sw).div(crop_w)
            points[:, 1::2] = (points[:, 1::2] + pad_h - sh).div(crop_h)
            im_lb[point_key] = points

        return im_lb


class RandomAffine(object):
    def __init__(
        self,
        p=0.5,
        size=(384, 384),
        degrees=90,
        translate=0.1,
        scale=0.2,
        shear=15,
        fill_value=255,
    ):
        self.p = p
        self.size = size
        self.degrees = degrees
        self.translate = translate
        self.scale = scale
        self.shear = shear
        self.fill_value = fill_value

    def __call__(self, im_lb):
        if np.random.random() > self.p:
            return im_lb
        if self.size is None:
            return im_lb

        im = im_lb["im"]
        lb_seg = im_lb.get("lb_seg", None)

        raw_w, raw_h = im.size
        center = [raw_w / 2, raw_h / 2]
        # Rotation and Scale
        degrees = random.uniform(-self.degrees, self.degrees)
        scale = random.uniform(1 - self.scale, 1 + self.scale)

        # Shear
        s0 = math.tan(
            random.uniform(-self.shear, self.shear) * math.pi / 180
        )  # x shear (deg)
        s1 = math.tan(
            random.uniform(-self.shear, self.shear) * math.pi / 180
        )  # y shear (deg)
        shear = [s0, s1]
        # Translation
        t0 = (
            random.uniform(-self.translate, self.translate) * raw_w
        )  # x translation (pixels)
        t1 = (
            random.uniform(-self.translate, self.translate) * raw_h
        )  # y translation (pixels)
        translate = [t0, t1]

        inv_matrix = tf._get_inverse_affine_matrix(
            center, degrees, translate, scale, shear
        )
        inv_M = torch.cat(
            [torch.Tensor(inv_matrix).reshape(2, 3), torch.Tensor([[0, 0, 1]])], dim=0
        )
        M = torch.inverse(inv_M)

        im = tf.affine(
            im,
            degrees,
            translate,
            scale,
            shear,
            interpolation=InterpolationMode.BILINEAR,
        )
        im = tf.resize(im, (self.size[0], self.size[1]))
        im_lb["im"] = im

        if lb_seg is not None:
            lb_seg = tf.affine(
                lb_seg,
                degrees,
                translate,
                scale,
                shear,
                interpolation=InterpolationMode.NEAREST,
                fill=self.fill_value,
            )
            lb_seg = tf.resize(
                lb_seg,
                (self.size[0], self.size[1]),
                interpolation=InterpolationMode.NEAREST,
            )
            im_lb["lb_seg"] = lb_seg

        for point_key in POINT_KEYS:
            points = im_lb.get(point_key, None)
            if points is None:
                continue

            n, l = points.size(0), points.size(1)
            points = points.reshape(-1, 2)
            points[:, 0] *= raw_w
            points[:, 1] *= raw_h
            one = torch.ones(points.size(0)).reshape(-1, 1)
            p_xy1 = torch.cat([points, one], 1)
            xy = torch.matmul(p_xy1, M[:2, :].T)
            xy[:, 0] /= raw_w
            xy[:, 1] /= raw_h
            new_points = xy.reshape(n, l)
            im_lb[point_key] = new_points

        return im_lb


class RandomVerticalFlip(object):
    def __init__(self, p=0.5):
        self.p = p

    def __call__(self, im_lb):
        if np.random.random() > self.p:
            return im_lb

        im = im_lb["im"]
        im = tf.vflip(im)
        im_lb["im"] = im

        lb_seg = im_lb.get("lb_seg", None)
        if lb_seg is not None:
            lb_seg = tf.vflip(lb_seg)
            im_lb["lb_seg"] = lb_seg

        for point_key in POINT_KEYS:
            points = im_lb.get(point_key, None)
            if points is None:
                continue

            points[:, 1::2] = 1 - points[:, 1::2]
            im_lb[point_key] = points

        return im_lb


class RandomHorizontalFlip(object):
    def __init__(self, p=0.5):
        self.p = p

    def __call__(self, im_lb):
        if np.random.random() > self.p:
            return im_lb

        im = im_lb["im"]
        im = tf.hflip(im)
        im_lb["im"] = im

        lb_seg = im_lb.get("lb_seg", None)
        if lb_seg is not None:
            lb_seg = tf.hflip(lb_seg)
            im_lb["lb_seg"] = lb_seg

        for point_key in POINT_KEYS:
            points = im_lb.get(point_key, None)
            if points is None:
                continue

            points[:, 0::2] = 1 - points[:, 0::2]
            im_lb[point_key] = points

        return im_lb


class ColorJitter(object):
    def __init__(self, p=0.5, brightness=0.0, contrast=0.0, saturation=0.0, hue=0.0):
        self.p = p
        self.color_jitter = T.ColorJitter(brightness, contrast, saturation, hue)

    def __call__(self, im_lb):
        if np.random.random() > self.p:
            return im_lb

        im = im_lb["im"]
        im = self.color_jitter(im)
        im_lb["im"] = im

        return im_lb


class Resize(object):
    def __init__(self, size=(384, 384)):
        self.size = size

    def __call__(self, im_lb):
        if self.size is None:
            return im_lb

        im = im_lb["im"]
        im_h, im_w = self.size
        im = tf.resize(im, (im_h, im_w))
        im_lb["im"] = im

        lb_seg = im_lb.get("lb_seg", None)
        if lb_seg is not None:
            lb_seg = tf.resize(
                lb_seg, (im_h, im_w), interpolation=InterpolationMode.NEAREST
            )
            im_lb["lb_seg"] = lb_seg

        return im_lb


class GaussianNoise(object):
    def __init__(self, p, mean, sigma):
        self.p = p
        self.mean = mean
        self.sigma = sigma

    def __call__(self, im_lb):
        if np.random.rand() > self.p:
            return im_lb

        im = im_lb["im"]

        img_ = np.array(im).copy() / 255.0

        sigma = np.maximum(np.random.rand() * self.sigma, 0.05)
        noise = np.random.normal(self.mean, sigma, img_.shape)
        out = noise + img_
        out = (np.clip(out, 0, 1) * 255.0).astype("uint8")
        im = Image.fromarray(out)

        im_lb["im"] = im
        return im_lb


class AddBlur(object):
    def __init__(self, p, blur="all"):
        self.p = p
        self.blur = blur

    def __call__(self, im_lb):
        if np.random.rand() > self.p:
            return im_lb
        im = im_lb["im"]

        if self.blur == "normal":
            im = im.filter(ImageFilter.BLUR)
        elif self.blur == "gaussian":
            im = im.filter(ImageFilter.GaussianBlur)
        elif self.blur == "mean":
            im = im.filter(ImageFilter.SMOOTH_MORE)
        elif self.blur == "all":
            blur_func = random.choice(
                [ImageFilter.BLUR, ImageFilter.GaussianBlur, ImageFilter.SMOOTH_MORE]
            )
            im = im.filter(blur_func)
        else:
            print("{} blur method not support, skip".format(self.blur))

        im_lb["im"] = im
        return im_lb


class ToTensor(object):
    def __init__(self):
        self.to_tensor = T.ToTensor()

    def __call__(self, im_lb):
        im = self.to_tensor(im_lb["im"])
        im_lb["im"] = im

        lb_seg = im_lb.get("lb_seg", None)
        if lb_seg is not None:
            lb_seg = torch.from_numpy(np.array(lb_seg)).long()
            im_lb["lb_seg"] = lb_seg

        return im_lb


class Compose(object):
    def __init__(self, do_list):
        self.do_list = do_list

    def __call__(self, im_lb):
        for comp in self.do_list:
            im_lb = comp(im_lb)
        return im_lb
