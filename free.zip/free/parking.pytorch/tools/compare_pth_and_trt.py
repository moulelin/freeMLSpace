import cv2
import numpy as np
import argparse
import sys
import torch

from pth_infer import PTHModule
from trt_infer import TRTModule

sys.path.insert(0, "../")
from lib.utils.common import init_opt
from lib.utils.vis_util import (
    draw_seg_images,
    plot_points,
    plot_angle,
    point_cls_color_list,
    center_cls_color_list,
    palette,
)


def get_parse():
    parser = argparse.ArgumentParser(description="Parking PyTorch Test On Imgs For Vis")
    parser.add_argument("--config", default="", type=str, help="path to config")
    return parser


if __name__ == "__main__":

    opt = get_parse().parse_args()
    init_opt(opt)
    opt.val_batch = 1

    img_file = (
        "/mnt/data/parking/datasets/debug/prelabel/image/1659680018.592188_589.png"
    )
    pth_model = "/mnt/data/parking/parking-automl-eval/20220725/models/pth/parking_slot_point-backup.pth"
    trt_model = "/mnt/data/parking/parking-automl-eval/20220725/models/trt/parking_slot_point_hrnet18_lite_800x800_bs1_fp16.trt"

    img = cv2.imread(img_file)
    input_array = np.ascontiguousarray(img.transpose((2, 0, 1))[None] / 255.0).astype(
        "float32"
    )
    input_tensor = torch.from_numpy(input_array).cuda()

    pth_func = PTHModule(pth_model, opt)
    trt_func = TRTModule(trt_model)

    pth_point_pred, pth_center_pred, pth_seg_pred = pth_func.inference(input_tensor)
    pth_point_pred = pth_point_pred.detach().cpu().squeeze(0).numpy()
    pth_center_pred = pth_center_pred.detach().cpu().squeeze(0).numpy()
    pth_seg_pred = pth_seg_pred.detach().cpu().squeeze(0).numpy()

    trt_out = trt_func.inference(input_array)
    trt_seg_pred = trt_out[0].reshape(800, 800).astype("int32")
    trt_point_pred = trt_out[1].reshape(128, 4)
    trt_center_pred = trt_out[2].reshape(128, 4)
    trt_point_cls = (trt_point_pred[:, 0:1] > 0.5) * 1.0
    trt_point_pred = np.concatenate([trt_point_cls, trt_point_pred[:, 1:]], axis=1)
    trt_center_cls = (trt_center_pred[:, 0:1] > 0.5) * 1.0
    trt_center_pred = np.concatenate([trt_center_cls, trt_center_pred[:, 1:]], axis=1)

    print(pth_seg_pred.shape, trt_seg_pred.shape)
    print((pth_seg_pred != trt_seg_pred).sum())
    print(np.unique(trt_seg_pred, return_counts=True))

    combined_img, seg_img = draw_seg_images(trt_seg_pred, img)
    cv2.imshow("debug", combined_img)
    cv2.waitKey(0)
