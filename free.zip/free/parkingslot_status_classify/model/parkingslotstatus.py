import torch
import torch.nn as nn
from model.network_blocks import BaseConv, CSPLayer


class ParkingSlotStatusNet(nn.Module):
    def __init__(self, width, height, status_num=2):
        super(ParkingSlotStatusNet, self).__init__()
        self.name = 'ParkingSlotStatus'
        self.backbone = nn.Sequential(
            BaseConv(3, 64, 3, 2, act='relu'),  # 1/2
            BaseConv(64, 128, 3, 2, act='relu'),  # 1/4
            CSPLayer(128, 128, n=2, act='relu'),
            BaseConv(128, 256, 3, 2, act='relu'),  # 1/8
            CSPLayer(256, 256, n=3, act='relu'),
            BaseConv(256, 512, 3, 2, act='relu'),  # 1/16
            CSPLayer(512, 512, n=4, act='relu'),
        )
        WH = width * height // 16 // 16
        self.status_head = nn.Sequential(
            BaseConv(512, 64, 1, 1, act='relu'),
            nn.Flatten(),
            nn.Linear(64 * WH, status_num)
        )

    def forward(self, x):
        x = self.backbone(x)
        status = self.status_head(x)

        return status
