import torch
from torch import nn
import numpy as np

from lib.models.common_opr.base_opr import ConvBNReLU
from lib.models.head.base_head import SegmentHead, chan_infos
from lib.models.common_opr.grid_point import bilinear_grid_sample_wb
from lib.models.common_opr.lss import LSSFPN
from lib.models.head.base_head import PointHead, DistributionHead, chan_infos
from lib.models.backbone.resnet import GeneralizedResNet


class FishEyeFSSegHead(nn.Module):
    def __init__(self, opt, backbone, decoder, mode="train"):
        super(FishEyeFSSegHead, self).__init__()
        self.mode = mode
        self.opt = opt
        self.backbone = backbone
        self.name = "fisheye_freespace_seg"
        n_classes = self.opt.n_cats

        ### bev config 
        self.N = opt.num_cameras
        self.xbound = opt.xbound
        self.ybound = opt.ybound
        self.zbound = opt.zbound
        self.bev_range = np.array([self.xbound[0], self.xbound[1],
                                   self.ybound[0], self.ybound[1],
                                   self.zbound[0], self.zbound[1]], dtype=np.float32)
        self.bev_resolution = np.array([self.xbound[-1], self.ybound[-1], self.zbound[-1]], dtype=np.float32)
        self.bev_length, self.bev_width, self.bev_height = ((self.bev_range[1::2] - self.bev_range[0::2]) / self.bev_resolution).astype(np.int32)
        
        self.sample_heights = opt.sample_heights if hasattr(opt, "sample_heights") and getattr(opt, "sample_heights") else None

        if self.sample_heights is not None:
            self.bev_height = len(self.sample_heights)

        self.base_chan = 64

        self.bev_compressor = nn.Sequential(
            nn.Conv2d(self.base_chan * self.bev_height, self.base_chan, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(self.base_chan),
            nn.ReLU(),
        )
        self.bev_backbone = GeneralizedResNet(self.base_chan, [[2, self.base_chan * 2, 2], [2, self.base_chan * 4, 2], [2, self.base_chan * 4, 2]])
        self.bev_fpn = LSSFPN(
            in_indices=[-1, 0],
            in_channels=[self.base_chan * 4, self.base_chan * 2],
            out_channels=self.base_chan * 2,
            scale_factor=1
        )

        self.freespacehead = SegmentHead(
            self.base_chan * 2, 256, n_classes, up_factor=2, aux=False
        )

        # if self.mode in ["train", "val"]:
        #     if "lite" in self.opt.backbone:
        #         self.aux2 = SegmentHead(self.base_chan, 128, n_classes, up_factor=0.5)
        #         self.aux3 = SegmentHead(self.base_chan, 128, n_classes, up_factor=1)
        #         self.aux4 = SegmentHead(self.base_chan * 2, 128, n_classes, up_factor=2)
        #         self.aux5 = SegmentHead(self.base_chan * 4, 128, n_classes, up_factor=4)
        #     else:
        #         self.aux2 = SegmentHead(self.base_chan, 128, n_classes, up_factor=0.5)
        #         self.aux3 = SegmentHead(self.base_chan * 2, 128, n_classes, up_factor=1)
        #         self.aux4 = SegmentHead(self.base_chan * 4, 128, n_classes, up_factor=2)
        #         self.aux5 = SegmentHead(self.base_chan * 8, 128, n_classes, up_factor=4)
        # else:
        self.decoder = decoder
        self.init_weights()
    
    def reduce_mean_bev_feature(self, bev_feature):
        """
        params:
            bev_Feature: B*N*C*H*W
        """
        eps = 1e-7
        mask = (torch.abs(bev_feature) > 0).float()
        numer = torch.sum(bev_feature, dim=1)
        denom = torch.sum(mask, dim=1) + torch.tensor([eps]).type_as(numer)
        mean = numer / denom

        return mean

    def view_transformer(self, feature_img, pix_coords):
        """
        params:
            feature_img: (B*N)*C*H*W
            pix_coords: (B*N)*1*(bev_L*bev_W*bev_H)*2
        """
        BN, C, H, W = feature_img.shape

        B = BN // self.N

        bev_feature = bilinear_grid_sample_wb(feature_img, pix_coords, align_corners=False)
        bev_feature = self.reduce_mean_bev_feature(
            bev_feature.view(B, self.N, self.base_chan, self.bev_height, self.bev_length * self.bev_width)
        )
        bev_feature = self.bev_compressor(
            bev_feature.view(B, self.base_chan * self.bev_height, self.bev_length, self.bev_width)
        )

        return bev_feature

    def forward(self, input, input2=None):
        if not hasattr(self.opt, "onnx"):
            self.opt.onnx = 0
        if self.opt.onnx == 1:
            image = input
            pix_coords = input2 
        else:
            image = input["image"]
            pix_coords = input["pix_coords"]

        B, N, C_raw, H_raw, W_raw = image.size()
        _, _, bev_height, bev_hw, _ =  pix_coords.size()

        pix_coords = pix_coords.view(B*N, bev_height, bev_hw, 2)

        # get image feature
        x_dict = self.backbone(image.view(B*N, C_raw, H_raw, W_raw))
        feat = x_dict["feat"]

        # get bev feature
        bev_feature = self.view_transformer(feat, pix_coords)
        bev_feature = self.bev_backbone(bev_feature)
        bev_feature = self.bev_fpn(bev_feature)  # [8, 128, 150, 150]

        # get pred
        freespace_logits = self.freespacehead(bev_feature)

        if self.mode in ["train", "val"]:
            # logits_aux2 = self.aux2(feat_dict["feat2"])
            # logits_aux3 = self.aux3(feat_dict["feat3"])
            # logits_aux4 = self.aux4(feat_dict["feat4"])
            # logits_aux5 = self.aux5(feat_dict["feat5"])
            return {
                # "logits_aux2": logits_aux2,
                # "logits_aux3": logits_aux3,
                # "logits_aux4": logits_aux4,
                # "logits_aux5": logits_aux5,
                "freespace_logits": freespace_logits,
            }
        else:
            return self.decoder.run(freespace_logits)

    def init_weights(self):
        for name, module in self.named_modules():
            if isinstance(module, (nn.Conv2d, nn.Linear)):
                # nn.init.kaiming_normal_(module.weight, mode='fan_out')
                continue
            elif isinstance(module, nn.modules.batchnorm._BatchNorm):
                if hasattr(module, "last_bn") and module.last_bn:
                    nn.init.zeros_(module.weight)
                else:
                    nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)
        self.load_pretrain()

    def load_pretrain(self):
        if self.opt.head_pretrain_path:
            print("load head pretrain model: ", self.opt.head_pretrain_path)
            state_dict = torch.load(self.opt.head_pretrain_path, map_location="cpu")
            if "net" in state_dict:
                state_dict = state_dict["net"]

            # filter_keys = []
            # for key in state_dict:
            #     if "seghead" in key:
            #         filter_keys.append(key)
            #     if "aux" in key:
            #         filter_keys.append(key)

            # for key in filter_keys:
            #     print(key)
            #     state_dict.pop(key)

            self.load_state_dict(state_dict, strict=False)
            print("loading complete.")
        else:
            print("no head pretrain model!!!")

    def get_params(self):
        def add_param_to_list(mod, wd_params, nowd_params):
            for param in mod.parameters():
                if param.dim() == 1:
                    nowd_params.append(param)
                elif param.dim() == 4:
                    wd_params.append(param)
                else:
                    print(name)

        (
            wd_params,
            nowd_params,
            lr_mul10_wd_params,
            lr_mul10_nowd_params,
            lr_mul2_wd_params,
            lr_mul2_nowd_params,
        ) = ([], [], [], [], [], [])
        for name, child in self.named_children():
            if "head" in name or "aux" in name:
                if "center" in name or "point" in name:
                    add_param_to_list(child, lr_mul2_wd_params, lr_mul2_nowd_params)
                else:
                    add_param_to_list(child, lr_mul10_wd_params, lr_mul10_nowd_params)
            else:
                add_param_to_list(child, wd_params, nowd_params)
        return (
            wd_params,
            nowd_params,
            lr_mul10_wd_params,
            lr_mul10_nowd_params,
            lr_mul2_wd_params,
            lr_mul2_nowd_params,
        )
