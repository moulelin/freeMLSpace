import cv2

import torch
import torch.nn as nn
import torch.nn.functional as F

from .common_loss.ohem_loss import OhemCELoss


class SegLoss(nn.Module):
    def __init__(self, opt):
        super(SegLoss, self).__init__()
        self.opt = opt
        self.ohemce_loss = OhemCELoss(
            thresh=self.opt.thresh_ohem,
            ignore_label=self.opt.ignore_label,
            norm_value=self.opt.n_cats - 1,
            reduction="mean",
        )
        self.mask_loss = nn.CrossEntropyLoss(
            ignore_index=self.opt.ignore_label,
            reduction="none",
            weight=None,
        )

        # ce_weight = torch.Tensor([1.0, 1.0, 1.0, 2.0, 1.0, 2.0, 4.0, 2.0, 1.0, 1.0])
        # self.ce_loss = nn.CrossEntropyLoss(
        #     ignore_index=self.opt.ignore_label, reduction="mean", weight=ce_weight,
        # )

    def forward(self, pred, truth, mask=None):
        loss_logits = self.ohemce_loss(pred["logits"], truth)

        # loss_ce = self.ce_loss(pred["logits"].reshape(-1, self.opt.n_cats), truth.reshape(-1)) * 0.1
        # loss_logits = loss_logits + loss_ce

        if mask is not None:
            loss_mask = self.mask_loss(pred["logits"], truth)
            loss_mask = loss_mask * (mask + 1.0)
            loss_mask = loss_mask.mean()
        else:
            loss_mask = 0

        d_truth = (
            F.interpolate(truth.float().unsqueeze(1), scale_factor=0.125)
            .squeeze(1)
            .long()
        )
        loss_logits_aux2 = self.ohemce_loss(pred["logits_aux2"], d_truth)
        loss_logits_aux3 = self.ohemce_loss(pred["logits_aux3"], d_truth)
        loss_logits_aux4 = self.ohemce_loss(pred["logits_aux4"], d_truth)
        loss_logits_aux5 = self.ohemce_loss(pred["logits_aux5"], d_truth)
        loss = (
            loss_logits
            + loss_logits_aux2
            + loss_logits_aux3
            + loss_logits_aux4
            + loss_logits_aux5
            + loss_mask
        )
        loss_tags = {
            "seg_loss": loss_logits.clone().detach().cpu().numpy(),
            "aux0_loss": loss_logits_aux2.clone().detach().cpu().numpy(),
            "aux1_loss": loss_logits_aux3.clone().detach().cpu().numpy(),
            "aux2_loss": loss_logits_aux4.clone().detach().cpu().numpy(),
            "aux3_loss": loss_logits_aux5.clone().detach().cpu().numpy(),
        }

        if mask is not None:
            loss_tags["mask_loss"] = loss_mask.clone().detach().cpu().numpy()
        else:
            loss_tags["mask_loss"] = 0

        return loss, loss_tags


class FreeSpaceLoss(nn.Module):
    def __init__(self, opt):
        super(FreeSpaceLoss, self).__init__()
        self.opt = opt

        self.ohemce_loss = OhemCELoss(
            thresh=self.opt.thresh_ohem,
            ignore_label=self.opt.ignore_label,
            norm_value=1,
            reduction="mean",
            # weight=weight,
        )

    def forward(self, pred, truth):
        loss_logits = self.ohemce_loss(pred["freespace_logits"], truth)

        loss = loss_logits * 2.0
        loss_tags = {
            "freespace_loss": loss.clone().detach().cpu().numpy(),
        }
        return loss, loss_tags


class FishEyeSegLoss(nn.Module):
    def __init__(self, opt):
        super(FishEyeSegLoss, self).__init__()
        self.opt = opt
        self.seg_loss = SegLoss(self.opt)
        # self.freespace_loss = FreeSpaceLoss(self.opt)
        self.w_seg = self.opt.w_seg

    def forward(self, pred, truth):
        seg_pred = pred
        loss_seg, seg_tags = self.seg_loss(
            seg_pred, truth["label_seg"], mask=truth.get("mask", None)
        )
        # loss_seg, seg_tags = self.seg_loss(seg_pred, truth["label_seg"], mask=None)
        # loss_freespace, freespace_tags = self.freespace_loss(seg_pred, truth["freespace_seg"])
        # loss = loss_seg * self.w_seg + loss_freespace * self.w_seg
        # loss_tags = {**seg_tags, **freespace_tags}
        # loss_tags["loss"] = loss_tags["seg_loss"] + loss_tags["freespace_loss"]
        loss = loss_seg * self.w_seg
        loss_tags = {**seg_tags}
        loss_tags["loss"] = loss_tags["seg_loss"]
        return loss, loss_tags
