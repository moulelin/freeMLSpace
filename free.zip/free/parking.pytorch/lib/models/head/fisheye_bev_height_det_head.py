import math
import sys
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

from lib.models.common_opr.base_opr import ConvBNReLU
from lib.models.common_opr.grid_point import bilinear_grid_sample_wb, bilinear_grid_sample_4d
from lib.models.common_opr.lss import LSSFPN
from lib.models.head.base_head import PointHead, DistributionHead, chan_infos
from lib.models.backbone.resnet import GeneralizedResNet


class FishEyeBevHeightDetHead(nn.Module):
    def __init__(self, opt, backbone, decoder, mode="train"):
        super(FishEyeBevHeightDetHead, self).__init__()

        self.name = "fisheye_bevdet"
        self.opt = opt
        self.mode = mode
        self.backbone = backbone

        ### bev config 
        self.N = opt.num_cameras
        self.xbound = opt.xbound
        self.ybound = opt.ybound
        self.zbound = opt.zbound
        self.bev_range = np.array([self.xbound[0], self.xbound[1],
                                   self.ybound[0], self.ybound[1],
                                   self.zbound[0], self.zbound[1]], dtype=np.float32)
        self.bev_resolution = np.array([self.xbound[-1], self.ybound[-1], self.zbound[-1]], dtype=np.float32)
        self.bev_length, self.bev_width, self.bev_height = ((self.bev_range[1::2] - self.bev_range[0::2]) / self.bev_resolution).astype(np.int32)
        
        self.sample_heights = opt.sample_heights if hasattr(opt, "sample_heights") and getattr(opt, "sample_heights") else None

        if self.sample_heights is not None:
            self.bev_height = len(self.sample_heights)

        base_chan = chan_infos[self.opt.backbone]
        self.bev_chan = 64

        ### image feature and height pred
        self.image_compressor = ConvBNReLU(base_chan * 8, self.bev_chan, 3, 1)
        self.image_height_estimation = DistributionHead(base_chan * 8, self.bev_chan, self.bev_height)

        ### bev feature
        self.bev_compressor = ConvBNReLU(self.bev_chan * self.bev_height, self.bev_chan, 1, 1, 0, bias=False)
        self.bev_backbone = GeneralizedResNet(self.bev_chan, [[2, self.bev_chan * 2, 2], [2, self.bev_chan * 4, 2], [2, self.bev_chan * 4, 2]])
        self.bev_fpn = LSSFPN(
            in_indices=[-1, 0],
            in_channels=[self.bev_chan * 4, self.bev_chan * 2],
            out_channels=self.bev_chan * 2,
            scale_factor=1
        )

        ### bev head info
        car_center_chan = 9  # heatmap + 2(off)
        # car_center_height_chan = 0 # center height
        car_lwh_chan = 4 # box length, width, height
        # car_yaw_chan = 0 # box yaw x, y
        # person_center_chan = 3  # heatmap + 2(off)
        # person_center_height_chan = 1
        # person_lwh_chan = 3
        # person_yaw_chan = 2

        self.car_center_head = PointHead(self.bev_chan * 2, 64, car_center_chan)      
        # self.car_center_height_head = PointHead(self.bev_chan * 2, 64, car_center_height_chan)      
        self.car_lwh_head = PointHead(self.bev_chan * 2, 64, car_lwh_chan)        
        # self.car_yaw_head = PointHead(self.bev_chan * 2, 64, car_yaw_chan)      
        # self.person_center_head = PointHead(self.bev_chan * 2, 64, person_center_chan)      
        # self.person_center_height_head = PointHead(self.bev_chan * 2, 64, person_center_height_chan)      
        # self.person_lwh_head = PointHead(self.bev_chan * 2, 64, person_lwh_chan)        
        # self.person_yaw_head = PointHead(self.bev_chan * 2, 64, person_yaw_chan)     

        if self.mode not in ["train", "val"]:  
            self.decoder = decoder

        self.init_weights()

    def reduce_mean_bev_feature(self, bev_feature):
        """
        params:
            bev_Feature: B*N*C*H*W
        """
        eps = 1e-7
        mask = (torch.abs(bev_feature) > 0).float()
        numer = torch.sum(bev_feature, dim=1)
        denom = torch.sum(mask, dim=1) + torch.tensor([eps]).type_as(numer)
        mean = numer / denom

        return mean

    def view_transformer(self, feature_img, pix_coords):
        """
        params:
            feature_img: (B*N)*C*D*H*W
            pix_coords: (B*N)*D*(bev_L*bev_W)*2
        """
        BN, C, D, H, W = feature_img.shape

        B = BN // self.N

        # bev_feature = F.grid_sample(feature_img, pix_coords, padding_mode='zeros', align_corners=False)      # B*N, C, bev_height, bev_length*bev_width
        bev_feature = bilinear_grid_sample_4d(feature_img, pix_coords, align_corners=False)
        bev_feature = self.reduce_mean_bev_feature(
            bev_feature.view(B, self.N, self.bev_chan, self.bev_height, self.bev_length * self.bev_width)
        )
        bev_feature = self.bev_compressor(
            bev_feature.view(B, self.bev_chan * self.bev_height, self.bev_length, self.bev_width)
        )

        return bev_feature

    def forward(self, input, input2=None):
        if not hasattr(self.opt, "onnx"):
            self.opt.onnx = 0
        if self.opt.onnx == 1:
            image = input
            pix_coords = input2 
        else:
            image = input["image"]
            pix_coords = input["pix_coords"]

        B, N, C_raw, H_raw, W_raw = image.size()
        _, _, num_height, bev_hw, _ =  pix_coords.size()

        pix_coords = pix_coords.view(B*N, num_height, bev_hw, 2)

        # get image feature
        x_dict = self.backbone(image.view(-1, C_raw, H_raw, W_raw))
        feat = x_dict["feat"]

        image_feature = self.image_compressor(feat)
        height_estimate = self.image_height_estimation(feat)
        image_3d_feature = image_feature.unsqueeze(2) * height_estimate.unsqueeze(1)

        # get bev feature
        bev_feature = self.view_transformer(image_3d_feature, pix_coords)
        bev_feature = self.bev_backbone(bev_feature)
        bev_feature = self.bev_fpn(bev_feature)

        # get pred
        car_center_pred = self.car_center_head(bev_feature)
        # car_center_height_pred = self.car_center_height_head(bev_feature)
        car_lwh_pred = self.car_lwh_head(bev_feature)
        # car_yaw_pred = self.car_yaw_head(bev_feature)
        # person_center_pred = self.person_center_head(bev_feature)
        # person_center_height_pred = self.person_center_height_head(bev_feature)
        # person_lwh_pred = self.person_lwh_head(bev_feature)
        # person_yaw_pred = self.person_yaw_head(bev_feature)     

        if self.mode in ["train", "val"]:
            # car_pred = torch.cat([car_center_pred, car_center_height_pred, car_lwh_pred, car_yaw_pred], dim=1)
            car_pred = torch.cat([car_center_pred, car_lwh_pred], dim=1)
            # person_pred = torch.cat([person_center_pred, person_center_height_pred, person_lwh_pred, person_yaw_pred], dim=1) 
            # return car_pred, person_pred
            return car_pred
        else:
            pred_dict = [[{
                # 'reg': car_center_pred[:, 4:6, ...],
                'reg1': car_center_pred[:, 3:5, ...],
                'reg2': car_center_pred[:, 5:7, ...],
                'reg3': car_center_pred[:, 7:9, ...],
                # 'height': car_center_height_pred,
                'dim': car_lwh_pred[:, 0:2, ...],
                'dim1': car_lwh_pred[:, 2:4, ...],
                # 'rot': car_yaw_pred,
                # 'heatmap': car_center_pred[:, 0:1, ...],
                'heatmap1': car_center_pred[:, 0:1, ...],
                'heatmap2': car_center_pred[:, 1:2, ...],
                'heatmap3': car_center_pred[:, 2:3, ...],
            }]
            # ,[{
            #     'reg': person_center_pred[:, :2, ...],
            #     'height': person_center_height_pred[:, :2, ...],
            #     'dim': person_lwh_pred,
            #     'rot': person_yaw_pred,
            #     'heatmap': person_center_pred[:, 0:1, ...],
            # }]
            ]
            return self.decoder.run(
                pred_dict
            )
    
    def init_weights(self):
        for name, module in self.named_modules():
            if isinstance(module, (nn.Conv2d, nn.Linear)):
                # nn.init.kaiming_normal_(module.weight, mode='fan_out')
                continue
            elif isinstance(module, nn.modules.batchnorm._BatchNorm):
                if hasattr(module, "last_bn") and module.last_bn:
                    nn.init.zeros_(module.weight)
                else:
                    nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)
        self.load_pretrain()

    def load_pretrain(self):
        if self.opt.head_pretrain_path:
            print("load head pretrain model: ", self.opt.head_pretrain_path)
            state_dict = torch.load(self.opt.head_pretrain_path, map_location="cpu")
            if "net" in state_dict:
                state_dict = state_dict["net"]

            # filter_keys = []
            # for key in state_dict:
            #     if "seghead" in key:
            #         filter_keys.append(key)
            #     if "aux" in key:
            #         filter_keys.append(key)

            # for key in filter_keys:
            #     print(key)
            #     state_dict.pop(key)

            self.load_state_dict(state_dict, strict=False)
            print("finished load")
        else:
            print("no head pretrain model!!!")

    def get_params(self):
        def add_param_to_list(mod, wd_params, nowd_params):
            for param in mod.parameters():
                if param.dim() == 1:
                    nowd_params.append(param)
                elif param.dim() == 4:
                    wd_params.append(param)
                else:
                    print(name)

        (
            wd_params,
            nowd_params,
            lr_mul10_wd_params,
            lr_mul10_nowd_params,
            lr_mul2_wd_params,
            lr_mul2_nowd_params,
        ) = ([], [], [], [], [], [])
        for name, child in self.named_children():
            if "head" in name:
                add_param_to_list(child, lr_mul2_wd_params, lr_mul2_nowd_params)
            else:
                add_param_to_list(child, wd_params, nowd_params)
        return (
            wd_params,
            nowd_params,
            lr_mul10_wd_params,
            lr_mul10_nowd_params,
            lr_mul2_wd_params,
            lr_mul2_nowd_params,
        )
