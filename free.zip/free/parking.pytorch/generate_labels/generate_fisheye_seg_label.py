import os
import cv2
import numpy as np
import json
import argparse
from tqdm import tqdm

import sys

sys.path.insert(0, "../")
from lib.datasets.dataset.fisheye import labels_info


parser = argparse.ArgumentParser(description="Make FishEye Segmentation Label")
parser.add_argument("--is_preprocess", default=1, type=int, help="is generate label")
parser.add_argument(
    "--train_datasets",
    default="{}",
    type=str,
    help="str of dict include path to train txt",
)
parser.add_argument(
    "--test_datasets",
    default="{}",
    type=str,
    help="str of dict include path to test txt",
)
parser.add_argument(
    "--dataset_root",
    default="/data/perception/datasets",
    type=str,
    help="path to origin data",
)
parser.add_argument(
    "--preprocess_root",
    default="/proc_data/perception/datasets",
    type=str,
    help="path to preprocess data",
)
parser.add_argument("--check_label", default=0, type=int, help="check label or not")
parser.add_argument("--thickness", default=8, type=int, help="thickness of slot line")
parser.add_argument(
    "--force", action="store_true", help="force makeing preprocess for each image"
)
opt = parser.parse_args()

color_infos = {}
id_infos = {}
for info in labels_info:
    name = info["name"]
    color_infos[name] = info["color"]
    id_infos[name] = info["id"]


class MakeSegTrainLabel(object):
    def __init__(self, opt):
        self.force = opt.force
        self.train_list_dict = eval(opt.train_datasets)
        self.test_list_dict = eval(opt.test_datasets)
        self.data_root = opt.dataset_root
        self.proc_root = opt.preprocess_root
        self.check_label = opt.check_label
        self.thickness = opt.thickness
        self.w = 640
        self.h = 512
        self.ignore_label = 255

    def get_data_list(self):
        image_list = []
        json_list = []
        resize_image_list = []
        lable_list = []

        print(self.train_list_dict)
        # train
        file_list = []
        for key in self.train_list_dict:
            if self.train_list_dict[key] in ["", " "]:
                continue
            with open(self.train_list_dict[key], "r") as f:
                lines = f.read().splitlines()
                file_list.extend(lines)
        # rm repeat
        lines = list(dict.fromkeys(file_list))
        print("train data num: ", len(lines))

        for line in lines:
            image_sub_path = line.replace("(0)", "")
            json_sub_path = (
                line.replace("image", "json")
                .replace("png", "json")
                .replace("jpg", "json")
            )
            resize_image_sub_path = line.replace("image", "resize_img").replace(
                "jpg", "png"
            )
            label_sub_path = line.replace("image", "label").replace("jpg", "png")
            image_list.append(os.path.join(self.data_root, image_sub_path))
            json_list.append(os.path.join(self.data_root, json_sub_path))
            resize_image_list.append(
                os.path.join(self.proc_root, resize_image_sub_path)
            )
            lable_list.append(os.path.join(self.proc_root, label_sub_path))

        print(self.test_list_dict)
        # test
        file_list = []
        for key in self.test_list_dict:
            if self.test_list_dict[key] in ["", " "]:
                continue
            with open(self.test_list_dict[key], "r") as f:
                lines = f.read().splitlines()
                file_list.extend(lines)
        # rm repeat
        lines = list(dict.fromkeys(file_list))
        print("test data num: ", len(lines))

        for line in lines:
            image_sub_path = line.replace("(0)", "")
            json_sub_path = (
                line.replace("image", "json")
                .replace("png", "json")
                .replace("jpg", "json")
            )
            resize_image_sub_path = line.replace("image", "resize_img").replace(
                "jpg", "png"
            )
            label_sub_path = line.replace("image", "label").replace("jpg", "png")
            image_list.append(os.path.join(self.data_root, image_sub_path))
            json_list.append(os.path.join(self.data_root, json_sub_path))
            resize_image_list.append(
                os.path.join(self.proc_root, resize_image_sub_path)
            )
            lable_list.append(os.path.join(self.proc_root, label_sub_path))

        return image_list, json_list, resize_image_list, lable_list

    def make_object_label(self, result, img, w_scale, h_scale):
        coords = np.array(result["segmentation"]).astype("float32")
        coords[:, 0] = coords[:, 0] * w_scale
        coords[:, 1] = coords[:, 1] * h_scale
        if self.check_label:
            zero_mask = np.zeros((img.shape), dtype=np.uint8)
            color = color_infos[result["type"]]
            mask = cv2.fillPoly(zero_mask, [coords.astype(np.int32)], color=color)
            img = cv2.addWeighted(src1=img, alpha=1, src2=mask, beta=1, gamma=0)
            return img
        else:
            if result["type"] not in id_infos:
                print("{} not in id_infos".format(result["type"]))
                color = self.ignore_label
            else:
                color = id_infos[result["type"]]
            cv2.fillPoly(img, [coords.astype(np.int32)], color=color)
            return img

    def make_label(self):
        image_list, json_list, resize_image_list, lable_list = self.get_data_list()

        count = 0
        for image_path, json_path, resize_image_path, label_path in tqdm(
            zip(image_list, json_list, resize_image_list, lable_list)
        ):

            if not self.force and os.path.exists(label_path):
                continue

            count += 1

            label_dir = os.path.dirname(label_path)
            if not os.path.exists(label_dir):
                os.makedirs(label_dir)

            resize_image_dir = os.path.dirname(resize_image_path)
            if not os.path.exists(resize_image_dir):
                os.makedirs(resize_image_dir)

            ori_img = cv2.imread(image_path)
            ori_h, ori_w, _ = ori_img.shape

            w_scale = self.w * 1.0 / ori_w
            h_scale = self.h * 1.0 / ori_h

            resize_img = cv2.resize(ori_img, (self.w, self.h))
            if self.check_label:
                img = resize_img
            else:
                img = np.zeros((self.h, self.w), dtype=np.uint8)

            try:
                with open(json_path, "r") as f:
                    raw_label = json.load(f)
                    for result in raw_label["results"]:
                        if "segmentation" in result.keys():
                            label_img = self.make_object_label(
                                result, img, w_scale, h_scale
                            )
            except Exception as e:
                print(f"error, skip {json_path}")
                print(e)
                label_img = (np.ones((self.h, self.w)) * self.ignore_label).astype(
                    "uint8"
                )

            if self.check_label:
                cv2.imshow("mask", label_img)
                cv2.waitKey(1000)
            else:
                cv2.imwrite(label_path, label_img)
                cv2.imwrite(resize_image_path, resize_img)
        print("finish preprocess data, preprocess new data {}".format(count))


if __name__ == "__main__":
    opt.is_preprocess = 1
    if int(opt.is_preprocess):
        make_seg_train_label = MakeSegTrainLabel(opt)
        make_seg_train_label.make_label()
    else:
        print("skip preprocess")
