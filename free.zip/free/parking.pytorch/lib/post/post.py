import cv2
import numpy as np
import os

from lib.utils.vis_util import (
    draw_seg_images,
    plot_points,
    plot_point_types,
    plot_angle,
    point_cls_color_list,
    center_cls_color_list,
    palette,
    get_line_point,
)
from lib.utils.bev_utils import visualize_bev_dt_v2


class BasePost:
    def __init__(self, opt, draw=False):
        self.opt = opt
        self.draw = draw

    def run(self, output, img):
        pass


class ParkingSlotSegPost(BasePost):
    def __init__(self, opt, draw=False):
        super(ParkingSlotSegPost, self).__init__(opt, draw)

    def run(self, output, img):
        point_pred, center_pred, seg_pred = output
        seg_pred = seg_pred.detach().cpu().squeeze(0).numpy()
        point_pred = point_pred.detach().cpu().squeeze(0).numpy()
        center_pred = center_pred.detach().cpu().squeeze(0).numpy()

        combined_img, seg_img = draw_seg_images(seg_pred, img)
        for i in range(2):
            point_mask = point_pred[:, 2 + i] > self.opt.thresh_point
            pts = point_pred[point_mask]
            plot_points(combined_img, pts[:, 4:], color=point_cls_color_list[i])
            plot_points(seg_img, pts[:, 4:], color=point_cls_color_list[i])

        for i in range(2):
            center_mask = center_pred[:, 2 + i] > self.opt.thresh_center
            cens = center_pred[center_mask]
            plot_points(combined_img, cens[:, 4:], color=center_cls_color_list[i])
            plot_points(seg_img, cens[:, 4:], color=center_cls_color_list[i])
        result_img = np.concatenate([combined_img, seg_img], axis=1)

        if self.draw:
            cv2.imshow("result_img", result_img)
            cv2.waitKey(0)
        return result_img


class ParkingSlotPointPost(BasePost):
    def __init__(self, opt, draw=False):
        super(ParkingSlotPointPost, self).__init__(opt, draw)

    def run(self, output, img):
        point_pred, center_pred, seg_pred = output
        seg_pred = seg_pred.detach().cpu().squeeze(0).numpy()
        point_pred = point_pred.detach().cpu().squeeze(0).numpy()
        center_pred = center_pred.detach().cpu().squeeze(0).numpy()

        combined_img, seg_img = draw_seg_images(seg_pred, img)

        point_mask = point_pred[:, 1] > self.opt.thresh_point
        point_pred = point_pred[point_mask]
        center_mask = center_pred[:, 1] > self.opt.thresh_center
        center_pred = center_pred[center_mask]

        enter_point = point_pred[point_pred[:, 0] <= self.opt.point_cls_thresh]
        end_point = point_pred[point_pred[:, 0] > self.opt.point_cls_thresh]
        if len(enter_point) > 0:
            plot_points(img, enter_point[:, 2:4], color=point_cls_color_list[0])
        if len(end_point) > 0:
            plot_points(img, end_point[:, 2:4], color=point_cls_color_list[1])

        empty_center = center_pred[center_pred[:, 0] <= self.opt.center_cls_thresh]
        occupied_center = center_pred[center_pred[:, 0] > self.opt.center_cls_thresh]
        if len(empty_center) > 0:
            plot_points(img, empty_center[:, 2:4], color=center_cls_color_list[0])
        if len(occupied_center) > 0:
            plot_points(img, occupied_center[:, 2:4], color=center_cls_color_list[1])

        result_img = np.concatenate([img, seg_img], axis=1)

        if self.draw:
            cv2.imshow("result_img", result_img)
            cv2.waitKey(0)
        return result_img


class ParkingSlotPointClsPost(BasePost):
    def __init__(self, opt, draw=False):
        super(ParkingSlotPointClsPost, self).__init__(opt, draw)

    def run(self, output, img):
        point_pred, center_pred, seg_pred = output
        seg_pred = seg_pred.detach().cpu().squeeze(0).numpy()
        point_pred = point_pred.detach().cpu().squeeze(0).numpy()
        center_pred = center_pred.detach().cpu().squeeze(0).numpy()

        combined_img, seg_img = draw_seg_images(seg_pred, img)

        point_mask = point_pred[:, 1] > self.opt.thresh_point
        point_pred = point_pred[point_mask]
        center_mask = center_pred[:, 1] > self.opt.thresh_center
        center_pred = center_pred[center_mask]

        enter_point = point_pred[point_pred[:, 0] <= self.opt.point_cls_thresh]
        end_point = point_pred[point_pred[:, 0] > self.opt.point_cls_thresh]
        if len(enter_point) > 0:
            plot_points(img, enter_point[:, 2:4], color=point_cls_color_list[0])
        if len(end_point) > 0:
            plot_points(img, end_point[:, 2:4], color=point_cls_color_list[1])

        empty_center = center_pred[center_pred[:, 0] <= self.opt.center_cls_thresh]
        occupied_center = center_pred[center_pred[:, 0] > self.opt.center_cls_thresh]
        if len(empty_center) > 0:
            type_ids = empty_center[:, -3:].argmax(axis=1)
            plot_points(img, empty_center[:, 2:4], color=center_cls_color_list[0])
            plot_point_types(
                img, empty_center[:, 2:4], type_ids, color=center_cls_color_list[0]
            )
        if len(occupied_center) > 0:
            type_ids = occupied_center[:, -3:].argmax(axis=1)
            plot_points(img, occupied_center[:, 2:4], color=center_cls_color_list[1])
            plot_point_types(
                img, occupied_center[:, 2:4], type_ids, color=center_cls_color_list[1]
            )

        result_img = np.concatenate([img, seg_img], axis=1)

        if self.draw:
            cv2.imshow("result_img", result_img)
            cv2.waitKey(0)
        return result_img


class ParkingSlotSegAnglePost(BasePost):
    def __init__(self, opt, draw=False):
        super(ParkingSlotSegAnglePost, self).__init__(opt, draw)

    def run(self, output, img):
        point_pred, center_pred, seg_pred = output
        seg_pred = seg_pred.detach().cpu().squeeze(0).numpy()
        point_pred = point_pred.detach().cpu().squeeze(0).numpy()
        center_pred = center_pred.detach().cpu().squeeze(0).numpy()

        combined_img, seg_img = draw_seg_images(seg_pred, img)

        point_mask = point_pred[:, 1] > self.opt.thresh_point
        point_pred = point_pred[point_mask]
        center_mask = center_pred[:, 1] > self.opt.thresh_center
        center_pred = center_pred[center_mask]

        # enter_point = point_pred[point_pred[:, 0] <= self.opt.point_cls_thresh]
        # end_point = point_pred[point_pred[:, 0] > self.opt.point_cls_thresh]
        # if len(enter_point) > 0:
        #     plot_points(img, enter_point[:, 2:4], color=point_cls_color_list[0])
        # if len(end_point) > 0:
        #     plot_points(img, end_point[:, 2:4], color=point_cls_color_list[1])

        empty_center = center_pred[center_pred[:, 0] <= self.opt.center_cls_thresh]
        occupied_center = center_pred[center_pred[:, 0] > self.opt.center_cls_thresh]
        if len(empty_center) > 0:
            plot_points(img, empty_center[:, 2:4], color=center_cls_color_list[0])

            plot_points(img, empty_center[:, 6:8], color=point_cls_color_list[0])
            plot_points(img, empty_center[:, 12:14], color=point_cls_color_list[0])
            plot_points(img, empty_center[:, 8:10], color=point_cls_color_list[1])
            plot_points(img, empty_center[:, 10:12], color=point_cls_color_list[1])

            plot_angle(
                img,
                empty_center[:, 2:4],
                empty_center[:, 4:6],
                color=center_cls_color_list[0],
            )

        if len(occupied_center) > 0:
            plot_points(img, occupied_center[:, 2:4], color=center_cls_color_list[1])

            plot_points(img, occupied_center[:, 6:8], color=point_cls_color_list[0])
            plot_points(img, occupied_center[:, 12:14], color=point_cls_color_list[0])
            plot_points(img, occupied_center[:, 8:10], color=point_cls_color_list[1])
            plot_points(img, occupied_center[:, 10:12], color=point_cls_color_list[1])

            plot_angle(
                img,
                occupied_center[:, 2:4],
                occupied_center[:, 4:6],
                color=center_cls_color_list[0],
            )

        result_img = np.concatenate([img, seg_img], axis=1)

        if self.draw:
            cv2.imshow("result_img", result_img)
            cv2.waitKey(0)
        return result_img


class ParkingCenterPointClsPost(BasePost):
    def __init__(self, opt, draw=False):
        super(ParkingCenterPointClsPost, self).__init__(opt, draw)

    def run(self, output, img):
        point_pred, center_pred, seg_pred = output
        seg_pred = seg_pred.detach().cpu().squeeze(0).numpy()
        point_pred = point_pred.detach().cpu().squeeze(0).numpy()
        center_pred = center_pred.detach().cpu().squeeze(0).numpy()

        combined_img, seg_img = draw_seg_images(seg_pred, img)

        point_mask = point_pred[:, 1] > self.opt.thresh_point
        point_pred = point_pred[point_mask]
        center_mask = center_pred[:, 1] > self.opt.thresh_center
        center_pred = center_pred[center_mask]

        # enter_point = point_pred[point_pred[:, 0] <= self.opt.point_cls_thresh]
        # end_point = point_pred[point_pred[:, 0] > self.opt.point_cls_thresh]
        # if len(enter_point) > 0:
        #     plot_points(img, enter_point[:, 2:4], color=point_cls_color_list[0])
        # if len(end_point) > 0:
        #     plot_points(img, end_point[:, 2:4], color=point_cls_color_list[1])

        empty_center = center_pred[center_pred[:, 0] <= self.opt.center_cls_thresh]
        occupied_center = center_pred[center_pred[:, 0] > self.opt.center_cls_thresh]
        if len(empty_center) > 0:
            plot_points(img, empty_center[:, 2:4], color=center_cls_color_list[0])

            plot_points(img, empty_center[:, 4:6], color=point_cls_color_list[0])
            plot_points(img, empty_center[:, 10:12], color=point_cls_color_list[0])
            plot_points(img, empty_center[:, 6:8], color=point_cls_color_list[0])
            plot_points(img, empty_center[:, 8:10], color=point_cls_color_list[0])

            type_ids = empty_center[:, 12:15].argmax(axis=1)
            plot_point_types(
                img, empty_center[:, 2:4], type_ids, color=center_cls_color_list[0]
            )

        if len(occupied_center) > 0:
            plot_points(img, occupied_center[:, 2:4], color=center_cls_color_list[1])

            plot_points(img, occupied_center[:, 4:6], color=point_cls_color_list[0])
            plot_points(img, occupied_center[:, 10:12], color=point_cls_color_list[0])
            plot_points(img, occupied_center[:, 6:8], color=point_cls_color_list[0])
            plot_points(img, occupied_center[:, 8:10], color=point_cls_color_list[0])

            type_ids = occupied_center[:, 12:15].argmax(axis=1)
            plot_point_types(
                img, occupied_center[:, 2:4], type_ids, color=center_cls_color_list[1]
            )

        result_img = np.concatenate([img, seg_img], axis=1)

        if self.draw:
            cv2.imshow("result_img", result_img)
            cv2.waitKey(0)
        return result_img


class ParkingMidClsPost(BasePost):
    def __init__(self, opt, draw=False):
        super(ParkingMidClsPost, self).__init__(opt, draw)

    def run(self, output, img):
        point_pred, mid_pred, center_pred, seg_pred = output
        seg_pred = seg_pred.detach().cpu().squeeze(0).numpy()
        point_pred = point_pred.detach().cpu().squeeze(0).numpy()
        mid_pred = mid_pred.detach().cpu().squeeze(0).numpy()
        center_pred = center_pred.detach().cpu().squeeze(0).numpy()

        combined_img, seg_img = draw_seg_images(seg_pred, img)

        # point_mask = point_pred[:, 1] > self.opt.thresh_point
        # point_pred = point_pred[point_mask]
        # mid_mask = mid_pred[:, 1] > self.opt.thresh_point
        # mid_pred = mid_pred[mid_mask]
        center_mask = center_pred[:, 1] > self.opt.thresh_center
        center_pred = center_pred[center_mask]

        # enter_point = point_pred[point_pred[:, 0] <= self.opt.point_cls_thresh]
        # end_point = point_pred[point_pred[:, 0] > self.opt.point_cls_thresh]
        # if len(enter_point) > 0:
        #     plot_points(img, enter_point[:, 2:4], color=point_cls_color_list[0])
        # if len(end_point) > 0:
        #     plot_points(img, end_point[:, 2:4], color=point_cls_color_list[1])

        empty_center = center_pred[center_pred[:, 0] <= self.opt.center_cls_thresh]
        occupied_center = center_pred[center_pred[:, 0] > self.opt.center_cls_thresh]
        if len(empty_center) > 0:
            plot_points(img, empty_center[:, 2:4], color=center_cls_color_list[0])

            plot_points(img, empty_center[:, 4:6], color=point_cls_color_list[0])
            plot_points(img, empty_center[:, 10:12], color=point_cls_color_list[0])
            plot_points(img, empty_center[:, 6:8], color=point_cls_color_list[0])
            plot_points(img, empty_center[:, 8:10], color=point_cls_color_list[0])

            type_ids = empty_center[:, 12:15].argmax(axis=1)
            plot_point_types(
                img, empty_center[:, 2:4], type_ids, color=center_cls_color_list[0]
            )

        if len(occupied_center) > 0:
            plot_points(img, occupied_center[:, 2:4], color=center_cls_color_list[1])

            plot_points(img, occupied_center[:, 4:6], color=point_cls_color_list[0])
            plot_points(img, occupied_center[:, 10:12], color=point_cls_color_list[0])
            plot_points(img, occupied_center[:, 6:8], color=point_cls_color_list[0])
            plot_points(img, occupied_center[:, 8:10], color=point_cls_color_list[0])

            type_ids = occupied_center[:, 12:15].argmax(axis=1)
            plot_point_types(
                img, occupied_center[:, 2:4], type_ids, color=center_cls_color_list[1]
            )

        result_img = np.concatenate([img, seg_img], axis=1)

        if self.draw:
            cv2.imshow("result_img", result_img)
            cv2.waitKey(0)
        return result_img


class ParkingMidWSPost(BasePost):
    def __init__(self, opt, draw=False):
        super(ParkingMidWSPost, self).__init__(opt, draw)

    def run(self, output, img):
        if len(output) == 6:
            point_pred, mid_pred, center_pred, seg_pred, ws_pred, sp_pred = output
            seg_pred = seg_pred.detach().cpu().squeeze(0).numpy()
            point_pred = point_pred.detach().cpu().squeeze(0).numpy()
            mid_pred = mid_pred.detach().cpu().squeeze(0).numpy()
            center_pred = center_pred.detach().cpu().squeeze(0).numpy()
            ws_pred = ws_pred.detach().cpu().squeeze(0).numpy()
            sp_pred = sp_pred.detach().cpu().squeeze(0).numpy()
        else:
            point_pred, center_pred, seg_pred, ws_pred, sp_pred = output
            seg_pred = seg_pred.detach().cpu().squeeze(0).numpy()
            point_pred = point_pred.detach().cpu().squeeze(0).numpy()
            center_pred = center_pred.detach().cpu().squeeze(0).numpy()
            ws_pred = ws_pred.detach().cpu().squeeze(0).numpy()
            sp_pred = sp_pred.detach().cpu().squeeze(0).numpy()
        # import pdb
        # pdb.set_trace()

        combined_img, seg_img = draw_seg_images(seg_pred, img)

        point_mask = point_pred[:, 1] > self.opt.thresh_point
        point_pred = point_pred[point_mask]
        mid_mask = mid_pred[:, 0] > self.opt.thresh_point
        mid_pred = mid_pred[mid_mask]
        center_mask = center_pred[:, 1] > self.opt.thresh_center
        center_pred = center_pred[center_mask]

        ws_mask = ws_pred[:, 0] > self.opt.thresh_ws
        ws_pred = ws_pred[ws_mask]

        sp_mask = sp_pred[:, 0] > self.opt.thresh_sp
        sp_pred = sp_pred[sp_mask]

        enter_point = point_pred[point_pred[:, 0] <= self.opt.point_cls_thresh]
        end_point = point_pred[point_pred[:, 0] > self.opt.point_cls_thresh]
        if len(enter_point) > 0:
            plot_points(seg_img, enter_point[:, 2:4], color=point_cls_color_list[0])
        if len(end_point) > 0:
            plot_points(seg_img, end_point[:, 2:4], color=point_cls_color_list[1])

        if len(mid_pred) > 0:
            plot_points(seg_img, mid_pred[:, 1:3], color=(0, 0, 0))

        empty_center = center_pred[center_pred[:, 0] <= self.opt.center_cls_thresh]
        occupied_center = center_pred[center_pred[:, 0] > self.opt.center_cls_thresh]
        if len(empty_center) > 0:
            plot_points(img, empty_center[:, 2:4], color=center_cls_color_list[0])

            plot_points(img, empty_center[:, 4:6], color=(200, 100, 100))
            plot_points(img, empty_center[:, 6:8], color=(200, 100, 100))
            plot_points(img, empty_center[:, 8:10], color=(200, 100, 100))
            plot_points(img, empty_center[:, 10:12], color=(200, 100, 100))

            plot_points(img, empty_center[:, 12:14], color=(0, 0, 0))
            plot_points(img, empty_center[:, 14:16], color=(0, 0, 0))
            plot_points(img, empty_center[:, 16:18], color=(0, 0, 0))
            plot_points(img, empty_center[:, 18:20], color=(0, 0, 0))

            type_ids = empty_center[:, -3:].argmax(axis=1)
            plot_point_types(
                img, empty_center[:, 2:4], type_ids, color=center_cls_color_list[0]
            )

        if len(occupied_center) > 0:
            plot_points(img, occupied_center[:, 2:4], color=center_cls_color_list[1])

            plot_points(img, occupied_center[:, 4:6], color=(200, 100, 100))
            plot_points(img, occupied_center[:, 6:8], color=(200, 100, 100))
            plot_points(img, occupied_center[:, 8:10], color=(200, 100, 100))
            plot_points(img, occupied_center[:, 10:12], color=(200, 100, 100))

            plot_points(img, occupied_center[:, 12:14], color=(0, 0, 0))
            plot_points(img, occupied_center[:, 14:16], color=(0, 0, 0))
            plot_points(img, occupied_center[:, 16:18], color=(0, 0, 0))
            plot_points(img, occupied_center[:, 18:20], color=(0, 0, 0))

            type_ids = occupied_center[:, -3:].argmax(axis=1)
            plot_point_types(
                img, occupied_center[:, 2:4], type_ids, color=center_cls_color_list[1]
            )

        plot_points(img, ws_pred[:, 1:3], color=(111, 200, 100))
        plot_points(img, sp_pred[:, 1:3], color=(111, 255, 100))

        result_img = np.concatenate([img, seg_img], axis=1)

        if self.draw:
            cv2.imshow("result_img", result_img)
            cv2.waitKey(0)
        return result_img


class FishEyeSegPost(BasePost):
    def __init__(self, opt, draw=False):
        super(FishEyeSegPost, self).__init__(opt, draw)

    def run(self, output, img):
        seg_pred = output
        seg_pred = seg_pred.detach().cpu().squeeze(0).numpy()

        combined_img, seg_img = draw_seg_images(seg_pred, img)
        result_img = np.concatenate([combined_img, seg_img], axis=1)

        if self.draw:
            c_x = 640 // 2
            c_y = 400

            cv2.circle(result_img, (c_x, c_y), 2, (255, 0, 0), 2)

            radiation_points = []
            radiation_line_points = []
            for i in range(0, self.opt.w_input, self.opt.radiation_interval):
                point = (i, 0)
                radiation_points.append(point)
                line_poins = get_line_point(c_x, c_y, i, 0)
                radiation_line_points.append(line_poins)
            for j in range(0, self.opt.h_input, self.opt.radiation_interval):
                point = (self.opt.w_input - 1, j)
                radiation_points.append(point)
                line_poins = get_line_point(c_x, c_y, self.opt.w_input - 1, j)
                radiation_line_points.append(line_poins)
            for i in range(self.opt.w_input - 1, -1, -self.opt.radiation_interval):
                point = (i, self.opt.h_input - 1)
                radiation_points.append(point)
                line_poins = get_line_point(c_x, c_y, i, self.opt.h_input - 1)
                radiation_line_points.append(line_poins)
            for j in range(self.opt.h_input - 1, -1, -self.opt.radiation_interval):
                point = (0, j)
                radiation_points.append(point)
                line_poins = get_line_point(c_x, c_y, 0, j)
                radiation_line_points.append(line_poins)

            for cls_id in range(self.opt.n_cats):
                if cls_id != 9:
                    continue
                mask = (seg_pred == cls_id).astype("uint8")
                if mask.sum() == 0:
                    continue

            if mask[c_y, c_x] == 1:
                target = 0
            else:
                target = 1

            for line_poins in radiation_line_points:
                for point in line_poins:
                    # cv2.circle(result_img, (point[0], point[1]), 1, (0, 0, 255), 2)
                    # result_img[point[1], point[0], :] = (0, 255, 0)
                    if mask[point[1], point[0]] == target:
                        target = 1 - target
                        cv2.circle(result_img, (point[0], point[1]), 1, (0, 0, 255), 2)
                        cv2.line(
                            result_img, (c_x, c_y), (point[0], point[1]), (255, 0, 0), 1
                        )

            cv2.imshow("result_img", result_img)
            cv2.waitKey(0)
            exit()
        return result_img


class LidarSegPost(BasePost):
    def __init__(self, opt, draw=False):
        super(LidarSegPost, self).__init__(opt, draw)

    def run(self, output, img):
        seg_pred = output
        seg_pred = seg_pred.detach().cpu().squeeze(0).numpy()

        depth = img[:, :, 0]
        depth = (
            cv2.normalize(
                depth,
                None,
                alpha=0,
                beta=1,
                norm_type=cv2.NORM_MINMAX,
                dtype=cv2.CV_32F,
            )
            * 255.0
        ).astype(np.uint8)

        depth = depth.reshape(self.opt.h_input, self.opt.w_input, 1).repeat(3, axis=2)
        seg_img = palette[seg_pred]
        result_img = np.concatenate([depth, seg_img], axis=0)

        if self.draw:
            cv2.imshow("result_img", result_img)
            cv2.waitKey(0)
        return result_img
    

class FishEyeDetPost(BasePost):
    def __init__(self, opt, draw=False):
        super(FishEyeDetPost, self).__init__(opt, draw)

    def run(self, output, bev_images, image, truth):
        box3d_preds = []
        for out in output:
            # box3d_preds.append(out.detach().cpu().squeeze(0).numpy())
            box3d_preds.append(out)

        show_img = visualize_bev_dt_v2(bev_images[0], box3d_preds, self.opt, image, truth)

        # cv2.imshow("result_img", show_img)
        # cv2.waitKey(0)
        # exit()
        return show_img


class FishEyeFSSegPost(BasePost):
    def __init__(self, opt, draw=False):
        super(FishEyeFSSegPost, self).__init__(opt, draw)

    def run(self, output, img, i):
        seg_pred = output
        seg_pred = seg_pred.detach().cpu().squeeze(0).numpy()
        img_rot = np.rot90(img, 2, axes=(1, 2))  # rotate 180

        combined_img, seg_img = draw_seg_images(seg_pred, img_rot)
        # surround images
        file_path = '/test_data/hans/freespace_more_data/train_val.txt'
        with open(file_path, 'r') as file:
            lines = file.readlines()
            line_count = len(lines)

        camera_front = lines[i].strip().replace("pcd", "camera/camera_surround_front_image")
        front = cv2.imread(camera_front.replace(".camera/camera_surround_front_image", ".jpg"))

        camera_right = lines[i].strip().replace("pcd", "camera/camera_surround_right_image")
        right = cv2.imread(camera_right.replace(".camera/camera_surround_right_image", ".jpg"))

        camera_rear = lines[i].strip().replace("pcd", "camera/camera_surround_rear_image")
        rear = cv2.imread(camera_rear.replace(".camera/camera_surround_rear_image", ".jpg"))

        camera_left = lines[i].strip().replace("pcd", "camera/camera_surround_left_image")
        left = cv2.imread(camera_left.replace(".camera/camera_surround_left_image", ".jpg"))

        gt_label = lines[i].strip().split('/')[-1].replace('pcd', 'png')
        gt_label_path = os.path.join('/test_data/hans/freespace_more_data/vlabel', gt_label)
        gt_img = cv2.imread(gt_label_path)

        # camera_imgs = cv2.vconcat([cv2.hconcat([front, right]), cv2.hconcat([left, rear])])
        camera_imgs = cv2.hconcat([front, right, rear, left])
        camera_imgs = cv2.resize(camera_imgs, (900, 180))
        result_img0 = np.concatenate([gt_img, combined_img, seg_img], axis=1)
        result_img = np.concatenate([result_img0, camera_imgs], axis=0)

        return result_img

