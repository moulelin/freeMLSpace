import torch
from torch import nn

from lib.models.head.base_head import SegmentHead, PointHead, chan_infos


class ParkingCenterPointClsHead(nn.Module):
    def __init__(self, opt, backbone, decoder, mode="train"):
        super(ParkingCenterPointClsHead, self).__init__()
        self.mode = mode
        self.opt = opt
        self.backbone = backbone
        self.name = "parking_slot_point_cls"
        n_classes = self.opt.n_cats
        point_out_chan = 4  # num_cls + 2
        center_out_chan = 4  # num_cls + 2(c_off)
        center_point_out_chan = 8  # 4(point) * 2(xy)
        type_out_chan = 3  # 3(type)

        base_chan = chan_infos[self.opt.backbone]

        self.seghead = SegmentHead(
            base_chan * 8, 256, n_classes, up_factor=8, aux=False
        )
        self.pointhead = PointHead(base_chan * 8, 256, point_out_chan)
        self.centerhead = PointHead(base_chan * 8, 256, center_out_chan)
        self.center_point_head = PointHead(base_chan * 8, 256, center_point_out_chan)
        self.center_type_head = PointHead(base_chan * 8, 256, type_out_chan)
        if self.mode in ["train", "val"]:
            if "lite" in self.opt.backbone:
                self.aux2 = SegmentHead(base_chan, 128, n_classes, up_factor=0.5)
                self.aux3 = SegmentHead(base_chan, 128, n_classes, up_factor=1)
                self.aux4 = SegmentHead(base_chan * 2, 128, n_classes, up_factor=2)
                self.aux5 = SegmentHead(base_chan * 4, 128, n_classes, up_factor=4)
            else:
                self.aux2 = SegmentHead(base_chan, 128, n_classes, up_factor=0.5)
                self.aux3 = SegmentHead(base_chan * 2, 128, n_classes, up_factor=1)
                self.aux4 = SegmentHead(base_chan * 4, 128, n_classes, up_factor=2)
                self.aux5 = SegmentHead(base_chan * 8, 128, n_classes, up_factor=4)
        else:
            self.decoder = decoder
        self.init_weights()

    def forward(self, x):
        feat_dict = self.backbone(x)

        logits = self.seghead(feat_dict["feat"])
        point_pred = self.pointhead(feat_dict["feat"])
        center_pred = self.centerhead(feat_dict["feat"])
        center_point_pred = self.center_point_head(feat_dict["feat"])
        center_type_pred = self.center_type_head(feat_dict["feat"])

        if self.mode in ["train", "val"]:
            logits_aux2 = self.aux2(feat_dict["feat2"])
            logits_aux3 = self.aux3(feat_dict["feat3"])
            logits_aux4 = self.aux4(feat_dict["feat4"])
            logits_aux5 = self.aux5(feat_dict["feat5"])

            center_pred = torch.cat(
                [center_pred, center_point_pred, center_type_pred], dim=1
            )
            return (
                point_pred,
                center_pred,
                {
                    "logits": logits,
                    "logits_aux2": logits_aux2,
                    "logits_aux3": logits_aux3,
                    "logits_aux4": logits_aux4,
                    "logits_aux5": logits_aux5,
                },
            )
        else:
            return self.decoder.run(
                point_pred, center_pred, logits, center_point_pred, center_type_pred
            )

    def init_weights(self):
        for name, module in self.named_modules():
            if isinstance(module, (nn.Conv2d, nn.Linear)):
                # nn.init.kaiming_normal_(module.weight, mode='fan_out')
                continue
            elif isinstance(module, nn.modules.batchnorm._BatchNorm):
                if hasattr(module, "last_bn") and module.last_bn:
                    nn.init.zeros_(module.weight)
                else:
                    nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)
        self.load_pretrain()

    def load_pretrain(self):
        if self.opt.head_pretrain_path:
            print("load head pretrain model: ", self.opt.head_pretrain_path)
            state_dict = torch.load(self.opt.head_pretrain_path, map_location="cpu")
            if "net" in state_dict:
                state_dict = state_dict["net"]

            # filter_keys = []
            # for key in state_dict:
            #     if "seghead" in key:
            #         filter_keys.append(key)
            #     if "aux" in key:
            #         filter_keys.append(key)

            # for key in filter_keys:
            #     print(key)
            #     state_dict.pop(key)

            self.load_state_dict(state_dict, strict=False)
            print("finished load")
        else:
            print("no head pretrain model!!!")

    def get_params(self):
        def add_param_to_list(mod, wd_params, nowd_params):
            for param in mod.parameters():
                if param.dim() == 1:
                    nowd_params.append(param)
                elif param.dim() == 4:
                    wd_params.append(param)
                else:
                    print(name)

        (
            wd_params,
            nowd_params,
            lr_mul10_wd_params,
            lr_mul10_nowd_params,
            lr_mul2_wd_params,
            lr_mul2_nowd_params,
        ) = ([], [], [], [], [], [])
        for name, child in self.named_children():
            if "head" in name or "aux" in name:
                if "center" in name or "point" in name:
                    add_param_to_list(child, lr_mul2_wd_params, lr_mul2_nowd_params)
                else:
                    add_param_to_list(child, lr_mul10_wd_params, lr_mul10_nowd_params)
            else:
                add_param_to_list(child, wd_params, nowd_params)
        return (
            wd_params,
            nowd_params,
            lr_mul10_wd_params,
            lr_mul10_nowd_params,
            lr_mul2_wd_params,
            lr_mul2_nowd_params,
        )
