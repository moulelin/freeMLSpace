import torch
import torch.nn as nn
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
import torchvision
import torch.multiprocessing as mp
from torch.utils.data import dataloader
from torch.utils import data

from model.parkingslotstatus import ParkingSlotStatusNet
from model.loss import ParkingSlotStatusLossFn
from dataset.parkingslotstatus_dataset import ParkingSlotStatusDataset
from utils.trainer import Trainer

import time
import argparse
import numpy as np
import os
from PIL import Image
import sys
import yaml

parser = argparse.ArgumentParser(description='PyTorch Parking Slot Classifer Training')
parser.add_argument('--resume', '-r', action='store_true', help='resume from checkpoint')
parser.add_argument('--ckpt', default='checkpoint/parkingslotstatus-backup.pth', type=str, help='resume checkpoint')
parser.add_argument('--hyp', default='config/hyp.yaml', type=str, help='hpyerparameter config file')
parser.add_argument('--half', default=0, type=int, help='using half precision training')
parser.add_argument('--adam', default=0, type=int, help='use adam optimizer')
parser.add_argument('--workers', default=0, type=int, help='image height')
parser.add_argument('--batch', default=32, type=int, help='batch size')
parser.add_argument('--datadir', default='', type=str, help='dataset dir')
parser.add_argument('--disturl', default='tcp://localhost:23456', type=str, help='torch distributed node0 IP and port')
parser.add_argument('--worldsize', default=1, type=int, help='the number of machines for distributed training')
parser.add_argument('--rank', default=0, type=int, help='the order of machines for distributed training')
args = parser.parse_args()


def setup(gpu_rank, world_size):
    ngpus_per_node = torch.cuda.device_count()
    args.worldsize = ngpus_per_node * args.worldsize
    args.rank = args.rank * ngpus_per_node + gpu_rank
    dist.init_process_group("nccl", init_method=args.disturl, rank=args.rank, world_size=args.worldsize)
    print('rank/total: %d/%d' % (args.rank, args.worldsize))


def cleanup():
    dist.destroy_process_group()


def dist_train(rank, world_size):
    setup(rank, world_size)

    with open(args.hyp) as f:
        hyp = yaml.load(f, Loader=yaml.SafeLoader)  # load hyps

    trainset = ParkingSlotStatusDataset(args.datadir, hyp['width'], hyp['height'])
    valset = ParkingSlotStatusDataset(args.datadir, hyp['width'], hyp['height'], mode='valid')
    train_sampler = torch.utils.data.distributed.DistributedSampler(trainset)
    val_sampler = torch.utils.data.distributed.DistributedSampler(valset)
    loader_train = data.DataLoader(trainset, batch_size=args.batch, shuffle=False,
                                   num_workers=args.workers, pin_memory=True, sampler=train_sampler, drop_last=True)
    loader_val = data.DataLoader(valset, batch_size=args.batch, shuffle=False,
                                 num_workers=args.workers, pin_memory=True, sampler=val_sampler, drop_last=True)

    print('initializing network...')
    network = ParkingSlotStatusNet(hyp['width'], hyp['height'])
    torch.backends.cudnn.benchmark = True
    net = network.cuda(rank)
    # criterion
    criterion = ParkingSlotStatusLossFn(w_status=hyp['status'], rank=rank).cuda(rank)
    dist.barrier()  # sync point

    trainer = Trainer(net, loader_train, loader_val, criterion, args, hyp, rank)
    trainer.run()

    cleanup()


if __name__ == '__main__':
    ngpus = torch.cuda.device_count()
    mp.spawn(dist_train, args=(ngpus,), nprocs=ngpus, join=True)
