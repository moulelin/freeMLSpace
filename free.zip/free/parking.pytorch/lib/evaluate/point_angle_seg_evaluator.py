import math
import numpy as np

import torch

from .point_seg_evaluator import PointSegEvaluator


class PointAngleSegEvaluator(PointSegEvaluator):
    def __init__(self, opt, decoder, dataset):
        super(PointAngleSegEvaluator, self).__init__(opt, decoder, dataset)

    def _get_results(self, avg_inference_t):
        self.generate_seg_results()
        self.generate_point_results()
        self.results["inference_time"] = avg_inference_t
        self.results["batchsize"] = self.opt.val_batch

    def _get_infer_buffer(self):
        buffer = {}
        buffer["hist"] = torch.zeros(self.num_classes, self.num_classes).cuda()
        buffer["point_pred"] = []
        buffer["point_tp_offset"] = []
        buffer["point_truth"] = []
        buffer["center_pred"] = []
        buffer["center_tp_offset"] = []
        buffer["center_angle"] = []
        buffer["center_truth"] = []
        return buffer

    def generate_point_results(self):
        point_pred_list = self._infer_buffer["point_pred"]
        point_truth_list = self._infer_buffer["point_truth"]
        center_pred_list = self._infer_buffer["center_pred"]
        center_truth_list = self._infer_buffer["center_truth"]

        (
            point_mAP,
            point_AP,
            point_Precision,
            point_Recall,
            point_F1,
            point_PR_list,
        ) = self._calc_mAP(point_pred_list, point_truth_list, 2)
        (
            center_mAP,
            center_AP,
            center_Precision,
            center_Recall,
            center_F1,
            center_PR_list,
        ) = self._calc_mAP(center_pred_list, center_truth_list, 2)

        point_tp_offset = np.mean(self._infer_buffer["point_tp_offset"])
        center_tp_offset = np.mean(self._infer_buffer["center_tp_offset"])

        center_angle = np.mean(self._infer_buffer["center_angle"])
        acc1, acc3, acc5 = self.get_angle_acc(self._infer_buffer["center_angle"])

        self.results["point"] = {
            "mAP": point_mAP,
            "AP": point_AP,
            "Precision": point_Precision,
            "Recall": point_Recall,
            "F1-score": point_F1,
            "PR": point_PR_list,
            "tp_offset": point_tp_offset,
        }
        self.results["center"] = {
            "mAP": center_mAP,
            "AP": center_AP,
            "Precision": center_Precision,
            "Recall": center_Recall,
            "F1-score": center_F1,
            "PR": center_PR_list,
            "tp_offset": center_tp_offset,
            "angle_diff": center_angle,
            "angle_acc": [acc1, acc3, acc5],
        }

        if self.opt.scene:
            for scene_name in self._scene_infer_buffers:
                if scene_name not in self.scene_results:
                    self.scene_results[scene_name] = {}
                for scene_value in self._scene_infer_buffers[scene_name]:
                    point_pred_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["point_pred"]
                    point_truth_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["point_truth"]
                    point_tp_offset = np.mean(
                        self._scene_infer_buffers[scene_name][scene_value][
                            "point_tp_offset"
                        ]
                    )
                    center_pred_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["center_pred"]
                    center_truth_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["center_truth"]
                    center_tp_offset = np.mean(
                        self._scene_infer_buffers[scene_name][scene_value][
                            "center_tp_offset"
                        ]
                    )

                    center_angle = np.mean(
                        self._scene_infer_buffers[scene_name][scene_value][
                            "center_angle"
                        ]
                    )
                    acc1, acc3, acc5 = self.get_angle_acc(
                        self._scene_infer_buffers[scene_name][scene_value][
                            "center_angle"
                        ]
                    )

                    (
                        point_mAP,
                        point_AP,
                        point_Precision,
                        point_Recall,
                        point_F1,
                        point_PR_list,
                    ) = self._calc_mAP(point_pred_list, point_truth_list, 2)
                    (
                        center_mAP,
                        center_AP,
                        center_Precision,
                        center_Recall,
                        center_F1,
                        center_PR_list,
                    ) = self._calc_mAP(center_pred_list, center_truth_list, 2)

                    if scene_value not in self.scene_results[scene_name]:
                        self.scene_results[scene_name][scene_value] = {}
                    self.scene_results[scene_name][scene_value]["point"] = {
                        "mAP": point_mAP,
                        "AP": point_AP,
                        "Precision": point_Precision,
                        "Recall": point_Recall,
                        "F1-score": point_F1,
                        "PR": point_PR_list,
                        "tp_offset": point_tp_offset,
                    }
                    self.scene_results[scene_name][scene_value]["center"] = {
                        "mAP": center_mAP,
                        "AP": center_AP,
                        "Precision": center_Precision,
                        "Recall": center_Recall,
                        "F1-score": center_F1,
                        "PR": center_PR_list,
                        "tp_offset": center_tp_offset,
                        "angle_diff": center_angle,
                        "angle_acc": [acc1, acc3, acc5],
                    }

    def get_angle_acc(self, angle_diff_list):
        if len(angle_diff_list) == 0:
            return None, None, None
        tp1 = 0
        tp3 = 0
        tp5 = 0
        for angle_diff in angle_diff_list:
            if angle_diff <= 1:
                tp1 += 1
            if angle_diff <= 3:
                tp3 += 1
            if angle_diff <= 5:
                tp5 += 1
        acc1 = tp1 * 1.0 / len(angle_diff_list)
        acc3 = tp3 * 1.0 / len(angle_diff_list)
        acc5 = tp5 * 1.0 / len(angle_diff_list)
        return acc1, acc3, acc5

    def get_degree_diff(self, a, b):
        d1 = a - b
        d2 = 360 - abs(d1)
        if d1 > 0:
            d2 = -d2
        if abs(d1) < abs(d2):
            return d1
        else:
            return d2

    def _match_point_pred_truth(self, pred, truth, th, mode="point"):
        num_preds = pred.size(0)
        num_truth = truth.size(0)
        mask_TPFP = torch.zeros(num_preds).cuda()
        mask_TPFN = torch.zeros(num_truth).cuda()

        tp_offset = 0
        tp_count = 0
        if mode == "center":
            angle_diff = []
        for i in range(num_preds):
            if num_truth > 0:
                dis = torch.sqrt(
                    (truth[:, 2] - pred[i, 2]) ** 2 + (truth[:, 3] - pred[i, 3]) ** 2
                )
                min_dis, idx = dis.min(0)
                if (
                    (min_dis < th)
                    and (pred[i, 0] == truth[idx, 0])
                    and (mask_TPFN[idx] == 0)
                ):
                    mask_TPFN[idx] = 1
                    mask_TPFP[i] = 1
                    tp_offset += min_dis.cpu().numpy()
                    tp_count += 1
                    if mode == "center":
                        pred_angle = (
                            math.atan2(
                                -pred[i, 5].cpu().numpy(), pred[i, 4].cpu().numpy()
                            )
                            / math.pi
                            * 180
                        )
                        gt_angle = (
                            math.atan2(
                                -truth[idx, 5].cpu().numpy(),
                                truth[idx, 4].cpu().numpy(),
                            )
                            / math.pi
                            * 180
                        )

                        # pred_angle = pred[i, 6].cpu().numpy()
                        if pred_angle < 0:
                            pred_angle += 360
                        if gt_angle < 0:
                            gt_angle += 360
                        angle_diff.append(
                            abs(self.get_degree_diff(gt_angle, pred_angle))
                        )

        pred_out = torch.cat([pred[:, :2], mask_TPFP.view(-1, 1)], dim=1)

        if tp_count:
            tp_offset = tp_offset / tp_count
        else:
            tp_offset = None

        if mode == "center":
            return pred_out, tp_offset, angle_diff
        else:
            return pred_out, tp_offset

    def _eval_point(self, label, pred, sample_idx, mode="point"):
        B = label.size(0)
        if mode == "point":
            thresh_point_dis = self.opt.thresh_point_dis
            thresh_point_score = self.opt.thresh_point
        elif mode == "center":
            thresh_point_dis = self.opt.thresh_center_dis
            thresh_point_score = self.opt.thresh_center
        else:
            print("{} not support".format(mode))
            exit()

        for i in range(B):
            truth = label[i].clone()
            truth = truth[truth[:, 1] == 1]
            pre = pred[i].clone()
            pre = pre[pre[:, 1] > thresh_point_score]
            if pre != None:
                if mode == "center":
                    pred_out, tp_offset, angle_diff = self._match_point_pred_truth(
                        pre, truth, thresh_point_dis, mode
                    )
                    self._infer_buffer[f"{mode}_angle"].extend(angle_diff)
                    if self.opt.scene:
                        scene_infos = self.opt.scene_infos_list[sample_idx]
                        for scene_name, scene_value in scene_infos.items():
                            if scene_value in self.opt.filter_keys:
                                continue
                            if tp_offset:
                                self._scene_infer_buffers[scene_name][scene_value][
                                    f"{mode}_angle"
                                ].append(angle_diff)
                else:
                    pred_out, tp_offset = self._match_point_pred_truth(
                        pre, truth, thresh_point_dis, mode
                    )
                self._infer_buffer[f"{mode}_pred"].append(pred_out)
                if tp_offset:
                    self._infer_buffer[f"{mode}_tp_offset"].append(tp_offset)
                if self.opt.scene:
                    scene_infos = self.opt.scene_infos_list[sample_idx]
                    for scene_name, scene_value in scene_infos.items():
                        if scene_value in self.opt.filter_keys:
                            continue
                        self._scene_infer_buffers[scene_name][scene_value][
                            f"{mode}_pred"
                        ].append(pred_out)
                        if tp_offset:
                            self._scene_infer_buffers[scene_name][scene_value][
                                f"{mode}_tp_offset"
                            ].append(tp_offset)

            if truth != None:
                self._infer_buffer[f"{mode}_truth"].append(truth[:, 0].view(-1, 1))
                if self.opt.scene:
                    scene_infos = self.opt.scene_infos_list[sample_idx]
                    for scene_name, scene_value in scene_infos.items():
                        if scene_value in self.opt.filter_keys:
                            continue
                        self._scene_infer_buffers[scene_name][scene_value][
                            f"{mode}_truth"
                        ].append(truth[:, 0].view(-1, 1))
