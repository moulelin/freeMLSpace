import cv2
import json
import os

from matplotlib.artist import get


def get_info_value(info, keys):
    tmp = info["metric"]
    if "segFallenPedestrian" in tmp and "segPedestrian" not in tmp:
        tmp["segPedestrian"] = tmp["segFallenPedestrian"]
    for i in range(len(keys)):
        tmp = tmp.get(keys[i], None)
        if tmp is None:
            return tmp
    return tmp


def get_scene_value(info, keys):
    tmp = info["scene"]
    tmp = tmp.get(keys[0], None)
    if tmp is None or tmp != keys[1]:
        return None
    else:
        return tmp


if __name__ == "__main__":

    # metric_tags = "point:tp"
    # metric_tags = "point:fp"
    # metric_tags = "point:fn"
    # metric_tags = "center:tp"
    # metric_tags = "center:fp"
    # metric_tags = "center:fn"
    # metric_tags = "offset:tp"
    # metric_tags = "offset:fp"
    # metric_tags = "type:tp"
    # metric_tags = "type:fp"
    # metric_tags = "ws:tp"
    # metric_tags = "ws:fp"
    # metric_tags = "segWheelStop:iou"
    # metric_tags = "segWall:iou"
    # metric_tags = "segPillar:iou"
    # metric_tags = "segParkLockClosed:iou"
    # metric_tags = "segVehicle:iou"
    # metric_tags = "segVegetation:iou"
    # metric_tags = "segCurb:iou"
    # metric_tags = "segPedestrian:iou"
    metric_tags = "segCone:iou"

    # scene_tags = "车位类型:垂直车位"
    # scene_tags = "车位类型:斜列车位"
    # scene_tags = "地面材质类型:水泥路"
    # scene_tags = "车位线类型:T形线"
    # scene_tags = "磨损程度:无磨损"
    # scene_tags = "环境要素:明亮"
    # scene_tags = "反光程度:轻微反光"
    # scene_tags = "地理要素:地下"
    scene_tags = "all"

    badcase_dir = "/mnt/data/data/fisheye/models/release/20230207/badcase"
    web_badcase_dirs = [
        # "/output/fisheye/automl-fisheye-eval-1orifisheval1101-u41it/automl-fisheye-eval-1orifisheval1101-u41it-bnbjx/report/badcase",
        "/output/fisheye/automl-fisheye-eval-1fsevalv0207-ytfxw/automl-fisheye-eval-1fsevalv0207-ytfxw-lr4t8/report/badcase",
    ]
    model1_info_file = "/mnt/data/data/fisheye/models/release/20230207/badcase/4fsrelabel0107-1/infos.json"
    model2_info_file = "/mnt/data/data/fisheye/models/release/20230207/badcase/fstrain0207-2/infos.json"

    with open(model1_info_file, "r") as f:
        infos1 = json.load(f)
    # print(infos1["0"])
    # exit()

    with open(model2_info_file, "r") as f:
        infos2 = json.load(f)

    print(infos1["0"])
    print(infos2["0"])
    print("infos1: ", len(infos1))
    print("infos2: ", len(infos2))

    metric_keys = metric_tags.split(":")
    scene_keys = scene_tags.split(":")

    badcase_count = 0
    img_path_metric_list = []
    for img_id in infos1:
        model1_img_path = infos1[img_id]["imgPath"]
        model2_img_path = infos2[img_id]["imgPath"]
        for web_badcase_dir in web_badcase_dirs:
            model1_img_path = model1_img_path.replace(web_badcase_dir, badcase_dir)
            model2_img_path = model2_img_path.replace(web_badcase_dir, badcase_dir)

        if scene_tags != "all":
            scene_value = get_scene_value(infos1[img_id], scene_keys)
            if scene_value is None:
                continue

        model1_metric_value = get_info_value(infos1[img_id], metric_keys)
        model2_metric_value = get_info_value(infos2[img_id], metric_keys)
        if model1_metric_value is None or model2_metric_value is None:
            continue

        badcase_count += 1
        img_path_metric_list.append(
            [
                model1_img_path,
                model2_img_path,
                model1_metric_value,
                model2_metric_value,
                model2_metric_value - model1_metric_value,
            ]
        )

    img_path_metric_list.sort(key=lambda x: x[-1], reverse=True)
    # img_path_metric_list.sort(key=lambda x: x[-1])

    for i in range(2000):
        model1_img_path = img_path_metric_list[i][0]
        model2_img_path = img_path_metric_list[i][1]
        model1_metric_value = img_path_metric_list[i][2]
        model2_metric_value = img_path_metric_list[i][3]
        diff = img_path_metric_list[i][3]

        img1 = cv2.imread(model1_img_path)
        h, w, _ = img1.shape
        img1 = cv2.resize(img1, (w, h))
        img2 = cv2.imread(model2_img_path)
        h, w, _ = img2.shape
        img2 = cv2.resize(img2, (w, h))
        cv2.imshow(f"1-{metric_tags}-{round(model1_metric_value, 3)}", img1)
        cv2.imshow(f"2-{metric_tags}-{round(model2_metric_value, 3)}", img2)
        key = cv2.waitKey(0)
        if key == 27:
            exit()
        cv2.destroyAllWindows()
