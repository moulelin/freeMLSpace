from .task.parking_slot_seg import ParkingSlotSegDataset
from .task.parking_slot_point import ParkingSlotPointDataset
from .task.parking_slot_seg_angle import ParkingSlotSegAngleDataset
from .task.cityscapes_seg import CityScapesSegDataset
from .task.fisheye_seg import FishEyeSegDataset
from .task.fisheye_freespace_seg import FishEyeFSSegDataset
from .task.lidar_seg import LidarSegDataset
from .task.parking_slot_point_cls import ParkingSlotPointClsDataset
from .task.parking_center_point_cls import ParkingCenterPointClsDataset
from .task.parking_slot_mid_point_cls import ParkingMidClsDataset
from .task.parking_slot_mid_ws import ParkingMidWSDataset
from .task.fisheye_bev_det import FishEyeBEVDetDataset


dataset_factory = {
    "parking_slot_seg": ParkingSlotSegDataset,
    "parking_slot_point": ParkingSlotPointDataset,
    "parking_slot_seg_angle": ParkingSlotSegAngleDataset,
    "fisheye_seg": FishEyeSegDataset,
    "fisheye_freespace_seg": FishEyeFSSegDataset,
    "lidar_seg": LidarSegDataset,
    "parking_slot_point_cls": ParkingSlotPointClsDataset,
    "parking_center_point_cls": ParkingCenterPointClsDataset,
    "parking_slot_mid_point_cls": ParkingMidClsDataset,
    "parking_slot_mid_ws": ParkingMidWSDataset,
    "fisheye_bev_det": FishEyeBEVDetDataset,
}


def get_dataset(task_name):
    return dataset_factory[task_name]
