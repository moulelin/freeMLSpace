import numpy as np
from PIL import Image

import torch

import lib.datasets.transform.common_transform as T
from lib.utils.vis_util import *
from lib.datasets.dataset.cityscapes import CityScapesDataset


colors = np.random.randint(0, 256, (256, 3), dtype=np.uint8)


class CityScapesSegDataset(CityScapesDataset):
    def __init__(self, opt, mode):
        super(CityScapesSegDataset, self).__init__(opt, mode)
        self.size = (self.opt.h_input, self.opt.w_input)
        if self.mode == "train":
            self.transform = T.Compose(
                [
                    # T.RandomResizedCrop(self.opt.scales, self.size),
                    T.RandomAffine(self.size, degrees=30),
                    T.RandomHorizontalFlip(),
                    T.ColorJitter(0.5, 0.5, 0.5, 0.5),
                    T.ToTensor(),
                ]
            )
        else:
            self.transform = T.Compose([T.Resize(self.size), T.ToTensor()])

    def __getitem__(self, index):
        image_path, label_path = (
            self.label_dict["image_list"][index],
            self.label_dict["label_seg_list"][index],
        )
        image, label_seg = Image.open(image_path), Image.open(label_path)
        label_seg = self.label_map[label_seg]
        label_seg = Image.fromarray(label_seg)
        im_lb = dict(im=image, lb_seg=label_seg, lb_slot=torch.Tensor([]))
        im_lb = self.transform(im_lb)

        image, label = im_lb["im"], dict(
            label_seg=im_lb["lb_seg"],
        )
        return image, label

    def verify(self, index):
        image, label = self.__getitem__(index)
        image = tensor_to_image(image)
        label_seg = label["label_seg"].squeeze(0).numpy()

        label_seg = colors[label_seg]
        combined_img = np.hstack([image, label_seg])
        return combined_img
        cv2.imshow("combined_img", combined_img)
        cv2.waitKey(0)
