import cv2

import torch
import torch.nn as nn
import torch.nn.functional as F
import pdb

from .common_loss.focal_loss import CenterFocalLoss, FocalLoss
# from .common_loss.iou_loss import IOULoss


class BEVPointLoss(nn.Module):
    def __init__(self, opt):
        super(BEVPointLoss, self).__init__()
        self.opt = opt
        self.pred_len = 13
        self.gt_len = 13
        self.focal_cls = CenterFocalLoss(alpha=4, beta=2)
        self.smooth_l1 = nn.SmoothL1Loss()
        self.mse_loss = nn.MSELoss()
        # self.iou_loss = IOULoss()

        self.w_map = self.opt.loss_bev_weight_dict["w_map"]
        self.w_mse = self.opt.loss_bev_weight_dict["w_mse"]
        self.w_off = self.opt.loss_bev_weight_dict["w_off"]
        # self.w_ch = self.opt.loss_bev_weight_dict["w_ch"]
        self.w_wlh = self.opt.loss_bev_weight_dict["w_wlh"]
        # self.w_angle = self.opt.loss_bev_weight_dict["w_angle"]
        # self.w_iou = self.opt.loss_bev_weight_dict["w_iou"]
    
    def get_corners(self, map, wlh, angle, inds):
        corners = torch.zeros((inds.shape[0], 5), device=map.device)
        xs = ((inds.float() / torch.tensor(320, dtype=torch.float)).int().float())
        ys = (inds % 320).int().float()
        rot_s = angle[:, 0]
        rot_c = angle[:, 1]
        wh = wlh[:, :2]
        radius = torch.atan2(rot_s, rot_c)
        corners[:, 0] = xs
        corners[:, 1] = ys
        corners[:, 2:4] = wh
        corners[:, 4] = radius
        return corners

    def forward(self, pred, truth, cls_name="car"):

        # original pred shape: [2, 9, 40, 40]
        pred = pred.permute(0, 2, 3, 1).contiguous().view(-1, self.pred_len).float()
        truth = truth.view(-1, self.gt_len).float()

        # pmap = pred[:, 0:1].sigmoid()
        pmap1 = pred[:, 0:1].sigmoid()
        pmap2 = pred[:, 1:2].sigmoid()
        pmap3 = pred[:, 2:3].sigmoid()
        # poff = pred[:, 4:6].sigmoid()
        poff1 = pred[:, 3:5].sigmoid()
        poff2 = pred[:, 5:7].sigmoid()
        poff3 = pred[:, 7:9].sigmoid()
        # p_ch = pred[:, 12:13]
        p_wlh = pred[:, 9:11]
        p_wlh1 = pred[:, 11:13]
        # p_angle = 2 * pred[:, 16:18].sigmoid() - 1

        # tmap = truth[:, 0:1]
        tmap1 = truth[:, 0:1]
        tmap2 = truth[:, 1:2]
        tmap3 = truth[:, 2:3]
        # toff = truth[:, 4:6]
        toff1 = truth[:, 3:5]
        toff2 = truth[:, 5:7]
        toff3 = truth[:, 7:9]
        # t_ch = truth[:, 12:13]
        t_wlh = truth[:, 9:11]
        t_wlh1 = truth[:, 11:13]
        # t_angle = truth[:, 16:18]

        # mask = tmap[:, 0].not_equal(self.opt.ignore_label)
        # if mask.sum() == 0:
        #     l_map = pmap.sum() * 0
        #     l_mse = pmap.sum() * 0
        #     l_off = poff.sum() * 0
        #     # l_ch = p_ch.sum() * 0
        #     # l_wlh = p_wlh.sum() * 0
        #     # l_angle = t_angle.sum() * 0
        #     # l_iou = t_angle.sum() * 0
        # else:
        #     pmap = pmap[mask]
        #     poff = poff[mask]
        #     # p_ch = p_ch[mask] 
        #     # p_wlh = p_wlh[mask]
        #     # p_angle = p_angle[mask]
           
        #     l_map = self.focal_cls(pmap, tmap)
        #     l_mse = self.mse_loss(pmap, tmap)

        #     pos_mask = tmap[:, 0].eq(1)
        #     inds = torch.nonzero(pos_mask).squeeze()
        #     if pos_mask.sum() > 0:
        #         l_off = self.smooth_l1(poff[pos_mask], toff[pos_mask])
        #         # l_ch = self.smooth_l1(p_ch[pos_mask], t_ch[pos_mask])
        #         # l_wlh = self.smooth_l1(p_wlh[pos_mask], t_wlh[pos_mask])
        #         # l_angle = self.smooth_l1(p_angle[pos_mask], t_angle[pos_mask])
        #         # if pos_mask.sum() == 1:
        #         #     inds = inds.unsqueeze(0)
        #         # p_corners = self.get_corners(pmap, p_wlh[pos_mask], p_angle[pos_mask], inds)
        #         # t_corners = self.get_corners(tmap, t_wlh[pos_mask], t_angle[pos_mask], inds)
        #         # l_iou = self.iou_loss(p_corners, t_corners)

        #     else:
        #         l_off = poff.sum() * 0
        #         # l_ch = p_ch.sum() * 0
        #         # l_wlh = p_wlh.sum() * 0
        #         # l_angle = t_angle.sum() * 0
        #         # l_iou = t_angle.sum() * 0

        mask1 = tmap1[:, 0].not_equal(self.opt.ignore_label)
        if mask1.sum() == 0:
            l_map1 = pmap1.sum() * 0
            l_mse1 = pmap1.sum() * 0
            l_off1 = poff1.sum() * 0
            l_wlh = p_wlh.sum() * 0
            l_wlh1 = p_wlh1.sum() * 0
        else:
            pmap1 = pmap1[mask1]
            poff1 = poff1[mask1]
            p_wlh = p_wlh[mask1]
            p_wlh1 = p_wlh1[mask1]
           
            l_map1 = self.focal_cls(pmap1, tmap1)
            l_mse1 = self.mse_loss(pmap1, tmap1)

            pos_mask1 = tmap1[:, 0].eq(1)
            if pos_mask1.sum() > 0:
                l_off1 = self.smooth_l1(poff1[pos_mask1], toff1[pos_mask1])
                l_wlh = self.smooth_l1(p_wlh[pos_mask1], t_wlh[pos_mask1])
                l_wlh1 = self.smooth_l1(p_wlh1[pos_mask1], t_wlh1[pos_mask1])

            else:
                l_off1 = poff1.sum() * 0
                l_wlh = p_wlh.sum() * 0
                l_wlh1 = p_wlh1.sum() * 0

        mask2 = tmap2[:, 0].not_equal(self.opt.ignore_label)
        if mask2.sum() == 0:
            # l_wlh = p_wlh.sum() * 0
            l_map2 = pmap2.sum() * 0
            l_mse2 = pmap2.sum() * 0
            l_off2 = poff2.sum() * 0
        else:
            pmap2 = pmap2[mask2]
            poff2 = poff2[mask2]
           
            l_map2 = self.focal_cls(pmap2, tmap2)
            l_mse2 = self.mse_loss(pmap2, tmap2)

            pos_mask2 = tmap2[:, 0].eq(1)
            if pos_mask2.sum() > 0:
                # l_wlh = self.smooth_l1(p_wlh[pos_mask1], t_wlh[pos_mask1])
                l_off2 = self.smooth_l1(poff2[pos_mask2], toff2[pos_mask2])

            else:
                l_off2 = poff2.sum() * 0
                # l_wlh = p_wlh.sum() * 0

        mask3 = tmap3[:, 0].not_equal(self.opt.ignore_label)
        if mask3.sum() == 0:
            # l_wlh1 = p_wlh1.sum() * 0
            l_map3 = pmap3.sum() * 0
            l_mse3 = pmap3.sum() * 0
            l_off3 = poff3.sum() * 0
        else:
            pmap3 = pmap3[mask3]
            poff3 = poff3[mask3]
           
            l_map3 = self.focal_cls(pmap3, tmap3)
            l_mse3 = self.mse_loss(pmap3, tmap3)

            pos_mask3 = tmap3[:, 0].eq(1)
            if pos_mask3.sum() > 0:
                # l_wlh1 = self.smooth_l1(p_wlh1[pos_mask1], t_wlh1[pos_mask1])
                l_off3 = self.smooth_l1(poff3[pos_mask3], toff3[pos_mask3])

            else:
                l_off3 = poff3.sum() * 0
                # l_wlh1 = p_wlh1.sum() * 0
        
        # l_map = l_map * self.w_map
        l_map1 = l_map1 * self.w_map
        l_map2 = l_map2 * self.w_map
        l_map3 = l_map3 * self.w_map
        # l_mse = l_mse * self.w_mse
        l_mse1 = l_mse1 * self.w_mse
        l_mse2 = l_mse2 * self.w_mse
        l_mse3 = l_mse3 * self.w_mse
        # l_off = l_off * self.w_off
        l_off1 = l_off1 * self.w_off
        l_off2 = l_off2 * self.w_off
        l_off3 = l_off3 * self.w_off
        # l_ch = l_ch * self.w_ch
        l_wlh = l_wlh * self.w_wlh
        l_wlh1 = l_wlh1 * self.w_wlh
        # l_angle = l_angle * self.w_angle
        # l_iou = l_iou * self.w_iou

        loss = l_map1 + l_mse1 + l_off1 + l_map2 + l_mse2 + l_off2 + l_map3 + l_mse3 + l_off3 + l_wlh + l_wlh1

        loss_tags = {
            # f"{cls_name}_center_map": l_map.clone().detach().cpu().numpy(),
            # f"{cls_name}_center_mse": l_mse.clone().detach().cpu().numpy(),
            # f"{cls_name}_center_off": l_off.clone().detach().cpu().numpy(),

            f"{cls_name}_corner_map1": l_map1.clone().detach().cpu().numpy(),
            f"{cls_name}_corner_mse1": l_mse1.clone().detach().cpu().numpy(),
            f"{cls_name}_corner_off1": l_off1.clone().detach().cpu().numpy(),

            f"{cls_name}_corner_map2": l_map2.clone().detach().cpu().numpy(),
            f"{cls_name}_corner_mse2": l_mse2.clone().detach().cpu().numpy(),
            f"{cls_name}_corner_off2": l_off2.clone().detach().cpu().numpy(),

            f"{cls_name}_corner_map3": l_map2.clone().detach().cpu().numpy(),
            f"{cls_name}_corner_mse3": l_mse2.clone().detach().cpu().numpy(),
            f"{cls_name}_corner_off3": l_off2.clone().detach().cpu().numpy(),

            # f"{cls_name}_center_height": l_ch.clone().detach().cpu().numpy(),
            f"{cls_name}_box_wlh": l_wlh.clone().detach().cpu().numpy(),
            f"{cls_name}_box_wlh1": l_wlh1.clone().detach().cpu().numpy(),
            # f"{cls_name}_box_angle": l_angle.clone().detach().cpu().numpy(),
            # f"{cls_name}_box_iou": l_iou.clone().detach().cpu().numpy(),
            f"{cls_name}_bev_loss": loss.clone().detach().cpu().numpy(),
        }
        return loss, loss_tags


class FishEyeBEVDetLoss(nn.Module):
    def __init__(self, opt):
        super(FishEyeBEVDetLoss, self).__init__()
        self.opt = opt
        self.bev_point_loss = BEVPointLoss(self.opt)
        # self.freespace_loss = FreeSpaceLoss(self.opt)
        self.w_bev = self.opt.w_bev

    def forward(self, pred, truth):
        # car_preds, person_preds = pred
        # loss_car, car_tags = self.bev_point_loss(car_preds, truth["car_box3d"], cls_name="car")
        # loss_person, person_tags = self.bev_point_loss(person_preds, truth["person_box3d"], cls_name="person")
        # loss = (loss_car + loss_person) * self.w_bev
        # loss_tags = {**car_tags, **person_tags}
        # loss_tags["loss"] = loss_car.clone().detach().cpu().numpy() + loss_person.clone().detach().cpu().numpy()
        car_preds = pred
        loss_car, car_tags = self.bev_point_loss(car_preds, truth["car_box3d"], cls_name="car")
        loss = loss_car * self.w_bev
        loss_tags = {**car_tags}
        loss_tags["loss"] = loss_car.clone().detach().cpu().numpy()
        return loss, loss_tags
