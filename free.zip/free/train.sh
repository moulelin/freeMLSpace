#!/bin/bash

# cd /workspace/network/parking.pytorch/
# export PYTHONPATH=./

# python3 train.py \
#     --config ./configs/bev_det.yaml \
#     --train_datasets $TRAIN_PATH \
#     --test_datasets $TEST_PATH \
#     --dataset_root /data/perception/datasets \
#     --preprocess_root /proc_data/perception/datasets \
#     --ckpt_output /output/$PNAME/$JOBNAME/$PODNAME/checkpoint/ \
#     --log_output /output/$PNAME/$JOBNAME/$PODNAME/log \
#     --result_output /output/$PNAME/$JOBNAME/$PODNAME/result \
#     $RESUME


cd parking.pytorch/
export PYTHONPATH=./

python3 train.py \
    --config ./configs/bev_det.yaml \
    --ckpt_output /output/$PNAME/$JOBNAME/$PODNAME/checkpoint/ \
    --log_output /output/$PNAME/$JOBNAME/$PODNAME/log \
    --result_output /output/$PNAME/$JOBNAME/$PODNAME/result \

