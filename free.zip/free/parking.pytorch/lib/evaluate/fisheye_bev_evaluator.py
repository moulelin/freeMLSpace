import numpy as np

import torch

import math

from .seg_evaluator import SegEvaluator

from mmcv.ops import box_iou_rotated

import pdb
# torch.set_printoptions(precision=4, sci_mode=False)
# def to_float(out_tensor):
#     out_list = out_tensor.tolist()
#     out_list = [[round(x, 4) for x in row] for row in out_list]
#     pdb.set_trace()
#     return torch.tensor(out_list, device=out_tensor.device)

def get_corners(out_tensor):
    if out_tensor.shape[0] == 0:
        return None
    corners = torch.zeros((out_tensor.shape[0], 5), device=out_tensor.device)
    rot_s = out_tensor[:, 6]
    rot_c = out_tensor[:, 7]
    radius = torch.atan2(rot_s, rot_c)
    corners[:, :2] = out_tensor[:, 1:3]
    corners[:, 2:4] = out_tensor[:, 3:5]
    corners[:, 4] = radius
    return corners

class FisheyeBevEvaluator(SegEvaluator):
    def __init__(self, opt, decoder, dataset):
        super(FisheyeBevEvaluator, self).__init__(opt, decoder, dataset)

    def _get_results(self, avg_inference_t):
        self.generate_point_results()
        self.generate_box_results()
        self.results["inference_time"] = avg_inference_t
        self.results["batchsize"] = self.opt.val_batch
        print(self.results)
        exit()

    def _eval(self, preds, label, net, sample_idx):
        center_pred, wlh_pred, yaw_pred = self.align_outputs(preds, net)

        box3d_label = label["car_box3d"]

        center_label, wlh_label, yaw_label = (
            box3d_label[:, :, :, :3],
            box3d_label[:, :, :, 4:7],
            box3d_label[:, :, :, 7:9],
        )
        center_label, wlh_label, yaw_label = self.decoder.extract_truth_eval(
           center_label, wlh_label, yaw_label
        )
        self._eval_point(center_label, center_pred, sample_idx, "center")
        label = torch.cat([center_label, wlh_label, yaw_label], dim=2)
        pred = torch.cat([center_pred, wlh_pred, yaw_pred ], dim=2)
        self._eval_iou(label, pred, sample_idx, "iou")
        return center_pred

    def _get_infer_buffer(self):
        buffer = {}
        buffer["hist"] = torch.zeros(self.num_classes, self.num_classes).cuda()
        buffer["center_pred"] = []
        buffer["center_tp_offset"] = []
        buffer["center_truth"] = []
        buffer["iou_pred"] = []
        buffer["iou_tp"] = []
        buffer["iou_truth"] = []
        buffer["yaw_diff"] = []

        return buffer

    def generate_point_results(self):
        center_pred_list = self._infer_buffer["center_pred"]
        center_truth_list = self._infer_buffer["center_truth"]

        (
            center_mAP,
            center_AP,
            center_Precision,
            center_Recall,
            center_F1,
            center_PR_list,
        ) = self._calc_mAP(center_pred_list, center_truth_list, 1)

        center_tp_offset = np.mean(self._infer_buffer["center_tp_offset"])

        self.results["center"] = {
            "mAP": center_mAP,
            "AP": center_AP,
            "Precision": center_Precision,
            "Recall": center_Recall,
            "F1-score": center_F1,
            "PR": center_PR_list,
            "tp_offset": center_tp_offset,
        }

    def generate_box_results(self):
        iou_tp = self._infer_buffer["iou_tp"]
        yaw_tp = self._infer_buffer["yaw_diff"]

        (
            mASE,
            ASE,
        ) = self._calc_mASE(iou_tp, 1)

        (
            mAOE,
            max_yaw,
        ) = self._calc_mAOE(yaw_tp, 1)

        self.results["box"] = {
            "mASE": mASE,
            "ASE": ASE,
            "mAOE": mAOE,
            "max_yaw": max_yaw,
        }
        # pdb.set_trace()

    def align_outputs(self, preds, net):
        if net.model_type == "pth":
            center_pred = preds[0][:, :, :3]
            wlh_pred = preds[0][:, :, 4:7]
            yaw_pred = preds[0][:, :, 7:9]
        else:
            print("please input pth model")
        center_cls = (center_pred[:, :, 0:1] > self.opt.center_cls_thresh) * 1.0
        new_center_pred = torch.cat([center_cls, center_pred[:, :, 1:]], dim=2)
        return new_center_pred, wlh_pred, yaw_pred

    def _match_point_pred_truth(self, pred, truth, th, mode="center" ):
        num_preds = pred.size(0)
        num_truth = truth.size(0)
        mask_TPFP = torch.zeros(num_preds).cuda()
        mask_TPFN = torch.zeros(num_truth).cuda()
        if mode=="iou":
            corner_pred = get_corners(pred)
            corner_truth = get_corners(truth)
            if corner_pred==None or corner_truth==None:
                ious = None
            else:
                ious = box_iou_rotated(corner_pred.cpu(), corner_truth.cpu(), aligned=False)
                ious = ious.cuda()
            iou_list = []
            scale_list = []
            yaw_list = []
                
        tp_offset = 0
        tp_count = 0
        tp_iou = 0
        tp_yaw = 0
        pred_dis = 0
        pred_count = 0
        for i in range(num_preds):
            if num_truth > 0:
                dis = torch.sqrt(
                    (truth[:, 1] - pred[i, 1]) ** 2 + (truth[:, 2] - pred[i, 2]) ** 2
                )
                min_dis, idx = dis.min(0)
                pred_dis += min_dis.cpu().numpy()
                pred_count += 1
                if (
                    (min_dis < th)
                    and (mask_TPFN[idx] == 0)
                ):
                    mask_TPFN[idx] = 1
                    mask_TPFP[i] = 1

                    tp_offset += min_dis.cpu().numpy()
                    if mode=="iou" and ious != None:
                        iou_list.append(1-ious[i, idx])
                        scale_iou = math.sqrt(corner_pred[i, 2] * math.sqrt(corner_pred[i, 3])) / math.sqrt(corner_truth[idx, 2] * math.sqrt(corner_truth[idx, 3]))
                        scale_list.append(scale_iou)
                        # yaw_list.append(abs(math.degrees(corner_pred[i, 4] - corner_truth[idx, 4])))
                        yaw_list.append(np.arcsin(np.sin(abs(corner_pred[i, 4].cpu() - corner_truth[idx, 4].cpu())))*180/np.pi)
                    tp_count += 1

        pred_out = torch.cat([pred[:, :1], mask_TPFP.view(-1, 1)], dim=1)

        if tp_count:
            tp_offset = tp_offset / tp_count
            if mode == "iou":
                iou_list = torch.tensor(iou_list)
                scale_list = torch.tensor(scale_list)
                tp_iou = torch.cat([iou_list.unsqueeze(0), scale_list.unsqueeze(0)])
                tp_yaw = torch.tensor(yaw_list)
        else:
            tp_offset = None
            tp_iou = None
            tp_yaw = None
        return pred_out, tp_offset, tp_iou, tp_yaw

    def _eval_point(self, label, pred, sample_idx, mode="center"):
        B = label.size(0)
        if mode == "center":
            thresh_point_dis = self.opt.thresh_center_dis
            thresh_point_score = self.opt.thresh_center
        else:
            print("{} not support".format(mode))
            exit()

        for i in range(B):
            truth = label[i].clone()
            truth = truth[truth[:, 0] == 1]
            pre = pred[i].clone()
            pre = pre[pre[:, 0] > thresh_point_score]
            if pre != None:
                pred_out, tp_offset, _, _ = self._match_point_pred_truth(
                    pre, truth, thresh_point_dis
                )
                self._infer_buffer[f"{mode}_pred"].append(pred_out)
                if tp_offset:
                    self._infer_buffer[f"{mode}_tp_offset"].append(tp_offset)

            if truth != None:
                self._infer_buffer[f"{mode}_truth"].append(truth[:, 0].view(-1, 1))

    def _eval_iou(self, label, pred, sample_idx, mode="iou"):
        B = label.size(0)
        if mode == "iou":
            thresh_point_dis = self.opt.thresh_center_dis
            thresh_point_score = self.opt.thresh_center
        else:
            print("{} not support".format(mode))
            exit()

        for i in range(B):
            truth = label[i].clone()
            truth = truth[truth[:, 0] == 1]
            pre = pred[i].clone()
            pre = pre[pre[:, 0] > thresh_point_score]
            if pre != None:
                pred_out, tp_offset, tp_iou, tp_yaw = self._match_point_pred_truth(
                    pre, truth, thresh_point_dis, mode=mode
                )
                self._infer_buffer[f"{mode}_pred"].append(pred_out)
                if tp_iou is not None:
                    self._infer_buffer[f"{mode}_tp"].append(tp_iou)
                if tp_yaw is not None:
                    self._infer_buffer["yaw_diff"].append(tp_yaw)

            if truth != None:
                self._infer_buffer[f"{mode}_truth"].append(truth[:, 0].view(-1, 1))


    def _calc_PR(self, pred, truth):
        prob_obj = pred[:, 0]
        _, idx = prob_obj.sort(descending=True)
        pred_sorted = pred.index_select(0, idx).clone()
        npos = truth.size()[0]
        TP = pred_sorted[:, -1].float() == 1
        FP = pred_sorted[:, -1].float() == 0
        acc_FP = FP.cumsum(dim=0).float()
        acc_TP = TP.cumsum(dim=0).float()
        rec = (acc_TP / npos + 1e-16).view(-1, 1)
        prec = torch.div(acc_TP, (acc_FP + acc_TP)).view(-1, 1)
        PR = torch.cat((rec, prec), dim=1)
        if len(PR) == 0:
            PR = torch.zeros((1, 2)).cuda()
        return PR

    def _calc_AP(self, PR):
        AP = 0
        num, _ = PR.size()
        ap = PR[0, 1] * (PR[0, 0] - 0)
        AP = AP + ap
        for i in range(1, num):
            ap = PR[i, 1] * (PR[i, 0] - PR[i - 1, 0])
            AP = AP + ap
        if torch.isnan(AP):
            AP = 0
        return AP

    def _calc_mAP(self, pred_list, truth_list, num_cls):
        AP_array = torch.zeros(num_cls)
        Precision_array = torch.zeros(num_cls)
        Recall_array = torch.zeros(num_cls)
        F1_array = torch.zeros(num_cls)
        total_pred = torch.cat(pred_list, dim=0).cuda()
        total_truth = torch.cat(truth_list, dim=0).cuda()
        PR_list = []
        for i in range(num_cls):
            # mask1 = total_pred[:, 0] == i
            # pred = total_pred[mask1, :].clone()
            # mask2 = total_truth[:, 0] == i
            # truth = total_truth[mask2, :].clone()
            pred = total_pred.clone()
            truth = total_truth.clone()
            PR = self._calc_PR(pred, truth)
            PR_list.append(PR.cpu().numpy())
            Precision_array[i] = PR[-1, 1]
            Recall_array[i] = PR[-1, 0]
            F1_array[i] = (
                2
                * Precision_array[i]
                * Recall_array[i]
                / (Precision_array[i] + Recall_array[i] + 1e-16)
            )
            AP = self._calc_AP(PR)
            AP_array[i] = AP
        mAP = AP_array.sum() / num_cls
        return (
            mAP.cpu().numpy(),
            AP_array.cpu().numpy(),
            Precision_array.cpu().numpy(),
            Recall_array.cpu().numpy(),
            F1_array.cpu().numpy(),
            PR_list,
        )

    def _calc_ASE(self, iou_list, scale_list):
        ASE = 0
        num = iou_list.shape[0]
        for i in range(num):
            ASE += iou_list[i] / scale_list[i]
        if num == 0:
            return ASE
        ASE /= num
        return ASE
    
    def _calc_AOE(self, yaw_list):
        AOE = 0
        num = yaw_list.shape[0]
        for i in range(num):
            AOE += yaw_list[i]
        if num == 0:
            return AOE
        AOE /= num
        return AOE

    def _calc_mASE(self, iou_tp, num_cls):
        num = len(iou_tp)
        ASE_array = torch.zeros(num_cls)
        for i in range(num_cls):
            ASE = 0
            for j in range(num):
                ase = self._calc_ASE(iou_tp[j][0, :], iou_tp[j][1, :])
                ASE += ase
            ASE_array[i] = ASE / num
        mASE = ASE_array.sum() / num_cls
        return (
            mASE.cpu().numpy(),
            ASE_array.cpu().numpy(),
        )
    def _calc_mAOE(self, yaw_tp, num_cls):
        num = len(yaw_tp)
        AOE_array = torch.zeros(num_cls)
        max_yaw = 0
        for i in range(num_cls):
            AOE = 0
            for j in range(num):
                aoe = self._calc_AOE(yaw_tp[j])
                AOE += aoe
                max_yaw = max(max_yaw, max(yaw_tp[j]))
            AOE_array[i] = AOE / num
        mAOE = AOE_array.sum() / num_cls
        return (
            mAOE.cpu().numpy(),
            max_yaw.cpu()
        )