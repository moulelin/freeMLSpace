import time
import numpy as np
from tqdm import tqdm
import cv2
import os
import json
import math

import torch

from lib.post.post_factory import create_post
from lib.utils.common import metric_name_to_camel, train_id_to_name_map


class SegEvaluator:
    def __init__(self, opt, decoder, dataset):
        self.opt = opt
        self.ignore_label = self.opt.ignore_label
        self.num_classes = self.opt.n_cats
        self.dataset = dataset

        self._infer_buffer = self._get_infer_buffer()  # save middle results
        self._scene_infer_buffers = self._get_scene_infer_buffers()
        self.results = {}
        self.scene_results = {}

        self.decoder = decoder

        if self.opt.badcase:
            self.poster = create_post(opt)

            self.badcase_imgs_dir = os.path.join(
                self.opt.badcase_root, opt.model_version, "imgs"
            )
            self.badcase_info_file = os.path.join(
                self.opt.badcase_root, opt.model_version, "infos.json"
            )
            if not os.path.exists(self.badcase_imgs_dir):
                os.makedirs(self.badcase_imgs_dir)

            self.badcase_infos = {}
            self.cur_infos = {}

            self.seg_labels_info = self.dataset.labels_info
            self.seg_id_map = train_id_to_name_map(self.seg_labels_info)

        assert opt.val_batch == 1, "only support batch 1"

    def __call__(self, net, data_loader):
        diter = tqdm(enumerate(data_loader), total=len(data_loader))

        inference_t = 0
        count = 0
        for i, batch in diter:
            image, label = self.sample_to_cuda(batch)

            if net.model_type == "trt":
                image = image.cpu().numpy()

            if i == 0:
                preds = net.inference(image)
            else:
                st = time.time()
                preds = net.inference(image)
                et = time.time()
                inference_t += et - st
                count += 1

            if self.opt.badcase:
                self.cur_infos = {}
                self.cur_infos["metric"] = {}
            align_preds = self._eval(preds, label, net, i)

            if self.opt.badcase:
                if net.model_type == "trt":
                    img_show = np.ascontiguousarray(
                        image[0].transpose((1, 2, 0))[:, :, ::-1] * 255.0
                    ).astype("uint8")
                else:
                    image = image.cpu().squeeze(0)
                    img_show = image.permute(1, 2, 0).contiguous().numpy()
                    img_show = img_show[:, :, ::-1]
                    img_show = (img_show * 255.0).astype(np.uint8)
                result_img = self.poster.run(align_preds, img_show)
                badcase_gt = self.dataset.verify(i)
                input_img_path = self.dataset.label_dict["image_list"][i]
                img_name = input_img_path.split("/")[-1][:-4]

                badcase_img = np.concatenate([badcase_gt, result_img], axis=0)
                h, w, _ = badcase_img.shape
                badcase_img = cv2.resize(badcase_img, (w // 2, h // 2))
                img_path = os.path.join(
                    self.badcase_imgs_dir, "{}.jpg".format(img_name)
                )
                cv2.imwrite(img_path, badcase_img)

                self.cur_infos["imgPath"] = img_path
                self.cur_infos["img_path"] = img_path

                if self.opt.scene:
                    self.cur_infos["scene"] = {}
                    scene_infos = self.opt.scene_infos_list[i]
                    for scene_name, scene_value in scene_infos.items():
                        if scene_value in self.opt.filter_keys:
                            continue
                        self.cur_infos["scene"][scene_name] = scene_value

                # metric_name_to_camel
                new_metrics = {}
                for metric_name in self.cur_infos["metric"]:
                    new_metric_name = metric_name_to_camel(metric_name)
                    new_metrics[new_metric_name] = self.cur_infos["metric"][metric_name]
                self.cur_infos["metric"] = new_metrics

                self.badcase_infos[i] = self.cur_infos
        if self.opt.badcase:
            with open(self.badcase_info_file, "w") as f:
                f.write(json.dumps(self.badcase_infos))

        avg_inference_t = inference_t * 1.0 / count
        print("count: ", count)
        self._get_results(avg_inference_t)

        return self.results, self.scene_results

    def _get_results(self, avg_inference_t):
        self.generate_seg_results()
        self.results["inference_time"] = avg_inference_t
        self.results["batchsize"] = self.opt.val_batch

    def _eval(self, preds, label, net, sample_idx):
        seg_pred = self.align_outputs(preds, net)
        seg_label = label["label_seg"]
        seg_label = self.decoder.extract_truth(seg_label)
        self._eval_seg(seg_label, seg_pred, sample_idx)
        return seg_pred

    def _get_infer_buffer(self):
        buffer = {}
        buffer["hist"] = torch.zeros(self.num_classes, self.num_classes).cuda()
        return buffer

    def _get_scene_infer_buffers(self):
        if self.opt.scene:
            scene_infer_buffers = {}
            for scene_infos in self.opt.scene_infos_list:
                for scene_name, scene_value in scene_infos.items():
                    if scene_value in self.opt.filter_keys:
                        continue
                    if scene_name not in scene_infer_buffers:
                        scene_infer_buffers[scene_name] = {}
                    if scene_value not in scene_infer_buffers[scene_name]:
                        scene_infer_buffers[scene_name][
                            scene_value
                        ] = self._get_infer_buffer()
        else:
            scene_infer_buffers = None
        return scene_infer_buffers

    def generate_seg_results(self):
        hist = self._infer_buffer["hist"]
        ious, miou = self._calc_miou(hist)

        self.results["seg"] = {
            "ious": ious,
            "miou": miou,
            "hist": hist.detach().cpu().numpy(),
        }

        if self.opt.scene:
            for scene_name in self._scene_infer_buffers:
                if scene_name not in self.scene_results:
                    self.scene_results[scene_name] = {}
                for scene_value in self._scene_infer_buffers[scene_name]:
                    hist = self._scene_infer_buffers[scene_name][scene_value]["hist"]
                    ious, miou = self._calc_miou(hist)

                    if scene_value not in self.scene_results[scene_name]:
                        self.scene_results[scene_name][scene_value] = {}

                    self.scene_results[scene_name][scene_value]["seg"] = {
                        "ious": ious,
                        "miou": miou,
                        "hist": hist.detach().cpu().numpy(),
                    }

    def align_outputs(self, pred, net):
        if net.model_type == "pth":
            return pred
        else:
            return torch.tensor(
                pred[0]
                .reshape(self.opt.val_batch, self.opt.h_input, self.opt.w_input)
                .astype("int32")
            ).cuda()

    def _eval_seg(self, label, pred, sample_idx):

        keep = label != self.ignore_label
        ignore_idx = label == self.ignore_label
        if ignore_idx.sum() == label.numel():
            cur_hist = torch.zeros((self.num_classes, self.num_classes)).cuda()
        else:
            cur_hist = torch.bincount(
                label[keep] * self.num_classes + pred[keep],
                minlength=self.num_classes**2,
            ).view(self.num_classes, self.num_classes)
        self._infer_buffer["hist"] += cur_hist

        if self.opt.badcase:
            cur_ious = cur_hist.diag() / (
                cur_hist.sum(dim=0) + cur_hist.sum(dim=1) - cur_hist.diag() + 1e-6
            )

            for badcase_label in range(self.opt.n_cats):
                num_badcase_label = label.eq(badcase_label).sum()
                if num_badcase_label > 0:
                    metric_name = "seg-{}".format(self.seg_id_map[badcase_label])
                    self.cur_infos["metric"][metric_name] = {}
                    self.cur_infos["metric"][metric_name]["iou"] = float(
                        cur_ious[badcase_label].cpu()
                    )

        if self.opt.scene:
            scene_infos = self.opt.scene_infos_list[sample_idx]
            for scene_name, scene_value in scene_infos.items():
                if scene_value in self.opt.filter_keys:
                    continue
                self._scene_infer_buffers[scene_name][scene_value][
                    "hist"
                ] += torch.bincount(
                    label[keep] * self.num_classes + pred[keep],
                    minlength=self.num_classes**2,
                ).view(
                    self.num_classes, self.num_classes
                )

    def _calc_miou(self, hist):
        ious = hist.diag() / (hist.sum(dim=0) + hist.sum(dim=1) - hist.diag() + 1e-6)
        ious = ious.detach().cpu().numpy()
        miou = np.nanmean(ious)
        return ious, miou.item()

    def sample_to_cuda(self, data):
        if isinstance(data, str):
            return data
        elif isinstance(data, dict):
            return {key: self.sample_to_cuda(data[key]) for key in data.keys()}
        elif isinstance(data, list):
            return [self.sample_to_cuda(val) for val in data]
        else:
            return data.cuda()
