import torch
import torch.nn as nn
import torch.nn.functional as F


class FocalLossFn(nn.Module):
    def __init__(self, num_classes, rank=0):
        super(FocalLossFn, self).__init__()
        self.num_cls = num_classes
        self.one_hot = torch.eye(self.num_cls).cuda(rank)

    def focal_loss(self, x, y):
        alpha = 0.25
        gamma = 2
        t = self.one_hot[y, :]
        p = x.sigmoid()
        pt = p * t + (1 - p) * (1 - t)  # pt = p if t > 0 else 1-p
        w = alpha * t + (1 - alpha) * (1 - t)  # w = alpha if t > 0 else 1-alpha
        w = w * (1 - pt).pow(gamma)
        w = w.detach()
        return F.binary_cross_entropy_with_logits(x, t, w)

    def forward(self, pred, truth):
        truth = truth.squeeze(1)
        loss = self.focal_loss(pred, truth)
        return loss


class ParkingSlotStatusLossFn(nn.Module):
    def __init__(self, status_num=2, w_status=1.0, rank=0):
        super(ParkingSlotStatusLossFn, self).__init__()
        self.loss_fn_status = FocalLossFn(status_num, rank=rank)
        self.w_status = w_status

    def forward(self, pred_dict, truth_dict):
        loss_status = self.loss_fn_status(pred_dict, truth_dict) * self.w_status
        loss = loss_status
        loss_tags = {
            'status': loss_status.clone().detach().cpu().numpy(),
            'loss': loss.clone().detach().cpu().numpy()
        }
        return loss, loss_tags
