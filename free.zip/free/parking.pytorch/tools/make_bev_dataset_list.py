import argparse
import os
import os.path as osp
import sys
import random


parser = argparse.ArgumentParser(description="Make Dataset List")
parser.add_argument(
    "--detdir", default="/test_data/zhengming", type=str, help="path to input dir"
)
parser.add_argument(
    "--outdir", default="./datasets", type=str, help="path to output dir"
)
args = parser.parse_args()

if not osp.exists(args.outdir):
    os.makedirs(args.outdir)
# train & val
train_label_file = osp.join(args.outdir, "train_label_list.txt")
val_label_file = osp.join(args.outdir, "val_label_list.txt")

input_root = osp.realpath(args.detdir)
input_root_len = len(input_root) + 1

file_list = []
for root, dirs, filenames in os.walk(args.detdir):
    if "slice" in root:
        if "prelabel" in root:
            if "lidar_continue" in root:
                for filename in filenames:
                    file_list.append(osp.join(root[input_root_len:], filename))

random.shuffle(file_list)
# sampling train:val = 9:1
trainlist = file_list[: int(0.9 * len(file_list))]
vallist = file_list[(int(0.9 * len(file_list)) + 1) :]
with open(train_label_file, "w") as f:
    for img in trainlist:
        f.write(img + "\n")
with open(val_label_file, "w") as f:
    for img in vallist:
        f.write(img + "\n")

print("train data: " + str(len(trainlist)) + "/" + str(len(file_list)))
print("val data: " + str(len(vallist)) + "/" + str(len(file_list)))
