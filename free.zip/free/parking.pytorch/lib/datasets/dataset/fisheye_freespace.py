import numpy as np
import os
import yaml
import json
import math
import pickle
from tqdm import tqdm

# from scipy.spatial.transform import Rotation as R

from .base_dataset import BaseDataset
from lib.datasets.utils.quaternion import Quaternion


CAMERA_NAMES = ["CAM_FRONT", "CAM_LEFT", "CAM_RIGHT", "CAM_REAR"]
CAMERA_PARAMS = {
    "CAM_FRONT": [
        "camera_surround_front_intrinsics.yaml",
        "camera_surround_front_2_vehicle_extrinsics.yaml",
    ],
    "CAM_LEFT": [
        "camera_surround_left_intrinsics.yaml",
        "camera_surround_left_2_vehicle_extrinsics.yaml",
    ],
    "CAM_RIGHT": [
        "camera_surround_right_intrinsics.yaml",
        "camera_surround_right_2_vehicle_extrinsics.yaml",
    ],
    "CAM_REAR": [
        "camera_surround_rear_intrinsics.yaml",
        "camera_surround_rear_2_vehicle_extrinsics.yaml",
    ],
}

labels_info = [
    {
        "name": "obstacle",
        "id": 1,
        "color": [0, 0, 0],
        "train_id": 0,
    },
    {
        "name": "freespace",
        "id": 2,
        "color": [0, 0, 0],
        "train_id": 1,
    },
    {
        "name": "ignore",
        "id": 0,
        "color": [0, 0, 0],
        "train_id": 255,
    },
]


class FishEyeFSDataset(BaseDataset):
    def __init__(self, opt, mode):
        super(FishEyeFSDataset, self).__init__(opt, mode)
        self.label_ignore = opt.ignore_label
        self.camera_dict = {"front":"1", "right":"2", "rear":"3", "left":"4"}
        self._camera_names = CAMERA_NAMES
        self._train_category = labels_info
        self.history_data_path = self.opt.history_data if hasattr(self.opt, "history_data") else ""
        self._get_dataset()
        self.len = len(self.label_dict["img_list"])

    @property
    def camera_names(self):
        return self._camera_names

    @property
    def train_category(self):
        return self._train_category

    @property
    def label_dict(self):
        return self._label_dict

    def _get_dataset(self):
        if self.mode == "train":
            datalist_dict = self.train_path_dict
        else:
            datalist_dict = self.test_path_dict

        print(datalist_dict)

        ## init history data
        history_label_dict = None
        if self.history_data_path != "":
            history_label_dict = {}
            history_data = os.path.join(self.history_data_path, f"{self.mode}_pre_data.pkl")
            if os.path.exists(history_data):
                with open(history_data, "rb") as f:
                    history_label_dict = pickle.load(f)
            else:
                print(f"No historical data found: {history_data}")
        else:
            print("Not using historical data")

        if history_label_dict is not None:
            if len(history_label_dict) > 0:
                print(f"use historical data: {history_data}")
                self._label_dict = history_label_dict
                return

        for key in datalist_dict:
            file_list = []
            with open(datalist_dict[key], "r") as f:
                lines = f.read().splitlines()
                file_list.extend(lines)
        # rm repeat
        lines = list(dict.fromkeys(file_list))
        lines.sort()
        print("data num: ", len(lines))

        img_list = []
        calib_list = []
        ann_list = []
        count = 0
        for line in tqdm(lines):
            filename = line.split("/")[-1]
            sub_folder_name = line.split("/")[-3]
            current_dataroot = line.rsplit('/', 3)[0]
            filename_end = filename.split(".")[-1]
            basename = filename[: -(len(filename_end) + 1)]
            imgname = basename

            img_dict = {}
            calib_dict = {}
            for cam in self.camera_names:
                cam_low = cam.split("_")[-1].lower()
                img_dir = f"camera/camera_surround_{cam_low}_image"
                if os.path.exists(os.path.join(current_dataroot, sub_folder_name, img_dir, imgname + ".jpg")):
                    img_path = os.path.join(current_dataroot, sub_folder_name, img_dir, imgname + ".jpg")
                elif os.path.exists(os.path.join(current_dataroot, sub_folder_name, img_dir, imgname + ".png")):
                    img_path = os.path.join(current_dataroot, sub_folder_name, img_dir, imgname + ".png")

                        
                img_dict[cam] = img_path
                calib_dict[cam] = self._get_calib(os.path.join(current_dataroot, sub_folder_name), cam)

            if len(img_dict.keys())!=4:
                continue
            ann_file = os.path.join(
                '/test_data/hans/freespace_more_data/', f"fss/{basename}.png"
            )

            img_list.append(img_dict)
            calib_list.append(calib_dict)
            ann_list.append(ann_file)

        self._label_dict = dict(
            img_list=img_list,
            calib_list=calib_list,
            ann_list=ann_list,
        )
        if history_label_dict is not None:
            with open(history_data, "wb") as f:
                pickle.dump(self._label_dict, f)

    def _get_calib(self, dataset_dir, cam):
        cam_calib_params = {}
        extrinsic_file = os.path.join(
            self.data_root, dataset_dir, "calib", CAMERA_PARAMS[cam][1]
        )
        intrinsic_file = os.path.join(
            self.data_root, dataset_dir, "calib", CAMERA_PARAMS[cam][0]
        )
        with open(extrinsic_file) as f:
            extrin_trans = yaml.load(f, Loader=yaml.SafeLoader)
            extrin_trans = extrin_trans["transform"]
            translation = extrin_trans["translation"]
            rotation = extrin_trans["rotation"]
            rot_CV = Quaternion(
                [rotation["w"], rotation["x"], rotation["y"], rotation["z"]]
            )
            trans_CV = np.array([translation["x"], translation["y"], translation["z"]])
        with open(intrinsic_file) as f:
            intrin_trans = yaml.load(f, Loader=yaml.SafeLoader)
            affine = np.array(intrin_trans["affine"])
            distortion_center = np.array(intrin_trans["distortion_center"])
            world2cam = np.array(intrin_trans["world2cam"])
        cam_calib_params["rot_CV"] = rot_CV
        cam_calib_params["trans_CV"] = trans_CV
        cam_calib_params["distortion_center"] = distortion_center
        cam_calib_params["affine"] = affine
        cam_calib_params["world2cam"] = world2cam
        return cam_calib_params

    def _get_ann(self, ann_file):
        ann_dict = {}
        ann_dict["filename"] = ann_file
        with open(os.path.join(ann_file)) as f:
            objects = json.load(f)["object"]
            for i, obj in enumerate(objects):
                ann_dict[str(i)] = {}
                ann_dict[str(i)]["category_name"] = obj["obj_type"]
                ann_dict[str(i)]["translation"] = [
                    obj["psr"]["position"]["x"],
                    obj["psr"]["position"]["y"],
                    obj["psr"]["position"]["z"],
                ]
                # ann_dict[str(i)]['rotation'] = (R.from_euler('z', obj['psr']['rotation']['z'])).as_matrix()
                ann_dict[str(i)]["rotation"] = self._euler_matrix(
                    obj["psr"]["rotation"]["z"], "z"
                )
                ann_dict[str(i)]["size"] = [
                    obj["psr"]["scale"]["y"],
                    obj["psr"]["scale"]["x"],
                    obj["psr"]["scale"]["z"],
                ]
        return ann_dict

    def _euler_matrix(self, radian, mode="z"):
        assert mode in ["x", "y", "z"], f"mode {mode} not in [x, y, z]"

        if mode == "x":
            M = [
                [1.0, 0.0, 0.0],
                [0.0, math.cos(radian), -math.sin(radian)],
                [0.0, math.sin(radian), math.cos(radian)],
            ]
        elif mode == "y":
            M = [
                [math.cos(radian), 0.0, math.sin(radian)],
                [0.0, 1.0, 0.0],
                [-math.sin(radian), 0, math.cos(radian)],
            ]
        else:
            M = [
                [math.cos(radian), -math.sin(radian), 0.0],
                [math.sin(radian), math.cos(radian), 0.0],
                [0.0, 0.0, 1.0],
            ]
        return np.array(M)

    def __len__(self):
        return self.len
