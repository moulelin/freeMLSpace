#include <stdlib.h>
#include <algorithm>
#include <assert.h>
#include <cmath>
#include <cuda_runtime_api.h>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <sys/stat.h>
#include <time.h>
// #include <string>
#include <string.h>
// #include <boost/algorithm/string.hpp>

#include "NvInfer.h"
#include "NvOnnxParser.h"
#include "EntropyCalibrator.h"

using namespace std;
using namespace nvinfer1;

class Logger : public nvinfer1::ILogger
{
public:
    Logger(Severity severity = Severity::kWARNING)
        : reportableSeverity(severity)
    {
    }

    void log(Severity severity, const char* msg) throw() override
    {
        // suppress messages with severity enum value greater than the reportable
        if (severity > reportableSeverity)
            return;

        switch (severity)
        {
        case Severity::kINTERNAL_ERROR: std::cerr << "INTERNAL_ERROR: "; break;
        case Severity::kERROR: std::cerr << "ERROR: "; break;
        case Severity::kWARNING: std::cerr << "WARNING: "; break;
        case Severity::kINFO: std::cerr << "INFO: "; break;
        default: std::cerr << "UNKNOWN: "; break;
        }
        std::cerr << msg << std::endl;
    }

    Severity reportableSeverity;
};

static Logger gLogger;

int get_stream_from_file(const char* filename, unsigned char* buf, size_t* size)
{
    FILE* fp = fopen(filename, "rb");
    if(fp == NULL)
    {
        printf("Can not open trt file\n");
        return -1;
    }else{
        fseek(fp,0L,SEEK_END); 
        *size = ftell(fp);
        fseek(fp,0L,SEEK_SET);
        int ret = fread(buf, 1, *size, fp);
        fclose(fp);
        return ret;
    }
}

void onnxToTRTModel(const char* modelFile, // name of the onnx model
                    unsigned int maxBatchSize,    // batch size - NB must be at least as large as the batch we want to run with
                    DataType dataType,
                    int useDLA,
                    IHostMemory*& trtModelStream, // output buffer for the TensorRT model
                    const char* dataDir,
                    const char* outTrtFile) 
{
    // int verbosity = (int) nvinfer1::ILogger::Severity::kWARNING;
    const auto explicitBatch = 1U << static_cast<uint32_t>(NetworkDefinitionCreationFlag::kEXPLICIT_BATCH);

    // create the builder
    IBuilder* builder = createInferBuilder(gLogger);
    nvinfer1::INetworkDefinition* network = builder->createNetworkV2(explicitBatch);
    auto config = builder->createBuilderConfig();

    auto parser = nvonnxparser::createParser(*network, gLogger);

    const int stream_size = 1000;//1000MB
    unsigned char* stream_buf;
    size_t size;
    stream_buf = (unsigned char*)calloc(stream_size*1024*1024, 1);
    if(stream_buf){
        get_stream_from_file(modelFile, stream_buf, &size);
    }else{
        printf("malloc stream space failed!\n");
        return ;
    }

    std::unique_ptr<IInt8Calibrator> calibrator; // for int8 calibration
    std::cout<<size<<std::endl;
    //if (!parser->parseFromFile(modelFile, verbosity))
    if (!parser->parse(stream_buf, size))
    {
        string msg("failed to parse onnx file");
        gLogger.log(nvinfer1::ILogger::Severity::kERROR, msg.c_str());
        exit(EXIT_FAILURE);
    }

    auto dims = network->getInput(0)->getDimensions();
    cout<<"Input shape: ";
    for(int i=0; i<dims.nbDims; i++)
    {
        cout<<dims.d[i]<<" ";
    }
    cout<<endl;
    maxBatchSize = dims.d[0];
    std::string networkName(modelFile);

    // Build the engine
    builder->setMaxBatchSize(maxBatchSize);
    config->setMaxWorkspaceSize(1 << 30);
    // config->setFlag(BuilderFlag::kGPU_FALLBACK);
    // config->setFlag(BuilderFlag::kSTRICT_TYPES);
    if (dataType == DataType::kHALF)
    {
        config->setFlag(BuilderFlag::kFP16);
    }
    if (dataType == DataType::kINT8)
    {
        config->setFlag(BuilderFlag::kINT8);
        BatchStream calibrationStream(1000, dims, dataDir);
        calibrator.reset(new Int8EntropyCalibrator2<BatchStream>(calibrationStream, 0, networkName.c_str()));
        config->setInt8Calibrator(calibrator.get());
    }

    if (useDLA > -1)
    {
        cout<<"DLA cores on this platform: "<<builder->getNbDLACores()<<endl;
        if (builder->getNbDLACores() == 0)
        {
            cout << "Trying to use DLA core " << useDLA << " on a platform that doesn't have any DLA cores"<< endl;
            return;
        }
        config->setFlag(BuilderFlag::kGPU_FALLBACK);
        // builder->setFp16Mode(true);
        // config->setFlag(BuilderFlag::kFP16);
        config->setDefaultDeviceType(DeviceType::kDLA);
        config->setDLACore(useDLA);
        config->setFlag(BuilderFlag::kSTRICT_TYPES);
    }

    // char *resize_name = "Resize";
    // for(int i=0; i<network->getNbLayers(); i++)
    // {
    //     nvinfer1::ILayer* layer = network->getLayer(i);
    //     // nvinfer1::LayerType layer_type = layer->getType();
    //     std::string layer_name = layer->getName();
    //     if (std::strstr(layer_name.c_str(), resize_name) != NULL)
    //     {
    //         // layer->setPrecision(DataType::kFLOAT);
    //         // layer->setOutputType(0, DataType::kFLOAT);
    //         layer->setInputType(0, DataType::kHALF);
    //         layer->setPrecision(DataType::kHALF);
    //         layer->setOutputType(0, DataType::kHALF);
    //         cout<<layer_name<<" ";
    //     }
    // }
    // cout<<endl;

    cout<<"start building engine!"<<endl;
    ICudaEngine* engine = builder->buildEngineWithConfig(*network, *config);
    assert(engine);
    cout<<"build engine finished!"<<endl;

    // serialize the engine, then close everything down
    trtModelStream = engine->serialize();
    FILE* fp = fopen(outTrtFile, "wb");
    fwrite(trtModelStream->data(), 1, trtModelStream->size(), fp);
    fclose(fp);

    engine->destroy();
    parser->destroy();
    network->destroy();
    builder->destroy();
    free(stream_buf);
}

void printHelpInfo()
{
    std::cout << "Usage: ./buildtrt [-h or --help] [--datadir=<path to data directory>] "
                 "[--useDLACore=<int>]"
              << std::endl;
    std::cout << "--help, -h      Display help information" << std::endl;
    std::cout << "--model=        Specify path to a ONNX model directory." << std::endl;
    std::cout << "--datadir       Specify path to a data directory, overriding the default. This option can be used "
                 "multiple times to add multiple directories."
              << std::endl;
    std::cout << "--useDLACore=N  Specify a DLA engine for layers that support DLA. Value can range from 0 to n-1, "
                 "where n is the number of DLA engines on the platform."
              << std::endl;
    std::cout << "--batch=N         Set batch size (default = 32)." << std::endl;
    std::cout << "--int8=N         Set int8 precision (default = float32)." << std::endl;
    std::cout << "--fp16=N         Set fp16 precision (default = float32)." << std::endl;
}

int main(int argc, char* argv[])
{
    if (argc >= 2 && (!strncmp(argv[1], "--help", 6) || !strncmp(argv[1], "-h", 2)))
    {
        printHelpInfo();
        return 0;
    }

    std::vector<std::string> dataTypeNames = {"FP32", "FP16", "INT8"};
    std::vector<DataType> dataTypes = {DataType::kFLOAT, DataType::kHALF, DataType::kINT8};

    int batch = 1;
    int dla = -1;
    int precision = 0;
    char* modelfile = NULL;
    char* datadir = NULL;
    char trtfile[128];
    char tail[128];
    memset(trtfile, 0, 128);
    memset(tail, 0, 128);
    // Parse extra arguments
    for (int i = 1; i < argc; ++i)
    {
        if (!strncmp(argv[i], "--batch=", 8))
        {
            batch = atoi(argv[i] + 8);
        }
        else if (!strncmp(argv[i], "--model=", 8))
        {
            modelfile = argv[i] + 8;
        }
        else if (!strncmp(argv[i], "--datadir=", 10))
        {
            datadir = argv[i] + 10;
        }
        else if (!strncmp(argv[i], "--int8=", 7))
        {
            if (atoi(argv[i] + 7))
                precision = 2;
                strcat(tail, "_int8");
        }
        else if (!strncmp(argv[i], "--fp16=", 7))
        {
            if (atoi(argv[i] + 7))
                precision = 1;
                strcat(tail, "_fp16");
        }
        else if (!strncmp(argv[i], "--useDLACore=", 13))
        {
            dla = atoi(argv[i] + 13);
            strcat(tail, "_dla");
        }
        else{
            cout<<"Unsupported input parameter: "<<argv[i]<<endl;
        }
    }
    if(precision == 0)
    {
        strcat(tail, "_fp32");
    }
    int len = strlen(modelfile);
    memcpy(trtfile, modelfile, len-5);
    strcat(tail, ".trt");
    strcat(trtfile, tail);
    // string trtfile(modelfile);
    // boost::replace_last(trtfile, ".onnx", ".trt");
    cout<<"Output model: "<<trtfile<<endl;
    cout<<"Use Precision: "<<dataTypeNames[precision]<<endl;
    cout<<"Use DLA core: "<<dla<<endl;

    IHostMemory* trtModelStream{nullptr};
    onnxToTRTModel(modelfile, batch, dataTypes[precision], dla, trtModelStream, datadir, trtfile);
    assert(trtModelStream != nullptr);

    return 0;
}