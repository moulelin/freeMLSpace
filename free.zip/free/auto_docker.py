import sys
import os


if __name__ == "__main__":
    ### login devops-harbor.zeekrlife.com
    login_cmd = "docker login devops-harbor.zeekrlife.com"
    os.system(login_cmd)

    ### generate docker
    build_docker_cmd = "docker build -t devops-harbor.zeekrlife.com/zeekr_automl/parking_automl:lidar ."
    os.system(build_docker_cmd)

    ### push docker
    push_docker_cmd = (
        "docker push devops-harbor.zeekrlife.com/zeekr_automl/parking_automl:lidar"
    )
    os.system(push_docker_cmd)
