import argparse
import os
import time
import torch
from pynvml import *
import psutil


K_NUM = 1024
M_NUM = 1048576
MAX_TIME = 604800  # 7 day


class Profiler:
    def __init__(self, num_gpus, log="./profile_log", disk_name=None):
        self._num_gpus = num_gpus
        nvmlInit()

        deviceCount = nvmlDeviceGetCount()
        assert (
            self._num_gpus == deviceCount
        ), f"input gpu num {self._num_gpus} != nvml gpu num {deviceCount}"

        self.log_path = log

        self._read_bytes = 0
        self._write_bytes = 0
        self._read_time = 0
        self._write_time = 0
        self._disk_name = disk_name

    def update_disk_io(self):
        if self._disk_name is None:
            disk_info = psutil.disk_io_counters()
        else:
            disk_info = psutil.disk_io_counters(perdisk=True)[self._disk_name]
        self._read_bytes = disk_info.read_bytes
        self._write_bytes = disk_info.write_bytes
        self._read_time = disk_info.read_time
        self._write_time = disk_info.write_time

    def add_io_profile(self):
        cur_time = time.time()
        if self._disk_name is None:
            disk_info = psutil.disk_io_counters()
        else:
            disk_info = psutil.disk_io_counters(perdisk=True)[self._disk_name]

        read_interval_time = disk_info.read_time - self._read_time
        write_interval_time = disk_info.write_time - self._write_time

        if read_interval_time == 0:
            read_speed = 0
        else:
            read_speed = (
                (disk_info.read_bytes - self._read_bytes)
                * 1.0
                / M_NUM
                * 1000
                / read_interval_time
            )

        if write_interval_time == 0:
            write_speed = 0
        else:
            write_speed = (
                (disk_info.write_bytes - self._write_bytes)
                * 1.0
                / M_NUM
                * 1000
                / write_interval_time
            )

        item = f"time:{cur_time} read_speed:{read_speed} write_speed:{write_speed}\n"

        with open(self.log_path, "a") as f:
            f.write(item)

    def add_gpu_profile(self):

        total_memory = 0
        total_free = 0
        total_used = 0
        total_util_rate = 0

        cur_time = time.time()

        for i in range(self._num_gpus):
            handle = nvmlDeviceGetHandleByIndex(i)
            info = nvmlDeviceGetMemoryInfo(handle)
            gpu_name = nvmlDeviceGetName(handle)
            util_rate = nvmlDeviceGetUtilizationRates(handle)

            total_memory += (info.total // M_NUM) / 1024
            total_free += (info.free // M_NUM) / 1024
            total_used += (info.used // M_NUM) / 1024
            total_util_rate += util_rate.gpu
        avg_memory_rate = total_used / total_memory * 100
        avg_util_rate = total_util_rate / self._num_gpus
        item = f"time:{cur_time} gpu_memory_rate:{avg_memory_rate} gpu_util_rate:{avg_util_rate}\n"

        with open(self.log_path, "a") as f:
            f.write(item)

    def add_node_profile(self, node_name, value="start"):
        cur_time = time.time()
        item = f"time:{cur_time} {node_name}:{value}\n"
        with open(self.log_path, "a") as f:
            f.write(item)


def get_parse():
    parser = argparse.ArgumentParser(description="Profiler")
    parser.add_argument(
        "--log", default="./profile_log", type=str, help="path to save_log"
    )
    parser.add_argument("--interval", default=1, type=int, help="interval time, second")
    return parser


if __name__ == "__main__":
    opt = get_parse().parse_args()

    ngpus = torch.cuda.device_count()
    gpu_profiler = Profiler(ngpus, log=opt.log)
    count = 0
    while True:
        gpu_profiler.add_gpu_profile()
        gpu_profiler.update_disk_io()
        time.sleep(opt.interval)
        gpu_profiler.add_io_profile()
        count += opt.interval
        if count > MAX_TIME:
            print("has processed 604800 seconds, 7days. stop save profile")
            break
