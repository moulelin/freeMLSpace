import os
import argparse
import cv2
from tabulate import tabulate

import torch
from torch.utils import data

from lib.datasets.dataset_factory import get_dataset
from lib.models.model_factory import create_model, creat_decoder
from lib.evaluate.evaluator_factory import create_evaluator
from lib.utils.common import (
    init_opt,
    get_scene_count_info,
    get_scene_infos_list_from_test_dict,
    english_to_chinese,
    train_id_to_name_map,
)
from tools.pth_infer import PTHModule
from tools.trt_infer import TRTModule
from tools.make_report import generate_doc
from tools.make_csv import generate_csv


@torch.no_grad()
def eval_model(opt, net, decoder, valset):

    loader_val = data.DataLoader(
        valset,
        batch_size=opt.val_batch,
        shuffle=False,
        num_workers=opt.workers,
        pin_memory=True,
        drop_last=True,
    )

    eval_func = create_evaluator(opt, decoder, valset)
    eval_results, scene_results = eval_func(net, loader_val)

    # center metric
    if "center" in eval_results:
        table_center_header = ["Class", "Precision", "Recall", "F1-score", "AP"]
        center_results = eval_results["center"]
        table_center_data = [
            (
                "Car",
                center_results["Precision"][0],
                center_results["Recall"][0],
                center_results["F1-score"][0],
                center_results["AP"][0],
            ),
            ("mAP: ", center_results["mAP"]),
            ("tp_offset: ", center_results["tp_offset"]),
        ]
        if "angle_diff" in center_results:
            table_center_data.append(("angle_diff: ", center_results["angle_diff"]))
        if "angle_acc" in center_results:
            table_center_data.append(("angle_acc: ", center_results["angle_acc"]))
        print(tabulate(table_center_data, headers=table_center_header, tablefmt="grid"))
        print("\n")

    # seg metric
    if "seg" in eval_results:
        table_iou_data = []
        table_iou_header = ["Class", "Iou"]
        seg_results = eval_results["seg"]

        train_id_map = train_id_to_name_map(valset.labels_info)
        opt.train_id_map = train_id_map
        for i in range(opt.n_cats):
            table_iou_data.append(
                [
                    train_id_map[i],
                    seg_results["ious"][i],
                ]
            )
        table_iou_data.append(["mIOU: ", seg_results["miou"]])
        print(tabulate(table_iou_data, headers=table_iou_header, tablefmt="grid"))

    # edge metric
    if "edge" in eval_results:
        print(
            ">>>>>>>>>>>>>>>>>> edge metric start <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
        )
        dist_heads = []
        for i in range(len(opt.grid_dists) + 1):
            if i == 0:
                dist_heads.append(f"<{opt.grid_dists[i]}")
                continue
            if i == len(opt.grid_dists):
                dist_heads.append(f">{opt.grid_dists[-1]}")
                continue
            dist_heads.append(f"{opt.grid_dists[i-1]}-{opt.grid_dists[i]}")
        print(dist_heads)

        edge_results = eval_results["edge"]
        train_id_map = train_id_to_name_map(valset.labels_info)
        opt.train_id_map = train_id_map

        table_edge_data = []
        table_edge_header = [
            "Class",
            "Precision",
            "Recall",
            "F1",
            "Diff_avg",
            "Diff_std",
        ]
        table_edge_data.append(["all dist"])

        for i in range(opt.n_cats):
            item = []
            item.append(train_id_map[i])
            item.extend(
                [
                    round(edge_results["Precision_all"][i][0], 4),
                    round(edge_results["Recall_all"][i][0], 4),
                    round(edge_results["F1_all"][i][0], 4),
                    round(edge_results["Diff_avg_all"][i][0], 4),
                    round(edge_results["Diff_std_all"][i][0], 4),
                ]
            )
            table_edge_data.append(item)
        print(tabulate(table_edge_data, headers=table_edge_header, tablefmt="grid"))

        for j, dist_head in enumerate(dist_heads):
            table_edge_data = []
            table_edge_data.append([dist_head])

            for i in range(opt.n_cats):
                item = []
                item.append(train_id_map[i])
                item.extend(
                    [
                        round(edge_results["Precision"][i][j], 4),
                        round(edge_results["Recall"][i][j], 4),
                        round(edge_results["F1"][i][j], 4),
                        round(edge_results["Diff_avg"][i][j], 4),
                        round(edge_results["Diff_std"][i][j], 4),
                    ]
                )
                table_edge_data.append(item)
            print(tabulate(table_edge_data, headers=table_edge_header, tablefmt="grid"))
        print(
            ">>>>>>>>>>>>>>>>>> edge metric end <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
        )

    # cls metric
    if "cls" in eval_results:
        table_cls_data = []
        table_cls_header = ["Class", "slot_num", "Precision", "Recall", "F1"]
        cls_results = eval_results["cls"]
        for i, cls_name in enumerate(opt.slot_type):
            table_cls_data.append(
                [
                    cls_name,
                    cls_results["slot_num"][i],
                    cls_results["Precision"][i],
                    cls_results["Recall"][i],
                    cls_results["F1"][i],
                ]
            )
        print(tabulate(table_cls_data, headers=table_cls_header, tablefmt="grid"))

    # offset metric
    if "offset" in eval_results:
        table_offset_data = []
        table_offset_header = ["point", "acc"]
        offset_results = eval_results["offset"]
        table_offset_data.append(["all", offset_results])
        print(tabulate(table_offset_data, headers=table_offset_header, tablefmt="grid"))

    # ws metric
    if "ws" in eval_results:
        table_ws_header = ["Precision", "Recall", "F1-score", "AP", "tp_offset"]
        ws_results = eval_results["ws"]
        table_ws_data = [
            (
                ws_results["Precision"][0],
                ws_results["Recall"][0],
                ws_results["F1-score"][0],
                ws_results["AP"][0],
                ws_results["tp_offset"],
            ),
        ]
        print("ws result: ")
        print(tabulate(table_ws_data, headers=table_ws_header, tablefmt="grid"))
        print("\n")

    # sp metric
    if "sp" in eval_results:
        table_sp_header = ["Precision", "Recall", "F1-score", "AP", "tp_offset"]
        sp_results = eval_results["sp"]
        table_sp_data = [
            (
                sp_results["Precision"][0],
                sp_results["Recall"][0],
                sp_results["F1-score"][0],
                sp_results["AP"][0],
                sp_results["tp_offset"],
            ),
        ]
        print("sp result: ")
        print(tabulate(table_sp_data, headers=table_sp_header, tablefmt="grid"))
        print("\n")

    # mid metric
    if "mid" in eval_results:
        table_mid_header = ["Precision", "Recall", "F1-score", "AP", "tp_offset"]
        mid_results = eval_results["mid"]
        table_mid_data = [
            (
                mid_results["Precision"][0],
                mid_results["Recall"][0],
                mid_results["F1-score"][0],
                mid_results["AP"][0],
                mid_results["tp_offset"],
            ),
        ]
        print("mid result: ")
        print(tabulate(table_mid_data, headers=table_mid_header, tablefmt="grid"))
        print("\n")

    # parking slot metric
    if "slot" in eval_results:
        table_slot_header = ["Class", "Precision", "Recall", "F1-score"]
        slot_results = eval_results["slot"]
        table_slot_data = [
            (
                "Only Slot",
                slot_results["Precision"][0],
                slot_results["Recall"][0],
                slot_results["F1-score"][0],
            ),
            (
                "With Status",
                slot_results["Precision"][1],
                slot_results["Recall"][1],
                slot_results["F1-score"][1],
            ),
            (
                "With Type",
                slot_results["Precision"][2],
                slot_results["Recall"][2],
                slot_results["F1-score"][2],
            ),
            (
                "With Status and Type",
                slot_results["Precision"][3],
                slot_results["Recall"][3],
                slot_results["F1-score"][3],
            ),
        ]
        print(tabulate(table_slot_data, headers=table_slot_header, tablefmt="grid"))
        print("\n")

    return eval_results, scene_results


def evaluate(opt):

    test_datasets = (
        eval(opt.test_datasets) if type(opt.test_datasets) == str else opt.test_datasets
    )

    if opt.scene:
        scene_infos_list = get_scene_infos_list_from_test_dict(
            opt.dataset_root, test_datasets, filter_keys=opt.filter_keys
        )
        scene_count_info = get_scene_count_info(
            scene_infos_list, filter_keys=opt.filter_keys
        )
    else:
        scene_infos_list = []
        scene_count_info = {}

    opt.scene_infos_list = scene_infos_list
    opt.onnx = 0

    torch.cuda.init()

    # creat decoder
    decoder = creat_decoder(opt)

    # creat dataset
    Dataset = get_dataset(opt.task)
    valset = Dataset(opt, "val")

    general_results = {}
    scene_results = {}
    model_versions = list(opt.model_info.keys())
    for model_version in model_versions:
        # creat model
        if opt.model_info[model_version]["type"] == "trt":
            net = TRTModule(opt.model_info[model_version]["model_path"])
        elif opt.model_info[model_version]["type"] == "pth":
            net = PTHModule(opt.model_info[model_version]["model_path"], opt)

        opt.model_version = model_version
        single_general_results, single_scene_results = eval_model(
            opt, net, decoder, valset
        )
        print(single_scene_results.keys())
        single_general_results["model_path"] = opt.model_info[model_version][
            "model_path"
        ]

        torch.cuda.empty_cache()
        general_results[model_version] = single_general_results
        scene_results[model_version] = single_scene_results

    if not opt.scene:
        scene_results = None

    # filter
    filtered_scene_count_info = scene_count_info
    filtered_scene_results = scene_results
    # if "all" in test_datasets:
    #     filtered_scene_count_info = scene_count_info
    #     filtered_scene_results = scene_results
    # else:
    #     valid_scene_value_list = list(test_datasets.keys())
    #     valid_scene_value_list_ch = [english_to_chinese.get(value, value) for value in valid_scene_value_list]
    #     print(valid_scene_value_list, valid_scene_value_list_ch)

    #     valid_scene_value_set = set(valid_scene_value_list_ch)
    #     print("valid scene value: ", valid_scene_value_set)

    #     filtered_scene_count_info = {}
    #     for scene_name in scene_count_info:
    #         for scene_value in scene_count_info[scene_name]:
    #             if scene_value in valid_scene_value_set:
    #                 if scene_name not in filtered_scene_count_info:
    #                     filtered_scene_count_info[scene_name] = {}
    #                 filtered_scene_count_info[scene_name][scene_value] = scene_count_info[scene_name][scene_value]

    #     filtered_scene_results = {}
    #     for model_version in scene_results:
    #         filtered_scene_results[model_version] = {}
    #         for scene_name in scene_results[model_version]:
    #             for scene_value in scene_results[model_version][scene_name]:
    #                 if scene_value in valid_scene_value_set:
    #                     if scene_name not in filtered_scene_results[model_version]:
    #                         filtered_scene_results[model_version][scene_name] = {}
    #                     filtered_scene_results[model_version][scene_name][scene_value] = scene_results[model_version][scene_name][scene_value]

    # generate_doc(
    #     opt.report_path,
    #     test_datasets,
    #     general_results,
    #     filtered_scene_results,
    #     filtered_scene_count_info,
    #     opt,
    # )

    # generate_csv(
    #     opt.report_path,
    #     general_results,
    #     filtered_scene_results,
    #     filtered_scene_count_info,
    #     opt,
    # )


def get_model_infos(model_info_str):
    model_infos = {}
    tmp_infos = eval(model_info_str)
    for model_name in tmp_infos:
        model_infos[model_name] = {}
        model_infos[model_name]["model_path"] = tmp_infos[model_name]
        model_infos[model_name]["type"] = tmp_infos[model_name].split(".")[-1]
    return model_infos


def get_parse():
    parser = argparse.ArgumentParser(description="Parking PyTorch Test On Imgs For Vis")
    parser.add_argument("--config", default="", type=str, help="path to config")
    parser.add_argument("--model_info", default="", type=str, help="eval model infos")
    parser.add_argument(
        "--test_datasets", default="", type=str, help="str of dict: path to test txt"
    )
    parser.add_argument(
        "--dataset_root", default="", type=str, help="path to origin data"
    )
    parser.add_argument(
        "--preprocess_root", default="", type=str, help="path to preprocess data"
    )
    parser.add_argument(
        "--report_path", default="./debug/report", type=str, help="path to save report"
    )
    parser.add_argument("--scene", action="store_true", help="decode for onnx, trt")
    parser.add_argument("--is_badcase", default=0, type=int, help="is badcase")
    parser.add_argument(
        "--history_data", default="", type=str, help="path to history data"
    )
    return parser


if __name__ == "__main__":

    opt = get_parse().parse_args()
    init_opt(opt)
    opt.val_batch = 1
    opt.onnx = 1
    opt.filter_keys = ["unknown", "NULL", "特殊车位线", "严重磨损", "-", "unknow"]
    opt.badcase = opt.is_badcase
    print(opt)

    if not os.path.exists(opt.report_path):
        os.makedirs(opt.report_path)

    if opt.badcase:
        badcase_root = os.path.join(opt.report_path, "badcase")
        opt.badcase_root = badcase_root
        if not os.path.exists(opt.badcase_root):
            os.makedirs(opt.badcase_root)

    print(opt.model_info)
    model_info = get_model_infos(opt.model_info)
    opt.model_info = model_info
    print(opt.model_info)

    evaluate(opt)
