import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

from lib.models.common_opr.base_opr import ConvBNReLU, conv1x1, conv3x3
from lib.models.head.base_head import chan_infos


__all__ = ["hrnet16_lite", "hrnet18_lite", "hrnet32_lite", "hrnet48_lite"]


Cfgs = {
    "hrnet16_lite": {
        "FINAL_CONV_KERNEL": 1,
        "STAGE1": {
            "NUM_MODULES": 1,
            "NUM_BRANCHES": 1,
            "NUM_BLOCKS": [4],
            "NUM_CHANNELS": [32],
            "BLOCK": "BOTTLENECK",
            "FUSE_METHOD": "SUM",
        },
        "STAGE2": {
            "NUM_MODULES": 1,
            "NUM_BRANCHES": 2,
            "NUM_BLOCKS": [4, 4],
            "NUM_CHANNELS": [16, 32],
            "BLOCK": "BASIC",
            "FUSE_METHOD": "SUM",
        },
        "STAGE3": {
            "NUM_MODULES": 4,
            "NUM_BRANCHES": 3,
            "NUM_BLOCKS": [4, 4, 4],
            "NUM_CHANNELS": [16, 32, 64],
            "BLOCK": "BASIC",
            "FUSE_METHOD": "SUM",
        },
    },
    "hrnet18_lite": {
        "FINAL_CONV_KERNEL": 1,
        "STAGE1": {
            "NUM_MODULES": 1,
            "NUM_BRANCHES": 1,
            "NUM_BLOCKS": [4],
            "NUM_CHANNELS": [64],
            "BLOCK": "BOTTLENECK",
            "FUSE_METHOD": "SUM",
        },
        "STAGE2": {
            "NUM_MODULES": 1,
            "NUM_BRANCHES": 2,
            "NUM_BLOCKS": [4, 4],
            "NUM_CHANNELS": [18, 36],
            "BLOCK": "BASIC",
            "FUSE_METHOD": "SUM",
        },
        "STAGE3": {
            "NUM_MODULES": 4,
            "NUM_BRANCHES": 3,
            "NUM_BLOCKS": [4, 4, 4],
            "NUM_CHANNELS": [18, 36, 72],
            "BLOCK": "BASIC",
            "FUSE_METHOD": "SUM",
        },
    },
    "hrnet32_lite": {
        "FINAL_CONV_KERNEL": 1,
        "STAGE1": {
            "NUM_MODULES": 1,
            "NUM_BRANCHES": 1,
            "NUM_BLOCKS": [4],
            "NUM_CHANNELS": [64],
            "BLOCK": "BOTTLENECK",
            "FUSE_METHOD": "SUM",
        },
        "STAGE2": {
            "NUM_MODULES": 1,
            "NUM_BRANCHES": 2,
            "NUM_BLOCKS": [4, 4],
            "NUM_CHANNELS": [32, 64],
            "BLOCK": "BASIC",
            "FUSE_METHOD": "SUM",
        },
        "STAGE3": {
            "NUM_MODULES": 4,
            "NUM_BRANCHES": 3,
            "NUM_BLOCKS": [4, 4, 4],
            "NUM_CHANNELS": [32, 64, 128],
            "BLOCK": "BASIC",
            "FUSE_METHOD": "SUM",
        },
    },
    "hrnet48_lite": {
        "FINAL_CONV_KERNEL": 1,
        "STAGE1": {
            "NUM_MODULES": 1,
            "NUM_BRANCHES": 1,
            "NUM_BLOCKS": [4],
            "NUM_CHANNELS": [64],
            "BLOCK": "BOTTLENECK",
            "FUSE_METHOD": "SUM",
        },
        "STAGE2": {
            "NUM_MODULES": 1,
            "NUM_BRANCHES": 2,
            "NUM_BLOCKS": [4, 4],
            "NUM_CHANNELS": [48, 96],
            "BLOCK": "BASIC",
            "FUSE_METHOD": "SUM",
        },
        "STAGE3": {
            "NUM_MODULES": 4,
            "NUM_BRANCHES": 3,
            "NUM_BLOCKS": [4, 4, 4],
            "NUM_CHANNELS": [48, 96, 192],
            "BLOCK": "BASIC",
            "FUSE_METHOD": "SUM",
        },
    },
}


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(
        self,
        inplanes,
        planes,
        stride=1,
        downsample=None,
        groups=1,
        base_width=64,
        dilation=1,
        norm_layer=None,
    ):
        super(BasicBlock, self).__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        if groups != 1 or base_width != 64:
            raise ValueError("BasicBlock only supports groups=1 and base_width=64")
        if dilation > 1:
            raise NotImplementedError("Dilation > 1 not supported in BasicBlock")
        # Both self.conv1 and self.downsample layers downsample the input when stride != 1
        self.conv1 = conv3x3(inplanes, planes, stride)
        self.bn1 = norm_layer(planes)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = conv3x3(planes, planes)
        self.bn2 = norm_layer(planes)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)

        return out


class Bottleneck(nn.Module):

    expansion = 4

    def __init__(
        self,
        inplanes,
        planes,
        stride=1,
        downsample=None,
        groups=1,
        base_width=64,
        dilation=1,
        norm_layer=None,
    ):
        super(Bottleneck, self).__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        width = int(planes * (base_width / 64.0)) * groups
        # Both self.conv2 and self.downsample layers downsample the input when stride != 1
        self.conv1 = conv1x1(inplanes, width)
        self.bn1 = norm_layer(width)
        self.conv2 = conv3x3(width, width, stride, groups, dilation)
        self.bn2 = norm_layer(width)
        self.conv3 = conv1x1(width, planes * self.expansion)
        self.bn3 = norm_layer(planes * self.expansion)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)

        return out


class HighResolutionModule(nn.Module):
    def __init__(
        self,
        num_branches,
        blocks,
        num_blocks,
        num_inchannels,
        num_channels,
        fuse_method,
        multi_scale_output=True,
        norm_layer=None,
    ):
        super(HighResolutionModule, self).__init__()
        self._check_branches(
            num_branches, blocks, num_blocks, num_inchannels, num_channels
        )

        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        self.norm_layer = norm_layer

        self.num_inchannels = num_inchannels
        self.fuse_method = fuse_method
        self.num_branches = num_branches

        self.multi_scale_output = multi_scale_output

        self.branches = self._make_branches(
            num_branches, blocks, num_blocks, num_channels
        )
        self.fuse_layers = self._make_fuse_layers()
        self.upconv_layers = self._make_upconv_layers(num_channels)
        self.relu = nn.ReLU(inplace=True)

    def _check_branches(
        self, num_branches, blocks, num_blocks, num_inchannels, num_channels
    ):
        if num_branches != len(num_blocks):
            error_msg = "NUM_BRANCHES({}) <> NUM_BLOCKS({})".format(
                num_branches, len(num_blocks)
            )
            raise ValueError(error_msg)

        if num_branches != len(num_channels):
            error_msg = "NUM_BRANCHES({}) <> NUM_CHANNELS({})".format(
                num_branches, len(num_channels)
            )
            raise ValueError(error_msg)

        if num_branches != len(num_inchannels):
            error_msg = "NUM_BRANCHES({}) <> NUM_INCHANNELS({})".format(
                num_branches, len(num_inchannels)
            )
            raise ValueError(error_msg)

    def _make_one_branch(self, branch_index, block, num_blocks, num_channels, stride=1):
        downsample = None
        if (
            stride != 1
            or self.num_inchannels[branch_index]
            != num_channels[branch_index] * block.expansion
        ):
            downsample = nn.Sequential(
                nn.Conv2d(
                    self.num_inchannels[branch_index],
                    num_channels[branch_index] * block.expansion,
                    kernel_size=1,
                    stride=stride,
                    bias=False,
                ),
                self.norm_layer(num_channels[branch_index] * block.expansion),
            )

        layers = []
        layers.append(
            block(
                self.num_inchannels[branch_index],
                num_channels[branch_index],
                stride,
                downsample,
                norm_layer=self.norm_layer,
            )
        )
        self.num_inchannels[branch_index] = num_channels[branch_index] * block.expansion
        for i in range(1, num_blocks[branch_index]):
            layers.append(
                block(
                    self.num_inchannels[branch_index],
                    num_channels[branch_index],
                    norm_layer=self.norm_layer,
                )
            )

        return nn.Sequential(*layers)

    def _make_branches(self, num_branches, block, num_blocks, num_channels):
        branches = []

        for i in range(num_branches):
            branches.append(self._make_one_branch(i, block, num_blocks, num_channels))

        return nn.ModuleList(branches)

    def _make_fuse_layers(self):
        if self.num_branches == 1:
            return None

        num_branches = self.num_branches
        num_inchannels = self.num_inchannels
        fuse_layers = []
        for i in range(num_branches if self.multi_scale_output else 1):
            fuse_layer = []
            for j in range(num_branches):
                if j > i:
                    fuse_layer.append(
                        nn.Sequential(
                            nn.Conv2d(
                                num_inchannels[j],
                                num_inchannels[i],
                                1,
                                1,
                                0,
                                bias=False,
                            ),
                            self.norm_layer(num_inchannels[i]),
                        )
                    )
                elif j == i:
                    fuse_layer.append(None)
                else:
                    conv3x3s = []
                    for k in range(i - j):
                        if k == i - j - 1:
                            num_outchannels_conv3x3 = num_inchannels[i]
                            conv3x3s.append(
                                nn.Sequential(
                                    nn.Conv2d(
                                        num_inchannels[j],
                                        num_outchannels_conv3x3,
                                        3,
                                        2,
                                        1,
                                        bias=False,
                                    ),
                                    self.norm_layer(num_outchannels_conv3x3),
                                )
                            )
                        else:
                            num_outchannels_conv3x3 = num_inchannels[j]
                            conv3x3s.append(
                                nn.Sequential(
                                    nn.Conv2d(
                                        num_inchannels[j],
                                        num_outchannels_conv3x3,
                                        3,
                                        2,
                                        1,
                                        bias=False,
                                    ),
                                    self.norm_layer(num_outchannels_conv3x3),
                                    nn.ReLU(inplace=True),
                                )
                            )
                    fuse_layer.append(nn.Sequential(*conv3x3s))
            fuse_layers.append(nn.ModuleList(fuse_layer))

        return nn.ModuleList(fuse_layers)

    def _make_upconv_layers(self, num_channels):
        if self.num_branches == 1:
            return []
        upconv_layers = []
        for i in range(len(self.fuse_layers)):
            upconv_layer = [
                None,
            ]
            for j in range(1, self.num_branches):
                if i == j:
                    upconv_layer.append(None)
                elif j > i:
                    chan = num_channels[i]
                    stride = 2 * (j - i)
                    ksize = stride
                    # ksize = stride * 2
                    # padding = (ksize - stride) // 2
                    upconv = nn.ConvTranspose2d(
                        chan, chan, ksize, stride, 0, groups=1, bias=False
                    )
                    upconv_layer.append(upconv)
                else:
                    upconv_layer.append(None)
            upconv_layers.append(nn.ModuleList(upconv_layer))
        return nn.ModuleList(upconv_layers)

    def get_num_inchannels(self):
        return self.num_inchannels

    def forward(self, x):
        if self.num_branches == 1:
            return [self.branches[0](x[0])]

        for i in range(self.num_branches):
            x[i] = self.branches[i](x[i])

        x_fuse = []
        for i in range(len(self.fuse_layers)):
            y = x[0] if i == 0 else self.fuse_layers[i][0](x[0])
            for j in range(1, self.num_branches):
                if i == j:
                    y = y + x[j]
                elif j > i:
                    # width_output = x[i].shape[-1]
                    # height_output = x[i].shape[-2]
                    # width_in = self.fuse_layers[i][j](x[j]).shape[-1]
                    # height_in = self.fuse_layers[i][j](x[j]).shape[-2]

                    # scale_w = int(width_output / width_in)
                    # scale_h = int(height_output / height_in)
                    # assert (
                    #     scale_w == scale_h
                    # ), f"scale size not equal: input shape [{height_in}, {width_in}], output shape [{height_output}, {width_output}]"
                    # y = y + F.interpolate(
                    #     self.fuse_layers[i][j](x[j]),
                    #     scale_factor=scale_w,
                    #     mode="bilinear",
                    #     align_corners=False,
                    # )
                    y = y + self.upconv_layers[i][j](self.fuse_layers[i][j](x[j]))
                else:
                    y = y + self.fuse_layers[i][j](x[j])
            x_fuse.append(self.relu(y))

        return x_fuse


blocks_dict = {"BASIC": BasicBlock, "BOTTLENECK": Bottleneck}


class HighResolutionLiteNet(nn.Module):
    def __init__(
        self,
        opt,
        mode="train",
        norm_layer=None,
    ):
        super(HighResolutionLiteNet, self).__init__()

        self.mode = mode
        self.opt = opt
        self.name = self.opt.backbone

        cfg = Cfgs[opt.backbone]
        base_chan = chan_infos[opt.backbone]
        if "16" in opt.backbone:
            pre_chan = 32
        else:
            pre_chan = 64

        base_chan = chan_infos[opt.backbone]

        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        self.norm_layer = norm_layer
        # stem network
        # stem net
        self.conv1 = nn.Conv2d(
            opt.input_channel, pre_chan, kernel_size=3, stride=2, padding=1, bias=False
        )
        self.bn1 = self.norm_layer(pre_chan)
        self.conv2 = nn.Conv2d(
            pre_chan, pre_chan, kernel_size=3, stride=2, padding=1, bias=False
        )
        self.bn2 = self.norm_layer(pre_chan)
        self.relu = nn.ReLU(inplace=True)

        self.aux1 = nn.Conv2d(
            pre_chan, base_chan, kernel_size=1, stride=1, padding=0, bias=False
        )

        # stage 1
        self.stage1_cfg = cfg["STAGE1"]
        num_channels = self.stage1_cfg["NUM_CHANNELS"][0]
        block = blocks_dict[self.stage1_cfg["BLOCK"]]
        num_blocks = self.stage1_cfg["NUM_BLOCKS"][0]
        self.layer1 = self._make_layer(
            block, pre_chan, num_channels, num_blocks, stride=2
        )
        stage1_out_channel = block.expansion * num_channels

        # stage 2
        self.stage2_cfg = cfg["STAGE2"]
        num_channels = self.stage2_cfg["NUM_CHANNELS"]
        block = blocks_dict[self.stage2_cfg["BLOCK"]]
        num_channels = [
            num_channels[i] * block.expansion for i in range(len(num_channels))
        ]
        self.transition1 = self._make_transition_layer(
            [stage1_out_channel], num_channels
        )
        self.stage2, pre_stage_channels = self._make_stage(
            self.stage2_cfg, num_channels
        )

        # stage 3
        self.stage3_cfg = cfg["STAGE3"]
        num_channels = self.stage3_cfg["NUM_CHANNELS"]
        block = blocks_dict[self.stage3_cfg["BLOCK"]]
        num_channels = [
            num_channels[i] * block.expansion for i in range(len(num_channels))
        ]
        self.transition2 = self._make_transition_layer(pre_stage_channels, num_channels)
        self.stage3, pre_stage_channels = self._make_stage(
            self.stage3_cfg, num_channels
        )

        pre_stage_channels.insert(0, base_chan)
        last_inp_channels = np.int(np.sum(pre_stage_channels))
        print("last_inp_channels: ", last_inp_channels, pre_stage_channels)

        self.down0 = nn.Conv2d(
            pre_stage_channels[0],
            pre_stage_channels[0],
            3,
            2,
            1,
            groups=pre_stage_channels[0],
            bias=False,
        )
        self.up2 = nn.ConvTranspose2d(
            pre_stage_channels[2], pre_stage_channels[2], 2, 2, 0, groups=1, bias=False
        )
        self.up3 = nn.ConvTranspose2d(
            pre_stage_channels[3], pre_stage_channels[3], 4, 4, 0, groups=1, bias=False
        )

        # x2
        self.up1_2 = nn.ConvTranspose2d(
            pre_stage_channels[1], pre_stage_channels[1], 2, 2, 0, groups=1, bias=False
        )
        self.up2_2 = nn.ConvTranspose2d(
            pre_stage_channels[2], pre_stage_channels[2], 4, 4, 0, groups=1, bias=False
        )
        self.up3_2 = nn.ConvTranspose2d(
            pre_stage_channels[3], pre_stage_channels[3], 8, 8, 0, groups=1, bias=False
        )

        out_chan = last_inp_channels
        print("out_chan: ", out_chan)
        self.fuse_conv = ConvBNReLU(last_inp_channels, out_chan, 3, 1, 1)
        self.fuse_conv2 = ConvBNReLU(last_inp_channels, out_chan, 3, 1, 1)

        self.init_weights()

    def init_weights(self):
        for name, module in self.named_modules():
            if isinstance(module, (nn.Conv2d, nn.Linear)):
                nn.init.kaiming_normal_(module.weight, mode="fan_out")
            elif isinstance(module, nn.modules.batchnorm._BatchNorm):
                if hasattr(module, "last_bn") and module.last_bn:
                    nn.init.zeros_(module.weight)
                else:
                    nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)
        self.load_pretrain()

    def load_pretrain(self):
        if self.opt.backbone_pretrain_path:
            print("load backbone pretrain model: ", self.opt.backbone_pretrain_path)
            state_dict = torch.load(self.opt.backbone_pretrain_path, map_location="cpu")

            self.load_state_dict(state_dict, strict=False)
            print("finished load")
        else:
            print("no backbone pretrain model!!!")

    def _make_transition_layer(self, num_channels_pre_layer, num_channels_cur_layer):
        num_branches_cur = len(num_channels_cur_layer)
        num_branches_pre = len(num_channels_pre_layer)

        transition_layers = []
        for i in range(num_branches_cur):
            if i < num_branches_pre:
                if num_channels_cur_layer[i] != num_channels_pre_layer[i]:
                    transition_layers.append(
                        nn.Sequential(
                            nn.Conv2d(
                                num_channels_pre_layer[i],
                                num_channels_cur_layer[i],
                                3,
                                1,
                                1,
                                bias=False,
                            ),
                            self.norm_layer(num_channels_cur_layer[i]),
                            nn.ReLU(inplace=True),
                        )
                    )
                else:
                    transition_layers.append(None)
            else:
                conv3x3s = []
                for j in range(i + 1 - num_branches_pre):
                    inchannels = num_channels_pre_layer[-1]
                    outchannels = (
                        num_channels_cur_layer[i]
                        if j == i - num_branches_pre
                        else inchannels
                    )
                    conv3x3s.append(
                        nn.Sequential(
                            nn.Conv2d(inchannels, outchannels, 3, 2, 1, bias=False),
                            self.norm_layer(outchannels),
                            nn.ReLU(inplace=True),
                        )
                    )
                transition_layers.append(nn.Sequential(*conv3x3s))

        return nn.ModuleList(transition_layers)

    def _make_layer(self, block, inplanes, planes, blocks, stride=1):
        downsample = None
        if stride != 1 or inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(
                    inplanes,
                    planes * block.expansion,
                    kernel_size=1,
                    stride=stride,
                    bias=False,
                ),
                self.norm_layer(planes * block.expansion),
            )

        layers = []
        layers.append(
            block(inplanes, planes, stride, downsample, norm_layer=self.norm_layer)
        )
        inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(inplanes, planes, norm_layer=self.norm_layer))

        return nn.Sequential(*layers)

    def _make_stage(self, layer_config, num_inchannels, multi_scale_output=True):
        num_modules = layer_config["NUM_MODULES"]
        num_branches = layer_config["NUM_BRANCHES"]
        num_blocks = layer_config["NUM_BLOCKS"]
        num_channels = layer_config["NUM_CHANNELS"]
        block = blocks_dict[layer_config["BLOCK"]]
        fuse_method = layer_config["FUSE_METHOD"]

        modules = []
        for i in range(num_modules):
            # multi_scale_output is only used last module
            if not multi_scale_output and i == num_modules - 1:
                reset_multi_scale_output = False
            else:
                reset_multi_scale_output = True

            modules.append(
                HighResolutionModule(
                    num_branches,
                    block,
                    num_blocks,
                    num_inchannels,
                    num_channels,
                    fuse_method,
                    reset_multi_scale_output,
                    norm_layer=self.norm_layer,
                )
            )
            num_inchannels = modules[-1].get_num_inchannels()

        return nn.Sequential(*modules), num_inchannels

    def _get_fuse(self, x_list):
        # Upsampling
        # x1_h, x1_w = x_list[1].size(2), x_list[1].size(3)
        # x0 = F.interpolate(
        #     x_list[0], scale_factor=0.5, mode="bilinear", align_corners=False
        # )
        # x2 = F.interpolate(
        #     x_list[2], scale_factor=2, mode="bilinear", align_corners=False
        # )
        # x3 = F.interpolate(
        #     x_list[3], scale_factor=4, mode="bilinear", align_corners=False
        # )

        x0 = self.down0(x_list[0])
        x2 = self.up2(x_list[2])
        x3 = self.up3(x_list[3])

        x = torch.cat([x0, x_list[1], x2, x3], 1)
        x = self.fuse_conv(x)
        return x

    def _get_fuse2(self, x_list):

        x1 = self.up1_2(x_list[1])
        x2 = self.up2_2(x_list[2])
        x3 = self.up3_2(x_list[3])

        x = torch.cat([x_list[0], x1, x2, x3], 1)
        x = self.fuse_conv2(x)
        return x

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)

        x = self.conv2(x)
        x = self.bn2(x)
        x = self.relu(x)

        aux1 = self.aux1(x)

        x = self.layer1(x)

        x_list = []
        for i in range(self.stage2_cfg["NUM_BRANCHES"]):
            if self.transition1[i] is not None:
                x_list.append(self.transition1[i](x))
            else:
                x_list.append(x)
        y_list = self.stage2(x_list)

        x_list = []
        for i in range(self.stage3_cfg["NUM_BRANCHES"]):
            if self.transition2[i] is not None:
                if i < self.stage2_cfg["NUM_BRANCHES"]:
                    x_list.append(self.transition2[i](y_list[i]))
                else:
                    x_list.append(self.transition2[i](y_list[-1]))
            else:
                x_list.append(y_list[i])
        y_list = self.stage3(x_list)

        y_list.insert(0, aux1)

        x_fuse = self._get_fuse(y_list)
        x_fuse2 = self._get_fuse2(y_list)

        return {
            "feat": x_fuse,
            "feat2": y_list[0],
            "feat3": y_list[1],
            "feat4": y_list[2],
            "feat5": y_list[3],
            "featx2": x_fuse2,
        }
