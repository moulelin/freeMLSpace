import numpy as np
import os
import yaml
import math


class SphericalProjection:
    def __init__(self, proj_w, proj_h, fov_up, fov_down, ignore_label):
        self.proj_w = proj_w
        self.proj_h = proj_h
        self.fov_up = fov_up
        self.fov_down = fov_down
        self.ignore_label = ignore_label

    def reset(self):
        # projected grid_range image - [H, W] grid_range (-1 is no data)
        self.proj_grid_range = np.full((self.proj_h, self.proj_w), -1, dtype=np.float32)

        # unprojected grid_range (list of depths for each point)
        self.unproj_grid_range = np.zeros((0, 1), dtype=np.float32)

        # projected point cloud xyz - [H,W,3] xyz coord (-1 is no data)
        self.proj_xyz = np.full((self.proj_h, self.proj_w, 3), -1, dtype=np.float32)

        # projected remission - [H,W] intensity (-1 is no data)
        self.proj_remission = np.full((self.proj_h, self.proj_w), -1, dtype=np.float32)

        # projected index (for each pixel, what I am in the pointcloud)
        # [H,W] index (-1 is no data)
        self.proj_idx = np.full((self.proj_h, self.proj_w), -1, dtype=np.int32)

        # projection label with semantic labels
        self.proj_label = np.zeros(
            (self.proj_h, self.proj_w), dtype=np.int32
        )  # [H,W]  label

        # inverse
        self.proj_y = None
        self.proj_x = None
        self.indices = None

    def make_point_projection(self, points, remissions):
        """Project a pointcloud into a spherical projection image.projection.
        Function takes no arguments because it can be also called externally
        if the value of the constructor was not set (in case you change your
        mind about wanting the projection)
        """
        # laser parameters
        fov_up = self.fov_up / 180.0 * np.pi  # field of view up in rad
        fov_down = self.fov_down / 180.0 * np.pi  # field of view down in rad
        fov = abs(fov_down) + abs(fov_up)  # get field of view total in rad

        # get depth of all points
        depth = np.linalg.norm(points, 2, axis=1)

        # get scan components
        scan_x = points[:, 0]
        scan_y = points[:, 1]
        scan_z = points[:, 2]

        # get angles of all points
        yaw = -np.arctan2(scan_y, scan_x)
        pitch = np.arcsin(scan_z / depth)

        # get projections in image coords  按弧度比例归一化算的点
        proj_x = 0.5 * (yaw / np.pi + 1.0)  # in [0.0, 1.0]
        proj_y = 1.0 - (pitch + abs(fov_down)) / fov  # in [0.0, 1.0]

        # scale to image size using angular resolution  实际投影到图片上的点
        proj_x *= self.proj_w  # in [0.0, W]
        proj_y *= self.proj_h  # in [0.0, H]

        # round and clamp for use as index 超过图片的点就放图片边缘，所有图片点坐标向下取整
        proj_x = np.floor(proj_x)
        proj_x = np.minimum(self.proj_w - 1, proj_x)
        proj_x = np.maximum(0, proj_x).astype(np.int32)  # in [0,W-1]
        self.proj_x = np.copy(proj_x)  # store a copy in orig order  保存一份投影点

        proj_y = np.floor(proj_y)
        proj_y = np.minimum(self.proj_h - 1, proj_y)
        proj_y = np.maximum(0, proj_y).astype(np.int32)  # in [0,H-1]
        self.proj_y = np.copy(proj_y)  # stope a copy in original order

        # copy of depth in original order
        self.unproj_grid_range = np.copy(depth)  # 按原来顺序保存一份深度

        # order in decreasing depth
        indices = np.agrid_range(depth.shape[0])
        order = np.argsort(depth)[::-1]
        depth = depth[order]  # 按深度从小到大排序
        indices = indices[order]  # 重新排index
        points = points[order]
        remission = remissions[order]
        proj_y = proj_y[order]
        proj_x = proj_x[order]

        # assing to images
        self.proj_grid_range[proj_y, proj_x] = depth
        self.proj_xyz[proj_y, proj_x] = points
        self.proj_remission[proj_y, proj_x] = remission
        self.proj_idx[proj_y, proj_x] = indices

        # inverse params
        self.proj_y = proj_y
        self.proj_x = proj_x
        self.indices = indices

    def make_label_projection(self, labels):
        mask = self.proj_idx >= 0
        self.proj_label[mask] = labels[self.proj_idx[mask]]

    def run_no_label(self, points, remissions):
        self.reset()
        self.make_point_projection(points, remissions)
        proj_data = np.concatenate(
            [
                self.proj_grid_range.reshape(self.proj_h, self.proj_w, 1),
                self.proj_xyz.reshape(self.proj_h, self.proj_w, 3),
                self.proj_remission.reshape(self.proj_h, self.proj_w, 1),
            ],
            axis=2,
        )
        proj_masks = (self.proj_idx >= 0) * 1.0
        return proj_data, proj_masks

    def run(self, points, remissions, labels):
        self.reset()
        self.make_point_projection(points, remissions)
        self.make_label_projection(labels)
        ignore_masks = self.proj_idx < 0
        proj_masks = (self.proj_idx >= 0) * 1.0
        proj_data = np.concatenate(
            [
                self.proj_grid_range.reshape(self.proj_h, self.proj_w, 1),
                self.proj_xyz.reshape(self.proj_h, self.proj_w, 3),
                self.proj_remission.reshape(self.proj_h, self.proj_w, 1),
            ],
            axis=2,
        )
        proj_labels = self.proj_label
        proj_labels[ignore_masks] = self.ignore_label
        return proj_data, proj_labels, proj_masks

    def inverse_label(self, proj_labels):
        if self.proj_x is None or self.proj_y is None or self.indices is None:
            print("ERROR: Please run make_point_projection before inverse")
            exit()
        num_points = len(self.indices)
        labels = np.zeros((num_points,))
        labels[self.indices] = proj_labels[self.proj_y, self.proj_x]
        return labels


class FishEyeProjection:
    def __init__(self, cam, calib_path, grid_range, grid_interval):
        self.cam = cam
        self.calib_path = calib_path
        self.grid_range = grid_range
        self.grid_interval = grid_interval
        self.extrinsics = {}
        self.intrinsics = {}

        self.extrinsics_file = os.path.join(
            self.calib_path, f"camera_surround_{self.cam}_2_vehicle_extrinsics.yaml"
        )
        self.intrinsics_file = os.path.join(
            self.calib_path, f"camera_surround_{self.cam}_intrinsics.yaml"
        )

        with open(self.extrinsics_file, "r") as f:
            self.extrinsics = yaml.load(f.read(), Loader=yaml.FullLoader)["transform"]

        with open(self.intrinsics_file, "r") as f:
            self.intrinsics = yaml.load(f.read(), Loader=yaml.FullLoader)
        self._transpose_matrix()

    def _transpose_matrix(self):
        """
        input: parameters output:R T
        """
        ### orientation position
        rotation_quaternion = [
            self.extrinsics["rotation"]["w"],
            self.extrinsics["rotation"]["x"],
            self.extrinsics["rotation"]["y"],
            self.extrinsics["rotation"]["z"],
        ]
        position = [
            self.extrinsics["translation"]["x"],
            self.extrinsics["translation"]["y"],
            self.extrinsics["translation"]["z"],
        ]

        rotation_quaternion = np.array(rotation_quaternion)
        self.translation = np.array(position)
        self.rotation = self._quaternion_to_rotation_matrix(rotation_quaternion)

    def _quaternion_to_rotation_matrix(self, quat):
        q = np.array([quat[1], quat[2], quat[3], quat[0]])
        n = np.dot(q, q)
        if n < np.finfo(q.dtype).eps:
            return np.identity(4)
        q = q * np.sqrt(2.0 / n)
        q = np.outer(q, q)
        rot_matrix = np.array(
            [
                (
                    1.0 - q[1, 1] - q[2, 2],
                    q[0, 1] - q[2, 3],
                    q[0, 2] + q[1, 3],
                    0.0,
                ),
                (
                    q[0, 1] + q[2, 3],
                    1.0 - q[0, 0] - q[2, 2],
                    q[1, 2] - q[0, 3],
                    0.0,
                ),
                (
                    q[0, 2] - q[1, 3],
                    q[1, 2] + q[0, 3],
                    1.0 - q[0, 0] - q[1, 1],
                    0.0,
                ),
                (0.0, 0.0, 0.0, 1.0),
            ],
            dtype=np.float64,
        )
        return rot_matrix[:3, :3]

    def _get_world_grid(self):
        """
        coordination = [x,y,z=0]
        """
        x, y = (
            self.extrinsics["translation"]["x"],
            self.extrinsics["translation"]["y"],
        )

        if self.cam == "left":
            xx = np.linspace(
                x - self.grid_range,
                x + self.grid_range,
                2 * int(self.grid_range / self.grid_interval) + 1,
            )
            yy = np.linspace(
                y, y + self.grid_range, int(self.grid_range / self.grid_interval) + 1
            )
            zz = np.linspace(0, 0, 1)
        if self.cam == "right":
            xx = np.linspace(
                x - self.grid_range,
                x + self.grid_range,
                2 * int(self.grid_range / self.grid_interval) + 1,
            )
            yy = np.linspace(
                y, y - self.grid_range, int(self.grid_range / self.grid_interval) + 1
            )
            zz = np.linspace(0, 0, 1)
        if self.cam == "rear":
            xx = np.linspace(
                x, x - self.grid_range, int(self.grid_range / self.grid_interval) + 1
            )
            yy = np.linspace(
                y - self.grid_range,
                y + self.grid_range,
                2 * int(self.grid_range / self.grid_interval) + 1,
            )
            zz = np.linspace(0, 0, 1)
        if self.cam == "front":
            xx = np.linspace(
                x, x + self.grid_range, int(self.grid_range / self.grid_interval) + 1
            )
            yy = np.linspace(
                y - self.grid_range,
                y + self.grid_range,
                2 * int(self.grid_range / self.grid_interval) + 1,
            )
            zz = np.linspace(0, 0, 1)

        X, Y, Z = np.meshgrid(xx, yy, zz)
        world_grid = np.concatenate(
            (X[:, :, :, None], Y[:, :, :, None], Z[:, :, :, None]), axis=-1
        )
        return world_grid

    def convert_wc_to_cc(self, world_coords):
        """
        车体坐标系 -> 相机坐标系: R * (pt - T)
        :return:
        """
        joint_x, joint_y = world_coords.shape[0], world_coords.shape[1]
        # 车体坐标系 -> 相机坐标系
        # [R|t] world coords -> camera coords
        cam_coords = np.zeros((joint_x, joint_y, 1, 3))  # joint camera
        for i in range(joint_x):
            for j in range(joint_y):
                cam_coords[i][j][0] = np.dot(
                    np.linalg.inv(self.rotation),
                    world_coords[i][j][0] - self.translation,
                )
        return cam_coords

    def _camera2img(self, vector, w, a, d_c):
        """
        :param vector: [x,y,z] 相机坐标系下的点坐标
        :param world2cam: [843.854, 638.9589999999999, 82.1872, 40.3643, 55.6989, 29.1943, 1.025,
                   0.563098, 2.67324, 0.818169, 8.487979999864693e-314]
        :param a: affine: [1, -2.33105e-05, -2.64691e-05, 1]
        :param d_c: distortion_center: [954.056, 770.884]
        :return:  [ix, iy]
        """
        flag = -1 if w[1] > 0 else 1
        r = math.sqrt(vector[0] ** 2 + vector[1] ** 2)
        theta = math.atan2(flag * vector[2], r)
        thetad = 0.0
        for i in range(len(w) - 1, -1, -1):
            thetad = thetad * theta + w[i]

        nx = vector[0] / r * thetad
        ny = vector[1] / r * thetad

        ix = nx * a[0] + ny * a[1] + d_c[0]
        iy = nx * a[2] + ny + d_c[1]

        return [ix, iy]

    def convert_cc_to_ic(self, cam_coords):
        """
        :param vector:相机坐标系下的点的坐标集合
        :param intristic:相机的内参
        :return:
        """

        joint_cam_x, joint_cam_y = cam_coords.shape[0], cam_coords.shape[1]
        img_coords = np.zeros((joint_cam_x, joint_cam_y, 2))  # joint camera
        world2cam, affine, distortion_center = (
            self.intrinsics["world2cam"],
            self.intrinsics["affine"],
            self.intrinsics["distortion_center"],
        )
        for i in range(joint_cam_x):
            for j in range(joint_cam_y):
                coor = cam_coords[i][j][0]
                img_coords[i][j] = self._camera2img(
                    coor, world2cam, affine, distortion_center
                )
        return img_coords

    def get_img_grid(self):
        world_grid = self._get_world_grid()
        cam_grid = self.convert_wc_to_cc(world_grid)
        img_grid = self.convert_cc_to_ic(cam_grid)
        return img_grid
