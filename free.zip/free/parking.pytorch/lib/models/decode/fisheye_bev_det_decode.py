import torch
from torch import nn
import torch.nn.functional as F
import numpy as np
import pdb


class FishEyeBEVDetDecoder(object):
    def __init__(self, opt):
        self.opt = opt
        self.w_input = self.opt.w_input
        self.h_input = self.opt.h_input
        self.batch = self.opt.val_batch
        self.bev_w = int((opt.xbound[1] - opt.xbound[0]) / opt.xbound[-1])
        self.bev_h = int((opt.ybound[1] - opt.ybound[0]) / opt.ybound[-1])
        self.scale = opt.scale_bev
        self.bev_resolution = np.array([opt.xbound[-1], opt.ybound[-1], opt.zbound[-1]], dtype=np.float32)
        self.voxel_size = list(self.bev_resolution)
        self.pc_range = [opt.xbound[0], opt.ybound[0], opt.zbound[0],
        opt.xbound[1], opt.ybound[1], opt.zbound[1]]
        self.onnx = getattr(self.opt, "onnx", 0)

        self.decode_point_xy = self.make_points_anchor()

    def _nms(self, heat, kernel=3):
        pad = (kernel - 1) // 2
        hmax = nn.functional.max_pool2d(heat, (kernel, kernel), stride=1, padding=pad)
        keep = F.relu(heat - hmax + 0.001) * 1000
        return heat * keep

    def extract_truth_eval(self, center_truth, wlh_truth, yaw_truth):
        center_heatmap = center_truth[..., 0:1].reshape(self.batch, -1, 1)
        center_loc = center_truth[..., 1:3].reshape(self.batch, -1, 2)
        center_loc = center_loc + self.decode_point_xy
        center_loc[:, :, 0:1] = center_loc[:, :, 0:1] * self.scale * self.voxel_size[0] + self.pc_range[0]
        center_loc[:, :, 1:2] = center_loc[:, :, 1:2] * self.scale * self.voxel_size[1] + self.pc_range[1]
        center_truth = torch.cat([center_heatmap, center_loc], dim=2)
        wlh_truth = wlh_truth.reshape(self.batch, -1, 4)
        wlh_truth[:, :, 0] = wlh_truth[:, :, 0] * self.scale * self.voxel_size[0]
        wlh_truth[:, :, 1] = wlh_truth[:, :, 1] * self.scale * self.voxel_size[1]
        yaw_truth = yaw_truth.reshape(self.batch, -1, 2)
        return center_truth, wlh_truth, yaw_truth

    def extract_truth(self, truth):
        return truth

    def run(self, pred_dict):
        # seg_pred
        # seg_pred = seg_pred.argmax(dim=1)
        # seg_pred = seg_pred.permute(0, 2, 3, 1).contiguous().argmax(dim=3)
        # freespace_pred = freespace_pred.permute(0, 2, 3, 1).contiguous().argmax(dim=3)
        box3d_pred = []
        
        for task_id in range(len(pred_dict)):
            # heatmap = pred_dict[task_id][0]['heatmap'].sigmoid()
            # point_heatmap = self._nms(heatmap)
            # point_heatmap = point_heatmap.permute(0, 2, 3, 1).contiguous().reshape(1, -1, 1)

            heatmap1 = pred_dict[task_id][0]['heatmap1'].sigmoid()
            point_heatmap1 = self._nms(heatmap1)
            point_heatmap1 = point_heatmap1.permute(0, 2, 3, 1).contiguous().reshape(1, -1, 1)

            heatmap2 = pred_dict[task_id][0]['heatmap2'].sigmoid()
            point_heatmap2 = self._nms(heatmap2)
            point_heatmap2 = point_heatmap2.permute(0, 2, 3, 1).contiguous().reshape(1, -1, 1)

            heatmap3 = pred_dict[task_id][0]['heatmap3'].sigmoid()
            point_heatmap3 = self._nms(heatmap3)
            point_heatmap3 = point_heatmap3.permute(0, 2, 3, 1).contiguous().reshape(1, -1, 1)

            # # loc
            # reg = pred_dict[task_id][0]['reg'].sigmoid()
            # point_loc = reg.permute(0, 2, 3, 1).contiguous().reshape(1, -1, 2)
            # point_loc = point_loc + self.decode_point_xy
            # point_loc[:, :, 0] = point_loc[:, :, 0] * self.scale * self.voxel_size[0] + self.pc_range[0]
            # point_loc[:, :, 1] = point_loc[:, :, 1] * self.scale * self.voxel_size[1] + self.pc_range[1]

            # loc1
            reg1 = pred_dict[task_id][0]['reg1'].sigmoid()
            point_loc1 = reg1.permute(0, 2, 3, 1).contiguous().reshape(1, -1, 2)
            point_loc1 = point_loc1 + self.decode_point_xy
            point_loc1[:, :, 0] = point_loc1[:, :, 0] * self.scale * self.voxel_size[0] + self.pc_range[0]
            point_loc1[:, :, 1] = point_loc1[:, :, 1] * self.scale * self.voxel_size[1] + self.pc_range[1]

            # loc2
            reg2 = pred_dict[task_id][0]['reg2'].sigmoid()
            point_loc2 = reg2.permute(0, 2, 3, 1).contiguous().reshape(1, -1, 2)
            point_loc2 = point_loc2 + self.decode_point_xy
            point_loc2[:, :, 0] = point_loc2[:, :, 0] * self.scale * self.voxel_size[0] + self.pc_range[0]
            point_loc2[:, :, 1] = point_loc2[:, :, 1] * self.scale * self.voxel_size[1] + self.pc_range[1]

            # loc3
            reg3 = pred_dict[task_id][0]['reg3'].sigmoid()
            point_loc3 = reg3.permute(0, 2, 3, 1).contiguous().reshape(1, -1, 2)
            point_loc3 = point_loc3 + self.decode_point_xy
            point_loc3[:, :, 0] = point_loc3[:, :, 0] * self.scale * self.voxel_size[0] + self.pc_range[0]
            point_loc3[:, :, 1] = point_loc3[:, :, 1] * self.scale * self.voxel_size[1] + self.pc_range[1]

            # # rot
            # rot = 2 * pred_dict[task_id][0]['rot'].sigmoid() - 1
            # # rot_sine = rot[:, 0:1, :, :]
            # # rot_cosine = rot[:, 1:2, :, :]
            # # rot = torch.atan2(rot_sine, rot_cosine)
            # # point_rot = rot.permute(0, 2, 3, 1).contiguous().reshape(1, -1, 1)
            # point_rot = rot.permute(0, 2, 3, 1).contiguous().reshape(1, -1, 2)

            # # height
            # height = pred_dict[task_id][0]['height']
            # point_height = height.permute(0, 2, 3, 1).contiguous().reshape(1, -1, 1)

            # dim
            dim = pred_dict[task_id][0]['dim']
            dim[:, 0, :, :] = dim[:, 0, :, :] * self.voxel_size[1] * self.scale
            dim[:, 1, :, :] = dim[:, 1, :, :] * self.voxel_size[0] * self.scale
            point_dim = dim.permute(0, 2, 3, 1).contiguous().reshape(1, -1, 2)

            # dim1
            dim1 = pred_dict[task_id][0]['dim1']
            dim1[:, 0, :, :] = dim1[:, 0, :, :] * self.voxel_size[1] * self.scale
            dim1[:, 1, :, :] = dim1[:, 1, :, :] * self.voxel_size[0] * self.scale
            point_dim1 = dim1.permute(0, 2, 3, 1).contiguous().reshape(1, -1, 2) 

            # _, idx_point = torch.topk(point_heatmap[:, :, 0], 64, dim=1)
            _, idx_point1 = torch.topk(point_heatmap1[:, :, 0], 64, dim=1)
            _, idx_point2 = torch.topk(point_heatmap2[:, :, 0], 64, dim=1)
            _, idx_point3 = torch.topk(point_heatmap3[:, :, 0], 64, dim=1)
            # pts_prob = point_heatmap[0, :, :].index_select(0, idx_point[0, :])
            pts_prob1 = point_heatmap1[0, :, :].index_select(0, idx_point1[0, :])
            pts_prob2 = point_heatmap2[0, :, :].index_select(0, idx_point2[0, :])
            pts_prob3 = point_heatmap3[0, :, :].index_select(0, idx_point3[0, :])
            # pts_loc = point_loc[0, :, :].index_select(0, idx_point[0, :])
            pts_loc1 = point_loc1[0, :, :].index_select(0, idx_point1[0, :])
            pts_loc2 = point_loc2[0, :, :].index_select(0, idx_point2[0, :])
            pts_loc3 = point_loc3[0, :, :].index_select(0, idx_point3[0, :])
            # pts_yaw = point_rot[0, :, :].index_select(0, idx_point[0, :])
            pts_dim = point_dim[0, :, :].index_select(0, idx_point1[0, :])
            pts_dim1 = point_dim1[0, :, :].index_select(0, idx_point1[0, :])
            # pts_height = point_height[0, :, :].index_select(0, idx_point[0, :])

            points = torch.cat([pts_prob1.unsqueeze(0), pts_prob2.unsqueeze(0), pts_prob3.unsqueeze(0), 
                                pts_loc1.unsqueeze(0), pts_loc2.unsqueeze(0),pts_loc3.unsqueeze(0), 
                                pts_dim.unsqueeze(0), pts_dim1.unsqueeze(0)], dim=2)
            box3d_pred.append(points)           
        if not self.onnx:
            return box3d_pred
        else:
            return box3d_pred

    def make_points_anchor(self):
        w_output = self.bev_w // self.scale
        h_output = self.bev_h // self.scale
        ys, xs = torch.meshgrid(torch.arange(h_output), torch.arange(w_output))
        xys = torch.stack([xs, ys], dim=2).float().view(1, -1, 2)        
        decode_point_xy = xys.repeat(1, 1, 1).float().cuda()
        return decode_point_xy
