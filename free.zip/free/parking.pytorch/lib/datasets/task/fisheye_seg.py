import numpy as np
from PIL import Image
import os
import math

import torch

import lib.datasets.transform.common_transform as T
import lib.datasets.transform.fisheye_transform as FT
from lib.utils.vis_util import *
from lib.datasets.dataset.fisheye import FishEyeDataset
from lib.datasets.utils.projections import FishEyeProjection


ogm_map = np.zeros((256,))
ogm_idxs = [4, 5, 6, 7, 9, 10, 11, 12, 14, 17, 19, 20, 21]
ignore_idxs = [15, 23]
for i in ogm_idxs:
    ogm_map[i] = 1
for i in ignore_idxs:
    ogm_map[i] = 255
ogm_map[255] = 255

invert_cls_ids = [9, 12, 17, 19]  # pre ogm map, car,person,cone,enclosure

camera_names = ["front", "left", "right", "rear"]

FREE_SPACE_ID = 25
EGO_CAR_ID = 24


def get_edge(img):
    x = cv2.Sobel(img, cv2.CV_16S, 1, 0)
    y = cv2.Sobel(img, cv2.CV_16S, 0, 1)

    absX = cv2.convertScaleAbs(x)  # 转回uint8
    absY = cv2.convertScaleAbs(y)

    dst = cv2.addWeighted(absX, 0.5, absY, 0.5, 0)
    dst = dst.max(axis=2)
    return dst


class FishEyeSegDataset(FishEyeDataset):
    def __init__(self, opt, mode):
        super(FishEyeSegDataset, self).__init__(opt, mode)
        self.size = (self.opt.h_input, self.opt.w_input)
        if self.mode == "train":
            self.transform = T.Compose(
                [
                    # T.RandomResizedCrop(0.5, (0.9, 1.1), self.size),
                    T.RandomAffine(0.3, self.size, degrees=15, fill_value=EGO_CAR_ID),
                    T.RandomHorizontalFlip(0.5),
                    # T.RandomVerticalFlip(0.5),
                    T.ColorJitter(0.5, 0.5, 0.5, 0.5, 0.5),
                    T.GaussianNoise(0.2, 0, 0.1),
                    T.AddBlur(0.1, "all"),
                    T.ToTensor(),
                ]
            )
            self.add_reflective = FT.AddReflective(0.2, 10, 80)
            self.add_obj_invert = FT.AddObjInvert(0.2, invert_cls_ids, FREE_SPACE_ID)
            self.add_ego_invert = FT.AddEgoInvert(0.2, EGO_CAR_ID)
        else:
            self.transform = T.Compose([T.Resize(self.size), T.ToTensor()])

    def __getitem__(self, index):
        image_path, resize_image_path, label_path = (
            self.label_dict["image_list"][index],
            self.label_dict["resize_image_list"][index],
            self.label_dict["label_seg_list"][index],
        )
        image, label_seg = Image.open(resize_image_path), Image.open(label_path)

        if self.mode == "train":
            image = np.array(image)
            label_seg = np.array(label_seg)

            image = self.add_reflective(image)
            image = self.add_obj_invert(image, label_seg)
            # image = self._convert_freespace(image, label_seg, 0.05)
            # image, label_seg = self._copy_and_paste(image, label_seg, 0.05)
            image = self.add_ego_invert(image, label_seg)

            image = Image.fromarray(image.astype("uint8"))
            label_seg = Image.fromarray(label_seg.astype("uint8"))

        im_lb = dict(im=image, lb_seg=label_seg)
        im_lb = self.transform(im_lb)

        ori_label_seg = np.array(im_lb["lb_seg"]).astype("int32")
        label_seg = self.label_map[ori_label_seg]
        label_seg = torch.from_numpy(label_seg).long()

        # ogm_seg = ogm_map[ori_label_seg]
        # freespace_seg = self.get_freespace(ogm_seg)
        # label_seg[freespace_seg == 1] = 9
        # label_seg[freespace_seg == self.opt.ignore_label] = self.opt.ignore_label

        img = (im_lb["im"].numpy().transpose(1, 2, 0) * 255).astype("uint8")
        edge = get_edge(img)
        mask = torch.from_numpy(edge / 255.0)

        image = im_lb["im"]
        if self.mode == "train":
            if np.random.rand() < 0.3:
                np_image = image.numpy()[::-1, :, :]
                image = torch.from_numpy(np.ascontiguousarray(np_image))

        image, label = image, dict(
            label_seg=label_seg,
            mask=mask,
            # freespace_seg=freespace_seg,
        )
        return image, label

    def verify(self, index):
        image, label = self.__getitem__(index)
        image = tensor_to_image(image)
        label_seg = label["label_seg"].squeeze(0).numpy()
        # freespace_seg = label["freespace_seg"].squeeze(0).numpy()
        # print(freespace_seg.shape)
        # freespace_seg = palette[freespace_seg]

        # if "mask" in label:
        #     mask = label["mask"].squeeze(0).numpy()
        #     cv2.imshow("mask", mask)

        label_seg = palette[label_seg]
        combined_img = np.hstack([image, label_seg])

        # num_cls = self.opt.n_cats
        # color_map = np.zeros((num_cls * 20, 100, 3))
        # for i in range(num_cls):
        #     color_map[i * 20:(i + 1) * 20, :, :] = palette[i, :].reshape(1, -1)
        # color_map = color_map.astype("uint8")
        # cv2.imshow("color_map", color_map)

        return combined_img
        cv2.imshow("combined_img", combined_img)
        cv2.waitKey(0)

    def get_grid(self, index):
        image_path = self.label_dict["image_list"][index]

        dataset_dir = os.path.dirname(image_path)
        img_name = os.path.basename(image_path)
        calib_dir = dataset_dir[:-5] + "calib"
        cur_cam = None
        for camera_name in camera_names:
            if camera_name in img_name:
                cur_cam = camera_name
                break

        if cur_cam is None:
            return None
        if not os.path.exists(calib_dir):
            return None

        fisheye_proj = FishEyeProjection(
            cur_cam, calib_dir, self.opt.grid_range, self.opt.grid_interval
        )
        img_grid = fisheye_proj.get_img_grid()

        scale_w = self.opt.w_input / 1920
        scale_h = self.opt.h_input / 1536
        img_grid[:, :, 0] = img_grid[:, :, 0] * scale_w
        img_grid[:, :, 1] = img_grid[:, :, 1] * scale_h
        return img_grid
