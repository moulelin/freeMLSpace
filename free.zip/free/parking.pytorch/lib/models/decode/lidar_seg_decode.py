import torch
from torch import nn
import torch.nn.functional as F


class LidarSegDecoder(object):
    def __init__(self, opt):
        self.opt = opt
        self.w_input = self.opt.w_input
        self.h_input = self.opt.h_input
        self.batch = self.opt.val_batch
        self.onnx = getattr(self.opt, "onnx", 0)

    def extract_truth(self, seg_truth):
        return seg_truth

    def run(self, seg_pred):
        # seg_pred
        # seg_pred = seg_pred.argmax(dim=1)
        seg_pred = seg_pred.permute(0, 2, 3, 1).contiguous().argmax(dim=3)

        if not self.onnx:
            return seg_pred
        else:
            return seg_pred
