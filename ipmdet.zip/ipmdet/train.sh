#!/bin/bash

exp_id=$1

git diff > git_diff.txt
current_git_branch_latest_id=`git rev-parse HEAD`
current_git_branch_latest_short_id=`git rev-parse --short HEAD`

CUDA_VISIBLE_DEVICES=0 python train.py --exp_id ${exp_id}_${current_git_branch_latest_short_id}