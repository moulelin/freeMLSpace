import time
import os
from tqdm import tqdm
import numpy as np
import torch
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.tensorboard import SummaryWriter

from lib.optimizer.optim import make_optimizer
from lib.optimizer.scheduler import make_scheduler


class Trainer(object):
    def __init__(
        self,
        net,
        trainLoader,
        valLoader,
        criterion,
        opt,
        rank,
        decoder,
        optimizer=None,
        profiler=None,
    ):
        self.base_net = net
        self.netname = self.base_net.name
        self.loader_train = trainLoader
        self.epoch_iter = len(self.loader_train)
        self.loader_val = valLoader
        self.criterion = criterion
        self.opt = opt
        self.rank = rank
        self.n_iter = 0
        self.start_epoch = 0
        self.last_epoch = -1
        self.max_epoch = self.opt.maxepoch
        self.decoder = decoder
        self.num_classes = self.opt.n_cats
        self.ignore_label = self.opt.ignore_label
        self._infer_buffer = self._get_infer_buffer()
        self.results = {}
        self.profiler = profiler

        if self.rank == 0:
            if not os.path.isdir(self.opt.ckpt_output):
                os.makedirs(self.opt.ckpt_output)
            if not os.path.isdir(self.opt.log_output):
                os.makedirs(self.opt.log_output)

            save_dir = os.path.join(self.opt.log_output, self.netname)
            i = 0
            while os.path.exists(save_dir):
                save_dir = os.path.join(self.opt.log_output, self.netname + "_%02d" % i)
                i += 1
            self.writer = SummaryWriter(save_dir)

            with open(self.opt.result_output, "w") as f:
                f.write("step;total_loss;result;miou\n")

        self.optimizer = make_optimizer(self.base_net, self.opt)
        if self.opt.resume != "":
            self.resume_train()
        self.opt.last_epoch = self.last_epoch
        self.opt.max_iter = self.max_epoch * self.epoch_iter
        self.opt.warmup_iter = self.opt.warmup_iter
        self.scheduler = make_scheduler(self.optimizer, self.opt)

        self.min_loss = 1e5
        self.net = DDP(self.base_net, device_ids=[rank])
        # self.net = DDP(self.base_net, device_ids=[rank], find_unused_parameters=True)

    def run(self):
        for epoch in range(self.start_epoch, self.max_epoch):
            if self.rank == 0:
                print("\n  Start Training Epoch: %03d/%03d" % (epoch, self.max_epoch))
            t0 = time.time()
            # Train
            loss_train = self.train_epoch(epoch)
            # val
            loss_val, average_miou = self.validate_epoch(epoch)

            # Check and save model
            self.save_checkpoint(epoch, loss_val)
            t1 = time.time()
            if self.rank == 0:
                print(
                    "train_loss: {}, val_loss: {}, average_miou: {}".format(
                        loss_train, loss_val, average_miou
                    )
                )
                self.writer.add_scalars(
                    "Loss/train-val",
                    {"train_loss": loss_train, "val_loss": loss_val},
                    epoch,
                )
                with open(self.opt.result_output, "a") as f:
                    f.write(f"{epoch};{loss_train};{loss_val};{average_miou}\n")
            print("one training epoch time: ", t1 - t0)
        print("Training completed")

    def train_epoch(self, epoch):
        self.net.train()
        # 在不同epoch下输入数据不同
        self.loader_train.sampler.set_epoch(epoch)

        loss_train = 0.0

        if self.opt.profile and self.rank == 0:
            self.profiler.add_node_profile("train_iter", "start")
        pbar = tqdm(enumerate(self.loader_train), total=len(self.loader_train))
        if self.opt.profile and self.rank == 0:
            self.profiler.add_node_profile("train_iter", "end")

        if self.opt.profile and self.rank == 0:
            self.profiler.add_node_profile("train_epoch", "start")
        for i, batch in pbar:
            if self.opt.profile and self.rank == 0 and i == 0:
                self.profiler.add_node_profile("first_batch", "start")

            self.optimizer.zero_grad()

            data, truth = self.sample_to_cuda(batch)
            if self.opt.profile and self.rank == 0 and i == 0:
                self.profiler.add_node_profile("begin_infer", "start")

            pred = self.net(data)
            loss, loss_tags = self.criterion(pred, truth)

            loss *= self.opt.worldsize
            loss.backward()
            self.optimizer.step()

            if self.rank == 0 and (self.n_iter % 30 == 0):
                for k in loss_tags.keys():
                    self.writer.add_scalar("Loss/%s" % k, loss_tags[k], self.n_iter)
            loss_train += loss_tags["loss"]
            # record lr
            if self.rank == 0:
                self.writer.add_scalar(
                    "learning_rate", self.scheduler.get_lr()[0], self.n_iter
                )
            # Take a scheduler step
            self.scheduler.step()
            self.n_iter += 1
        if self.opt.profile and self.rank == 0:
            self.profiler.add_node_profile("train_epoch", "end")

        return loss_train / (i + 1)

    def validate_epoch(self, epoch):
        self.net.eval()

        self.loader_val.sampler.set_epoch(epoch)

        loss_val = 0.0

        if self.opt.profile and self.rank == 0:
            self.profiler.add_node_profile("val_iter", "start")
        pbar = tqdm(enumerate(self.loader_val), total=len(self.loader_val))
        if self.opt.profile and self.rank == 0:
            self.profiler.add_node_profile("val_iter", "end")

        num = 0
        miou_sum = 0

        if self.opt.profile and self.rank == 0:
            self.profiler.add_node_profile("val_epoch", "start")
        for i, batch in pbar:
            data, truth = self.sample_to_cuda(batch)
            with torch.no_grad():
                pred = self.net(data)
                loss, loss_tags = self.criterion(pred, truth)
                # if type(pred).__name__ == "dict":
                #     seg_pred = pred["logits"]
                # else:
                #     seg_pred = None
                #     for idx in range(len(pred)):
                #         if type(pred[idx]) == dict:
                #             seg_pred = pred[idx]["logits"]
                #             break
                # seg_pred = torch.argmax(seg_pred, dim=1)  # N x 800 x 800
                # seg_truth = truth["label_seg"]  # N x 800 x 800
                # for k in range(len(seg_pred)):
                #     sample_seg_pred = seg_pred[k]
                #     sample_seg_truth = seg_truth[k]
                #     self._eval_seg(sample_seg_truth, sample_seg_pred)
                #     miou = self.generate_seg_results()
                #     num += 1
                #     miou_sum += miou
                loss_val += loss_tags["loss"]
        if self.opt.profile and self.rank == 0:
            self.profiler.add_node_profile("val_epoch", "end")

        average_miou = 0
        return loss_val / (i + 1), average_miou

    def sample_to_cuda(self, data):
        if isinstance(data, str):
            return data
        elif isinstance(data, dict):
            return {key: self.sample_to_cuda(data[key]) for key in data.keys()}
        elif isinstance(data, list):
            return [self.sample_to_cuda(val) for val in data]
        else:
            return data.cuda(self.rank)

    def save_checkpoint(self, epoch, loss_val):
        if self.rank == 0:
            print("Saving weights...")
            net_dict = self.net.module.state_dict()
            state = {
                "net": net_dict,
                "loss": loss_val,
                "iter": self.n_iter,
                "epoch": epoch,
                "last_epoch": self.scheduler.last_epoch,
                "optimizer": self.optimizer.state_dict(),
                "opt": self.opt,
            }
            if (epoch + 1) % (self.max_epoch // 20) == 0:
                torch.save(
                    state,
                    os.path.join(
                        self.opt.ckpt_output, "%s-%03d.pth" % (self.netname, epoch)
                    ),
                )
            if loss_val < self.min_loss:
                torch.save(
                    state,
                    os.path.join(self.opt.ckpt_output, "%s-best.pth" % (self.netname)),
                )
                self.min_loss = loss_val
            torch.save(
                state,
                os.path.join(self.opt.ckpt_output, "%s-backup.pth" % (self.netname)),
            )

    def resume_train(self):
        pth = torch.load(self.opt.resume, map_location="cpu")
        self.base_net.load_state_dict(pth["net"])
        self.optimizer.load_state_dict(pth["optimizer"])
        self.start_epoch = pth["epoch"] + 1
        self.n_iter = pth["iter"]
        self.last_epoch = pth["last_epoch"]

    def _calc_miou(self, hist):
        ious = hist.diag() / (hist.sum(dim=0) + hist.sum(dim=1) - hist.diag() + 1e-6)
        miou = np.nanmean(ious.detach().cpu().cpu().numpy())
        return ious.cpu().numpy(), miou.item()

    def _get_infer_buffer(self):
        buffer = {}
        buffer["hist"] = torch.zeros(self.num_classes, self.num_classes).cuda()
        return buffer

    def generate_seg_results(self):
        hist = self._infer_buffer["hist"]
        ious, miou = self._calc_miou(hist)

        self.results["seg"] = {
            "ious": ious,
            "miou": miou,
        }

        return self.results["seg"]["miou"]

    def _eval_seg(self, label, pred):
        keep = label != self.ignore_label
        self._infer_buffer["hist"] += (
            torch.bincount(
                label[keep] * self.num_classes + pred[keep],
                minlength=self.num_classes**2,
            )
            .view(self.num_classes, self.num_classes)
            .cuda(0)
        )
