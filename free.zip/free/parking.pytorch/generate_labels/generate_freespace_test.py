import argparse
import os
import time
import random
import numpy as np
import re
import open3d as o3d
import matplotlib.pyplot as plt
from PIL import Image
from tqdm import tqdm

color_map = np.array(
    [
        [0, 0, 0, 255], 
        [255, 0, 255, 255],    # 1  driveable_surface     dark pink
        [255, 120, 50, 255],   # 2  barrier               orange
        [0, 150, 245, 255],    # 3  car                   blue
        [255, 0, 255, 255],    # 4  driveable_surface     dark pink
        [255, 192, 203, 255],  # 5  bicycle               pink
        [0, 150, 245, 255],    # 6  car                   blue
        [0, 255, 255, 255],    # 7  construction_vehicle  cyan
        [200, 180, 0, 255],    # 8  motorcycle            dark orange
        [255, 0, 0, 255],      # 9  pedestrian            red
        [255, 240, 150, 255],  # 10 traffic_cone          light yellow
        [135, 60, 0, 255],     # 11 trailer               brown
        [150, 240, 80, 255],   # 12 terrain               light green
        [220, 0, 220, 255],    # 13 truck                 purple
        [255, 255, 0, 255],    # 14 bus                   yellow
        [175, 0, 75, 255],     # 15 other_flat            dark red
        [75, 0, 75, 255],      # 16 sidewalk              dark purple
        [230, 230, 250, 255],  # 17 man-made              white
        [0, 175, 0, 255],      # 18 vegetation            green
        [139, 137, 137, 255],  # 19 obstacle              grey
    ]
)

# todo: put them in configs
x_min, x_max, y_min, y_max = -15, 15, -15, 15
grid_size = 0.1


parser = argparse.ArgumentParser(description="Generate BEVFreespace Label")
parser.add_argument("--datadir", default='/test_data/hans/freespace_more_data/', type=str, help="path to data folder")
parser.add_argument("--rege", required=True, type=str, help="y/n, whether to regenerate datalist")
args = parser.parse_args()


def split_files(folder_path, train_ratio=0.9):
    file_paths = []
    for sub_folder_name in os.listdir(folder_path):
        sub_folder_path = os.path.join(folder_path, sub_folder_name)
        pcd_folder_path = sub_folder_path + '/pcd'
        for root, dirs, files in os.walk(pcd_folder_path):
            for file in files:
                sub_file_path = os.path.join(root, file)
                file_paths.append(sub_file_path)

    file_paths = sorted(file_paths, key=lambda s: float(re.findall(r'\d+\.\d+', s)[0]))
    file_paths = sorted(file_paths, key=lambda s: s.split('parking')[1])
    write_to_file(file_paths, os.path.join(folder_path, 'all_data.txt'))
    random.shuffle(file_paths)
    split_index = int(len(file_paths) * train_ratio)

    train_file_paths = file_paths[:split_index]
    val_file_paths = file_paths[split_index:]
    val_file_paths = sorted(val_file_paths, key=lambda s: float(re.findall(r'\d+\.\d+', s)[0]))
    val_file_paths = sorted(val_file_paths, key=lambda s: s.split('parking')[1])

    write_to_file(train_file_paths, os.path.join(folder_path, 'train.txt'))
    write_to_file(val_file_paths, os.path.join(folder_path, 'val.txt'))

    return file_paths

def write_to_file(file_paths, file_name):
    with open(file_name, 'w') as f:
        for file_path in file_paths:
            f.write(file_path + '\n')

# generate data split
folder_path = args.datadir
if args.rege == 'y':
    # split_files(folder_path)
    with open(os.path.join(folder_path, 'all_data.txt'), 'r') as f:
        lines = f.readlines()[-2000:]

    lines = [line.split(',')[0]+'\n' for line in lines]

    # random.shuffle(lines)
    lines.sort()
    val_lines = lines[:int(len(lines)*0.1)]
    train_lines = lines[int(len(lines)*0.1):]

    with open(os.path.join(folder_path, 'train_val.txt'), 'w') as f:
        f.writelines(lines)

    with open(os.path.join(folder_path, 'val.txt'), 'w') as f:
        f.writelines(val_lines)

    with open(os.path.join(folder_path, 'train.txt'), 'w') as f:
        f.writelines(train_lines)
    
    print('data split DONE')


# generate labels
file_path = args.datadir + 'train_val.txt'
# progress_file_path = args.datadir + 'progress.txt'

with open(file_path, 'r') as file:
        lines = file.readlines()

start_line = 0

line_count = len(lines)
for i in tqdm(range(start_line, line_count)):
    pcd_file = lines[i].strip()
    pcd = o3d.io.read_point_cloud(pcd_file)
    # delete points higher than 2m, lower than ground, and self around
    nppoints = np.asarray(pcd.points)
    nppoints[nppoints[:,2] > 2.0] = np.nan
    delete_mask = (nppoints[:,0] < 4.5) & (nppoints[:,0] > -2.0) & (np.abs(nppoints[:,1]) < 1.2)
    nppoints[delete_mask] = np.nan
    nppoints = nppoints[~np.isnan(nppoints).any(axis=1)]  # remove nan points
    pcd.points = o3d.utility.Vector3dVector(nppoints)

    semantics = [0] * len(pcd.points)
    for k in range(len(pcd.points)):
        if pcd.points[k][2] <= 0.15:  # find ground
            semantics[k] = 1
            pcd.points[k][2] = 0.0
        else:
            semantics[k] = 18  # obstacle
    color = color_map[semantics] / 255.0
    pcd.colors = o3d.utility.Vector3dVector(color[..., :3].reshape(-1, 3))

    for m in range(len(pcd.points)):  # flatten to BEV
        if pcd.points[m][2] != 0.0:
            pcd.points[m][2] = 0.0

    # range mask
    points = np.asarray(pcd.points)
    colors = np.asarray(pcd.colors)
    mask = np.logical_and(
        np.logical_and(points[:, 0] >= x_min, points[:, 0] <= x_max),
        np.logical_and(points[:, 1] >= y_min, points[:, 1] <= y_max),
    )
    filtered_points = points[mask]
    filtered_colors = colors[mask]
    # # visualize pcd
    # filtered_pcd = o3d.geometry.PointCloud()
    # filtered_pcd.points = o3d.utility.Vector3dVector(filtered_points)
    # filtered_pcd.colors = o3d.utility.Vector3dVector(filtered_colors)
    # # o3d.visualization.draw_geometries([filtered_pcd], width=900, height=900)
    # o3d.io.write_point_cloud(args.datadir + f'ply/{i + 1}.ply', filtered_pcd)

    # generate grid
    rows = int((y_max - y_min) / grid_size)
    cols = int((x_max - x_min) / grid_size)

    grid = np.zeros((rows, cols), dtype=np.uint8)
    for n in range(len(filtered_points)):
        x, y, label = filtered_points[n][0], filtered_points[n][1], filtered_colors[n]
        # point's coordinate in grid
        row = int((y - y_min) / grid_size)
        col = int((x - x_min) / grid_size)
        if 0 <= row < rows and 0 <= col < cols:
            if label[1] == 0:  # if ground
                grid[col, row] = 1
            elif label[0] == 0:  # if obstacle
                grid[col, row] = 2

    # generate radial label
    # right
    grid_process = np.zeros((rows, cols), dtype=np.uint8)
    for angle in range(0, 720, 1):
        radian = np.deg2rad(angle/4)
        dx = np.cos(radian) * 0.06
        dy = np.sin(radian) * 0.06
        x, y = 3.90643, 0
        first_ground = False
        first_obstacle  = False
        while x_min < x < x_max and y_min < y < y_max:
            row = int((y - y_min) / grid_size)
            col = int((x - x_min) / grid_size)
            if grid[col][row] == 1:  # ground
                first_ground = True
            elif grid[col][row] == 2:  # obstacle
                first_obstacle = True      
            if first_ground == True and first_obstacle == False:
                grid_process[col][row] = 1  # mark as ground
            elif first_ground == True and first_obstacle == True:
                grid_process[col][row] = 2  # mark as obstacle
            x = x + dx
            y = y + dy

    # rear
    for angle in range(360, 1080, 1):
        radian = np.deg2rad(angle/4)
        dx = np.cos(radian) * 0.06
        dy = np.sin(radian) * 0.06
        x, y = -1.039624, 0
        first_ground = False
        first_obstacle  = False
        while x_min < x < x_max and y_min < y < y_max:
            row = int((y - y_min) / grid_size)
            col = int((x - x_min) / grid_size)
            if grid[col][row] == 1:  # ground
                first_ground = True
            elif grid[col][row] == 2:  # obstacle
                first_obstacle = True      
            if first_ground == True and first_obstacle == False:
                grid_process[col][row] = 1  # mark as ground
            elif first_ground == True and first_obstacle == True and grid[col][row] != 2 and grid_process[col][row] != 1:
                grid_process[col][row] = 2  # mark as obstacle
            elif first_ground == True and first_obstacle == True and grid[col][row] != 2 and grid_process[col][row] == 1:
                grid_process[col][row] = 1
            elif first_ground == True and first_obstacle == True and grid[col][row] == 2:
                grid_process[col][row] = 2
            x = x + dx
            y = y + dy

    # front
    for angle in range(0, 360, 1):
        radian = np.deg2rad(angle/4)
        dx = np.cos(radian) * 0.06
        dy = np.sin(radian) * 0.06
        x, y = 2.16, 1.08
        first_ground = False
        first_obstacle  = False
        while x_min < x < x_max and y_min < y < y_max:
            row = int((y - y_min) / grid_size)
            col = int((x - x_min) / grid_size)
            if grid[col][row] == 1:  # ground
                first_ground = True
            elif grid[col][row] == 2:  # obstacle
                first_obstacle = True      
            if first_ground == True and first_obstacle == False:
                grid_process[col][row] = 1  # mark as ground
            elif first_ground == True and first_obstacle == True and grid[col][row] != 2 and grid_process[col][row] != 1:
                grid_process[col][row] = 2  # mark as obstacle
            elif first_ground == True and first_obstacle == True and grid[col][row] != 2 and grid_process[col][row] == 1:
                grid_process[col][row] = 1
            elif first_ground == True and first_obstacle == True and grid[col][row] == 2:
                grid_process[col][row] = 2
            x = x + dx
            y = y + dy
    for angle in range(1080, 1440, 1):
        radian = np.deg2rad(angle/4)
        dx = np.cos(radian) * 0.06
        dy = np.sin(radian) * 0.06
        x, y = 2.16, 1.08
        first_ground = False
        first_obstacle  = False
        while x_min < x < x_max and y_min < y < y_max:
            row = int((y - y_min) / grid_size)
            col = int((x - x_min) / grid_size)
            if grid[col][row] == 1:  # ground
                first_ground = True
            elif grid[col][row] == 2:  # obstacle
                first_obstacle = True      
            if first_ground == True and first_obstacle == False:
                grid_process[col][row] = 1  # mark as ground
            elif first_ground == True and first_obstacle == True and grid[col][row] != 2 and grid_process[col][row] != 1:
                grid_process[col][row] = 2  # mark as obstacle
            elif first_ground == True and first_obstacle == True and grid[col][row] != 2 and grid_process[col][row] == 1:
                grid_process[col][row] = 1
            elif first_ground == True and first_obstacle == True and grid[col][row] == 2:
                grid_process[col][row] = 2
            x = x + dx
            y = y + dy

    # left
    for angle in range(720, 1440, 1):
        radian = np.deg2rad(angle/4)
        dx = np.cos(radian) * 0.06
        dy = np.sin(radian) * 0.06
        x, y = 2.16, -1.08
        first_ground = False
        first_obstacle  = False
        while x_min < x < x_max and y_min < y < y_max:
            row = int((y - y_min) / grid_size)
            col = int((x - x_min) / grid_size)
            if grid[col][row] == 1:  # ground
                first_ground = True
            elif grid[col][row] == 2:  # obstacle
                first_obstacle = True      
            if first_ground == True and first_obstacle == False:
                grid_process[col][row] = 1  # mark as ground
            elif first_ground == True and first_obstacle == True and grid[col][row] != 2 and grid_process[col][row] != 1:
                grid_process[col][row] = 2  # mark as obstacle
            elif first_ground == True and first_obstacle == True and grid[col][row] != 2 and grid_process[col][row] == 1:
                grid_process[col][row] = 1
            elif first_ground == True and first_obstacle == True and grid[col][row] == 2:
                grid_process[col][row] = 2
            x = x + dx
            y = y + dy

    # grid to image
    image_process = Image.fromarray(grid_process, mode='L')
    rotated_image = image_process.rotate(180)
    split_path = pcd_file.split("/")
    png_name = split_path[-1].replace(".pcd", ".png")
    label_folder_path = os.path.join(folder_path, 'fss/', png_name)
    if not os.path.exists(os.path.join(folder_path, 'fss/')):
      os.makedirs(os.path.join(folder_path, 'fss/'))
    rotated_image.save(label_folder_path, "PNG")


    # grid to image
    grid_vis = grid_process * 100
    image_process = Image.fromarray(grid_vis, mode='L')
    rotated_image = image_process.rotate(180)
    split_path = pcd_file.split("/")
    png_name = split_path[-1].replace(".pcd", ".png")
    label_folder_path = os.path.join(folder_path, 'vlabel/', png_name)
    if not os.path.exists(os.path.join(folder_path, 'vlabel/')):
      os.makedirs(os.path.join(folder_path, 'vlabel/'))
    rotated_image.save(label_folder_path, "PNG")

