import torch
from torch.utils import data
from model.parkingslotstatus import ParkingSlotStatusNet
from dataset.parkingslotstatus_dataset import ParkingSlotStatusDataset
import os
import numpy as np
from tqdm import tqdm
import argparse

parser = argparse.ArgumentParser(description='PyTorch ParkingSlotClsNet Testing')
parser.add_argument('--pth', default='checkpoint/ParkingSlotStatus-best.pth', type=str, help='model ckpt')
parser.add_argument('--W', default=64, type=int, help='input width')
parser.add_argument('--H', default=64, type=int, help='input height')
parser.add_argument('--onnx', default=0, type=int, help='output onnx')
parser.add_argument('--batch', default=32, type=int, help='batch size')
parser.add_argument('--datadir', default='', type=str, help='detection dataset dir')
parser.add_argument('--show', default=1, type=int, help='show result with image')
args = parser.parse_args()

status_names = ['occupied', 'empty']


def calc_precision(pred, truth, cls_num, names):
    precision = torch.zeros(cls_num)
    print('class name     precision   total_samples')
    for i in range(cls_num):
        mask = (truth == i)
        num_total = mask.sum()
        precision[i] = (pred[mask] == truth[mask]).sum().float() / num_total
        print('%12s' % names[i], '  %.4f' % (float(precision[i])), '     %5d' % (int(num_total)))


valset = ParkingSlotStatusDataset(args.datadir, args.W, args.H, mode='valid')
loader_val = data.DataLoader(valset, batch_size=args.batch, shuffle=0, num_workers=0, drop_last=True)

net = ParkingSlotStatusNet(args.W, args.H, status_num=2)
checkpoint = torch.load(args.pth)
net.load_state_dict(checkpoint['net'])
net = net.cuda().eval()
pbar = tqdm(enumerate(loader_val), total=len(loader_val))
status_pred_list = []
status_truth_list = []
for i, (image, truth) in pbar:
    image = image.cuda()
    pred = net(image)

    _, status_pred = torch.max(pred, dim=1)
    status_pred_list.append(status_pred.cpu())
    status_truth_list.append(truth.squeeze(1))

status_pred = torch.cat(status_pred_list, dim=0)
status_truth = torch.cat(status_truth_list, dim=0)
print('\n parking slot status precision:')
calc_precision(status_pred, status_truth, 2, status_names)


if args.onnx:
    dummy_input = torch.randn(1, 3, 64, 64, device='cuda')
    torch.onnx.export(net, dummy_input, "onnx/%s_%dx%d_bs%d.onnx" % ('ParkingSlotClsNet', 64, 64, 1), verbose=True,
                      opset_version=9)
