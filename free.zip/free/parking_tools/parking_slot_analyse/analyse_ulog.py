import matplotlib.pyplot as plt
import datetime
import argparse
import math
import re

parser = argparse.ArgumentParser(description='analyse parking_slot from ulog')
parser.add_argument('--log_file', default='', type=str, help='log path')
parser.add_argument('--slot_id', default=0, type=int, help='slot id')
parser.add_argument('--parking_only', default=0, type=int, help='draw slot curve line only when apa_state=parking')
opt = parser.parse_args()

apa_state = {"OFF": 0, "INITIAL": 1, "STANDBY": 2, "SEARCH": 3, "PREPARK": 4, "PARKING": 5}

class AnalyseUlog(object):
    def __init__(self, log_file, slot_id):
        self.log_file = log_file
        self.slot_id = slot_id
    
    def read_log(self):
        with open(self.log_file, 'r') as f:
            log = f.read()
        pattern_timestamp = re.compile('Timestamp: (\d+\.?\d*)')
        timestamp_list = pattern_timestamp.findall(log)
        pattern_slot = re.compile('Timestamp: (\d+\.?\d*) apa_state: (\d+\.?\d*) id: (\d+\.?\d*) track_c0_x: (-?\d+\.?\d*) track_c0_y: (-?\d+\.?\d*) track_c1_x: (-?\d+\.?\d*) track_c1_y: (-?\d+\.?\d*) det_c0_x: (-?\d+\.?\d*) det_c0_y: (-?\d+\.?\d*) det_c1_x: (-?\d+\.?\d*) det_c1_y: (-?\d+\.?\d*) track_slot_width: (\d+\.?\d*) detect_slot_width: (\d+\.?\d*) odom_theta: (-?\d+\.?\d*) detect_theta: (-?\d+\.?\d*) dis_ws: (\d+\.?\d*)')
        slot_list = pattern_slot.findall(log)
        slot_list = [slot for slot in slot_list if int(slot[2]) == self.slot_id]
        if opt.parking_only == 1:
          slot_list = [slot for slot in slot_list if int(slot[1]) == apa_state["PARKING"]]
        
        self.slot_timestamp = [datetime.datetime.fromtimestamp(float(slot[0])) for slot in slot_list]
        self.track_c0_x = [float(slot[3]) for slot in slot_list]
        self.track_c0_y = [float(slot[4]) for slot in slot_list]
        self.track_c1_x = [float(slot[5]) for slot in slot_list]
        self.track_c1_y = [float(slot[6]) for slot in slot_list]
        self.det_c0_x = [float(slot[7]) for slot in slot_list]
        self.det_c0_y = [float(slot[8]) for slot in slot_list]
        self.det_c1_x = [float(slot[9]) for slot in slot_list]
        self.det_c1_y = [float(slot[10]) for slot in slot_list]
        self.track_slot_width = [float(slot[11]) for slot in slot_list]
        self.detect_slot_width = [float(slot[12]) for slot in slot_list]
        self.track_slot_theta = [float(slot[13]) for slot in slot_list]
        self.detect_slot_theta = [float(slot[14]) for slot in slot_list]
        self.ws_timestamp = [datetime.datetime.fromtimestamp(float(slot[0])) for slot in slot_list if float(slot[15]) > 0]
        self.ws_dis = [float(slot[15]) for slot in slot_list if float(slot[15]) > 0] 
        self.normalize_theta()
        
    def draw_result(self):
        fig,axes = plt.subplots(nrows=4, ncols=2)
        fig.tight_layout()
        
        axes[0, 0].plot(self.slot_timestamp, self.det_c0_x, label="det_c0_x", color="g", alpha=1, linewidth=1)
        axes[0, 0].plot(self.slot_timestamp, self.track_c0_x, label="track_c0_x", color="r", alpha=1, linewidth=1)
        axes[0, 0].legend()
        axes[0, 0].set_title("c0_x")
        axes[0, 0].set_xlabel("timestamp(s)")
        axes[0, 0].set_ylabel("position(m)")
        axes[0, 0].grid()
        
        axes[0, 1].plot(self.slot_timestamp, self.det_c0_y, label="det_c0_y", color="g", alpha=1, linewidth=1)
        axes[0, 1].plot(self.slot_timestamp, self.track_c0_y, label="track_c0_y", color="r", alpha=1, linewidth=1)
        axes[0, 1].legend()
        axes[0, 1].set_title("c0_y")
        axes[0, 1].set_xlabel("timestamp(s)")
        axes[0, 1].set_ylabel("position(m)")
        axes[0, 1].grid()
        
        axes[1, 0].plot(self.slot_timestamp, self.det_c1_x, label="det_c1_x", color="g", alpha=1, linewidth=1)
        axes[1, 0].plot(self.slot_timestamp, self.track_c1_x, label="track_c1_x", color="r", alpha=1, linewidth=1)
        axes[1, 0].legend()
        axes[1, 0].set_title("c1_x")
        axes[1, 0].set_xlabel("timestamp(s)")
        axes[1, 0].set_ylabel("position(m)")
        axes[1, 0].grid()
        
        axes[1, 1].plot(self.slot_timestamp, self.det_c1_y, label="det_c1_y", color="g", alpha=1, linewidth=1)
        axes[1, 1].plot(self.slot_timestamp, self.track_c1_y, label="track_c1_y", color="r", alpha=1, linewidth=1)
        axes[1, 1].legend()
        axes[1, 1].set_title("c1_y")
        axes[1, 1].set_xlabel("timestamp(s)")
        axes[1, 1].set_ylabel("position(m)")
        axes[1, 1].grid()
        
        axes[2, 0].plot(self.slot_timestamp, self.detect_slot_width, label="detect_slot_width", color="g", alpha=1, linewidth=1)
        axes[2, 0].plot(self.slot_timestamp, self.track_slot_width, label="track_slot_width", color="r", alpha=1, linewidth=1)
        axes[2, 0].legend()
        axes[2, 0].set_title("slot_width")
        axes[2, 0].set_xlabel("timestamp(s)")
        axes[2, 0].set_ylabel("position(m)")
        axes[2, 0].grid()
        
        axes[2, 1].plot(self.slot_timestamp, self.detect_slot_theta, label="detect_slot_theta", color="g", alpha=1, linewidth=1)
        axes[2, 1].plot(self.slot_timestamp, self.track_slot_theta, label="track_slot_theta", color="r", alpha=1, linewidth=1)
        axes[2, 1].legend()
        axes[2, 1].set_title("slot_theta")
        axes[2, 1].set_xlabel("timestamp(s)")
        axes[2, 1].set_ylabel("position(m)")
        axes[2, 1].grid()
        
        axes[3, 0].plot(self.ws_timestamp, self.ws_dis, label="ws_dis", color="r", alpha=1, linewidth=1)
        axes[3, 0].legend()
        axes[3, 0].set_title("ws_dis")
        axes[3, 0].set_xlabel("timestamp(s)")
        axes[3, 0].set_ylabel("position(m)")
        axes[3, 0].grid()
        
        plt.show()

    def normalize_theta(self):
        if self.track_slot_theta[0] - self.detect_slot_theta[0] > 180:
            self.track_slot_theta[0] -=360
        elif self.track_slot_theta[0] - self.detect_slot_theta[0] < -180:
            self.track_slot_theta[0] +=360
        for i in range(len(self.detect_slot_theta)):
            if i > 0 and self.detect_slot_theta[i] - self.detect_slot_theta[i - 1] > 180:
                self.detect_slot_theta[i] -= 360
            elif i > 0 and self.detect_slot_theta[i] - self.detect_slot_theta[i - 1] < -180:
                self.detect_slot_theta[i] += 360
        for i in range(len(self.track_slot_theta)):
            if i > 0 and self.track_slot_theta[i] - self.track_slot_theta[i - 1] > 180:
                self.track_slot_theta[i] -= 360
            elif i > 0 and self.track_slot_theta[i] - self.track_slot_theta[i - 1] < -180:
                self.track_slot_theta[i] += 360 

if __name__ == '__main__':
    analyser = AnalyseUlog(opt.log_file, opt.slot_id)
    analyser.read_log()
    analyser.draw_result()