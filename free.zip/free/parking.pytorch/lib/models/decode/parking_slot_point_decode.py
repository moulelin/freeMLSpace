import torch
from torch import nn
import torch.nn.functional as F


class ParkingSlotPointDecoder(object):
    def __init__(self, opt):
        self.opt = opt
        self.w_input = self.opt.w_input
        self.h_input = self.opt.h_input
        self.scale_point = self.opt.scale_point
        self.batch = self.opt.val_batch
        self.onnx = getattr(self.opt, "onnx", 0)
        self.make_points_anchor()

    def _nms(self, heat, kernel=3):
        pad = (kernel - 1) // 2
        hmax = nn.functional.max_pool2d(heat, (kernel, kernel), stride=1, padding=pad)
        keep = F.relu(heat - hmax + 0.001) * 1000
        return heat * keep

    def extract_truth(self, point_truth, center_truth, seg_truth):
        point_heatmap = point_truth[..., 0:1].reshape(self.batch, -1, 1)
        point_cls = point_truth[..., 1:2].reshape(self.batch, -1, 1)
        point_loc = point_truth[..., 2:4].reshape(self.batch, -1, 2)
        point_loc = (point_loc + self.decode_point_xy) * self.scale_point

        center_heatmap = center_truth[..., 0:1].reshape(self.batch, -1, 1)
        center_cls = center_truth[..., 1:2].reshape(self.batch, -1, 1)
        center_loc = center_truth[..., 2:4].reshape(self.batch, -1, 2)
        center_loc = (center_loc + self.decode_point_xy) * self.scale_point

        point_truth = torch.cat([point_cls.float(), point_heatmap, point_loc], dim=2)
        center_truth = torch.cat(
            [
                center_cls.float(),
                center_heatmap,
                center_loc,
            ],
            dim=2,
        )
        return point_truth, center_truth, seg_truth

    def run(self, point_pred, center_pred, seg_pred):
        # seg_pred
        # seg_pred = seg_pred.argmax(dim=1)
        seg_pred = seg_pred.permute(0, 2, 3, 1).contiguous().argmax(dim=3)
        # point_pred
        point_pred = point_pred.sigmoid()
        point_heatmap = point_pred[:, 0:1, :]
        point_heatmap = self._nms(point_heatmap)
        point_heatmap = (
            point_heatmap.permute(0, 2, 3, 1).contiguous().reshape(self.batch, -1, 1)
        )
        point_loc = (
            point_pred[:, 2:4]
            .permute(0, 2, 3, 1)
            .contiguous()
            .reshape(self.batch, -1, 2)
        )
        point_loc = (point_loc + self.decode_point_xy) * self.scale_point
        point_cls = (
            point_pred[:, 1:2, :]
            .permute(0, 2, 3, 1)
            .contiguous()
            .reshape(self.batch, -1, 1)
        )
        # center pred
        center_pred = center_pred.sigmoid()
        center_heatmap = center_pred[:, 0:1, :]
        center_heatmap = self._nms(center_heatmap)
        center_heatmap = (
            center_heatmap.permute(0, 2, 3, 1).contiguous().reshape(self.batch, -1, 1)
        )
        center_loc = (
            center_pred[:, 2:4]
            .permute(0, 2, 3, 1)
            .contiguous()
            .reshape(self.batch, -1, 2)
        )
        center_loc = (center_loc + self.decode_point_xy) * self.scale_point
        center_cls = (
            center_pred[:, 1:2, :]
            .permute(0, 2, 3, 1)
            .contiguous()
            .reshape(self.batch, -1, 1)
        )

        if not self.onnx:
            point_pred = torch.cat([point_cls.float(), point_heatmap, point_loc], dim=2)
            center_pred = torch.cat(
                [
                    center_cls.float(),
                    center_heatmap,
                    center_loc,
                ],
                dim=2,
            )
            return point_pred, center_pred, seg_pred
        else:
            _, idx_point = torch.topk(point_heatmap[:, :, 0], 128, dim=1)
            _, idx_center = torch.topk(center_heatmap[:, :, 0], 128, dim=1)
            points_list = []
            center_list = []
            for i in range(self.batch):
                # point
                pts_loc = point_loc[i, :, :].index_select(0, idx_point[i, :])
                pts_cls = point_cls[i, :, :].index_select(0, idx_point[i, :])
                pts_prob = point_heatmap[i, :, :].index_select(0, idx_point[i, :])
                points = torch.cat([pts_cls, pts_prob, pts_loc], dim=1)
                points_list.append(points)
                # center
                cen_loc = center_loc[i, :, :].index_select(0, idx_center[i, :])
                cen_cls = center_cls[i, :, :].index_select(0, idx_center[i, :])
                cen_prob = center_heatmap[i, :, :].index_select(0, idx_center[i, :])
                centers = torch.cat([cen_cls, cen_prob, cen_loc], dim=1)
                center_list.append(centers)
            if self.batch == 1:
                return points.unsqueeze(0), centers.unsqueeze(0), seg_pred
            else:
                points = torch.stack(points_list, 0).contiguous()
                centers = torch.stack(center_list, 0).contiguous()
                return points, centers, seg_pred

    def make_points_anchor(self):
        w_output = self.w_input // self.scale_point
        h_output = self.h_input // self.scale_point
        ys, xs = torch.meshgrid(torch.arange(h_output), torch.arange(w_output))
        xys = torch.stack([xs, ys], dim=2).float().view(1, -1, 2)
        self.decode_point_xy = xys.repeat(self.batch, 1, 1).cuda()
