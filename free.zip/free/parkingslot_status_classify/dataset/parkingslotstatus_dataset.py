import torch
import torchvision as tv
from torch.utils import data
from torchvision import transforms as T
import numpy as np
import os
import json
from PIL import Image


class_label = {'occupied': 0, 'empty': 1}


class ParkingSlotStatusDataset(data.Dataset):
    def __init__(self, datadir, width, height, mode='train'):
        self.mode = mode
        self.width = width
        self.height = height
        if mode == 'train':
            image_list_file = os.path.join(datadir, 'train_list.txt')
            self.transform = T.Compose([T.RandomAffine(degrees=10, translate=(0.05, 0.05), shear=5),
                                        T.ColorJitter(0.1, 0.1, 0.1, 0.03),
                                        T.ToTensor()])
        else:
            image_list_file = os.path.join(datadir, 'val_list.txt')
            self.transform = T.Compose([T.ToTensor()])
        self.image_list = []
        self.label_list = []
        with open(image_list_file, 'r') as f:
            for image in f.readlines():
                self.image_list.append(os.path.join(datadir, image.strip()))
                label = image.replace('image', 'label').replace('png', 'json').strip()
                label_path = os.path.join(datadir, label)
                with open(label_path, 'r') as f1:
                    label_json = json.load(f1)
                    label_train = class_label[label_json['status']]
                    self.label_list.append(torch.LongTensor([int(label_train)]))

    def __len__(self):
        return len(self.image_list)

    def __getitem__(self, index):
        fimg = self.image_list[index]
        label = self.label_list[index]
        img = Image.open(fimg)
        w, h = img.size
        l = max(w, h)
        scaled_img = Image.new('RGB', (l, l))
        x0 = (l - w) // 2
        y0 = (l - h) // 2
        scaled_img.paste(img, (x0, y0))
        img = scaled_img.resize((self.width, self.height))
        img = self.transform(img)
        return img, label
