import cv2
import math
import numpy as np
from PIL import Image


class AddWater(object):
    def __init__(
        self,
        p=0.2,
        num_angle=72,  # num r,
        r_list=[15, 25, 35, 45],  # len r list
        offset=50,  # water offset for slot center
        min_smooth_k=10,  # min smooth water edge kernel size
        max_smooth_k=20,  # max smooth water edge kernel size
    ):
        self.p = p
        self.num_angle = num_angle
        self.r_list = r_list
        self.offset = offset
        self.min_smooth_k = min_smooth_k
        self.max_smooth_k = max_smooth_k

    def __call__(self, image, label_slot):
        image = np.array(image).astype("uint8")
        h, w, _ = image.shape
        for slot in label_slot:
            if slot[-1] == 0:
                if np.random.rand() > self.p:
                    continue

                min_x = int(min(slot[:-1][0::2]) * w)
                max_x = int(max(slot[:-1][0::2]) * w)
                min_y = int(min(slot[:-1][1::2]) * h)
                max_y = int(max(slot[:-1][1::2]) * h)

                min_x = max(min_x, 0)
                max_x = min(max_x, w - 1)
                min_y = max(min_y, 0)
                max_y = min(max_y, h - 1)

                ctr_x = (min_x + max_x) // 2
                ctr_y = (min_y + max_y) // 2
                image = self._generate_water_mask(image, ctr_x, ctr_y, w, h)
        image = Image.fromarray(image)
        return image

    def _generate_water_mask(self, image, ctr_x, ctr_y, w, h):
        num_water = np.random.choice([1, 2, 3])
        for _ in range(num_water):
            # generate water templete
            templete = []
            r = np.random.choice(self.r_list)

            d_angle = 360 / self.num_angle
            for i in range(self.num_angle):
                cur_r = r * (0.8 + np.random.rand() * 0.4)
                x = int(cur_r * math.cos(math.radians(i * d_angle)))
                y = int(cur_r * math.sin(math.radians(i * d_angle)))
                templete.append([x, y])
            templete = np.array(templete)

            # offset water position
            dx = self.offset - np.random.randint(0, 3 * self.offset)
            dy = self.offset - np.random.randint(0, 3 * self.offset)

            templete[:, 0] = templete[:, 0] + dx + ctr_x
            templete[:, 1] = templete[:, 1] + dy + ctr_y
            templete[:, 0] = np.maximum(templete[:, 0], 0)
            templete[:, 0] = np.minimum(templete[:, 0], w - 1)
            templete[:, 1] = np.maximum(templete[:, 1], 0)
            templete[:, 1] = np.minimum(templete[:, 1], h - 1)

            tmp = np.zeros((h, w))
            cv2.fillPoly(tmp, [templete.astype(np.int32)], color=1)

        # smooth edge
        k = np.random.randint(self.min_smooth_k, self.max_smooth_k)
        kernel = cv2.getStructuringElement(2, (k, k))
        tmp = cv2.dilate(tmp, kernel)
        ratio = np.ones((h, w)) * (0.3 + np.random.rand() * 0.5)
        mask = tmp * ratio
        mask[mask == 0] = 1

        image = (image * mask.reshape(h, w, 1)).astype("uint8")
        return image


class ChangeLineColor(object):
    def __init__(self, p=0.3, p1=0.4, p2=0.7):
        self.p = p
        self.p1 = p1
        self.p2 = p2

    def __call__(self, image, label_slot):
        if np.random.rand() > self.p:
            return image

        image = np.array(image).astype("uint8")
        h, w, _ = image.shape
        line_mask = np.zeros((h, w), dtype=np.uint8)
        label_slot = np.array(label_slot)
        label_slot = label_slot[:, :-1]
        label_slot[:, 0::2] = label_slot[:, 0::2] * w
        label_slot[:, 1::2] = label_slot[:, 1::2] * h
        label_slot = label_slot.astype("int32")
        for slot in label_slot:
            cv2.line(
                line_mask, (slot[0], slot[1]), (slot[2], slot[3]), thickness=8, color=1
            )
            cv2.line(
                line_mask, (slot[2], slot[3]), (slot[4], slot[5]), thickness=8, color=1
            )
            cv2.line(
                line_mask, (slot[4], slot[5]), (slot[6], slot[7]), thickness=8, color=1
            )
            cv2.line(
                line_mask, (slot[6], slot[7]), (slot[0], slot[1]), thickness=8, color=1
            )

        line_image = image * line_mask.reshape(h, w, 1)
        th = line_image[line_image > 0].mean()
        color_mask = (
            (line_image[:, :, 0] > th)
            * (line_image[:, :, 1] > th)
            * (line_image[:, :, 2] > th)
        )
        ratio_mask = np.ones((h, w, 3))

        p = np.random.rand()
        if p > self.p2:
            ratio_mask[:, :, 0] = ratio_mask[:, :, 0] + color_mask * (
                0.5 + np.random.rand()
            )
            ratio_mask[:, :, 1] = ratio_mask[:, :, 1] + color_mask * (
                0.5 + np.random.rand()
            )
            ratio_mask[:, :, 2] = ratio_mask[:, :, 2] + color_mask * (
                0.1 - np.random.rand() * 0.2
            )
        elif p > self.p1:
            ratio_mask[:, :, 0] = ratio_mask[:, :, 0] - color_mask * (
                0.1 + np.random.rand() * 0.2
            )
            ratio_mask[:, :, 1] = ratio_mask[:, :, 1] - color_mask * (
                0.2 + np.random.rand() * 0.2
            )
            ratio_mask[:, :, 2] = ratio_mask[:, :, 2] - color_mask * (
                0.6 + np.random.rand() * 0.4
            )
        else:
            ratio_mask[:, :, 0] = ratio_mask[:, :, 0] - color_mask * (
                0.2 + np.random.rand() * 0.2
            )
            ratio_mask[:, :, 1] = ratio_mask[:, :, 1] - color_mask * (
                0.2 + np.random.rand() * 0.2
            )
            ratio_mask[:, :, 2] = ratio_mask[:, :, 2] - color_mask * (
                0.2 + np.random.rand() * 0.2
            )
        convert_image = (np.clip(image * ratio_mask, 0, 255)).astype("uint8")
        convert_image = Image.fromarray(convert_image)

        return convert_image
