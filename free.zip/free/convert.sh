#!/bin/bash

cd /workspace/network/parking.pytorch/
export PYTHONPATH=./

python3 tools/onnx_to_trt.py \
    --config ./configs/fisheye_seg.yaml \
    --model_info $MODEL_PATH \
    --onnx_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
    --save_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
    --fp16 \
    --trt8 \
    --batch 1

# python3 tools/pth_to_onnx.py \
#     --config ./configs/fisheye_seg.yaml \
#     --model_info $MODEL_PATH \
#     --save_path /output/$PNAME/$JOBNAME/$PODNAME/convert \
#     --opset_version 11 \
#     --batch 1

# python3 tools/onnx_to_trt.py \
#     --config ./configs/fisheye_seg.yaml \
#     --onnx_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
#     --save_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
#     --trt8 \
#     --batch 1

# python3 tools/onnx_to_trt.py \
#     --config ./configs/fisheye_seg.yaml \
#     --onnx_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
#     --save_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
#     --fp16 \
#     --trt8 \
#     --batch 1

# python3 tools/onnx_to_trt.py \
#     --config ./configs/fisheye_seg.yaml \
#     --onnx_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
#     --save_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
#     --int8 \
#     --img_dir /proc_data/parking/fisheye/calibrator_imgs \
#     --trt8 \
#     --batch 1

# python3 tools/pth_to_onnx.py \
#     --config ./configs/fisheye_seg.yaml \
#     --model_info $MODEL_PATH \
#     --save_path /output/$PNAME/$JOBNAME/$PODNAME/convert \
#     --opset_version 11 \
#     --batch 4

# python3 tools/onnx_to_trt.py \
#     --config ./configs/fisheye_seg.yaml \
#     --onnx_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
#     --save_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
#     --trt8 \
#     --batch 4

# python3 tools/onnx_to_trt.py \
#     --config ./configs/fisheye_seg.yaml \
#     --onnx_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
#     --save_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
#     --fp16 \
#     --trt8 \
#     --batch 4

# python3 tools/onnx_to_trt.py \
#     --config ./configs/fisheye_seg.yaml \
#     --onnx_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
#     --save_path /output/$PNAME/$JOBNAME/$PODNAME/convert/ \
#     --int8 \
#     --img_dir /proc_data/parking/fisheye/calibrator_imgs \
#     --trt8 \
#     --batch 4
