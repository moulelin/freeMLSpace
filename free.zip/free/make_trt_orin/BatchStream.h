/*
 * Copyright (c) 2019, NVIDIA CORPORATION. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef BATCH_STREAM_H
#define BATCH_STREAM_H

#include "NvInfer.h"
#include <fstream>
#include <iostream>
#include <algorithm>
#include <assert.h>
#include <stdio.h>
#include <vector>
#include <dirent.h>
// #include <opencv2/imgcodecs.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>

int listdir(const char* basePath, std::vector<std::string>& file_list)
{
    DIR *dir;
    struct dirent *ptr;
    char base[256];

    if ((dir=opendir(basePath)) == NULL)
    {
        perror("Open dir error...");
        exit(1);
    }
    while ((ptr=readdir(dir)) != NULL)
    {
        memset(base, '\0', sizeof(base));
        if(strcmp(ptr->d_name, ".")==0 || strcmp(ptr->d_name, "..")==0)    ///current dir OR parrent dir
            continue;
        else if(ptr->d_type == 8)     ///file
        {
            sprintf(base, "%s/%s", basePath, ptr->d_name);
            file_list.push_back(std::string(base));
        }
        else if(ptr->d_type == 10)    ///link file
        {
            continue;
        }
        else if(ptr->d_type == 4)     ///dir
        {
            sprintf(base, "%s/%s", basePath, ptr->d_name);
            listdir(base, file_list);
        }
    }
    closedir(dir);
    return 1;
}


class IBatchStream
{
public:
    virtual void reset(int firstBatch) = 0;
    virtual bool next() = 0;
    virtual void skip(int skipCount) = 0;
    virtual float* getBatch() = 0;
    virtual int getBatchesRead() const = 0;
    virtual int getBatchSize() const = 0;
    virtual nvinfer1::Dims getDims() const = 0;
};

class BatchStream : public IBatchStream
{
public:
    // This constructor expects that the dimensions include the batch dimension.
    BatchStream(int maxBatches, nvinfer1::Dims dims, std::string dataDir)
        : mBatchSize(dims.d[0])
        , mMaxBatches(maxBatches)
        , mDims(dims)
        , mDataDir(dataDir)
    {
        listdir(dataDir.c_str(), mListFile);
        mMaxBatches = std::min(maxBatches, int(mListFile.size() / mBatchSize));
        std::cout<<"BatchStream read file number: "<<mListFile.size()<<std::endl;
        std::cout<<"Max calibration batch: "<<mMaxBatches<<std::endl;
        mImageSize = mDims.d[1] * mDims.d[2] * mDims.d[3];
        mBatch.resize(mBatchSize * mImageSize, 0);
        mFileBatch.resize(mImageSize, 0);
        reset(0);
    }

    // Resets data members
    void reset(int firstBatch) override
    {
        mBatchCount = 0;
        mFileCount = 0;
        skip(firstBatch);
    }

    // Advance to next batch and return true, or return false if there is no batch left.
    bool next() override
    {
        if(mBatchCount == mMaxBatches)
        {
            return false;
        }

        for(int batchPos = 0; batchPos < mBatchSize; batchPos++)
        {
            if (!update())
            {
                return false;
            }
            std::copy_n(getFileBatch(), mImageSize, getBatch() + batchPos * mImageSize);
        }
        std::cout<<"BatchStream Processing: "<<mBatchCount<<"/"<<mMaxBatches<<std::endl;
        mBatchCount++;
        return true;
    }

    // Skips the batches
    void skip(int skipCount) override
    {
        if (mBatchSize >= mDims.d[0] && mBatchSize % mDims.d[0] == 0)
        {
            mFileCount += skipCount * mBatchSize / mDims.d[0];
            return;
        }

        int x = mBatchCount;
        for (int i = 0; i < skipCount; i++)
        {
            next();
        }
        mBatchCount = x;
    }

    float* getBatch() override
    {
        return mBatch.data();
    }

    int getBatchesRead() const override
    {
        return mBatchCount;
    }

    int getBatchSize() const override
    {
        return mBatchSize;
    }

    nvinfer1::Dims getDims() const override
    {
        return mDims;
    }

private:
    float* getFileBatch()
    {
        return mFileBatch.data();
    }

    bool update()
    {
        if (mFileCount >= mListFile.size())
        {
            return false;
        }
        else
        {
            std::string fName = mListFile[mFileCount];
            cv::Mat img = cv::imread(fName);
            cv::Mat img_resize = img;
            cv::resize(img, img_resize, cv::Size(mDims.d[3], mDims.d[2]));
            assert(mDims.d[1] == 3);

            mFileCount++;
            u_char* img_ptr = img_resize.data;
            std::vector<float> data(mImageSize);
            const float scale = 1.0 / 255.0;
            // const float bias = 1.0;

            int H = mDims.d[2];
            int W = mDims.d[3];
            // Normalize input data
            for(int j=0; j<H; j++)
            {
                for(int i=0; i<W; i++)
                {
                    data[2*H*W + j*W + i] = float(img_ptr[j*W*3 + i*3]) * scale; // b
                    data[H*W + j*W + i] = float(img_ptr[j*W*3 + i*3 + 1]) * scale; // g
                    data[j*W + i] = float(img_ptr[j*W*3 + i*3 + 2]) * scale; // r
                }
            }
            std::copy_n(data.data(), mImageSize, getFileBatch());
        }
        return true;
    }

    int mBatchSize{0};
    int mMaxBatches{0};
    int mBatchCount{0};
    uint32_t mFileCount{0};
    int mImageSize{0};
    std::vector<float> mBatch;         //!< Data for the batch
    std::vector<float> mFileBatch;     //!< List of image files
    nvinfer1::Dims mDims;              //!< Input dimensions
    std::string mDataDir;              //!< Directory where the files can be found
    std::vector<std::string> mListFile; //!< File names of the list of image names
};

#endif
