import torch
import cv2
import numpy as np
import pdb
from typing import Tuple

from lib.datasets.utils.box3d import Box
from lib.datasets.utils.quaternion import Quaternion
from lib.utils.vis_util import *

def tensor_to_image(tensor):
    tensor = tensor.cpu().squeeze(0)
    img = tensor.permute(1, 2, 0).contiguous()
    img = img.numpy() * 255
    img = img[:,:,::-1].astype(np.uint8)
    return img

def bev_feature_to_image(bev_feature, height_index=None):
    """
    Args:
        bev_feature: B * C * H * W
    """
    B, C, H, W = bev_feature.shape
    if height_index is None:
        bev_feature, _ = torch.max(bev_feature.view(B, -1, 3, H, W), dim=1)
    else:
        bev_feature = bev_feature.view(B, -1, 3, H, W)[:, height_index, ...]
    image = bev_feature[0].detach().permute(1, 2, 0).numpy()
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    return image


def merge_four_images(img_list):
    img_top = np.concatenate(img_list[:2], axis=1)
    img_bot = np.concatenate(img_list[2:], axis=1)
    img_merged = np.concatenate([img_top, img_bot], axis=0)
    return img_merged


def project_points_to_img(points, intrinsic, img_post_rot=None, img_post_trans=None):
    """
    Args:
        points: 3*N, np.array
        intrinsic: 3*3
        img_post_rot: 3*3
        img_post_trans: 3
    Return:
        uv_points: 2*N
    """
    eps = 1e-7
    image_points = np.dot(intrinsic, points)
    image_points = image_points / (image_points[2:, :] + eps)
    if img_post_rot is not None and img_post_trans is not None:
        image_points = img_post_rot @ image_points + img_post_trans[..., None]
    image_points = image_points[:2, :]
    image_points = np.where(
        points[2:, :] > 0, image_points, np.full_like(image_points, -1)
    )
    return image_points


def box3d_ang_to_box3d_quat(box3d):
    # input: Nx10 [[cls, prob, x,y,z,w,l,h,sin,cos]]
    # output: Nx12 [[cls, prob, q0,q1,q2,q3,x,y,z,w,l,h]]
    if box3d.size(1) == 10:
        pc = box3d[:, 0:2]
        xyzwlh = box3d[:, 2:8]
        ang = box3d[:, 8:10]
    else:
        pc = box3d[:, 0:1]
        xyzwlh = box3d[:, 1:7]
        ang = box3d[:, 7:9]
    N = box3d.size(0)
    if N == 0:
        return torch.empty(0, 12)
    rot = torch.atan2(ang[:, 0], ang[:, 1])
    rot_mat = torch.zeros(N, 3, 3)
    rot_mat[:, 2, 2] = 1
    rot_mat[:, 0, 0] = rot.cos()
    rot_mat[:, 1, 1] = rot.cos()
    rot_mat[:, 0, 1] = -rot.sin()
    rot_mat[:, 1, 0] = rot.sin()
    quat_list = []
    for i in range(N):
        rot = rot_mat[i, :, :].numpy()
        q = Quaternion._from_matrix(rot, rtol=1e-3, atol=1e-5)
        quat = torch.from_numpy(q.q).float()
        quat_list.append(quat)
    quat_v = torch.stack(quat_list, dim=0)
    box_out = torch.cat([pc, quat_v, xyzwlh], dim=1)
    return box_out.clone()


def draw_box3d_on_img(
    img: np.ndarray,
    box: Box,
    intrinsic: np.ndarray = np.eye(3),
    img_post_rot: np.ndarray = np.eye(3),
    img_post_trans: np.ndarray = np.zeros(3),
    colors: Tuple = ((0, 0, 255), (255, 0, 0), (155, 155, 155)),
    linewidth: int = 2,
) -> None:
    corners = project_points_to_img(
        box.corners(), intrinsic, img_post_rot, img_post_trans
    )[:2, :]

    def draw_rect(selected_corners, color):
        prev = selected_corners[-1]
        for corner in selected_corners:
            cv2.line(
                img,
                (int(prev[0]), int(prev[1])),
                (int(corner[0]), int(corner[1])),
                color,
                linewidth,
            )
            prev = corner

    # Draw the sides
    for i in range(4):
        cv2.line(
            img,
            (int(corners.T[i][0]), int(corners.T[i][1])),
            (int(corners.T[i + 4][0]), int(corners.T[i + 4][1])),
            colors[2][::-1],
            linewidth,
        )

    # Draw front (first 4 corners) and rear (last 4 corners) rectangles(3d)/lines(2d)
    draw_rect(corners.T[:4], colors[0][::-1])
    draw_rect(corners.T[4:], colors[1][::-1])

    # Draw line indicating the front
    center_bottom_forward = np.mean(corners.T[2:4], axis=0)
    center_bottom = np.mean(corners.T[[2, 3, 7, 6]], axis=0)
    cv2.line(
        img,
        (int(center_bottom[0]), int(center_bottom[1])),
        (int(center_bottom_forward[0]), int(center_bottom_forward[1])),
        colors[0][::-1],
        linewidth,
    )


def pix_camera2image(pix_coords, affines, distortion_centers, world2cams):
    pix_coords_np = pix_coords.numpy()
    world2cams_np = world2cams.numpy()
    affines_np = affines.numpy()
    distortion_centers_np = distortion_centers.numpy()
    rho = np.sqrt(
        np.square(pix_coords_np[:, :, 0, :]) + np.square(pix_coords_np[:, :, 1, :])
    )
    theta = np.arctan(np.divide(-pix_coords_np[:, :, 2, :], rho))
    thetad = np.zeros((theta.shape[0], theta.shape[1], theta.shape[2]), dtype=np.float)
    for i in range(world2cams.shape[2] - 1, -1, -1):
        thetad = thetad * theta + world2cams_np[:, :, i : i + 1]

    pix_coords_np[:, :, 0, :] = pix_coords_np[:, :, 0, :] / rho * thetad
    pix_coords_np[:, :, 1, :] = pix_coords_np[:, :, 1, :] / rho * thetad
    pix_coords_np[:, :, 0, :] = (
        pix_coords_np[:, :, 0, :] * affines_np[:, :, 0:1]
        + pix_coords_np[:, :, 1, :] * affines_np[:, :, 1:2]
        + distortion_centers_np[:, :, 0:1]
    )
    pix_coords_np[:, :, 1, :] = (
        pix_coords_np[:, :, 0, :] * affines_np[:, :, 2:3]
        + pix_coords_np[:, :, 1, :]
        + distortion_centers_np[:, :, 1:2]
    )
    pix_coords_np = torch.from_numpy(pix_coords_np)
    pix_coords = pix_coords_np.type_as(pix_coords)
    return pix_coords


def point_camera2image(points_np, affines_np, distortion_centers_np, world2cams_np, img_post_rot, img_post_trans):
    rho = np.sqrt(np.square(points_np[0, :]) + np.square(points_np[1, :]))
    theta = np.arctan(np.divide(-points_np[2, :], rho))
    thetad = np.zeros((theta.shape[0]), dtype=np.float)
    for i in range(world2cams_np.shape[0]-1, -1, -1):
        thetad = thetad * theta + world2cams_np[i:i+1]
    points_np[0, :] = points_np[0, :] / rho * thetad
    points_np[1, :] = points_np[1, :] / rho * thetad
    points_np[0, :] = points_np[0, :] * affines_np[0:1] + points_np[1, :] * affines_np[1:2] + distortion_centers_np[0:1]
    points_np[1, :] = points_np[0, :] * affines_np[2:3] + points_np[1, :] + distortion_centers_np[1:2]
    if img_post_rot is not None and img_post_trans is not None:
        points_np = img_post_rot @ points_np + img_post_trans[..., None]
    points = points_np[:2, :]
    return points


def draw_box3d_on_img_v2(img: np.ndarray,
                      box: Box,
                      affines, 
                      distortion_centers, 
                      world2cams,
                      img_post_rot: np.ndarray = np.eye(3),
                      img_post_trans: np.ndarray = np.zeros(3),
                      colors: Tuple = ((0, 0, 255), (255, 0, 0), (155, 155, 155)),
                      linewidth: int = 2) -> None:
    
    corners = point_camera2image(box.corners(), affines, distortion_centers, world2cams, img_post_rot, img_post_trans)

    def draw_rect(selected_corners, color):
        prev = selected_corners[-1]
        for corner in selected_corners:
            cv2.line(img,
                        (int(prev[0]), int(prev[1])),
                        (int(corner[0]), int(corner[1])),
                        color, linewidth)
            prev = corner

    # Draw the sides
    for i in range(4):
        cv2.line(img,
                    (int(corners.T[i][0]), int(corners.T[i][1])),
                    (int(corners.T[i + 4][0]), int(corners.T[i + 4][1])),
                    colors[2][::-1], linewidth)

    # Draw front (first 4 corners) and rear (last 4 corners) rectangles(3d)/lines(2d)
    draw_rect(corners.T[:4], colors[0][::-1])
    draw_rect(corners.T[4:], colors[1][::-1])

    # Draw line indicating the front
    center_bottom_forward = np.mean(corners.T[2:4], axis=0)
    center_bottom = np.mean(corners.T[[2, 3, 7, 6]], axis=0)
    img = cv2.line(img,
                (int(center_bottom[0]), int(center_bottom[1])),
                (int(center_bottom_forward[0]), int(center_bottom_forward[1])),
                colors[0][::-1], linewidth)
    return img


def draw_box_in_bev(box_corners, bev_img, xbound, ybound, color=(0,255,0), thickness=1):
    assert box_corners.shape[1] == 4
    assert box_corners.shape[0] == 3
    corner_list = []
    for i in range(4):
        xyz = box_corners[:, i]
        y_idx = (xyz[0] - xbound[0]) / xbound[2]
        x_idx = (xyz[1] - ybound[0]) / ybound[2]
        corner_list.append(np.array([x_idx, y_idx], dtype=np.float32))
    pts = np.stack(corner_list, axis=0).astype(np.int32)
    cv2.polylines(bev_img, [pts], True, color, thickness)
    cv2.line(bev_img, (pts[0][0], pts[0][1]), (pts[1][0], pts[1][1]), (0,0,255), thickness)
    return bev_img


def draw_box_in_bev_gt(box_corners, bev_img, xbound, ybound, color=(0,255,0), thickness=1):
    assert box_corners.shape[1] == 4
    assert box_corners.shape[0] == 3
    corner_list = []
    for i in range(4):
        xyz = box_corners[:, i]
        y_idx = (xyz[0] - xbound[0]) / xbound[2]
        x_idx = (xyz[1] - ybound[0]) / ybound[2]
        corner_list.append(np.array([x_idx, y_idx], dtype=np.float32))
    pts = np.stack(corner_list, axis=0).astype(np.int32)
    cv2.polylines(bev_img, [pts], True, color, thickness)
    return bev_img


def visualize_bev_gt(bev_image, images, label_dict, xbound, ybound, ori_w, ori_h):

    box3d_label = label_dict["box3d"]
    mask = box3d_label[:, 4:6].sum(dim=1) > 0

    box3d_label = box3d_ang_to_box3d_quat(
        torch.cat(
            [
                box3d_label[mask, :-1],
                torch.sin(box3d_label[mask, -1:]),
                torch.cos(box3d_label[mask, -1:]),
            ],
            dim=1,
        )
    )

    img_list = []
    for n in range(4):
        img_t = images[n]
        img = tensor_to_image(img_t)
        rot = label_dict["rots"][n].double().numpy()
        tran = label_dict["trans"][n].numpy()
        affine = label_dict["affines"][n].numpy()
        distortion_center = label_dict["distortion_centers"][n].numpy()
        world2cam = label_dict["world2cams"][n].numpy()

        img_post_rot = label_dict["img_post_rot"][n].numpy()
        img_post_trans = label_dict["img_post_trans"][n].numpy()
        bev_rot = label_dict["bev_rot"][n].numpy()

        for j in range(box3d_label.size(0)):
            box3d_truth = box3d_label[j]
            if box3d_truth.sum() == 0:
                break
            quat, xyz, wlh = box3d_truth[1:5], box3d_truth[5:8], box3d_truth[8:11]
            box3d = Box(xyz.tolist(), wlh.tolist(), Quaternion(quat.tolist()))
            box3d.rotate(
                Quaternion._from_matrix(bev_rot, rtol=1e-03, atol=1e-05).inverse
            )
            box3d.translate(-tran)
            box3d.rotate(Quaternion._from_matrix(rot, rtol=1e-03, atol=1e-05).inverse)
            uv = point_camera2image(
                box3d.center[:, np.newaxis], affine, distortion_center, world2cam
            )[:, 0]

            if (
                (box3d.center[2] > 0)
                and (uv[0] >= -30)
                and (uv[0] < ori_w + 30)
                and (uv[1] >= 0)
                and (uv[1] < ori_h)
            ):
                img = draw_box3d_on_img_v2(
                    img,
                    box3d,
                    affine,
                    distortion_center,
                    world2cam,
                    img_post_rot,
                    img_post_trans,
                    linewidth=10,
                )

        img_list.append(img)
    imgs = merge_four_images(img_list)

    # show in BEV view
    bev_img = np.zeros(
        (
            int((xbound[1] - xbound[0]) /  xbound[2]),
            int((ybound[1] - ybound[0]) / ybound[2]),
            3,
        ),
        np.uint8,
    )

    # cv2.imshow("show_img", show_img)
    # cv2.waitKey(0)
    imgs = cv2.resize(
        imgs, [int(imgs.shape[1] / imgs.shape[0] * bev_img.shape[0]), bev_img.shape[0]]
    )
    show_img = [imgs]

    # draw own vehicle
    corners = np.array(
        [[3.94, 3.94, -1.06, -1.06], [1.0, -1.0, -1.0, 1.0], [0, 0, 0, 0]],
        dtype=np.float32,
    )

    bev_img = draw_box_in_bev(
        corners, bev_img, xbound, ybound, color=(255, 255, 255), thickness=1
    )

    # draw gt boxes
    for j in range(box3d_label.size(0)):
        box3d_truth = box3d_label[j]
        if box3d_truth.sum() == 0:
            break
        quat, xyz, wlh = box3d_truth[1:5], box3d_truth[5:8], box3d_truth[8:11]
        box3d = Box(xyz.tolist(), wlh.tolist(), Quaternion(quat.tolist()))
        corners = box3d.bottom_corners()
        bev_img = draw_box_in_bev_gt(
            corners, bev_img, xbound, ybound, color=(0, 255, 0)
        )
    bev_img = np.flip(bev_img, (0, 1))
    show_img.append(bev_img)

    bev_image = cv2.resize(bev_image, [bev_img.shape[1], bev_img.shape[0]])
    bev_image = np.flip(bev_image, (0, 1))
    show_img.append(bev_image)

    show_img = np.hstack(show_img).astype(np.uint8)

    # cv2.imshow('show_img', show_img)
    # cv2.waitKey(0)

    return show_img


def visualize_bev_gt_v2(bev_image, label_dict, xbound, ybound, scale_bev):

    # show in BEV view
    bev_img = np.zeros(
        (
            int((xbound[1] - xbound[0]) /  xbound[2]),
            int((ybound[1] - ybound[0]) /  ybound[2]),
            3,
        ),
        np.uint8,
    )

    # draw own vehicle
    corners = np.array(
        [[3.94, 3.94, -1.06, -1.06], [1.0, -1.0, -1.0, 1.0], [0, 0, 0, 0]],
        dtype=np.float32,
    )

    bev_img = draw_box_in_bev(
        corners, bev_img, xbound, ybound, color=(255, 255, 255), thickness=1
    )

    car_box3d_label = label_dict["car_box3d"].numpy()
    # person_box3d_label = label_dict["person_box3d"].numpy()
    print(car_box3d_label.shape)
    # print(person_box3d_label.shape)

    car_index = np.argwhere(car_box3d_label[:, :, 0] == 1)
    # person_index = np.argwhere(person_box3d_label[:, :, 0] == 1)


    for index in car_index:
        y = index[0] * scale_bev + int(car_box3d_label[index[0], index[1], 2] * scale_bev)
        x = index[1] * scale_bev + int(car_box3d_label[index[0], index[1], 1] * scale_bev)
        cv2.circle(bev_img, (x, y), 5, (0, 255, 0), -1)

        wl = car_box3d_label[index[0], index[1], 4:6] * scale_bev
        # x1 = int(x - wl[0] // 2)
        # y1 = int(y - wl[1] // 2)
        # x2 = int(x + wl[0] // 2)
        # y2 = int(y - wl[1] // 2)
        # x3 = int(x + wl[0] // 2)
        # y3 = int(y + wl[1] // 2)
        # x4 = int(x - wl[0] // 2)
        # y4 = int(y + wl[1] // 2)

        sin_rot = car_box3d_label[index[0], index[1], -2]
        cos_rot = car_box3d_label[index[0], index[1], -1]

        p1 = [wl[0] / 2, wl[1] / 2]
        p2 = [-wl[0] / 2,  wl[1] / 2]
        p3 = [ -wl[0] / 2, -wl[1] / 2]
        p4 = [wl[0] / 2,  -wl[1] / 2]

        R = np.matrix('{} {}; {} {}'.format(cos_rot, -sin_rot, sin_rot, cos_rot))

        p1_new = np.dot(p1, R)+ np.array([x, y])
        p2_new = np.dot(p2, R)+ np.array([x, y])
        p3_new = np.dot(p3, R)+ np.array([x, y])
        p4_new = np.dot(p4, R)+ np.array([x, y])

        cv2.line(bev_img, (int(p1_new[0, 0]), int(p1_new[0, 1])), (int(p2_new[0, 0]), int(p2_new[0, 1])), (255, 0, 0), 1)
        cv2.line(bev_img, (int(p2_new[0, 0]), int(p2_new[0, 1])), (int(p3_new[0, 0]), int(p3_new[0, 1])), (255, 0, 0), 1)
        cv2.line(bev_img, (int(p3_new[0, 0]), int(p3_new[0, 1])), (int(p4_new[0, 0]), int(p4_new[0, 1])), (255, 0, 0), 1)
        cv2.line(bev_img, (int(p4_new[0, 0]), int(p4_new[0, 1])), (int(p1_new[0, 0]), int(p1_new[0, 1])), (255, 0, 0), 1)

    show_img = []

    bev_img = np.flip(bev_img, (0, 1))
    show_img.append(bev_img)

    bev_image = cv2.resize(bev_image, [bev_img.shape[1], bev_img.shape[0]])
    bev_image = np.flip(bev_image, (0, 1))
    show_img.append(bev_image)

    show_img = np.hstack(show_img).astype(np.uint8)

    # cv2.imshow('show_img', show_img)
    # cv2.waitKey(0)

    return show_img


def visualize_bev_dt_v2(bev_image, box3d_preds, opt, image, truth):

    affines = truth["affines"].detach().cpu().squeeze(0).numpy()
    distortion_centers = truth["distortion_centers"].detach().cpu().squeeze(0).numpy()
    world2cams = truth["world2cams"].detach().cpu().squeeze(0).numpy()
    rots = truth["rots"].detach().cpu().squeeze(0).numpy()
    trans = truth["trans"].detach().cpu().squeeze(0).numpy()
    bev_rot = truth["bev_rot"].detach().cpu().squeeze(0).numpy()
    img_post_rot = truth['img_post_rot'].detach().cpu().squeeze(0).numpy()
    img_post_trans = truth['img_post_trans'].detach().cpu().squeeze(0).numpy()
    # show in BEV view
    bev_img = np.zeros(
        (
            int((opt.xbound[1] - opt.xbound[0]) /  opt.xbound[2]),
            int((opt.ybound[1] - opt.ybound[0]) /  opt.ybound[2]),
            3,
        ),
        np.uint8,
    )

    # draw own vehicle
    corners = np.array(
        [[3.94, 3.94, -1.06, -1.06], [1.0, -1.0, -1.0, 1.0], [0, 0, 0, 0]],
        dtype=np.float32,
    )

    bev_img = draw_box_in_bev(
        corners, bev_img, opt.xbound, opt.ybound, color=(255, 255, 255), thickness=1
    )
    
    car_box3d_pred = box3d_preds[0]
    car_box3d_pred = car_box3d_pred.detach().cpu().squeeze(0)
    # label = box3d_ang_to_box3d_quat(car_box3d_pred[car_box3d_pred[:,0]>0.5])
    label = car_box3d_pred[car_box3d_pred[:,0] > 0.5]
    car_box3d_pred = car_box3d_pred.numpy()
    # person_box3d_pred = box3d_preds[1]

    car_box3d_mask = car_box3d_pred[:, 0] > 0.5
    car_box3d_pred = car_box3d_pred[car_box3d_mask]
    # person_box3d_mask = person_box3d_pred[:, 0] > 0.5
    # person_box3d_pred = person_box3d_pred[person_box3d_mask]
    N = affines.shape[0]
    if len(car_box3d_pred) > 0:
        # match & adjust
        for c in range(len(car_box3d_pred)):
            box3d = car_box3d_pred[c]
            xnyn= box3d[[4, 3]]
            v = box3d[[9, 10]]
            v1 = box3d[[11, 12]]
            # mid ref
            mf = [xnyn[0] + v[0], xnyn[1] + v[1]]
            mf1 = [xnyn[0] + v1[0], xnyn[1] + v1[1]]
            for m in range(len(car_box3d_pred)):
                box3d = car_box3d_pred[m]
                xmym= box3d[[6, 5]]
                dist = (mf[0] - xmym[0]) ** 2 + (mf[1] - xmym[1]) ** 2
                if dist < 0.2:
                    car_box3d_pred[c][9] = car_box3d_pred[m][6] - car_box3d_pred[c][4]
                    car_box3d_pred[c][10] = car_box3d_pred[m][5] - car_box3d_pred[c][3]
                    car_box3d_pred[m][6] = 100
                    car_box3d_pred[m][5] = 100
                # match complete
                box3d[5] = box3d[3] + box3d[10]  # y
                box3d[6] = box3d[4] + box3d[9]  # x
                box3d[7] = box3d[3] + box3d[12]
                box3d[8] = box3d[4] + box3d[11]
                l = np.sqrt(box3d[9] ** 2 + box3d[10] ** 2) * 2
                w = np.sqrt(box3d[11] ** 2 + box3d[12] ** 2) * 2
                h = 1.6
                yaw_l = np.arctan2(box3d[10], box3d[9])
                yaw_90 = yaw_l - np.pi / 2
                yaw_w = np.arctan2(box3d[12], box3d[11])
                delta = np.absolute(yaw_90 - yaw_w)
                # print(delta)
                if 3.5 > delta > 2.8:
                    yaw_90 = yaw_l + np.pi / 2
                y = box3d[5] + np.sin(yaw_90) * w / 2
                x = box3d[6] + np.cos(yaw_90) * w / 2
                z = 0.8
                xyz = [x, y, z]
                wlh = [w, l, h]
                box3d = Box(xyz, wlh, Quaternion([np.cos(yaw_l / 2.), 0., 0., np.sin(yaw_l / 2.)]))
                corners = box3d.bottom_corners()
                bev_img = draw_box_in_bev(corners, bev_img, opt.xbound, opt.ybound, color=(255, 0, 0), thickness=1)
                        
        
        for i in range(len(car_box3d_pred)):
            box3d = car_box3d_pred[i]
            # draw ref
            ny = int((box3d[4] - opt.xbound[0]) / opt.xbound[2])
            nx = int((box3d[3] - opt.ybound[0]) / opt.ybound[2])
            cv2.circle(bev_img, (nx, ny), 2, (0, 255, 0), -1)

            fy = int((box3d[6] - opt.xbound[0]) / opt.xbound[2])
            fx = int((box3d[5] - opt.ybound[0]) / opt.ybound[2])
            cv2.circle(bev_img, (fx, fy), 2, (0, 255, 255), -1)
            f1y = int((box3d[8] - opt.xbound[0]) / opt.xbound[2])
            f1x = int((box3d[7] - opt.ybound[0]) / opt.ybound[2])
            cv2.circle(bev_img, (f1x, f1y), 2, (0, 255, 255), -1)

            # # draw vector
            # vx = int(box3d[10] / opt.xbound[2] * 2)
            # vy = int(box3d[9] / opt.ybound[2] * 2)
            # mid_ref_x = nx + vx
            # mid_ref_y = ny + vy
            # cv2.line(bev_img,
            #         (nx, ny),
            #         (mid_ref_x, mid_ref_y),
            #         (255, 144, 30), 1)

            # v1x = int(box3d[12] / opt.xbound[2] * 2)
            # v1y = int(box3d[11] / opt.ybound[2] * 2)
            # mid_ref1_x = nx + v1x
            # mid_ref1_y = ny + v1y
            # cv2.line(bev_img,
            #         (nx, ny),
            #         (nx + v1x, ny + v1y),
            #         (255, 0, 0), 1)
      

    # draw box3d on image
    fisheye_img_list = []
    # if len(car_box3d_pred) > 0:
    for cam_i in range(N):
        img = tensor_to_image(image[0][cam_i])
        rot = rots[cam_i, ...]
        tran = trans[cam_i, ...]
        for i in range(len(car_box3d_pred)):
            box3d = car_box3d_pred[i]
            # find center, xyz, whl, yaw 
            l = np.sqrt(box3d[9] ** 2 + box3d[10] ** 2) * 2
            w = np.sqrt(box3d[11] ** 2 + box3d[12] ** 2) * 2
            h = 1.6
            yaw_l = np.arctan2(box3d[10], box3d[9])
            yaw_90 = yaw_l - np.pi / 2
            yaw_w = np.arctan2(box3d[12], box3d[11])
            delta = np.absolute(yaw_90 - yaw_w)
            if 3.5 > delta > 2.8:
                yaw_90 = yaw_l + np.pi / 2
            y = box3d[5] + np.sin(yaw_90) * w / 2
            x = box3d[6] + np.cos(yaw_90) * w / 2
            z = 0.8
            xyz = [x, y, z]
            wlh = [w, l, h]
            box3d = Box(xyz, wlh, Quaternion([np.cos(yaw_l / 2.), 0., 0., np.sin(yaw_l / 2.)]))
            box3d.rotate(Quaternion._from_matrix(bev_rot[0], rtol=1e-03, atol=1e-05).inverse)
            box3d.translate(-tran)
            box3d.rotate(Quaternion._from_matrix(rot, rtol=1e-03, atol=1e-05).inverse)
            draw_box3d_on_img_v2(img, box3d, affines[cam_i], distortion_centers[cam_i], world2cams[cam_i], img_post_rot[cam_i]*opt.scale_point, img_post_trans[cam_i]*opt.scale_point)
        fisheye_img_list.append(img)

    show_img = []
    fisheye_img_merge = merge_four_images(fisheye_img_list)
    fisheye_img_merge = cv2.resize(fisheye_img_merge, (int(fisheye_img_merge.shape[1] / fisheye_img_merge.shape[0] * 320),
                             320))


    bev_img = np.flip(bev_img, (0, 1))
    show_img.append(cv2.resize(bev_img, (320, 320)))

    bev_image = cv2.resize(bev_image, (320, 320))
    bev_image = np.flip(bev_image, (0, 1))
    show_img.append(bev_image)
    show_img.append(fisheye_img_merge)

    show_img = np.hstack(show_img).astype(np.uint8)

    # cv2.imshow('show_img', show_img)
    # cv2.waitKey(0)

    return show_img

