import torch
from torch.utils import data
from model.ipmdet import IpmDet, IpmDetOnnx
from dataset.nuscenes import BEVNuscenesLoader
from utils.tools import sample_to_cuda
import yaml
import cv2
import numpy as np
import argparse
from thop import profile
import time
import onnxruntime as rt

from torch.onnx import register_custom_op_symbolic
import torch.onnx.symbolic_helper as sym_help

parser = argparse.ArgumentParser(description='PyTorch bevdet Testing')
parser.add_argument('--pth', default='checkpoint/ipmdet-nuscenes-best.pth', type=str, help='model ckpt')
parser.add_argument('--hyp', default='config/hyp.ipmdet.nusc.yaml', type=str, help='learning rate')
parser.add_argument('--batch', default=1, type=int, help='batch size')
parser.add_argument('--detdir', default='/media/tianming/data/nuScenes', type=str, help='detection dataset dir')
parser.add_argument('--mode', default='test', type=str, choices=['test', 'export_onnx', 'eval'])
args = parser.parse_args()

# symbolic function makes aten::grid_sampler correspond to ONNX contrib operator
# from https://github.com/microsoft/onnxruntime/blob/master/onnxruntime/python/tools/pytorch_export_contrib_ops.py
def grid_sampler(g, input, grid, mode, padding_mode, align_corners):
    # mode
    #   'bilinear'      : onnx::Constant[value={0}]
    #   'nearest'       : onnx::Constant[value={1}]
    #   'bicubic'       : onnx::Constant[value={2}]
    # padding_mode
    #   'zeros'         : onnx::Constant[value={0}]
    #   'border'        : onnx::Constant[value={1}]
    #   'reflection'    : onnx::Constant[value={2}]
    mode = sym_help._maybe_get_const(mode, "i")
    padding_mode = sym_help._maybe_get_const(padding_mode, "i")
    mode_str = ['bilinear', 'nearest', 'bicubic'][mode]
    padding_mode_str = ['zeros', 'border', 'reflection'][padding_mode]
    align_corners = int(sym_help._maybe_get_const(align_corners, "b"))

    # From opset v13 onward, the output shape can be specified with
    # (N, C, H, W) (N, H_out, W_out, 2) => (N, C, H_out, W_out)
    # input_shape = input.type().sizes()
    # grid_shape = grid.type().sizes()
    # output_shape = input_shape[:2] + grid_shape[1:3]
    # g.op(...).setType(input.type().with_sizes(output_shape))

    return g.op("com.microsoft::GridSample", input, grid,
                mode_s=mode_str,
                padding_mode_s=padding_mode_str,
                align_corners_i=align_corners)

register_custom_op_symbolic('::grid_sampler', grid_sampler, 1)

if __name__ == '__main__':
    torch.set_grad_enabled(False)

    with open(args.hyp) as f:
        hyp = yaml.load(f, Loader=yaml.SafeLoader)  # load hyps
        grid_conf = {
            'xbound': hyp['xbound'],
            'ybound': hyp['ybound'],
            'zbound': hyp['zbound']
        }

    if args.mode == 'export_onnx':
        model = IpmDetOnnx
    else:
        model = IpmDet
    net = model(hyp).cuda()
    checkpoint = torch.load(args.pth, map_location=torch.device('cpu'))
    print('epoch: ', checkpoint['epoch'])
    net.load_state_dict(checkpoint['net'])
    net = net.cuda().eval()

    if args.mode == 'test':
        valset = BEVNuscenesLoader(args.detdir, None, hyp['width'], hyp['height'], grid_conf,
                                            hyp['image_aug'], hyp['bev_aug'], use_lidar=True, mode='val')
        valloader = data.DataLoader(valset, batch_size=1, shuffle=False, num_workers=0, pin_memory=True, drop_last=True)

        for i, data_dict in enumerate(valloader):
            data_dict = sample_to_cuda(data_dict)
            t0 = time.time()
            with torch.cuda.amp.autocast(enabled=True):
                _, _, data_dict = net(data_dict)
            torch.cuda.synchronize()
            t1 = time.time()

            image_file = 'show_results/result_%06d.jpg'%i
            print(f"sample {i} inference time is {(t1 - t0)*1000} ms, image save as {image_file}")

            show_img = net.visualize_result(data_dict)
            cv2.imwrite(image_file, show_img)
            # cv2.imshow("show_img", show_img)
            # cv2.waitKey(0)
    elif args.mode == 'export_onnx':
        print(f'=================== Start to export onnx... ===================')
        n_cams = 6
        image = torch.randn(args.batch, n_cams, 3, hyp['height'], hyp['width'], device='cuda')
        intrins = torch.randn(args.batch, n_cams, 3, 3, device='cuda')
        rots = torch.randn(args.batch, n_cams, 3, 3, device='cuda')
        trans = torch.randn(args.batch, n_cams, 3, device='cuda')

        T_c2v = torch.eye(4).type_as(intrins)
        T_c2v = T_c2v.repeat(args.batch, n_cams, 1, 1)
        T_c2v[:, :, 0:3, 0:3] = rots
        T_c2v[:, :, 0:3, 3] = trans
        pix_coords = net.calc_pix_coords(intrins, T_c2v, normalize=True)

        dummy_input = (image, pix_coords)
        output_names = [
            'task_0/heatmap',    # torch.Size([1, 1, 192, 96])
            'task_0/bbox',       # torch.Size([1, 8, 192, 96]), {reg: 2, height: 1, dim: 3, rot: 2}
            'task_1/heatmap',    # torch.Size([1, 2, 192, 96])
            'task_1/bbox',       # torch.Size([1, 8, 192, 96]), {reg: 2, height: 1, dim: 3, rot: 2}
            'task_2/heatmap',    # torch.Size([1, 2, 192, 96])
            'task_2/bbox',       # torch.Size([1, 8, 192, 96]), {reg: 2, height: 1, dim: 3, rot: 2}
        ]
        onnx_dir = "onnx/%s_%dx%d_bs%d.onnx"%(net.name, hyp['width'], hyp['height'], args.batch)
        torch.onnx.export(net, dummy_input,
                          onnx_dir, verbose=True, opset_version=11,
                          input_names=['image', 'pix_coords'],
                          output_names=output_names,
                          export_params=True)
        flops, params = profile(net, inputs=dummy_input)
        print("flops: {:.3f}G".format(flops / 1e9))
        print("params: {:.3f}M".format(params / 1e6))

        # Inference with pytorch
        check_output_name = 'task_0/heatmap'
        pred_pt = net(*dummy_input)[output_names.index(check_output_name)]
        # Inference with onnx
        sess = rt.InferenceSession(onnx_dir, providers=['CUDAExecutionProvider'])
        dummy_input = dict(image=image.cpu().numpy(),
                           pix_coords=pix_coords.cpu().numpy())
        pred_onnx = sess.run([check_output_name], dummy_input)

        print(f'pytorch-onnx diff: {np.abs(pred_onnx[0] - pred_pt.cpu().numpy()).max()}')
    elif args.mode == 'eval':
        raise NotImplementedError
    else:
        print(f'Mode {args.mode} is invalid!')
