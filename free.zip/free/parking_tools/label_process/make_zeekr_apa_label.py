import os
import shutil
import random
import argparse
from os.path import join as opj

parser = argparse.ArgumentParser(description='make training dataset')
parser.add_argument('--src_dir', default='', type=str, help='original dataset dir')
parser.add_argument('--dst_dir', default='', type=str, help='training dataset dir')
parser.add_argument('--split_ratio', default=0.8, type=float, help='training dataset dir')
opt = parser.parse_args()

class MakeTrainDataset(object):
    def __init__(self, src_dir, dst_dir, split_ratio=0.8):
        self.src_dir = src_dir
        self.dst_dir = dst_dir
        self.dst_image_dir = opj(self.dst_dir, "image")
        self.dst_label_dir = opj(self.dst_dir, "label")
        self.split_ratio = split_ratio
        if not os.path.isdir(self.dst_image_dir):
            os.makedirs(self.dst_image_dir)
        if not os.path.isdir(self.dst_label_dir):
            os.makedirs(self.dst_label_dir)
    
    def generate_images_and_labels(self):
        exist_dir = os.listdir(self.dst_image_dir)
        for sub_dir in os.listdir(self.src_dir):
            if sub_dir not in exist_dir:
                self.copy_images_and_labels(sub_dir)
                

    def copy_images_and_labels(self, sub_dir):
        images = os.listdir(opj(self.src_dir, sub_dir, "png"))
        labels = os.listdir(opj(self.src_dir, sub_dir, "json"))
        assert(len(images) == len(labels))
        shutil.copytree(opj(self.src_dir, sub_dir, "png"), opj(self.dst_image_dir, sub_dir))
        shutil.copytree(opj(self.src_dir, sub_dir, "json"), opj(self.dst_label_dir, sub_dir))
        self.split_image(sub_dir, images)


    def split_image(self, sub_dir, images):
        split_number = self.split_ratio * len(images)
        train_images = random.sample(images, int(split_number))
        test_images = [image for image in images if image not in train_images]
        print('The number of train images is : ' + str(len(train_images)) + '\n'
              + 'The number of test images is : ' + str(len(test_images)) + '\n')
        with open(os.path.join(self.dst_dir, 'train_list.txt'), 'a') as f:
            for image in train_images:
                f.write(opj("image", sub_dir, image) + '\n')

        with open(os.path.join(self.dst_dir, 'test_list.txt'), 'a') as f:
            for image in test_images:
                f.write(opj("image", sub_dir, image) + '\n')


if __name__ == '__main__':
    if not opt.src_dir or not opt.dst_dir:
        print("please enter dir of dataset")
    make_train_dataset = MakeTrainDataset(opt.src_dir, opt.dst_dir, opt.split_ratio)
    make_train_dataset.generate_images_and_labels()

