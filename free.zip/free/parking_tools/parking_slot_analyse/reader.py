from rclpy.serialization import deserialize_message
from rosidl_runtime_py.utilities import get_message
import rosbag2_py


class Reader(object):
    """Reader"""
    # db3 can be a db3 file or a folder contain db3 files
    def __init__(self, db3):
        self._db3 = db3
        self._reader = rosbag2_py.SequentialReader()
        storage_options, converter_options = self.__get_rosbag_options(self._db3)
        self._reader.open(storage_options, converter_options)
        topic_types = self._reader.get_all_topics_and_types()
        self._topic_msg_dict = {topic_types[i].name: get_message(topic_types[i].type) for i in range(len(topic_types))}

    def read_messages(self, topics=None):
        if topics is None:
            topics = []
        storage_filter = rosbag2_py.StorageFilter(topics=topics)
        self._reader.set_filter(storage_filter)
        while self._reader.has_next():
            topic, data, t = self._reader.read_next()
            msg = deserialize_message(data, self._topic_msg_dict[topic])
            yield topic, msg, t
        return True

    @staticmethod
    def __get_rosbag_options(path, serialization_format='cdr'):
        storage_options = rosbag2_py.StorageOptions(uri=path, storage_id='sqlite3')
        converter_options = rosbag2_py.ConverterOptions(
            input_serialization_format=serialization_format,
            output_serialization_format=serialization_format)
        return storage_options, converter_options


if __name__ == "__main__":
    # example
    reader = Reader("/zdrive/jy/uproute/new.db3")
    for topic, msg, t in reader.read_messages():
        print(topic, msg.header, t)
