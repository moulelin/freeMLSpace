import torch
import torch.nn as nn
import torch.nn.functional as F


def _safelog(x, eps=1e-6):
    return torch.log(torch.max(x, torch.ones_like(x) * eps))


class CenterFocalLoss(nn.Module):
    """Modified focal loss. Exactly the same as CornerNet."""

    def __init__(self, alpha=4, beta=2):
        super().__init__()
        self.alpha = alpha
        self.beta = beta

    def forward(self, pred, gt):
        pred = pred.float()
        pos_inds = gt.eq(1).float()
        neg_inds = gt.lt(1).float()

        neg_weights = torch.pow(1 - gt, self.alpha)

        loss = 0
        pos_loss = _safelog(pred) * torch.pow(1 - pred, self.beta) * pos_inds
        neg_loss = (
            _safelog(1 - pred) * torch.pow(pred, self.beta) * neg_weights * neg_inds
        )

        num_pos = pos_inds.float().sum()
        pos_loss = pos_loss.sum()
        neg_loss = neg_loss.sum()

        if num_pos == 0:
            loss = loss - neg_loss
        else:
            loss = loss - (pos_loss + neg_loss) / num_pos
        return loss


class FocalLoss(nn.Module):
    def __init__(
        self, class_num, alpha=None, gamma=2, ignore_label=None, size_average=True
    ):
        super(FocalLoss, self).__init__()
        if alpha is None:
            self.alpha = torch.ones((class_num,))
        elif isinstance(alpha, list):
            assert (
                len(alpha) == class_num
            ), "ERROR: focal loss alpha is list, but length not equal class num"
            self.alpha = torch.Tensor(alpha)
        elif isinstance(alpha, int) or isinstance(alpha, float):
            self.alpha = torch.ones((class_num,)) * alpha
        else:
            print("ERROR: type of alpha not support, alpha: ", alpha)
            exit()

        self.gamma = gamma
        self.class_num = class_num
        self.size_average = size_average
        self.ignore_label = ignore_label

    def forward(self, pred, gt):
        pred = pred.reshape(-1, self.class_num)
        gt = gt.reshape(-1)

        if self.ignore_label is not None:
            mask = gt != self.ignore_label
            pred = pred[mask]
            gt = gt[mask]

        loss = torch.zeros(1, device=pred.device)
        if pred.size(0) > 0:
            logits = F.softmax(pred)

            alpha = self.alpha.to(pred.device)
            alpha = alpha[gt]

            class_mask = torch.zeros_like(logits)
            ids = gt.view(-1, 1)
            class_mask.scatter_(1, ids.data, 1.0)
            probs = (logits * class_mask).sum(1).view(-1)

            focal_loss = -alpha * torch.pow((1 - probs), self.gamma) * torch.log(probs)

            if self.size_average:
                loss += focal_loss.mean()
            else:
                loss += focal_loss.sum()
        return loss
