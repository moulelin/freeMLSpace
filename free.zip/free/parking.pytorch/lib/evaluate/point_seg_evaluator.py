import numpy as np

import torch

from .seg_evaluator import SegEvaluator


class PointSegEvaluator(SegEvaluator):
    def __init__(self, opt, decoder, dataset):
        super(PointSegEvaluator, self).__init__(opt, decoder, dataset)

    def _get_results(self, avg_inference_t):
        self.generate_seg_results()
        self.generate_point_results()
        self.results["inference_time"] = avg_inference_t
        self.results["batchsize"] = self.opt.val_batch

    def _eval(self, preds, label, net, sample_idx):
        point_pred, center_pred, seg_pred = self.align_outputs(preds, net)

        point_label, center_label, seg_label = (
            label["label_point"],
            label["label_center"],
            label["label_seg"],
        )
        point_label, center_label, seg_label = self.decoder.extract_truth(
            point_label, center_label, seg_label
        )
        self._eval_point(point_label, point_pred, sample_idx, "point")
        self._eval_point(center_label, center_pred, sample_idx, "center")
        self._eval_seg(seg_label, seg_pred, sample_idx)
        return point_pred, center_pred, seg_pred

    def _get_infer_buffer(self):
        buffer = {}
        buffer["hist"] = torch.zeros(self.num_classes, self.num_classes).cuda()
        buffer["point_pred"] = []
        buffer["point_tp_offset"] = []
        buffer["point_truth"] = []
        buffer["center_pred"] = []
        buffer["center_tp_offset"] = []
        buffer["center_truth"] = []
        return buffer

    def generate_point_results(self):
        point_pred_list = self._infer_buffer["point_pred"]
        point_truth_list = self._infer_buffer["point_truth"]
        center_pred_list = self._infer_buffer["center_pred"]
        center_truth_list = self._infer_buffer["center_truth"]

        (
            point_mAP,
            point_AP,
            point_Precision,
            point_Recall,
            point_F1,
            point_PR_list,
        ) = self._calc_mAP(point_pred_list, point_truth_list, 2)
        (
            center_mAP,
            center_AP,
            center_Precision,
            center_Recall,
            center_F1,
            center_PR_list,
        ) = self._calc_mAP(center_pred_list, center_truth_list, 2)

        point_tp_offset = np.mean(self._infer_buffer["point_tp_offset"])
        center_tp_offset = np.mean(self._infer_buffer["center_tp_offset"])

        self.results["point"] = {
            "mAP": point_mAP,
            "AP": point_AP,
            "Precision": point_Precision,
            "Recall": point_Recall,
            "F1-score": point_F1,
            "PR": point_PR_list,
            "tp_offset": point_tp_offset,
        }
        self.results["center"] = {
            "mAP": center_mAP,
            "AP": center_AP,
            "Precision": center_Precision,
            "Recall": center_Recall,
            "F1-score": center_F1,
            "PR": center_PR_list,
            "tp_offset": center_tp_offset,
        }

        if self.opt.scene:
            for scene_name in self._scene_infer_buffers:
                if scene_name not in self.scene_results:
                    self.scene_results[scene_name] = {}
                for scene_value in self._scene_infer_buffers[scene_name]:
                    point_pred_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["point_pred"]
                    point_truth_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["point_truth"]
                    point_tp_offset = np.mean(
                        self._scene_infer_buffers[scene_name][scene_value][
                            "point_tp_offset"
                        ]
                    )
                    center_pred_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["center_pred"]
                    center_truth_list = self._scene_infer_buffers[scene_name][
                        scene_value
                    ]["center_truth"]
                    center_tp_offset = np.mean(
                        self._scene_infer_buffers[scene_name][scene_value][
                            "center_tp_offset"
                        ]
                    )

                    (
                        point_mAP,
                        point_AP,
                        point_Precision,
                        point_Recall,
                        point_F1,
                        point_PR_list,
                    ) = self._calc_mAP(point_pred_list, point_truth_list, 2)
                    (
                        center_mAP,
                        center_AP,
                        center_Precision,
                        center_Recall,
                        center_F1,
                        center_PR_list,
                    ) = self._calc_mAP(center_pred_list, center_truth_list, 2)

                    if scene_value not in self.scene_results[scene_name]:
                        self.scene_results[scene_name][scene_value] = {}
                    self.scene_results[scene_name][scene_value]["point"] = {
                        "mAP": point_mAP,
                        "AP": point_AP,
                        "Precision": point_Precision,
                        "Recall": point_Recall,
                        "F1-score": point_F1,
                        "PR": point_PR_list,
                        "tp_offset": point_tp_offset,
                    }
                    self.scene_results[scene_name][scene_value]["center"] = {
                        "mAP": center_mAP,
                        "AP": center_AP,
                        "Precision": center_Precision,
                        "Recall": center_Recall,
                        "F1-score": center_F1,
                        "PR": center_PR_list,
                        "tp_offset": center_tp_offset,
                    }

    def align_outputs(self, preds, net):
        if net.model_type == "pth":
            point_pred, center_pred, seg_pred = preds
        else:
            seg_pred = torch.tensor(
                preds[0]
                .reshape(self.opt.val_batch, self.opt.h_input, self.opt.w_input)
                .astype("int32")
            ).cuda()
            point_pred = (
                torch.tensor(preds[1].reshape(self.opt.val_batch, 128, -1))
                .float()
                .cuda()
            )
            center_pred = (
                torch.tensor(preds[2].reshape(self.opt.val_batch, 128, -1))
                .float()
                .cuda()
            )
        point_cls = (point_pred[:, :, 0:1] > self.opt.point_cls_thresh) * 1.0
        new_point_pred = torch.cat([point_cls, point_pred[:, :, 1:]], dim=2)
        center_cls = (center_pred[:, :, 0:1] > self.opt.center_cls_thresh) * 1.0
        new_center_pred = torch.cat([center_cls, center_pred[:, :, 1:]], dim=2)
        return new_point_pred, new_center_pred, seg_pred

    def _match_point_pred_truth(self, pred, truth, th):
        num_preds = pred.size(0)
        num_truth = truth.size(0)
        mask_TPFP = torch.zeros(num_preds).cuda()
        mask_TPFN = torch.zeros(num_truth).cuda()

        tp_offset = 0
        tp_count = 0
        pred_dis = 0
        pred_count = 0
        for i in range(num_preds):
            if num_truth > 0:
                dis = torch.sqrt(
                    (truth[:, 2] - pred[i, 2]) ** 2 + (truth[:, 3] - pred[i, 3]) ** 2
                )
                min_dis, idx = dis.min(0)
                pred_dis += min_dis.cpu().numpy()
                pred_count += 1
                if (
                    (min_dis < th)
                    and (pred[i, 0] == truth[idx, 0])
                    and (mask_TPFN[idx] == 0)
                ):
                    mask_TPFN[idx] = 1
                    mask_TPFP[i] = 1
                    tp_offset += min_dis.cpu().numpy()
                    tp_count += 1
        pred_out = torch.cat([pred[:, :2], mask_TPFP.view(-1, 1)], dim=1)

        if tp_count:
            tp_offset = tp_offset / tp_count
        else:
            tp_offset = None
        return pred_out, tp_offset

    def _eval_point(self, label, pred, sample_idx, mode="point"):
        B = label.size(0)
        if mode == "point":
            thresh_point_dis = self.opt.thresh_point_dis
            thresh_point_score = self.opt.thresh_point
        elif mode == "center":
            thresh_point_dis = self.opt.thresh_center_dis
            thresh_point_score = self.opt.thresh_center
        else:
            print("{} not support".format(mode))
            exit()

        for i in range(B):
            truth = label[i].clone()
            truth = truth[truth[:, 1] == 1]
            pre = pred[i].clone()
            pre = pre[pre[:, 1] > thresh_point_score]
            if pre != None:
                pred_out, tp_offset = self._match_point_pred_truth(
                    pre, truth, thresh_point_dis
                )
                self._infer_buffer[f"{mode}_pred"].append(pred_out)
                if tp_offset:
                    self._infer_buffer[f"{mode}_tp_offset"].append(tp_offset)
                if self.opt.scene:
                    scene_infos = self.opt.scene_infos_list[sample_idx]
                    for scene_name, scene_value in scene_infos.items():
                        if scene_value in self.opt.filter_keys:
                            continue
                        self._scene_infer_buffers[scene_name][scene_value][
                            f"{mode}_pred"
                        ].append(pred_out)
                        if tp_offset:
                            self._scene_infer_buffers[scene_name][scene_value][
                                f"{mode}_tp_offset"
                            ].append(tp_offset)

            if truth != None:
                self._infer_buffer[f"{mode}_truth"].append(truth[:, 0].view(-1, 1))
                if self.opt.scene:
                    scene_infos = self.opt.scene_infos_list[sample_idx]
                    for scene_name, scene_value in scene_infos.items():
                        if scene_value in self.opt.filter_keys:
                            continue
                        self._scene_infer_buffers[scene_name][scene_value][
                            f"{mode}_truth"
                        ].append(truth[:, 0].view(-1, 1))

    def _calc_PR(self, pred, truth):
        prob_obj = pred[:, 1]
        _, idx = prob_obj.sort(descending=True)
        pred_sorted = pred.index_select(0, idx).clone()
        npos = truth.size()[0]
        TP = pred_sorted[:, -1].float() == 1
        FP = pred_sorted[:, -1].float() == 0
        acc_FP = FP.cumsum(dim=0).float()
        acc_TP = TP.cumsum(dim=0).float()
        rec = (acc_TP / npos + 1e-16).view(-1, 1)
        prec = torch.div(acc_TP, (acc_FP + acc_TP)).view(-1, 1)
        PR = torch.cat((rec, prec), dim=1)
        if len(PR) == 0:
            PR = torch.zeros((1, 2)).cuda()
        return PR

    def _calc_AP(self, PR):
        AP = 0
        num, _ = PR.size()
        ap = PR[0, 1] * (PR[0, 0] - 0)
        AP = AP + ap
        for i in range(1, num):
            ap = PR[i, 1] * (PR[i, 0] - PR[i - 1, 0])
            AP = AP + ap
        if torch.isnan(AP):
            AP = 0
        return AP

    def _calc_mAP(self, pred_list, truth_list, num_cls):
        AP_array = torch.zeros(num_cls)
        Precision_array = torch.zeros(num_cls)
        Recall_array = torch.zeros(num_cls)
        F1_array = torch.zeros(num_cls)
        total_pred = torch.cat(pred_list, dim=0).cuda()
        total_truth = torch.cat(truth_list, dim=0).cuda()
        PR_list = []
        for i in range(num_cls):
            mask1 = total_pred[:, 0] == i
            pred = total_pred[mask1, :].clone()
            mask2 = total_truth[:, 0] == i
            truth = total_truth[mask2, :].clone()
            PR = self._calc_PR(pred, truth)
            PR_list.append(PR.cpu().numpy())
            Precision_array[i] = PR[-1, 1]
            Recall_array[i] = PR[-1, 0]
            F1_array[i] = (
                2
                * Precision_array[i]
                * Recall_array[i]
                / (Precision_array[i] + Recall_array[i] + 1e-16)
            )
            AP = self._calc_AP(PR)
            AP_array[i] = AP
        mAP = AP_array.sum() / num_cls
        return (
            mAP.cpu().numpy(),
            AP_array.cpu().numpy(),
            Precision_array.cpu().numpy(),
            Recall_array.cpu().numpy(),
            F1_array.cpu().numpy(),
            PR_list,
        )
