import torch
import torch.nn as nn
import torch.nn.functional as F


class BinaryDiceLoss(nn.Module):
    def __init__(self, smooth_scale=1):
        super(BinaryDiceLoss, self).__init__()
        self.smooth_scale = smooth_scale

    def forward(self, pred, gt):
        N = gt.size()[0]
        pred_map = pred.view(N, -1)
        gt_map = gt.view(N, -1)

        inter = (pred_map * gt_map).sum(dim=1)
        dice_eff = (2 * inter + self.smooth_scale) / (
            pred_map.sum(dim=1) + gt_map.sum(dim=1) + self.smooth_scale
        )
        loss = 1 - dice_eff.sum() / N
        return loss


class MultiClassDiceLoss(nn.Module):
    def __init__(self, smooth_scale=1, ignore_label=-1):
        super(MultiClassDiceLoss, self).__init__()
        self.smooth_scale = smooth_scale
        self.ignore_label = ignore_label
        self.binary_dice_loss = BinaryDiceLoss(self.smooth_scale)

    def forward(self, pred, gt):
        """
        pred: (NCHW)
        gt: (NHW)
        """

        num_class = pred.size()[1]

        logits = F.softmax(pred, dim=1)

        loss = 0
        for cls_id in range(num_class):
            if cls_id == self.ignore_label:
                continue
            gt_mask = (gt == cls_id) * 1.0
            single_dice_loss = self.binary_dice_loss(logits[:, cls_id, :, :], gt_mask)
            loss += single_dice_loss
        return loss / num_class


class DiceLoss(nn.Module):
    def __init__(self, num_class, ignore_label):
        super(DiceLoss, self).__init__()
        self.num_class = num_class
        self.ignore_label = ignore_label

    def forward(self, pred, truth):
        loss = 0
        pred = F.softmax(pred.float(), dim=1)
        for i in range(self.num_class):
            if i == self.ignore_label:
                continue
            gt_mask = (truth == i) * 1.0
            if gt_mask.sum() == 0:
                continue

            pred_score = pred[:, i, :, :]
            inter = 2 * (pred_score * gt_mask).sum()
            union = torch.pow(pred_score, 2).sum() + torch.pow(gt_mask, 2).sum() + 1

            cls_dice_loss = 1 - inter / union
            loss += cls_dice_loss
        return loss
