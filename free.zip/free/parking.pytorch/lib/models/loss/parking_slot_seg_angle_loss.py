import cv2

import torch
import torch.nn as nn
import torch.nn.functional as F

from .common_loss.ohem_loss import OhemCELoss
from .common_loss.focal_loss import CenterFocalLoss
from .common_loss.dice_loss import MultiClassDiceLoss

# from .common_loss.lovasz_softmax import Lovasz_softmax


class SegLoss(nn.Module):
    def __init__(self, opt):
        super(SegLoss, self).__init__()
        self.opt = opt
        self.ohemce_loss = OhemCELoss(
            thresh=self.opt.thresh_ohem,
            ignore_label=self.opt.ignore_label,
            norm_value=self.opt.n_cats - 1,
            reduction="mean",
        )
        self.multi_dice_loss = MultiClassDiceLoss(
            smooth_scale=1,
            ignore_label=self.opt.ignore_label,
        )
        # self.ls = Lovasz_softmax(ignore=self.opt.ignore_label)

    def forward(self, pred, truth):
        loss_logits = self.ohemce_loss(pred["logits"], truth)
        loss_dice = self.multi_dice_loss(pred["logits"], truth)
        # loss_lovasz = self.ls(pred["logits"], truth)

        d_truth = (
            F.interpolate(truth.float().unsqueeze(1), scale_factor=0.125)
            .squeeze(1)
            .long()
        )

        loss_logits_aux2 = self.ohemce_loss(pred["logits_aux2"], d_truth)
        loss_logits_aux3 = self.ohemce_loss(pred["logits_aux3"], d_truth)
        loss_logits_aux4 = self.ohemce_loss(pred["logits_aux4"], d_truth)
        loss_logits_aux5 = self.ohemce_loss(pred["logits_aux5"], d_truth)
        loss = (
            loss_logits
            + loss_dice
            + loss_logits_aux2
            + loss_logits_aux3
            + loss_logits_aux4
            + loss_logits_aux5
            # + loss_lovasz
        )
        loss_tags = {
            "seg_loss": loss_logits.clone().detach().cpu().numpy(),
            "dice_loss": loss_dice.clone().detach().cpu().numpy(),
            "aux0_loss": loss_logits_aux2.clone().detach().cpu().numpy(),
            "aux1_loss": loss_logits_aux3.clone().detach().cpu().numpy(),
            "aux2_loss": loss_logits_aux4.clone().detach().cpu().numpy(),
            "aux3_loss": loss_logits_aux5.clone().detach().cpu().numpy(),
            # "lovasz_loss": loss_lovasz.clone().detach().cpu().numpy(),
        }
        return loss, loss_tags


class PointLoss(nn.Module):
    def __init__(self, opt):
        super(PointLoss, self).__init__()
        self.opt = opt
        self.pred_len = 4
        self.focal_cls = CenterFocalLoss(alpha=4, beta=2)
        self.F1off = nn.SmoothL1Loss()
        self.mse_loss = nn.MSELoss()
        self.bce = nn.BCEWithLogitsLoss()

        self.w_map = self.opt.loss_point_weight_dict["w_map"]
        self.w_mse = self.opt.loss_point_weight_dict["w_mse"]
        self.w_cls = self.opt.loss_point_weight_dict["w_cls"]
        self.w_off = self.opt.loss_point_weight_dict["w_off"]

    def forward(self, pred, truth):
        device = pred.device
        lcls, loff = torch.zeros(1, device=device), torch.zeros(1, device=device)
        pred = pred.permute(0, 2, 3, 1).contiguous().view(-1, self.pred_len)
        truth = truth.view(-1, self.pred_len)

        pmap = pred[:, 0:1].float().sigmoid()
        pcls = pred[:, 1:2].float()
        poff = pred[:, 2:4].float().sigmoid()

        tmap = truth[:, 0:1]
        tcls = truth[:, 1:2]
        toff = truth[:, 2:4]

        l_map = self.focal_cls(pmap, tmap)
        l_mse = self.mse_loss(pmap, tmap)

        mask = tmap[:, 0].eq(1)
        if mask.sum() > 0:
            lcls = self.bce(pcls[mask].view(-1), tcls[mask].view(-1))
            loff = self.F1off(poff[mask], toff[mask])

        l_map = l_map * self.w_map
        l_mse = l_mse * self.w_mse
        lcls = lcls * self.w_cls
        loff = loff * self.w_off
        loss = l_map + l_mse + lcls + loff
        loss_tags = {
            "point_map": l_map.clone().detach().cpu().numpy(),
            "point_mse": l_mse.clone().detach().cpu().numpy(),
            "point_cls": lcls.clone().detach().cpu().numpy(),
            "point_off": loff.clone().detach().cpu().numpy(),
            "point_loss": loss.clone().detach().cpu().numpy(),
        }
        return loss, loss_tags


class CenterLoss(nn.Module):
    def __init__(self, opt):
        super(CenterLoss, self).__init__()
        self.opt = opt
        self.pred_len = 14
        self.focal_cls = CenterFocalLoss(alpha=4, beta=2)
        self.F1off = nn.SmoothL1Loss()
        self.mse_loss = nn.MSELoss()
        self.bce = nn.BCEWithLogitsLoss()

        self.w_map = self.opt.loss_center_weight_dict["w_map"]
        self.w_mse = self.opt.loss_center_weight_dict["w_mse"]
        self.w_cls = self.opt.loss_center_weight_dict["w_cls"]
        self.w_off = self.opt.loss_center_weight_dict["w_off"]
        self.w_angle = self.opt.loss_center_weight_dict["w_angle"]
        self.w_p = self.opt.loss_center_weight_dict["w_p"]

    def forward(self, pred, truth):
        device = pred.device
        lcls, loff = torch.zeros(1, device=device), torch.zeros(1, device=device)
        langle, l_poff = torch.zeros(1, device=device), torch.zeros(1, device=device)
        dis_loss, margin_loss, vertical_loss = (
            torch.zeros(1, device=device),
            torch.zeros(1, device=device),
            torch.zeros(1, device=device),
        )
        pred = pred.permute(0, 2, 3, 1).contiguous().view(-1, self.pred_len)
        truth = truth.view(-1, self.pred_len)

        pmap = pred[:, 0:1].float().sigmoid()
        pcls = pred[:, 1:2].float()
        poff = pred[:, 2:4].float().sigmoid()
        pangle = 2 * pred[:, 4:6].float().sigmoid() - 1
        p_poff = pred[:, 6:14]

        tmap = truth[:, 0:1]
        tcls = truth[:, 1:2]
        toff = truth[:, 2:4]
        tangle = truth[:, 4:6]
        t_poff = truth[:, 6:14]

        l_map = self.focal_cls(pmap, tmap)
        l_mse = self.mse_loss(pmap, tmap)

        mask = tmap[:, 0].eq(1)
        if mask.sum() > 0:

            sample_pcls = pcls[mask].view(-1)
            sample_tcls = tcls[mask].view(-1)
            cls_mask = sample_tcls.not_equal(self.opt.ignore_label)

            if cls_mask.sum() > 0:
                lcls = self.bce(sample_pcls[cls_mask], sample_tcls[cls_mask])

            loff = self.F1off(poff[mask], toff[mask])
            langle = self.F1off(pangle[mask], tangle[mask]) + self.mse_loss(
                pangle[mask], tangle[mask]
            )
            l_poff = self.F1off(p_poff[mask], t_poff[mask]) + self.mse_loss(
                p_poff[mask], t_poff[mask]
            )

            ### offset dis
            enter_dis = torch.sqrt(
                torch.pow((p_poff[:, 0] - p_poff[:, 6]), 2)
                + torch.pow((p_poff[:, 1] - p_poff[:, 7]), 2)
            )
            end_dis = torch.sqrt(
                torch.pow((p_poff[:, 2] - p_poff[:, 4]), 2)
                + torch.pow((p_poff[:, 3] - p_poff[:, 5]), 2)
            )
            gt_enter_dis = torch.sqrt(
                torch.pow((t_poff[:, 0] - t_poff[:, 6]), 2)
                + torch.pow((t_poff[:, 1] - t_poff[:, 7]), 2)
            )
            gt_end_dis = torch.sqrt(
                torch.pow((t_poff[:, 2] - t_poff[:, 4]), 2)
                + torch.pow((t_poff[:, 3] - t_poff[:, 5]), 2)
            )
            margin_enter_loss = torch.max(
                9 - enter_dis[mask], torch.zeros_like(enter_dis[mask])
            ).mean()
            margin_end_loss = torch.max(
                9 - end_dis[mask], torch.zeros_like(end_dis[mask])
            ).mean()
            dis_enter_loss = self.F1off(enter_dis[mask], gt_enter_dis[mask])
            dis_end_loss = self.F1off(end_dis[mask], gt_end_dis[mask])
            margin_loss = margin_enter_loss + margin_end_loss * 0.1
            dis_loss = (dis_enter_loss + dis_end_loss) * 0.01

            ### offset angle
            enter_dx = p_poff[:, 0] - p_poff[:, 6]
            enter_dy = p_poff[:, 1] - p_poff[:, 7]
            end_dx = p_poff[:, 2] - p_poff[:, 4]
            end_dy = p_poff[:, 3] - p_poff[:, 5]

            enter_angle = torch.cat([enter_dx.view(-1, 1), enter_dy.view(-1, 1)], dim=1)
            enter_angle = enter_angle / torch.sqrt(
                torch.pow(enter_angle, 2).sum(dim=1, keepdim=True)
            )
            end_angle = torch.cat([end_dx.view(-1, 1), end_dy.view(-1, 1)], dim=1)
            end_angle = end_angle / torch.sqrt(
                torch.pow(end_angle, 2).sum(dim=1, keepdim=True)
            )

            enter_vertical_loss = torch.abs(
                (enter_angle[mask] * tangle[mask]).sum(dim=1)
            ).mean()
            end_vertical_loss = torch.abs(
                (end_angle[mask] * tangle[mask]).sum(dim=1)
            ).mean()
            vertical_loss = enter_vertical_loss + end_vertical_loss

        l_map = l_map * self.w_map
        l_mse = l_mse * self.w_mse
        lcls = lcls * self.w_cls
        loff = loff * self.w_off
        l_poff = l_poff * self.w_p
        langle = langle * self.w_angle

        loss = (
            l_map
            + l_mse
            + lcls
            + loff
            + l_poff
            + langle
            + dis_loss
            + margin_loss
            + vertical_loss
        )
        loss_tags = {
            "center_map": l_map.clone().detach().cpu().numpy(),
            "center_mse": l_mse.clone().detach().cpu().numpy(),
            "center_cls": lcls.clone().detach().cpu().numpy(),
            "center_off": loff.clone().detach().cpu().numpy(),
            "center_p_off": l_poff.clone().detach().cpu().numpy(),
            "center_angle": langle.clone().detach().cpu().numpy(),
            "dis_loss": dis_loss.clone().detach().cpu().numpy(),
            "margin_loss": margin_loss.clone().detach().cpu().numpy(),
            "vertical_loss": vertical_loss.clone().detach().cpu().numpy(),
            "center_loss": loss.clone().detach().cpu().numpy(),
        }
        return loss, loss_tags


class ParkingSlotSegAngleLoss(nn.Module):
    def __init__(self, opt):
        super(ParkingSlotSegAngleLoss, self).__init__()
        self.opt = opt
        self.seg_loss = SegLoss(self.opt)
        self.point_loss = PointLoss(self.opt)
        self.center_loss = CenterLoss(self.opt)
        self.w_seg = self.opt.w_seg
        self.w_point = self.opt.w_point
        self.w_center = self.opt.w_center

    def forward(self, pred, truth):
        point_pred, center_pred, seg_pred = pred
        loss_point, point_tags = self.point_loss(point_pred, truth["label_point"])
        loss_center, center_tags = self.center_loss(center_pred, truth["label_center"])
        loss_seg, seg_tags = self.seg_loss(seg_pred, truth["label_seg"])
        loss = (
            loss_point * self.w_point
            + loss_center * self.w_center
            + loss_seg * self.w_seg
        )
        loss_tags = {**point_tags, **center_tags, **seg_tags}
        loss_tags["loss"] = (
            loss_tags["seg_loss"] + loss_tags["point_loss"] + loss_tags["center_loss"]
        )
        return loss, loss_tags
