from torch.utils import data
import numpy as np
import os
import json
import time

from .base_dataset import BaseDataset

labels_info = [
    {"name": "background", "id": 0, "train_id": 0, "color": (200, 0, 200)},
    {"name": "entry line", "id": 1, "train_id": 0, "color": (0, 255, 0)},
    {"name": "separate line", "id": 2, "train_id": 0, "color": (20, 20, 255)},
    {"name": "wheel stop", "id": 3, "train_id": 1, "color": (185, 122, 87)},
    {"name": "speed bump", "id": 4, "train_id": 2, "color": (110, 110, 0)},
    {"name": "lane", "id": 5, "train_id": 3, "color": (255, 193, 37)},
    {"name": "wall", "id": 6, "train_id": 4, "color": (241, 230, 255)},
    {"name": "pillar", "id": 7, "train_id": 5, "color": (255, 246, 143)},
    {"name": "high obstacle", "id": 8, "train_id": 0, "color": (233, 100, 0)},
    {"name": "low obstacle", "id": 9, "train_id": 0, "color": (233, 134, 100)},
    {"name": "park lock open", "id": 10, "train_id": 0, "color": (233, 100, 200)},
    {"name": "park lock closed", "id": 11, "train_id": 0, "color": (233, 50, 50)},
    {"name": "vehicle", "id": 12, "train_id": 0, "color": (255, 0, 0)},
    {"name": "vegetation", "id": 13, "train_id": 0, "color": (147, 253, 194)},
    {"name": "curb", "id": 14, "train_id": 6, "color": (128, 128, 0)},
    {"name": "pedestrian", "id": 15, "train_id": 0, "color": (204, 153, 255)},
    {"name": "drains", "id": 16, "train_id": 7, "color": (238, 162, 173)},
    {"name": "ego car", "id": 0, "train_id": 0, "color": (255, 20, 255)},
    {"name": "ground arrow", "id": 17, "train_id": 8, "color": (120, 100, 10)},
    {"name": "cone", "id": 18, "train_id": 0, "color": (120, 100, 10)},
    {"name": "enclosure", "id": 19, "train_id": 0, "color": (120, 100, 10)},
]

slot_map = {
    "vertical": 0,
    "vertical slot": 0,
    "horizontal": 1,
    "horizontal slot": 1,
    "oblique": 2,
    "oblique slot": 2,
}


status_info = {"empty": 0, "occupied": 1}


class ParkingSlotDataset(BaseDataset):
    def __init__(self, opt, mode):
        super(ParkingSlotDataset, self).__init__(opt, mode)

        self.label_ignore = opt.ignore_label
        self._label_map = np.arange(256).astype(np.uint8)
        self._labels_info = labels_info
        for el in self._labels_info:
            self._label_map[el["id"]] = el["train_id"]
        self._get_dataset()
        self.len = len(self.label_dict["image_list"])

    @property
    def label_dict(self):
        return self._label_dict

    @property
    def label_map(self):
        return self._label_map

    @property
    def labels_info(self):
        return self._labels_info

    def _get_dataset(self):
        st = time.time()
        if self.mode == "train":
            datalist_dict = self.train_path_dict
        else:
            datalist_dict = self.test_path_dict

        print(datalist_dict)

        file_list = []
        for key in datalist_dict:
            if datalist_dict[key] in ["", " "]:
                continue
            with open(datalist_dict[key], "r") as f:
                lines = f.read().splitlines()
                file_list.extend(lines)
        # rm repeat
        lines = list(dict.fromkeys(file_list))
        lines.sort()
        et = time.time()
        print("read txt: ", et - st, flush=True)

        image_list = []
        label_seg_list = []
        label_slot_list = []
        label_wheel_stop_list = []
        label_speed_bump_list = []
        label_slot_type_list = []

        st = time.time()
        for line in lines:
            image_path = os.path.join(self.data_root, line)

            if not os.path.exists(image_path):
                print(f"not find {image_path}")
                continue

            label_path = os.path.join(self.proc_root, line.replace("image", "label"))
            json_path = os.path.join(
                self.data_root, line.replace("image", "json").replace("png", "json")
            )

            wheel_stop_list = self._get_wheel_stop(json_path)
            speed_bump_list = self._get_speed_bump(json_path)
            slot_list, slot_type_list = self._get_slot(json_path)

            try:
                if len(slot_list) > 0:
                    label_slot = np.concatenate(slot_list, axis=0)
                else:
                    label_slot = np.array(slot_list).reshape(-1, 9)
                assert label_slot.shape[1] == 9, "label_slot shape 1 != 9"
            except Exception as e:
                print(e)
                print(f"file error: {json_path}")
                continue

            label_slot_list.append(label_slot)
            image_list.append(image_path)
            label_seg_list.append(label_path)
            label_slot_type_list.append(slot_type_list)
            label_wheel_stop_list.append(wheel_stop_list)
            label_speed_bump_list.append(speed_bump_list)
        et = time.time()
        print("prase label: ", et - st, flush=True)

        assert len(image_list) == len(label_seg_list)
        print("actual data num: ", len(image_list))
        self.len = len(image_list)

        self._label_dict = dict(
            image_list=image_list,
            label_seg_list=label_seg_list,
            label_slot_list=label_slot_list,
            label_wheel_stop_list=label_wheel_stop_list,
            label_slot_type_list=label_slot_type_list,
            label_speed_bump_list=label_speed_bump_list,
        )

    def _get_slot(self, json_path):
        with open(json_path, "r") as f:
            results = json.load(f)["results"]
        slot_list = []
        slot_type_list = []
        for obj in results:
            if "corner_points" in obj.keys():
                corner_points = np.array(obj["corner_points"], dtype=np.float32)
                corner_points[:, 0] /= self.opt.w_input
                corner_points[:, 1] /= self.opt.h_input
                corner_points = corner_points.reshape(1, -1)

                # add slot status on the end
                slot_status = np.array(
                    status_info.get(obj["status"], 255), dtype=np.float32
                ).reshape(1, -1)
                slot = np.concatenate((corner_points, slot_status), axis=1)
                slot_list.append(slot)

                slot_type = obj["type"]
                slot_type_id = slot_map.get(slot_type, 255)
                slot_type_list.append(slot_type_id)
        return slot_list, slot_type_list

    def _get_wheel_stop(self, json_path):
        with open(json_path, "r") as f:
            results = json.load(f)["results"]
        wheel_stop_list = []
        for obj in results:
            if "segmentation" in obj.keys():
                type = obj["type"]
                if type == "wheel stop":
                    if "keypoints" not in obj:
                        return None
                    wheel_stop = np.array(obj["keypoints"], dtype=np.float32)
                    wheel_stop[:, 0] /= self.opt.w_input
                    wheel_stop[:, 1] /= self.opt.h_input

                    if len(wheel_stop) == 2:
                        wheel_stop_list.append(wheel_stop[0, :].reshape(-1))
                        wheel_stop_list.append(wheel_stop[1, :].reshape(-1))
                    else:
                        wheel_stop_list.append(wheel_stop.reshape(-1))
        return wheel_stop_list

    def _get_speed_bump(self, json_path):
        with open(json_path, "r") as f:
            results = json.load(f)["results"]
        speed_bump_list = []

        for obj in results:
            if "segmentation" in obj.keys():
                type = obj["type"]
                if type == "speed bump":
                    if "keypoints" not in obj:
                        return None
                    speed_bump = np.array(obj["keypoints"], dtype=np.float32)
                    speed_bump[:, 0] /= self.opt.w_input
                    speed_bump[:, 1] /= self.opt.h_input
                    if len(speed_bump) == 2:
                        speed_bump_list.append(speed_bump[0, :].reshape(-1))
                        speed_bump_list.append(speed_bump[1, :].reshape(-1))
                    else:
                        speed_bump_list.append(speed_bump.reshape(-1))
        return speed_bump_list

    def __len__(self):
        return self.len
