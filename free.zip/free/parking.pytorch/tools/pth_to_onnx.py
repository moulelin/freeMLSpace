import argparse
import os
import sys

import torch
import pdb

# sys.path.insert(0, "../")
sys.path.append(os.path.abspath(os.path.join(os.getcwd())))
from lib.models.model_factory import create_model
from lib.utils.common import init_opt


def get_model(opt):
    print("initializing network...")
    model = create_model(opt, "pred")
    checkpoint = torch.load(opt.pth)
    model.load_state_dict(checkpoint["net"], strict=False)
    net = model.cuda().eval()
    return net


def export_onnx(net, opt, base_name):
    if base_name != 'fisheye_bev_det':
        dummy_input = torch.randn(opt.val_batch, 3, opt.h_input, opt.w_input, device="cuda")
    else:
        image = torch.randn(opt.val_batch, opt.num_cameras, 3, opt.h_input, opt.w_input, device='cuda') 
        bev_l = int((opt.xbound[1] - opt.xbound[0]) / opt.xbound[-1])
        bev_w = int((opt.ybound[1] - opt.ybound[0]) / opt.ybound[-1])
        
        sample_heights = opt.sample_heights if hasattr(opt, "sample_heights") and getattr(opt, "sample_heights") else None
        if sample_heights is None:
            bev_height = int((opt.zbound[1] - opt.zbound[0]) / opt.zbound[-1])
        else:
            bev_height = len(sample_heights)

        pix_coords = torch.randn(opt.val_batch, opt.num_cameras, bev_height, bev_l*bev_w, 2, device='cuda')

        dummy_input = (image, pix_coords)
    torch.onnx.export(
        net,
        dummy_input,
        os.path.join(
            opt.save_path,
            f"{base_name}_{opt.backbone}_{opt.w_input}x{opt.h_input}_bs{opt.val_batch}.onnx",
        ),
        verbose=True,
        opset_version=opt.opset_version,
    )
    return


def get_parse():
    parser = argparse.ArgumentParser(description="Parking PyTorch Model Convert Onnx")
    parser.add_argument("--config", default="./configs/bev_det.yaml", type=str, help="path to config")
    parser.add_argument(
        "--model_info", default='{"pth":"/test_output/hans/checkpoint_test/fisheye_bevdet-backup.pth"}', type=str, help="convert model infos"
    )
    parser.add_argument("--save_path", default="/test_output/hans/checkpoint_test/", type=str, help="path to save onnx")
    parser.add_argument("--batch", default=1, type=int, help="batchsize")
    parser.add_argument(
        "--opset_version",
        default=11,
        type=int,
        help="onnx version: trt6 or 7:10, trt8: 11",
    )
    return parser


if __name__ == "__main__":
    opt = get_parse().parse_args()
    init_opt(opt)
    opt.val_batch = opt.batch
    opt.onnx = 1
    print(opt)

    model_info = eval(opt.model_info)
    if len(model_info) != 1:
        print(
            "Convert: model_infos only support one model, but get {}".format(
                len(model_info)
            )
        )
        exit()

    key = list(model_info.keys())[0]
    opt.pth = model_info[key]

    if not os.path.exists(opt.save_path):
        os.makedirs(opt.save_path)

    net = get_model(opt)
    with torch.no_grad():
        export_onnx(net, opt, opt.task)
