import math
import numpy as np
from PIL import Image

import torch

import lib.datasets.transform.common_transform as T
from lib.datasets.transform.parkingslot_transform import AddWater, ChangeLineColor
from lib.utils.vis_util import *
from lib.datasets.dataset.parking_slot import ParkingSlotDataset


np.random.seed(1234)
colors = np.random.randint(0, 256, (256, 3), dtype=np.uint8)


class ParkingSlotPointClsDataset(ParkingSlotDataset):
    def __init__(self, opt, mode):
        super(ParkingSlotPointClsDataset, self).__init__(opt, mode)
        self.size = (self.opt.h_input, self.opt.w_input)
        if self.mode == "train":
            self.transform = T.Compose(
                [
                    # T.RandomResizedCrop(self.opt.scales, self.size),
                    T.RandomAffine(self.size),
                    T.RandomHorizontalFlip(),
                    T.RandomVerticalFlip(),
                    T.ColorJitter(0.5, 0.5, 0.5, 0.5),
                    T.GaussianNoise(0.2, 0, 0.1),
                    T.AddBlur(0.2, "gaussian"),
                    T.ToTensor(),
                ]
            )
            self.add_water = AddWater(p=0.2)
            self.change_line_color = ChangeLineColor(p=0.2)
        else:
            self.transform = T.Compose([T.Resize(self.size), T.ToTensor()])

    def __getitem__(self, index):
        image_path, label_path = (
            self.label_dict["image_list"][index],
            self.label_dict["label_seg_list"][index],
        )
        image, label_seg = Image.open(image_path), Image.open(label_path)
        label_seg = self.label_map[label_seg]
        label_seg = Image.fromarray(label_seg)
        label_slot = torch.from_numpy(self.label_dict["label_slot_list"][index])
        label_slot_type = torch.from_numpy(
            np.array(self.label_dict["label_slot_type_list"][index])
        )

        # parkingslot special transform
        if self.mode == "train" and len(label_slot) > 0:
            image = self.change_line_color(
                image, self.label_dict["label_slot_list"][index]
            )
            image = self.add_water(image, self.label_dict["label_slot_list"][index])

        im_lb = dict(im=image, lb_seg=label_seg, lb_slot=label_slot[:, :-1])
        im_lb = self.transform(im_lb)

        if len(label_slot) > 0:
            points = im_lb["lb_slot"].reshape(-1, 2)
            # point 0 and point 3 are entry points, while point 1 and point 2 are end points
            point_entry = (
                torch.tensor([1, 0, 0, 1]).repeat(len(points) // 4).reshape(-1, 1)
            )
            point_end = (
                torch.tensor([0, 1, 1, 0]).repeat(len(points) // 4).reshape(-1, 1)
            )
            label_point = torch.cat([points, point_entry, point_end], dim=1)
            label_point = self._make_point_label(label_point)

            center_x = torch.mean(im_lb["lb_slot"][:, ::2], dim=1)
            center_y = torch.mean(im_lb["lb_slot"][:, 1::2], dim=1)
            center = torch.stack((center_x, center_y), dim=1)
            one_hot = torch.eye(2)
            center_cls = one_hot[label_slot[:, -1].long()]
            center_type = label_slot_type.reshape(-1, 1).long()
            label_center = torch.cat([center, center_cls, center_type], dim=1)
            label_center = self._make_center_label(label_center)
        else:
            h = self.opt.h_input // self.opt.scale_point
            w = self.opt.w_input // self.opt.scale_point
            label_point = torch.zeros(h, w, 4)
            label_center = torch.zeros(h, w, 5)

        image, label = im_lb["im"], dict(
            label_seg=im_lb["lb_seg"],
            label_point=label_point,
            label_center=label_center,
        )
        return image, label

    def _make_point_label(self, label_point):
        mask = (
            (label_point[:, 0] > 0)
            * (label_point[:, 1] > 0)
            * (label_point[:, 0] < 1)
            * (label_point[:, 1] < 1)
        )
        label_point = label_point[mask, :].clone()
        h = self.opt.h_input // self.opt.scale_point
        w = self.opt.w_input // self.opt.scale_point
        truth = torch.zeros(h, w, 4)
        if label_point.numel() > 0:
            heat_list = []
            for i in range(2):
                mask = label_point[:, 2 + i] > 0
                pts = label_point[mask, :].clone()
                for j in range(mask.sum()):
                    p = pts[j, :].numpy()
                    ux = int(p[0] * w)
                    uy = int(p[1] * h)
                    tx = p[0] * w - ux
                    ty = p[1] * h - uy
                    truth[uy, ux, 1] = i
                    truth[uy, ux, 2] = tx
                    truth[uy, ux, 3] = ty
                    heat = self._make_gaussian_2d(ux, 3, uy, 3, 0, w, h)
                    heat_list.append(heat)
            if len(heat_list) > 0:
                heat = torch.cat(heat_list, dim=0)
                heatmap, _ = heat.max(dim=0)
                truth[..., 0] = heatmap
        return truth

    def _make_center_label(self, label_center):
        mask = (
            (label_center[:, 0] > 0)
            * (label_center[:, 1] > 0)
            * (label_center[:, 0] < 1)
            * (label_center[:, 1] < 1)
        )
        label_center = label_center[mask, :].clone()
        h = self.opt.h_input // self.opt.scale_point
        w = self.opt.w_input // self.opt.scale_point
        truth = torch.zeros(h, w, 5)
        if label_center.numel() > 0:
            heat_list = []
            for i in range(2):
                mask = label_center[:, 2 + i] > 0
                pts = label_center[mask, :].clone()
                for j in range(mask.sum()):
                    p = pts[j, :].numpy()
                    ux = int(p[0] * w)
                    uy = int(p[1] * h)
                    tx = p[0] * w - ux
                    ty = p[1] * h - uy
                    truth[uy, ux, 1] = i
                    truth[uy, ux, 2] = tx
                    truth[uy, ux, 3] = ty
                    truth[uy, ux, 4] = int(p[4])

                    heat = self._make_gaussian_2d(ux, 3, uy, 3, 0, w, h)
                    heat_list.append(heat)

            if len(heat_list) > 0:
                heat = torch.cat(heat_list, dim=0)
                heatmap, _ = heat.max(dim=0)
                truth[..., 0] = heatmap
        return truth

    def _make_gaussian_2d(self, ux, rx, uy, ry, yaw, w_output, h_output):
        x = np.arange(w_output)
        y = np.arange(h_output)
        X, Y = np.meshgrid(x, y)
        X = X - ux
        Y = Y - uy
        C = np.concatenate(
            (X.reshape(1, h_output, w_output), Y.reshape(1, h_output, w_output)), 0
        ).copy()
        C = C.reshape(2, -1)
        R = np.array([[math.cos(yaw), -math.sin(yaw)], [math.sin(yaw), math.cos(yaw)]])
        C1 = np.dot(R, C)
        C1 = C1.reshape(2, h_output, w_output)
        X = C1[0, :, :]
        Y = C1[1, :, :]
        expo = (X**2) / (rx**2) + (Y**2) / (ry**2)
        expo = expo * (-0.5)
        im = np.exp(expo)
        im = torch.from_numpy(im)
        return im.float().view(1, h_output, w_output)

    def verify(self, index):
        image, label = self.__getitem__(index)
        image = tensor_to_image(image)
        label_seg = label["label_seg"].squeeze(0).numpy()
        label_point = label["label_point"].squeeze(0).numpy()
        label_center = label["label_center"].squeeze(0).numpy()

        point_index = np.argwhere(label_point[:, :, 0] == 1)
        center_index = np.argwhere(label_center[:, :, 0] == 1)

        for point in point_index:
            point_cls = label_point[point[0], point[1], 1]
            y = point[0] * 8 + int(label_point[point[0], point[1], 3] * 8)
            x = point[1] * 8 + int(label_point[point[0], point[1], 2] * 8)
            if point_cls == 0:
                cv2.circle(image, (x, y), 5, (0, 255, 0), -1)
            else:
                cv2.circle(image, (x, y), 5, (255, 0, 0), -1)

        for point in center_index:
            point_cls = label_center[point[0], point[1], 1]
            y = point[0] * 8 + int(label_center[point[0], point[1], 3] * 8)
            x = point[1] * 8 + int(label_center[point[0], point[1], 2] * 8)
            if point_cls == 0:
                cv2.circle(image, (x, y), 5, (200, 200, 0), -1)
                cv2.putText(
                    image,
                    "{}".format(int(label_center[point[0], point[1], 4])),
                    (x, y),
                    cv2.FONT_HERSHEY_COMPLEX,
                    2,
                    (200, 200, 0),
                    2,
                )
            else:
                cv2.circle(image, (x, y), 5, (0, 200, 200), -1)
                cv2.putText(
                    image,
                    "{}".format(int(label_center[point[0], point[1], 4])),
                    (x, y),
                    cv2.FONT_HERSHEY_COMPLEX,
                    2,
                    (0, 200, 200),
                    2,
                )

        label_seg = colors[label_seg]
        combined_img = np.hstack([image, label_seg])
        return combined_img
        # cv2.imshow("combined_img", combined_img)
        # cv2.waitKey(0)
