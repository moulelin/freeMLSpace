import os
import torch
import torchvision
import numpy as np
from torch import nn
import torch.nn.functional as F
from model.network_blocks import BaseConv
from model.darknet import CSPDarknet
from mmdet.models import build_backbone
from mmcv.cnn import (build_conv_layer, build_norm_layer, build_upsample_layer,
                      constant_init, is_norm, kaiming_init)

class UpsamplingConcat(nn.Module):
    def __init__(self, in_channels, out_channels, scale_factor=2):
        super().__init__()

        self.upsample = nn.Upsample(scale_factor=scale_factor, mode='bilinear', align_corners=False)

        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.InstanceNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.InstanceNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x_to_upsample, x):
        x_to_upsample = self.upsample(x_to_upsample)
        x_to_upsample = torch.cat([x, x_to_upsample], dim=1)
        return self.conv(x_to_upsample)

# class Encoder_res50(nn.Module):
#     def __init__(self, C):
#         super().__init__()
#         self.C = C
#         resnet = torchvision.models.resnet50(pretrained=True)
#         self.backbone = nn.Sequential(*list(resnet.children())[:-4])
#         self.layer3 = resnet.layer3

#         self.depth_layer = nn.Conv2d(512, self.C, kernel_size=1, padding=0)
#         self.upsampling_layer = UpsamplingConcat(1536, 512)

#     def forward(self, x):
#         x1 = self.backbone(x)
#         x2 = self.layer3(x1)
#         x = self.upsampling_layer(x2, x1)
#         x = self.depth_layer(x)

#         return x

class Encoder_resnet(nn.Module):
    def __init__(self,
                 depth,
                 output_channels,
                 use_indices=[0, 1, 2, 3],
                 upsample_strides=[0.25, 0.5, 1, 2],
                 in_channels=[256, 512, 1024, 2048],
                 out_channels=[128, 128, 128, 128],
                 use_conv_for_no_stride=False):
        super().__init__()
        self.backbone = build_backbone(dict(
            type='ResNet',
            depth=depth,
            frozen_stages=0,
            out_indices=use_indices,
            norm_eval=False,
            init_cfg=dict(type='Pretrained', checkpoint='torchvision://resnet50'),
        ))

        deblocks = []
        for i, out_channel in enumerate(out_channels):
            stride = upsample_strides[i]
            if stride > 1 or (stride == 1 and not use_conv_for_no_stride):
                upsample_layer = build_upsample_layer(
                    dict(type='deconv', bias=False),
                    in_channels=in_channels[i],
                    out_channels=out_channel,
                    kernel_size=upsample_strides[i],
                    stride=upsample_strides[i])
            else:
                stride = np.round(1 / stride).astype(np.int64)
                upsample_layer = build_conv_layer(
                    dict(type='Conv2d', bias=False),
                    in_channels=in_channels[i],
                    out_channels=out_channel,
                    kernel_size=stride,
                    stride=stride)

            deblock = nn.Sequential(upsample_layer,
                                    build_norm_layer(dict(type='BN', eps=1e-3, momentum=0.01), out_channel)[1],
                                    nn.ReLU(inplace=True))
            deblocks.append(deblock)
        self.deblocks = nn.ModuleList(deblocks)

        self.output_conv = nn.Sequential(
            nn.Conv2d(sum(out_channels), output_channels, kernel_size=1, padding=0, bias=False),
            # nn.GroupNorm(16, out_channels),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
            # nn.GroupNorm(16, out_channels),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        x = self.backbone(x)
        assert len(x) == len(self.deblocks)
        x = [deblock(x[i]) for i, deblock in enumerate(self.deblocks)]

        if len(x) > 1:
            x = torch.cat(x, dim=1)
        else:
            x = x[0]
        out = self.output_conv(x)
        return out

class Encoder_res18(nn.Module):
    def __init__(self, C):
        super().__init__()
        self.C = C
        resnet = torchvision.models.resnet18(pretrained=True)
        self.backbone = nn.Sequential(*list(resnet.children())[:-4])
        self.layer3 = resnet.layer3

        self.depth_layer = nn.Conv2d(256, self.C, kernel_size=1, padding=0)
        self.upsampling_layer = UpsamplingConcat(384, 256)

    def forward(self, x):
        x1 = self.backbone(x)
        x2 = self.layer3(x1)
        x = self.upsampling_layer(x2, x1)
        x = self.depth_layer(x)

        return x
class Up(nn.Module):
    def __init__(self, in_channels, out_channels, scale_factor=2):
        super(Up, self).__init__()
        self.up = nn.Upsample(scale_factor=scale_factor, mode='nearest')

        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=1, padding=0, bias=False),
            # nn.GroupNorm(16, out_channels),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
            # nn.GroupNorm(16, out_channels),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x1, x2):
        x1 = self.up(x1)
        x1 = torch.cat([x2, x1], dim=1)
        return self.conv(x1)

class CamEncoder(nn.Module):
    def __init__(self, C, backbone='yolo-m'):
        super(CamEncoder, self).__init__()
        self.C = C
        self.backbone_name = backbone

        pth = None
        if backbone == 'res50':
            self.trunk = Encoder_resnet(50, self.C)
        elif backbone == 'res18':
            self.trunk = Encoder_res18(self.C)
        elif backbone == 'yolo-m':
            self.trunk = CSPDarknet(0.67, 0.75, act='relu')
            pth = 'pretrain/CSPDarknet.pth'
            self.up = Up(768+384, C)
        else:
            self.trunk = CSPDarknet(1, 1, stem='focus', act='silu')
            pth = 'pretrain/CSPDarknet-l.pth'
            self.up = Up(1024+512, C)

        if pth is not None and os.path.exists(pth):
            print('load backbone %s'%pth)
            checkpoint = torch.load(pth, map_location=torch.device('cpu'))
            self.trunk.load_state_dict(checkpoint['net'])


    def forward(self, x):
        # return B*N x C x H x W
        if self.backbone_name.startswith('res'):
            x = self.trunk(x)
        else:
            x_dict = self.trunk(x)
            x = self.up(x_dict['dark5'], x_dict['dark4'])

        return x