import torch
from torch import nn

from lib.models.common_opr.base_opr import ConvBNReLU


chan_infos = {
    "bisenetv2": 16,
    "hrnet18": 18,
    "hrnet32": 32,
    "hrnet48": 48,
    "hrnet16_lite": 16,
    "hrnet18_lite": 18,
    "hrnet32_lite": 32,
    "hrnet48_lite": 48,
    "salsanext": 18,
    "yolo-m": 8,
    "yolo-l": 12,
}


class SegmentHead(nn.Module):
    def __init__(self, in_chan, mid_chan, n_classes, up_factor=8, aux=True):
        super(SegmentHead, self).__init__()
        self.conv = ConvBNReLU(in_chan, mid_chan, 3, stride=1)
        self.drop = nn.Dropout(0.1)
        self.up_factor = up_factor

        if aux:
            out_chan = n_classes
            if up_factor <= 1:
                stride = int(1 / up_factor)
                self.conv_out = nn.Sequential(
                    nn.Sequential(ConvBNReLU(mid_chan, mid_chan, 3, stride=stride)),
                    nn.Conv2d(mid_chan, out_chan, 1, 1, 0, bias=True),
                )
            else:
                mid_chan2 = up_factor * up_factor * 16
                up_factor = up_factor // 2
                self.conv_out = nn.Sequential(
                    nn.Sequential(
                        nn.Upsample(scale_factor=2),
                        ConvBNReLU(mid_chan, mid_chan2, 3, stride=1),
                    ),
                    nn.Conv2d(mid_chan2, out_chan, 1, 1, 0, bias=True),
                    nn.Upsample(
                        scale_factor=up_factor, mode="bilinear", align_corners=False
                    ),
                )
        else:
            up_factor = up_factor // 2
            self.conv_out = nn.Sequential(
                nn.ConvTranspose2d(mid_chan, mid_chan, 2, 2, 0, groups=1, bias=False),
                nn.Conv2d(mid_chan, n_classes, 1, 1, 0, bias=True),
                nn.Upsample(
                    scale_factor=up_factor, mode="bilinear", align_corners=False
                )
                if up_factor > 1
                else nn.Identity(),
            )

    def forward(self, x):
        feat = self.conv(x)
        feat = self.drop(feat)
        feat = self.conv_out(feat)
        return feat


class PointHead(nn.Module):
    def __init__(self, in_chan, mid_chan, out_chan):
        super(PointHead, self).__init__()
        self.conv = ConvBNReLU(in_chan, mid_chan, 3, stride=1)
        self.conv_out = nn.Conv2d(mid_chan, out_chan, 1, 1, 0)
        self.initialize_biases()

    def forward(self, x):
        feat = self.conv(x)
        feat = self.conv_out(feat)
        return feat

    def initialize_biases(
        self, cf=None
    ):  # initialize biases into Detect(), cf is class frequency
        # https://arxiv.org/abs/1708.02002 section 3.3
        # cf = torch.bincount(torch.tensor(np.concatenate(dataset.labels, 0)[:, 0]).long(), minlength=nc) + 1.
        b = self.conv_out.bias
        b.data.fill_(-2.19)  # from centernet
        self.conv_out.bias = torch.nn.Parameter(b.view(-1), requires_grad=True)


class DistributionHead(nn.Module):
    def __init__(self, in_chan, mid_chan, out_chan):
        super(DistributionHead, self).__init__()
        self.conv = ConvBNReLU(in_chan, mid_chan, 3, stride=1)
        self.conv_out = nn.Conv2d(mid_chan, out_chan, 1, 1, 0)
        self.softmax = nn.Softmax(dim=1)
        self.init_weights()

    def forward(self, x):
        feat = self.conv(x)
        feat = self.conv_out(feat)
        return self.softmax(feat)

    def init_weights(self):  
        for name, module in self.named_modules():
            if isinstance(module, (nn.Conv2d, nn.Linear)):
                nn.init.kaiming_normal_(module.weight, mode='fan_out')
            elif isinstance(module, nn.modules.batchnorm._BatchNorm):
                if hasattr(module, "last_bn") and module.last_bn:
                    nn.init.zeros_(module.weight)
                else:
                    nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)
