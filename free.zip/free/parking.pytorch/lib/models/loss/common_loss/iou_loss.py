import math

import torch
import torch.nn as nn
from mmcv.ops import box_iou_rotated

class IOULoss(nn.Module):
    def __init__(
        self, size_average=True
    ):
        super(IOULoss, self).__init__()
        self.size_average = size_average

    def forward(self, pred, gt):
        iou_loss = 1 - box_iou_rotated(pred, gt, aligned=True)
        loss = torch.zeros(1, device=pred.device)
        if self.size_average:
            loss += iou_loss.mean()
        else:
            loss += iou_loss.sum()
        return loss

