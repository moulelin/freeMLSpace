import cv2
import json
import os

from matplotlib.artist import get


def get_info_value(info, keys):
    tmp = info["metric"]
    for i in range(len(keys)):
        tmp = tmp.get(keys[i], None)
        if tmp is None:
            return tmp
    return tmp


def get_scene_value(info, keys):
    tmp = info["scene"]
    tmp = tmp.get(keys[0], None)
    if tmp is None or tmp != keys[1]:
        return None
    else:
        return tmp


if __name__ == "__main__":

    # metric_tags = "point:tp"
    # metric_tags = "point:fp"
    # metric_tags = "point:fn"
    # metric_tags = "center:tp"
    # metric_tags = "center:fp"
    # metric_tags = "center:fn"
    # metric_tags = "offset:tp"
    # metric_tags = "offset:fp"
    # metric_tags = "type:tp"
    # metric_tags = "type:fp"
    # metric_tags = "ws:tp"
    # metric_tags = "ws:fp"
    # metric_tags = "segWheelStop:iou"
    # metric_tags = "segWall:iou"
    # metric_tags = "segPillar:iou"
    # metric_tags = "segParkLockClosed:iou"
    # metric_tags = "segVehicle:iou"
    # metric_tags = "segVegetation:iou"
    # metric_tags = "segCurb:iou"
    # metric_tags = "segPedestrian:iou"
    # metric_tags = "segCone:iou"
    metric_tags = "segFreeSpace:iou"

    # scene_tags = "车位类型:垂直车位"
    # scene_tags = "车位类型:斜列车位"
    # scene_tags = "地面材质类型:水泥路"
    # scene_tags = "车位线类型:T形线"
    # scene_tags = "磨损程度:无磨损"
    # scene_tags = "环境要素:明亮"
    # scene_tags = "反光程度:轻微反光"
    # scene_tags = "地理要素:地下"
    scene_tags = "all"

    badcase_dir = "/mnt/data/data/fisheye/models/release/20230207/badcase"
    web_badcase_dir = "/output/fisheye/automl-fisheye-eval-1fsevalv0207-ytfxw/automl-fisheye-eval-1fsevalv0207-ytfxw-lr4t8/report/badcase"
    info_file = "/mnt/data/data/fisheye/models/release/20230207/badcase/fstrain0207-2/infos.json"

    with open(info_file, "r") as f:
        infos = json.load(f)

    print(infos["0"])

    metric_keys = metric_tags.split(":")
    scene_keys = scene_tags.split(":")

    badcase_count = 0
    img_path_metric_list = []
    for img_id in infos:
        img_name = infos[img_id]["imgPath"].replace(web_badcase_dir, badcase_dir)
        img_path = os.path.join(badcase_dir, img_name)

        if scene_tags != "all":
            scene_value = get_scene_value(infos[img_id], scene_keys)
            if scene_value is None:
                continue

        metric_value = get_info_value(infos[img_id], metric_keys)
        if metric_value is None:
            continue

        if metric_value < 0.05:
            continue

        badcase_count += 1
        img_path_metric_list.append([img_path, metric_value])

    # img_path_metric_list.sort(key=lambda x: x[1], reverse=True)
    img_path_metric_list.sort(key=lambda x: x[1])

    for i in range(2000):
        img_path = img_path_metric_list[i][0]
        metric_value = img_path_metric_list[i][1]

        img = cv2.imread(img_path)
        h, w, _ = img.shape
        img = cv2.resize(img, (w, h))
        cv2.imshow(f"{metric_tags}-{round(metric_value, 3)}", img)
        key = cv2.waitKey(0)
        if key == 27:
            exit()
        cv2.destroyAllWindows()
