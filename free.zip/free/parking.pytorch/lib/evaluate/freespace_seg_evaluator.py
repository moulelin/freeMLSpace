import time
import numpy as np
from tqdm import tqdm
import cv2
import os
import json
import math

import torch

from .seg_evaluator import SegEvaluator
from lib.utils.vis_util import get_line_point


class FreeSpaceSegEvaluator(SegEvaluator):
    def __init__(self, opt, decoder, dataset):
        super(FreeSpaceSegEvaluator, self).__init__(opt, decoder, dataset)
        self._radiation_lines = self.get_radiation_lines()
        self._ignore_kernel = np.ones((3, 3), np.uint8)
        self._grid_dists = self.opt.grid_dists

    def _init_grid_edge_indexs(self, grid):
        w = grid.shape[0]
        h = grid.shape[1]
        indexs = []
        for i in range(w):
            indexs.append([i, 0])
        for j in range(h):
            indexs.append([i, j])
        for i in range(w - 1, -1, -1):
            indexs.append([i, j])
        for j in range(h - 1, -1, -1):
            indexs.append([i, j])
        return np.array(indexs).astype("int32").reshape(-1, 2)

    def _get_grid_mask_and_dist(self, grid):
        indexs = self._init_grid_edge_indexs(grid)
        mask = np.zeros((self.opt.h_input, self.opt.w_input))
        points = grid.astype("int32")[indexs[:, 0], indexs[:, 1]]
        mask = cv2.fillPoly(mask, [points], color=1)

        grid_h, grid_w = grid.shape[0], grid.shape[1]
        if grid_h >= grid_w:
            center_x = 0
            center_y = grid_h // 2
        else:
            center_x = grid_w // 2
            center_y = 0
        center = np.array([center_x, center_y])

        point_center = grid[center_y, center_x]

        x_line = np.arange(0, grid_w).reshape(1, -1, 1).repeat(grid_h, axis=0)
        y_line = np.arange(0, grid_h).reshape(-1, 1, 1).repeat(grid_w, axis=1)
        meshgrid = np.concatenate([x_line, y_line], axis=2)
        # cv2.circle(mask, (int(grid[20, 160, 0]), int(grid[20, 160, 1])),  1, 0.5, 4)
        # print(center, grid.shape, meshgrid.shape)
        dist = (
            np.sqrt(((meshgrid - center.reshape(1, 1, 2)) ** 2).sum(axis=2))
            * self.opt.grid_interval
        )
        # print(dist.max(), dist[0, 0])
        # exit()
        return mask, dist

    def _get_results(self, avg_inference_t):
        self.generate_seg_results()
        self.generate_edge_results()
        self.results["inference_time"] = avg_inference_t
        self.results["batchsize"] = self.opt.val_batch

    def _eval(self, preds, label, net, sample_idx):
        seg_pred = self.align_outputs(preds, net)
        seg_label = label["label_seg"]
        seg_label = self.decoder.extract_truth(seg_label)
        self._eval_seg(seg_label, seg_pred, sample_idx)
        self._eval_edge(seg_label, seg_pred, sample_idx)
        return seg_pred

    def _get_infer_buffer(self):
        buffer = {}
        buffer["hist"] = torch.zeros(self.num_classes, self.num_classes).cuda()
        buffer["edge_point_tp"] = np.zeros(
            (self.num_classes, len(self.opt.grid_dists) + 1)
        )
        buffer["edge_point_fp"] = np.zeros(
            (self.num_classes, len(self.opt.grid_dists) + 1)
        )
        buffer["edge_point_fn"] = np.zeros(
            (self.num_classes, len(self.opt.grid_dists) + 1)
        )
        buffer["edge_point_diff"] = [
            [[] for j in range(len(self.opt.grid_dists) + 1)]
            for i in range(self.opt.n_cats)
        ]
        return buffer

    def _edge_metric(self, tp, fp, fn, diffs):
        edge_gt_num = tp + fn
        edge_dt_num = tp + fp

        recall = tp / (edge_gt_num + 1e-6)
        recall[edge_gt_num == 0] = -1

        precision = tp / (edge_dt_num + 1e-6)
        precision[edge_dt_num == 0] = -1

        f1 = 2 * recall * precision / (recall + precision + 1e-6)
        f1[edge_gt_num == 0] = -1
        f1[edge_dt_num == 0] = -1

        if f1.shape[1] == 1:
            offset_avg = np.zeros((self.opt.n_cats, 1))
            offset_std = np.zeros((self.opt.n_cats, 1))
            for i in range(self.opt.n_cats):
                tmp_diff = []
                for j in range(len(self.opt.grid_dists) + 1):
                    tmp_diff.extend(diffs[i][j])
                if len(tmp_diff) == 0:
                    offset_avg[i][0] = -1
                    offset_std[i][0] = -1
                else:
                    edge_point_diff = np.array(tmp_diff)
                    offset_avg[i][0] = edge_point_diff.mean()
                    offset_std[i][0] = edge_point_diff.std()
        else:
            offset_avg = np.zeros((self.opt.n_cats, len(self.opt.grid_dists) + 1))
            offset_std = np.zeros((self.opt.n_cats, len(self.opt.grid_dists) + 1))
            for i in range(self.opt.n_cats):
                for j in range(len(self.opt.grid_dists) + 1):
                    if len(diffs[i][j]) == 0:
                        offset_avg[i][j] = -1
                        offset_std[i][j] = -1
                    else:
                        edge_point_diff = np.array(diffs[i][j])
                        offset_avg[i][j] = edge_point_diff.mean()
                        offset_std[i][j] = edge_point_diff.std()
        return precision, recall, f1, offset_avg, offset_std

    def generate_edge_results(self):

        precision, recall, f1, offset_avg, offset_std = self._edge_metric(
            self._infer_buffer["edge_point_tp"],
            self._infer_buffer["edge_point_fp"],
            self._infer_buffer["edge_point_fn"],
            self._infer_buffer["edge_point_diff"],
        )

        (
            precision_all,
            recall_all,
            f1_all,
            offset_avg_all,
            offset_std_all,
        ) = self._edge_metric(
            self._infer_buffer["edge_point_tp"].sum(axis=1, keepdims=True),
            self._infer_buffer["edge_point_fp"].sum(axis=1, keepdims=True),
            self._infer_buffer["edge_point_fn"].sum(axis=1, keepdims=True),
            self._infer_buffer["edge_point_diff"],
        )

        self.results["edge"] = {
            "Recall": recall,
            "Precision": precision,
            "F1": f1,
            "Diff_avg": offset_avg,
            "Diff_std": offset_std,
            "Recall_all": recall_all,
            "Precision_all": precision_all,
            "F1_all": f1_all,
            "Diff_avg_all": offset_avg_all,
            "Diff_std_all": offset_std_all,
        }

        if self.opt.scene:
            for scene_name in self._scene_infer_buffers:
                if scene_name not in self.scene_results:
                    self.scene_results[scene_name] = {}
                for scene_value in self._scene_infer_buffers[scene_name]:

                    if scene_value not in self.scene_results[scene_name]:
                        self.scene_results[scene_name][scene_value] = {}

                    precision, recall, f1, offset_avg, offset_std = self._edge_metric(
                        self._scene_infer_buffers[scene_name][scene_value][
                            "edge_point_tp"
                        ],
                        self._scene_infer_buffers[scene_name][scene_value][
                            "edge_point_fp"
                        ],
                        self._scene_infer_buffers[scene_name][scene_value][
                            "edge_point_fn"
                        ],
                        self._scene_infer_buffers[scene_name][scene_value][
                            "edge_point_diff"
                        ],
                    )

                    (
                        precision_all,
                        recall_all,
                        f1_all,
                        offset_avg_all,
                        offset_std_all,
                    ) = self._edge_metric(
                        self._scene_infer_buffers[scene_name][scene_value][
                            "edge_point_tp"
                        ].sum(axis=1, keepdims=True),
                        self._scene_infer_buffers[scene_name][scene_value][
                            "edge_point_fp"
                        ].sum(axis=1, keepdims=True),
                        self._scene_infer_buffers[scene_name][scene_value][
                            "edge_point_fn"
                        ].sum(axis=1, keepdims=True),
                        self._scene_infer_buffers[scene_name][scene_value][
                            "edge_point_diff"
                        ],
                    )

                    self.scene_results[scene_name][scene_value]["edge"] = {
                        "Recall": recall,
                        "Precision": precision,
                        "F1": f1,
                        "Diff_avg": offset_avg,
                        "Diff_std": offset_std,
                        "Recall_all": recall_all,
                        "Precision_all": precision_all,
                        "F1_all": f1_all,
                        "Diff_avg_all": offset_avg_all,
                        "Diff_std_all": offset_std_all,
                    }

    def _eval_edge(self, label, pred, sample_idx):
        gt_seg = label.detach().cpu().squeeze(0).numpy()
        dt_seg = pred.detach().cpu().squeeze(0).numpy()
        ignore_mask = (gt_seg == self.opt.ignore_label).astype("uint8")
        ignore_mask = cv2.dilate(ignore_mask, self._ignore_kernel)

        grid = self.dataset.get_grid(sample_idx)
        if grid is not None and self.opt.is_grid:
            mask, dist = self._get_grid_mask_and_dist(grid)
            grid = grid.reshape(-1, 2)
            dist = dist.reshape(-1)
            # cv2.imshow("mask", mask)
            # cv2.waitKey(0)
            # exit()

            for cls_idx in range(self.opt.n_cats):
                if cls_idx == 0:
                    continue

                gt_mask = (gt_seg == cls_idx).astype("uint8")
                dt_mask = (dt_seg == cls_idx).astype("uint8")

                self.process_radiation_metric(
                    cls_idx,
                    gt_mask,
                    dt_mask,
                    ignore_mask,
                    0,
                    len(self._radiation_lines),
                    sample_idx,
                    grid,
                    dist,
                    mask,
                )

    def get_point_dist(self, points, grid, dist, mask):
        dist_list = []
        if len(points) > 0:
            # debug_mask = mask.reshape(mask.shape[0], mask.shape[1], 1)
            for i in range(len(points)):
                if mask[points[i][1], points[i][0]] == 0:
                    dist_list.append(self.opt.grid_dists[-1] + 1)
                    continue
                point = np.array(points[i]).reshape(1, 2)
                point_dist = np.sqrt(((grid - point) ** 2).sum(axis=1))
                nearest_idx = point_dist.argmin()
                dist_list.append(dist[nearest_idx])

                # debug_mask = np.concatenate([debug_mask, debug_mask, debug_mask], axis=2) * 255
                # debug_mask = debug_mask.astype("uint8")
                # print(point[0, 0], point[0, 1])
                # print(grid[nearest_idx])
                # cv2.circle(debug_mask, (point[0, 0], point[0, 1]), 1, (255, 0, 0), 8)
                # target = grid[nearest_idx]
                # print(target[0], target[1], dist[nearest_idx])
                # cv2.putText(debug_mask, str(dist[nearest_idx]), (int(target[0]), int(target[1])), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 1)

                # cv2.imshow("debug", debug_mask)
                # cv2.waitKey(0)
                # exit()
        return dist_list

    def _get_dist_idx(self, dist):
        grid_dists = self.opt.grid_dists

        for i in range(len(grid_dists)):
            if dist < grid_dists[i]:
                return i
        return i + 1

    def process_radiation_metric(
        self,
        cls_idx,
        gt_mask,
        dt_mask,
        ignore_mask,
        start,
        end,
        sample_idx,
        grid,
        dist,
        mask,
    ):
        gt_points_list = self.get_edge_points(gt_mask, ignore_mask, start, end)
        dt_points_list = self.get_edge_points(dt_mask, ignore_mask, start, end)

        for dt_points, gt_points in zip(dt_points_list, gt_points_list):
            dt_dists = self.get_point_dist(dt_points, grid, dist, mask)
            gt_dists = self.get_point_dist(gt_points, grid, dist, mask)
            if len(dt_points) == 0:
                for i in range(len(gt_points)):
                    dist_idx = self._get_dist_idx(gt_dists[i])
                    self._infer_buffer["edge_point_fn"][cls_idx][dist_idx] += 1
                continue
            if len(gt_points) == 0:
                for i in range(len(dt_points)):
                    dist_idx = self._get_dist_idx(dt_dists[i])
                    self._infer_buffer["edge_point_fp"][cls_idx][dist_idx] += 1
                continue

            gt_points_array = np.array(gt_points).reshape(-1, 1, 2)
            dt_points_array = np.array(dt_points).reshape(1, -1, 2)
            dist_m = np.sqrt(
                (gt_points_array[:, :, 0] - dt_points_array[:, :, 0]) ** 2
                + (gt_points_array[:, :, 1] - dt_points_array[:, :, 1]) ** 2
            )

            gt_mask = np.zeros(len(gt_points))

            tp = np.zeros(len(self.opt.grid_dists) + 1)
            fp = np.zeros(len(self.opt.grid_dists) + 1)
            fn = np.zeros(len(self.opt.grid_dists) + 1)
            diffs = [[] for j in range(len(self.opt.grid_dists) + 1)]
            for j in range(len(dt_points)):
                grid_dist_idx = self._get_dist_idx(dt_dists[j])
                for i in range(len(gt_points)):
                    min_idx = dist_m[:, j].argmin()
                    min_dist = dist_m[min_idx, j]
                    if gt_mask[min_idx] != 1 and min_dist < self.opt.radiation_thresh:
                        tp[grid_dist_idx] += 1
                        diffs[grid_dist_idx].append(min_dist)
                        gt_mask[min_idx] = 1
                    else:
                        fp[grid_dist_idx] += 1

            for i in range(len(gt_points)):
                if gt_mask[i] == 0:
                    grid_dist_idx = self._get_dist_idx(gt_dists[i])
                    fn[grid_dist_idx] += 1

            self._infer_buffer["edge_point_tp"][cls_idx] += tp
            self._infer_buffer["edge_point_fp"][cls_idx] += fp
            self._infer_buffer["edge_point_fn"][cls_idx] += fn
            for i in range(len(self._infer_buffer["edge_point_diff"][cls_idx])):
                self._infer_buffer["edge_point_diff"][cls_idx][i].extend(diffs[i])

            if self.opt.badcase:
                metric_name = "seg-{}".format(self.seg_id_map[cls_idx])
                if metric_name not in self.cur_infos["metric"]:
                    self.cur_infos["metric"][metric_name] = {}
                self.cur_infos["metric"][metric_name]["precision"] = float(
                    tp.sum() / (tp.sum() + fp.sum() + 0.001)
                )
                self.cur_infos["metric"][metric_name]["recall"] = float(
                    tp.sum() / (tp.sum() + fn.sum() + 0.001)
                )
                if len(diffs[i]) > 0:
                    self.cur_infos["metric"][metric_name]["diff"] = float(
                        np.array(diffs[i]).mean()
                    )
                else:
                    self.cur_infos["metric"][metric_name]["diff"] = -1

            if self.opt.scene:
                scene_infos = self.opt.scene_infos_list[sample_idx]
                for scene_name, scene_value in scene_infos.items():
                    if scene_value in self.opt.filter_keys:
                        continue
                    self._scene_infer_buffers[scene_name][scene_value]["edge_point_tp"][
                        cls_idx
                    ] += tp
                    self._scene_infer_buffers[scene_name][scene_value]["edge_point_fp"][
                        cls_idx
                    ] += fp
                    self._scene_infer_buffers[scene_name][scene_value]["edge_point_fn"][
                        cls_idx
                    ] += fn
                    for i in range(
                        len(
                            self._scene_infer_buffers[scene_name][scene_value][
                                "edge_point_diff"
                            ][cls_idx]
                        )
                    ):
                        self._scene_infer_buffers[scene_name][scene_value][
                            "edge_point_diff"
                        ][cls_idx][i].extend(diffs[i])

    def get_radiation_lines(self):
        radiation_lines = []
        for i in range(0, self.opt.w_input, self.opt.radiation_interval):
            points = np.array(
                get_line_point(
                    self.opt.radiation_source[0], self.opt.radiation_source[1], i, 0
                )
            )
            radiation_lines.append(points)
        for j in range(0, self.opt.h_input, self.opt.radiation_interval):
            points = np.array(
                get_line_point(
                    self.opt.radiation_source[0],
                    self.opt.radiation_source[1],
                    self.opt.w_input - 1,
                    j,
                )
            )
            radiation_lines.append(points)
        for i in range(self.opt.w_input - 1, -1, -self.opt.radiation_interval):
            points = np.array(
                get_line_point(
                    self.opt.radiation_source[0],
                    self.opt.radiation_source[1],
                    i,
                    self.opt.h_input - 1,
                )
            )
            radiation_lines.append(points)
        for j in range(self.opt.h_input - 1, -1, -self.opt.radiation_interval):
            points = np.array(
                get_line_point(
                    self.opt.radiation_source[0], self.opt.radiation_source[1], 0, j
                )
            )
            radiation_lines.append(points)
        return radiation_lines

    def get_edge_points(self, mask, ignore_mask, start, end):
        out_points = []
        if mask.sum() == 0:
            return [[] for i in range(end - start)]

        for line_points in self._radiation_lines[start:end]:
            ignore_values = ignore_mask[line_points[:, 1], line_points[:, 0]]
            values = mask[line_points[:, 1], line_points[:, 0]]
            values_ = np.insert(values[:-1], 0, values[0])

            change_points = line_points[(values != values_) & (ignore_values == 0), :]
            out_points.append(change_points.tolist())
        return out_points
