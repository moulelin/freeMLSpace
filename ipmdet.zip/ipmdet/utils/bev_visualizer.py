import cv2
import torch
import numpy as np
from typing import Tuple
from nuscenes.utils.data_classes import Box
from pyquaternion import Quaternion
from utils.tools import tensor_to_image, merge_six_images
from utils.vis import draw_voxel_heatmap, pointcloud_to_bevimg, draw_box_in_bev
from geometry.boxes3d import GenericBoxes3D, box3d_ang_to_box3d_quat
from nuscenes.utils.geometry_utils import view_points

color_list = [(0, 255, 255), (255, 255, 0), (0, 200, 255), (127, 0, 255), (0, 127, 255), \
    (127, 0, 127), (127, 100, 0), (255, 0, 0), (0, 0, 255), (255, 0, 255), ]

xbound = [-52.0, 52.0, 0.25]
ybound = [-52.0, 52.0, 0.25]
zbound = [-5.0, 5.0, 10.0]


def bev_feature_to_image(bev_feature, height_index=None):
    """
    Args:
        bev_feature: B * C * H * W
    """
    B, C, H, W = bev_feature.shape
    if height_index is None:
        bev_feature, _ = torch.max(bev_feature.view(B, -1, 3, H, W), dim=1)
    else:
        bev_feature = bev_feature.view(B, -1, 3, H, W)[:, height_index, ...]
    image = bev_feature[0].detach().permute(1, 2, 0).cpu().numpy()
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    return image

def project_points_to_img(points, intrinsic, img_post_rot=None, img_post_trans=None):
    '''
    Args:
        points: 3*N, np.array
        intrinsic: 3*3
        img_post_rot: 3*3
        img_post_trans: 3
    Return:
        uv_points: 2*N
    '''
    eps = 1e-7
    image_points = np.dot(intrinsic, points)
    image_points = image_points / (image_points[2:, :] + eps)
    if img_post_rot is not None and img_post_trans is not None:
        image_points = img_post_rot @ image_points + img_post_trans[..., None]
    image_points = image_points[:2, :]
    image_points = np.where(points[2:, :] > 0, image_points, np.full_like(image_points, -1))
    return image_points

def draw_box3d_on_img(img: np.ndarray,
                      box: Box,
                      intrinsic: np.ndarray = np.eye(3),
                      img_post_rot: np.ndarray = np.eye(3),
                      img_post_trans: np.ndarray = np.zeros(3),
                      colors: Tuple = ((0, 0, 255), (255, 0, 0), (155, 155, 155)),
                      linewidth: int = 2) -> None:
    corners = project_points_to_img(box.corners(), intrinsic, img_post_rot, img_post_trans)[:2, :]

    def draw_rect(selected_corners, color):
        prev = selected_corners[-1]
        for corner in selected_corners:
            cv2.line(img,
                        (int(prev[0]), int(prev[1])),
                        (int(corner[0]), int(corner[1])),
                        color, linewidth)
            prev = corner

    # Draw the sides
    for i in range(4):
        cv2.line(img,
                    (int(corners.T[i][0]), int(corners.T[i][1])),
                    (int(corners.T[i + 4][0]), int(corners.T[i + 4][1])),
                    colors[2][::-1], linewidth)

    # Draw front (first 4 corners) and rear (last 4 corners) rectangles(3d)/lines(2d)
    draw_rect(corners.T[:4], colors[0][::-1])
    draw_rect(corners.T[4:], colors[1][::-1])

    # Draw line indicating the front
    center_bottom_forward = np.mean(corners.T[2:4], axis=0)
    center_bottom = np.mean(corners.T[[2, 3, 7, 6]], axis=0)
    cv2.line(img,
                (int(center_bottom[0]), int(center_bottom[1])),
                (int(center_bottom_forward[0]), int(center_bottom_forward[1])),
                colors[0][::-1], linewidth)

def visualize_bev(data_dict):
    # show in image view
    box3d_preds = torch.zeros(0, 8)     # cls, x, y, z, l, w, h, yaw
    if 'box3d_preds' in data_dict:
        box3d_preds = data_dict['box3d_preds'].detach().cpu()

    label = data_dict['label'][0].cpu()
    mask = label[:, 4:6].sum(dim=1) > 0

    label = box3d_ang_to_box3d_quat(torch.cat([label[mask, :-1],
                                               torch.sin(label[mask, -1:]),
                                               torch.cos(label[mask, -1:])],
                                              dim=1))

    img_list = []
    for n in range(6):
        img_t = data_dict['image'][0, n]
        img = tensor_to_image(img_t)
        rot = data_dict['rots'][0, n].cpu().double().numpy()
        tran = data_dict['trans'][0, n].cpu().numpy()
        intrinsic = data_dict['intrins'][0, n].cpu().numpy()

        img_post_rot = data_dict['img_post_rot'][0, n].cpu().numpy()
        img_post_trans = data_dict['img_post_trans'][0, n].cpu().numpy()
        bev_rot = data_dict['bev_rot'][0, n].cpu().numpy()

        # for j in range(box3d_preds.size(0)):
        #     box3d_pred = box3d_preds[j, :].clone()
        #     xyz, wlh, yaw = box3d_pred[1:4], box3d_pred[[5, 4, 6]], box3d_pred[-1]
        #     box3d = Box(xyz.tolist(), wlh.tolist(), Quaternion([np.cos(yaw / 2.), 0., 0., np.sin(yaw / 2.)]))
        #     box3d.translate(-tran)
        #     box3d.rotate(Quaternion._from_matrix(rot, rtol=1e-03, atol=1e-05).inverse)
        #     uvz = np.dot(intrinsic, box3d.center)
        #     uv = uvz[:2] / uvz[2]
        #     if (box3d.center[2] > 0) and (uv[0] >= -30) and (uv[0] < img.shape[1]+30) and (uv[1] >= 0) and (uv[1] < img.shape[0]):
        #         box3d.render_cv2(img, intrinsic, normalize=True)

        for j in range(label.size(0)):
            box3d_truth = label[j]
            if box3d_truth.sum() == 0:
                break
            quat, xyz, wlh = box3d_truth[1:5], box3d_truth[5:8], box3d_truth[8:11]
            box3d = Box(xyz.tolist(), wlh.tolist(), Quaternion(quat.tolist()))
            box3d.rotate(Quaternion._from_matrix(bev_rot, rtol=1e-03, atol=1e-05).inverse)
            box3d.translate(-tran)
            box3d.rotate(Quaternion._from_matrix(rot, rtol=1e-03, atol=1e-05).inverse)
            uv = project_points_to_img(box3d.center[:, np.newaxis], intrinsic, img_post_rot, img_post_trans)[:, 0]
            if (box3d.center[2] > 0) and (uv[0] >= -30) and (uv[0] < img.shape[1]+30) and (uv[1] >= 0) and (uv[1] < img.shape[0]):
                draw_box3d_on_img(img, box3d, intrinsic, img_post_rot, img_post_trans, linewidth=1)
                text_pos = box3d.center.reshape(3, -1)
                text_pos = project_points_to_img(text_pos, intrinsic, img_post_rot, img_post_trans).astype(np.int32)[:, 0]
                cv2.putText(img, data_dict['box_description'][0][j][0], (text_pos[0], text_pos[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)

        img_list.append(img)
    imgs = merge_six_images(img_list)

    # show in BEV view
    bev_img = pointcloud_to_bevimg(data_dict['pointcloud'].squeeze(), xbound, ybound, zbound)
    imgs = cv2.resize(imgs, [int(imgs.shape[1] / imgs.shape[0] * bev_img.shape[0]),
                             bev_img.shape[0]])
    show_img = [imgs]

    if 'pred_heatmap' in data_dict:
        pred_heatmap = data_dict['pred_heatmap'].max(1, keepdims=True)[0].transpose(1, 2, 0)
        pred_heatmap = (pred_heatmap * 255).astype(np.uint8)
        pred_heatmap = cv2.resize(cv2.applyColorMap(pred_heatmap, cv2.COLORMAP_JET), [bev_img.shape[1], bev_img.shape[0]])
        bev_img = cv2.addWeighted(bev_img, 0.2, pred_heatmap, 1.0, 0.0)

    for j in range(box3d_preds.size(0)):
        box3d_pred = box3d_preds[j]
        cls_ = int(box3d_pred[0].long().numpy())
        xyz, wlh, yaw = box3d_pred[1:4], box3d_pred[[5, 4, 6]], box3d_pred[-1]
        box3d = Box(xyz.tolist(), wlh.tolist(), Quaternion([np.cos(yaw / 2.), 0., 0., np.sin(yaw / 2.)]))
        corners = box3d.bottom_corners()
        bev_img = draw_box_in_bev(corners, bev_img, xbound, ybound, color=color_list[cls_], thickness=2)

    for j in range(label.size(0)):
        box3d_truth = label[j]
        if box3d_truth.sum() == 0:
            break
        quat, xyz, wlh = box3d_truth[1:5], box3d_truth[5:8], box3d_truth[8:11]
        box3d = Box(xyz.tolist(), wlh.tolist(), Quaternion(quat.tolist()))
        corners = box3d.bottom_corners()
        bev_img = draw_box_in_bev(corners, bev_img, xbound, ybound, color=(0,255,0))
    bev_img = np.flip(bev_img, (0, 1))
    show_img.append(bev_img)

    if 'gt_heatmap' in data_dict:
        gt_heatmap = data_dict['gt_heatmap'].max(1, keepdims=True)[0].transpose(1, 2, 0)
        gt_heatmap = (gt_heatmap * 255).astype(np.uint8)
        gt_heatmap = cv2.resize(cv2.applyColorMap(gt_heatmap, cv2.COLORMAP_JET), [bev_img.shape[1], bev_img.shape[0]])
        gt_heatmap = np.flip(gt_heatmap, (0, 1))
        show_img.append(gt_heatmap)

    if 'seg_feature_map' in data_dict:
        segmentation_gt = data_dict['seg_feature_map'][0].transpose(1, 2, 0)
        segmentation_gt = (segmentation_gt * 255).astype(np.uint8)
        segmentation_gt = cv2.resize(cv2.applyColorMap(segmentation_gt, cv2.COLORMAP_JET), [bev_img.shape[1], bev_img.shape[0]])
        segmentation_gt = np.flip(segmentation_gt, (0, 1))
        show_img.append(segmentation_gt)

    if 'bev_image' in data_dict:
        bev_image = data_dict['bev_image']
        bev_image = (bev_image * 255).astype(np.uint8)
        bev_image = cv2.resize(bev_image, [bev_img.shape[1], bev_img.shape[0]])
        bev_image = np.flip(bev_image, (0, 1))
        show_img.append(bev_image)

    show_img = np.hstack(show_img)
    # cv2.imwrite('show_results/result_%06d.jpg'%i, show_img)
    # cv2.imshow("show_img", show_img)
    # cv2.waitKey(0)
    return show_img